var express = require('express');
var router = express.Router();
logger = require("../utils/jslogger.js");
//in memory counter
badgeCounter = {}
badgeCounterAppInFront = {} //app默认都在前台 [token:true/false]


/* GET users listing. */
router.get('/', function(req, res, next) {
  res.send('respond with a resource');
});

/* GET upload user token. */
router.get('/uploadToken', function(req, res, next) {
  uploadToken(req, res, next, false)

});

/* POST upload user token. */
router.post('/uploadToken', function(req, res, next) {
  uploadToken(req, res, next, true)
});

function uploadToken(req, res, next, isPost){
  if(isPost){
    var token = req.body.token
    var userId = req.body.user_id
  } else {
    var token = req.query.token
    var userId = req.query.user_id
  }
  if(userId && token){
    cache.set(userId, token, function(err){
      if (err) {
        //throw error;
        res.json({msg:"failed set token!", response_code:1})
      } else {
        logger.info("set token " + token + " for " + userId + " success!")
        res.json({msg:"set token success!", response_code:0})
      }
    })
  } else {
    res.json({msg:"failed set token, user_id and token must be provided!", response_code:2})
  }
}

/* GET push notification. */
router.get('/pushNotification', function(req, res, next) {
  pushNotification(req, res, next, false)
});

/* POST push notification. */
router.post('/pushNotification', function(req, res, next) {
  pushNotification(req, res, next, true)
});

function pushNotification(req, res, next, isPost){
  if(isPost){
    var msg = JSON.parse(req.body.msg)
    var userId = req.body.user_id
    logger.info(req.body)
    logger.info("alert is " + msg.alert)
  } else {
    var msg = req.query.msg
    var userId = req.query.user_id
  }
  //logger.info("userId: " + userId)
  if(userId && msg){
    try {
      var userIdJson = JSON.parse(userId)
    } catch (e) {}
    if(userIdJson){
        for(var i = 0; i<userIdJson.length; i++){
          sendToOnePerson(res, userIdJson[i], msg, true)
        }
        res.json({msg:"push messages complete!", response_code:0})
    } else {
      sendToOnePerson(res, userId, msg, false)
    }
  } else {
    res.json({msg:"failed to push notification, user_id and msg must be provided!", response_code:3})
  }
}

/**
 * 如果是给数组发送消息，不返回单条发送结果
 * @param res
 * @param userId
 * @param msg
 * @param isForArray
 */
function sendToOnePerson(res, userId, msg, isForArray){
  cache.get(userId, function (error, value) {
    if (error) {
      logger.info("error->token not found for user: " + userId)
      if(!isForArray) {
        res.json({msg:"failed to push message for " + userId, response_code:4})
      }
    }
    if(value){
      var token = value
      try {
        sendNotification(token, msg)
        if(!isForArray) {
          res.json({msg:"push msg success!", response_code:0})
        }
      } catch (e){
        if(!isForArray) {
          res.json({msg:"推送失败, " + e.toString(), response_code:5})
        }
      }
    } else {
      logger.info("token not found for user: " + userId)
      if(!isForArray) {
        res.json({msg:"failed to push message for " + userId, response_code:4})
      }
    }
  });
}


//apns start here

//<3ad86904 993e15aa a33d95fa 0e513a72 4966bc1f 0f34024b c2c1efcd 0cb2d90a>
//notification.device = new apns.Device("3ad86904993e15aaa33d95fa0e513a724966bc1f0f34024bc2c1efcd0cb2d90a");

function sendNotification(token, msg){
  logger.info("token: " + token + ", msg: " + JSON.stringify(msg))

  if(badgeCounter[token] == undefined){
    badgeCounter[token] = 1
  } else {
    if(!badgeCounterAppInFront[token]) {
      badgeCounter[token] = badgeCounter[token] + 1
    }
  }

  var msgJson = msg
  var myDevice = new apn.Device(token);
  var note = new apn.Notification();
  note.expiry = Math.floor(Date.now() / 1000) + 3600; // Expires 1 hour from now.
  note.badge = badgeCounter[token];
  note.sound = "ping.aiff";
  note.alert = msgJson.alert; //"\uD83D\uDCE7 \u2709 " +

  if(msgJson.payload){
    note.payload = msgJson.payload;
  }
  apnConnection.pushNotification(note, myDevice);
  if(msgJson.payload){
    delete msgJson.payload["aps"]
  }

  //logger.info("After sending..." + msgJson.alert)
}

/* GET push notification. */
router.get('/changeAppRunningStatus', function(req, res, next) {
  changeAppRunningStatus(req, res, next, false)
});

/* POST push notification. */
router.post('/changeAppRunningStatus', function(req, res, next) {
  changeAppRunningStatus(req, res, next, true)
});


function changeAppRunningStatus(req, res, next, isPost){
  if(isPost){
    var userId = req.body.user_id
    var isActive = req.body.is_active == true
  } else {
    var userId = req.query.user_id
    var isActive = req.query.is_active == false
  }
  logger.info("change userId: " + userId + "' status to " + isActive)

  cache.get(userId, function (error, value) {
    if (error) {
      logger.info("error->token not found for user: " + userId)
      res.json({msg: "failed to push message for " + userId, response_code: 4})
    }
    if (value) {
      var token = value
      badgeCounterAppInFront[token] = isActive
      if(badgeCounterAppInFront[token]){
        badgeCounter[token] = 0
      }
      if(badgeCounter[token] != undefined) {
        logger.info("change userId: " + userId + "' badgeCounter " + badgeCounter[token])
      }
      res.json({msg:"change user running status complete, current badgeCounter is " + (badgeCounter[token] ? badgeCounter[token] : 0), response_code:0})
    } else {
      logger.info("token not found for user: " + userId)
      res.json({msg: "failed to push message for " + userId, response_code: 4})
    }
  })
}

module.exports = router;
