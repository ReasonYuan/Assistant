/**
 * Created by johnny_peng on 15-6-2.
 */

var sha1 = require('sha1');

function createSession(deviceID, pw){
    var token = sha1(deviceID + pw);
    sessions[deviceID] = token;
    return token;
}

function isValidSession(req){
    var deviceID = req.param('devID');
    var token = req.param('accessToken');
    if(!token){
        token = req.header("accessToken");
    }
    if(!deviceID){
        deviceID = req.header("devID");
    }
    logger.info('accessToken = ' + token + ", deviceID = " + deviceID + ", s = " + sessions[deviceID]);
    //仅为测试方便, 正式发布时需要反注释
    //if ( app.get('env') == 'development' ) {
        if(token == '0987'){
            return true;
        }
    //}
    return sessions[deviceID] == token && token != null && token != '';
}

function simpleAuth(req, res, next){
    logger.info("access: " + req.path);
    if(!(req.path.indexOf("/users/login") >= 0)){
        if(!isValidSession(req)){
            var msg = '非法访问，请登录先!';
            res.json({resCode:FAILED_NO_VALID_SESSION, msg: msg});
            logger.error('simpleAuth:' + msg);
            return;
        }
    }
    next();
}

exports.simleAuth = simpleAuth;
exports.createSession = createSession;
exports.isValidSession = isValidSession;