/**
 * Created by johnny_peng on 15-5-20.
 */

//logger
var log4js = require('log4js');
//console log is loaded by default, so you won't normally need to do this
//log4js.loadAppender('console');
log4js.loadAppender('file');
var logDirectory = __dirname + '/../logs';
log4js.configure({
    appenders: [
        { type: 'console' },
        {
            "type": "dateFile",
            "filename": logDirectory + "/practice.log",
            "pattern": "-yyyy-MM-dd",
            "alwaysIncludePattern": false,
            category: 'practice'
        }
    ],
    replaceConsole: true
});
var fs = require('fs');
// ensure log directory exists
fs.existsSync(logDirectory) || fs.mkdirSync(logDirectory)
var logger = log4js.getLogger('traffic');
logger.setLevel('DEBUG');

//logger.trace('Entering cheese testing');
//logger.debug('Got cheese.');
//logger.info('Cheese is Gouda.');
//logger.warn('Cheese is quite smelly.');
//logger.error('Cheese is too ripe!');
//logger.fatal('Cheese was breeding ground for listeria.');

module.exports = logger;