var express = require('express');
var path = require('path');
var favicon = require('serve-favicon');
var logger = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');

var routes = require('./routes/index');
var users = require('./routes/users');
logger = require("./utils/jslogger.js");

process.env.NODE_ENV = 'production';

var app = express();

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');

// uncomment after placing your favicon in /public
//app.use(favicon(path.join(__dirname, 'public', 'favicon.ico')));
//app.use(logger('dev'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/', routes);
app.use('/users', users);


var CachemanFile = require('cacheman-file');
var Cacheman = require('cacheman');

var options = {
    ttl: 60*60*24*365*100,
    engine: 'file'
};
cache = new Cacheman('tokenCache', options);

//apns start here
apn = require('apn');

var options = {
    cert : "conf/practice_ios_inhouse_production_push_cert.pem", //"conf/apns_dev_cert.pem", //
    key: "conf/practice_ios_inhouse_production_push_key.pem", //"conf/apns_dev_key.pem",
    passphrase: "111111",
    fastMode: true
};
apnConnection = new apn.Connection(options);


apnConnection.on("error", function(error){
    logger.info("error: " + error)
});

apnConnection.on("socketError", function(error){
    logger.info("socket error: " + error)
});

apnConnection.on("transmitted", function (notification, device) { logger.info("transmitted: " + JSON.stringify(notification))});

apnConnection.on("completed", function(){ logger.info("the notification was sent!")   })

//apns end here

// catch 404 and forward to error handler
app.use(function(req, res, next) {
  var err = new Error('Not Found');
  err.status = 404;
  next(err);
});

// error handlers

// development error handler
// will print stacktrace
if (app.get('env') === 'development') {
  app.use(function(err, req, res, next) {
    res.status(err.status || 500);
    res.render('error', {
      message: err.message,
      error: err
    });
  });
}

// production error handler
// no stacktraces leaked to user
app.use(function(err, req, res, next) {
  res.status(err.status || 500);
  res.render('error', {
    message: err.message,
    error: {}
  });
});


module.exports = app;
