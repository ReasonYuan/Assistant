/**
 *
 * 医生详细信息页面的个人简介cell，包括头像、姓名等
 * @author reason 2015-12-08
 *
 */

'use strict';

var React = require('react-native');

var {
  StyleSheet,
  Text,
  View,
  Image,
  TouchableHighlight,
} = React;

var {BaseComponent} = require('../../utils/Styles');
var ImageView = require('../../widget/ImageView')
var Tools = require('../../utils/Tools')
var {Color,len} = require('../../utils/Styles')
var {w,h,f} = require('../../utils/Porting')

class DoctorHead extends React.Component{

	  constructor(props){
    	super(props)
	  }

  //聊天
  toChat(){
    var view = this.props.profile
    var message = {}
    message.talkers = [view.doctor]
    message.debugName = view.doctor.name
    message.relationship = {type:'FriendShip'}

    var CustomerChat = require("../chat/DoctorChatView");
    view.pushWidthComponent(<CustomerChat navigator={view.props.navigator} message={message}/>)
  }

  //得到医生头像
  getDoctorIcon(doctor){
    if(doctor.headIcon){
      return doctor.headIcon.objectKey
    }
    return null
  }

  showMsgIcon(){
    if(this.props.profile.props.showMsg){
      return (
        <TouchableHighlight
          underlayColor='transprent'
          onPress={()=>{this.toChat()}}
          style={istyles.msgContainer}>
          <Image style={istyles.msgIcon} source={require('../../res/icon_msg.png')}/>
        </TouchableHighlight>
      )
    }
  }

	render(){
    var doctor = this.props.profile.doctor
    var icon = this.getDoctorIcon(doctor)
    return(
      <View style={istyles.container}>
      <View  style={[istyles.infoContainer]}>
        <ImageView
          style={istyles.head}
          imageKey={icon}
          defaultSource={Tools.getHeadByUser(doctor)}/>

        <View style={istyles.infoView}>
          <View style={istyles.doctorInfoContainer}>
            <Text style={istyles.doctorInfoLabel}>{doctor.name}</Text>
            <Text style={istyles.doctorInfoLabel}>{doctor.department}</Text>
          </View>
          <Text style={istyles.hospital}>{doctor.hospital}</Text>
        </View>

        {
          this.showMsgIcon()
        }

  		</View>

      <Text style={istyles.shareLabel}>分享:</Text>
      </View>
    )
    // <Text style={istyles.desLabel}>简介:</Text>
    // <Text style={istyles.detailLabel} numberOfLines={3}>{doctor.introduction}</Text>
	}
}

var istyles = StyleSheet.create({
  container:{
    marginHorizontal:w(12),
    borderBottomWidth:1,
    borderColor:Color.itemDivider,
  },
  infoContainer:{
    height:h(55),
    paddingTop:h(15),
    flexDirection:'row',
  },
  infoView:{
    flex:1,
    marginLeft:w(10),
    justifyContent:'flex-end'
  },
  head:{
    width:w(40),
    height:w(40),
    borderRadius:len('headRadius')
  },
  doctorInfoContainer:{
    flexDirection:'row',
  },
  msgContainer:{
    width:w(40),
    height:w(28),
    alignItems:'flex-end',
    justifyContent:'center',
  },
  msgIcon:{
    padding:5,
    width:w(17),
    height:w(15),
    resizeMode:'cover',
    // infoView
    // marginRight:w(10),
  },
  doctorInfoLabel:{
    marginRight:w(10),
  },
  hospital:{
    fontSize:f(11),
    color:'#999',
    marginTop:h(3)
  },
  desLabel:{
    marginVertical:h(10),
    color:Color.title
  },
  detailLabel:{
    fontSize:12,
    color:'#666',
    marginBottom:h(30),
  },
  shareLabel:{
    marginVertical:h(10),
    // marginBottom:h(10),
    color:Color.title
  }
});

module.exports = DoctorHead;
