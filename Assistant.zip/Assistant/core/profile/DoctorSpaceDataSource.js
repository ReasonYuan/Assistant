/**
 *
 * 医生动态，对Restful接口数据的封装
 * @author johnny 2015-12-19
 *
 */

'use strict';

var Config = require("../../constant/Config")
var LocalCache = require("../sync/LocalCache")

var {Fetch} = require("../../JSLibrary/Logic");

class DoctorSpaceDataSource {

  pageSize = 10;
  callback = null;
  //第一页缓存
  isFirstLoad = true;

  //参数：医生的用户id
  constructor(userid, pageSize, callback){
    this.loading = false
    this.page = 1
    this.datas = {}
    this.dataList = []
    this.hasNextPage = true

    if(userid)this.userid=userid
    if(pageSize){
      this.pageSize = pageSize
    }
    if(callback){
      this.callback = callback
    }
  }

  convertID2DocumentID(data){
    if(data.shareMessages == this.datas[this.page])return

    data.userInfo.documentID = data.userInfo.id
    for(var i=0; i<data.shareMessages.length; i++){
      data.shareMessages[i].documentID = data.shareMessages[i].id
    }

    this.datas[this.page] = data.shareMessages
    this.dataList = []
    var keys = Object.keys(this.datas)
    for(var i = 0; i < keys.length; i++){
      var key = keys[i]
      this.dataList = this.dataList.concat(this.datas[key])
    }
    data.shareMessages = this.dataList
    return data
  }

  getNextPageData(){
    if(this.loading)return
    if(!this.hasNextPage)return

    var self = this
    // var localCacheKey = "d_space_local_cache_" + this.userid
    // var shouldCacheData = this.isFirstLoad
    // if(this.isFirstLoad){
    //   this.isFirstLoad = false
    //   //第一次要读取缓存
    //   LocalCache.get(localCacheKey, function(data){
    //     if(data && !data.error){
    //       if(self.callback) self.callback(data)
    //     }
    //   })
    // }


    // var webBaoshiServerURL = "http://115.29.229.128:5000/"
    var url = Config.webBaoshiServerURL + "sharemessage/get_user_shares" //Config.webBaoshiServerURL + "sharemessage/get_user_shares"
    var postData = {}
    postData.userId = this.userid
    postData.page = this.page
    postData.pageSize = this.pageSize
    this.loading = true
    Fetch.post("",postData,(data) => {
        if(data.error){
          if(this.callback) this.callback(data)
        } else {
          self.hasNextPage = (data.shareMessages.length == self.pageSize)
          if(this.callback) {
            this.callback(self.convertID2DocumentID(data))
          }
          this.page += 1
        }
        this.loading = false
      },url);
    // fetch(url, {
    //       method: "POST",
    //       headers: {'Content-Type': 'application/json'},
    //       body:JSON.stringify(postData)
    // })
    // .then((response) =>
    //   response.json()
    // )
    // .then((data) => {
    //     if(data.error){
    //       if(this.callback) this.callback(data)
    //     } else {
    //       self.hasNextPage = (data.shareMessages.length == self.pageSize)
    //       if(this.callback) {
    //         this.callback(self.convertID2DocumentID(data))
    //         // if(shouldCacheData){
    //         //   LocalCache.save(localCacheKey, data)
    //         // }
    //       }
    //       this.page += 1
    //     }
    //     this.loading = false
    //   }
    // ).catch(function(error) {
    //   if(error){
    //     var err = error
    //     console.log(err);
    //   }
    // })
  }

}

module.exports = DoctorSpaceDataSource
