
// var Database = require("./Database");
// var DatabaseManager = require("./DatabaseManager");
// var DatabaseFilter = require("./DatabaseFilter");
// var DatabaseView = require("./DatabaseView");
// var DBModel = require("./DBModel");
// var DBReplication = require("./DBReplication");
//
// var Couchbase = {
//   "Database":Database,
//   "DatabaseManager":DatabaseManager,
//   "DatabaseFilter":DatabaseFilter,
//   "DatabaseView":DatabaseView,
//   "DBModel":DBModel,
//   "DBReplication":DBReplication
// }

var {Couchbase} = require('../../JSLibrary/Logic');

module.exports = Couchbase;
