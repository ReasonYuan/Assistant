// 'use strict';
//
// var Config = require('../../constant/Config');
// class LocalCache {
//   static getLocalDocument(url,cb){
//     fetch(url, {
//       method: "GET",
//       headers: {
//         'Accept': 'application/json',
//         'Content-Type': 'application/json'
//       },
//     }).then((response) => response.json())
//     .then((data) => {
//       if(data && cb){
//         var rev = data._rev;
//         delete data._rev;
//         delete data._id;
//         cb(data,rev);
//       }else{
//         cb({});
//       }
//     }).catch((e)=>{
//       console.log("-->","getLocalDocument save errer:",e);
//     })
//   }
//
//   //缓存数据到本地
//   static save(key:String,value:Object){
//     var {DatabaseManager,DatabaseView} = require('../couchbase/Couchbase');
//     var dbName = DatabaseManager.instance.currentDatabase.dbName;
//     var url = Config.localURL+dbName+"/_local/"+key;
//     LocalCache.getLocalDocument(url,(old,rev)=>{
//       if(rev) url+="?rev="+rev;
//       fetch(url, {
//         method: "PUT",
//         headers: {
//           'Accept': 'application/json',
//           'Content-Type': 'application/json'
//         },
//         body: JSON.stringify(value)
//       }).then((response) => response.json())
//       .then((data) => {
//         console.log(data);
//       }).catch((e)=>{
//         console.log("-->","LocalCache save errer:",e);
//       })
//     });
//
//   }
//   //获取本地数据
//   static get(key:String,cb:Function){
//     var {DatabaseManager,DatabaseView} = require('../couchbase/Couchbase');
//     var dbName = DatabaseManager.instance.currentDatabase.dbName;
//     var url = Config.localURL+dbName+"/_local/"+key;
//     LocalCache.getLocalDocument(url,cb);
//   }
// }

var {LocalCache} = require('../../JSLibrary/Logic');
module.exports = LocalCache;
