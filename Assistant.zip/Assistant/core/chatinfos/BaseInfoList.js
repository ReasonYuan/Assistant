/**
 *
 * 聊天时发送其他附件消息的父类。
 * 因为用户与客户或医生的聊天界面及功能上都差不多。
 * @author reason 2015-12-08
 *
 */

'use strict';

var React = require('react-native');

var {
  StyleSheet,
  Text,
  Image,
  View,
  ListView,
  TouchableHighlight,
  Navigator
} = React;

var BaseComponent = require('../BaseComponent')
var { Message } = require('../Models');
var Constant = require('../../constant/Constant')
var {Color,fs} = require('../../utils/Styles')
var {w,h,f,screenWidth} = require('../../utils/Porting')
var FQListView = require('../../widget/FQListView')
var ImageView = require('../../widget/ImageView')

var WebResLoader = require('../webres/WebResLoader')

class BaseInfoList extends BaseComponent{

  constructor(props) {
    super(props);
    this.datas = [];

    this.state = {
      navigatorBarConfig:{title:this.getTitle(),leftButtonTitle:"取消"},
      dataSource:new ListView.DataSource({rowHasChanged: (r1, r2) => r1 !== r2})}
  }

  getTitle(){
    return ""
  }

  onLeftPress(){
    this.props.chatView.pop();
  }

  onDataChange(data,page){
    if(data == this.datas[page])return

    this.datas[page] = data

    var ary = []
    var keys = Object.keys(this.datas)
    for(var i = 0; i < keys.length; i++){
      var key = keys[i]
      ary = ary.concat(this.datas[key])
    }

    this.setState({dataSource:this.state.dataSource.cloneWithRows(ary),renderPlaceholderOnly: true})
  }

  getType(){}

 //点击一个信息子项，打开网页阅读
  onItemClicked(data){
    this.sendMessage(data)
  }

  sendMessage(data){
    var msg = new Message()
    msg.message = data
    msg.messageType = this.msgType
    this.props.chatView.sendInfoMessage(msg)
    this.props.chatView.pop()
  }

  scroll(e){ }


  renderIcon(url){
    if(url){
      return <Image style={istyles.icon} source={{uri: url}}/>
    }else{
      return <Image style={istyles.icon} source={require('../../res/icon_def.png')}/>
    }
  }

  //渲染cell
  renderRow(data){
    var res = data.value || data
    var url = (!res.icon || res.icon=="")?null:res.icon
    return(
      <TouchableHighlight
        underlayColor={Color.itemClick}
        onPress={()=>{this.onItemClicked(res)}}>

        <View style={istyles.contentContainer}>

          {this.renderIcon(url)}

          <Text numberOfLines={5} style={istyles.infoLabel}>
              {res.title}
          </Text>
        </View>
      </TouchableHighlight>
    )
  }

  _render(){
    return (
      <FQListView
          dataSource={this.state.dataSource}
          renderRow={this.renderRow.bind(this)}
          onScroll={(e)=>{this.scroll(e)}}
      />
    )
  }
}

var istyles = StyleSheet.create({
  contentContainer:{
    marginHorizontal:w(12),
    paddingVertical:w(12),
    alignItems:'center',
    flexDirection:'row',
    borderBottomWidth:w(0.5),
    borderColor:'#f2f2f2'
  },
  icon:{
    width:w(60),
    height:w(60),
    // backgroundColor:"#ddd"
  },
  infoLabel:{
    flex:1,
    marginLeft:w(10),
    fontSize:fs('22'),
    color:'#666',
    alignSelf:'flex-start',
  }
});

module.exports = BaseInfoList;
