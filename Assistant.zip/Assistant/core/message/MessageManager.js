/**
 *
 * 监听全局消息变化
 * @author johnny 2015-12-14
 *
 */

'use strict';

var Models = require("../Models")
var {User,Profile,Group,Patient,FriendShip,Message,Service,ChatFriendShip} = Models;
var {DatabaseView,DatabaseManager} = require("../couchbase/Couchbase");
var Config = require("../../constant/Config")
var UserCacheManager = require("../users/UserCacheManager")
var {AsyncStorage} = require("react-native")
var LocalCache = require('../sync/LocalCache')

var {Fetch} = require('../../JSLibrary/Logic')

/*
 * 总共有三种方式收到数据：
 * 1. 启动时时查询历史每个channel的最近一次消息
 * 2. 启动时查询最近50条记录，然后停止查询监听（对一切换账号时有用）
 * 3. 一直监听database的即时文档更新
 */
class MessageManager {

  latestMsgListView:DatabaseView;
  //lastMessageKey:String
  latestMessageCache = {};
  //只监听3个列表的消息变化，每个列表只有一个
  onMessageRecievedCallbacks = {};

  profile:Profile;

  unreadMsgFlagCache = {};

  MSG_G_VIEW_NAME = "Global_Message_Watcher";

  LATEST_MSG_LIST_READS = "LATEST_MSG_LIST_READS";

  //unread storage key prefix
  unreadPrefix;

  //当前正在聊天的channel
  currentChattingChannel = null;

  firstLoadingCallback = null;

  //for loading
  unreadStatusLoaded = false;

  //for loading
  latestMsgLoaded = false;

  //即时消息监听者key
  messageObserverKey;

  //latestChannelMsgDates
  latestChannelMsgDates = {};

  startWatchingMessage(firstLoadingCallback){
    var currentUserId = User.currentUser.documentID
    this.unreadPrefix = "_" + currentUserId + "_"
    this.firstLoadingCallback = firstLoadingCallback

    var self = this
    //装载本地最后接收消息记录
    LocalCache.get(this.LATEST_MSG_LIST_READS, function(data){
      if(data && !data.error){
        var keys = Object.keys(data)
        if(keys){
          for(var i=0; i<keys.length; i++){
            self.latestChannelMsgDates[keys[i]] = data[keys[i]]
          }
        }
        self.searchAllHistoryMessages(self.latestChannelMsgDates)
      }
    })

    //装载红点数据, 每一个channel的未读状态
    var thisUserKeys = []
    AsyncStorage.getAllKeys(function(error, keys){
      if(error){
        console.log("error: " + error);
      } else {
        var currentUserId = User.currentUser.documentID
        for(var i = 0; i<keys.length; i++){
          //key为"_"+userid + "_" + channel
          var key = keys[i]
          if(key && key.startsWith(self.unreadPrefix)){
            thisUserKeys.push(key)
          }
        }
      }
      AsyncStorage.multiGet(thisUserKeys, function(errors, result){
        for(var i=0; i<result.length; i++){
          if(!errors || !errors[i]){
            var value = result[i][1]
            var key = result[i][0]
            self.unreadMsgFlagCache[key] = value
            //console.log("key: " + key + ", value: " + value);
          } else {
            //console.log(i + " error: " + errors[i]);
          }
        }
        //TODO loading proccess
        self.unreadStatusLoaded = true
        self.checkLoadingStatus()
      })
    })

    //var self = this
    this.initialize()
    // User.currentUser.getProfile(function(profile){
    //   self.profile = profile
    //   self.initialize()
    // });

  }

  saveLatestRecievedDate(channel, date){
    this.latestChannelMsgDates[channel] = date
    //装载本地最后接收记录
    LocalCache.save(this.LATEST_MSG_LIST_READS, this.latestChannelMsgDates)
  }

  logout(){
    DatabaseManager.instance.currentDatabase.unregisterIntantObserver(this.messageObserverKey)
  }

  checkLoadingStatus(){
    if(this.unreadStatusLoaded && this.latestMsgLoaded){
      if(this.firstLoadingCallback) this.firstLoadingCallback()
    }
  }

  setOnMessageRecievedCallback(type, callback){
    this.onMessageRecievedCallbacks[type] = callback
  }

  updateLatestMessageList(channel, message){
    if(!this.latestMessageCache[channel]){
      var msgInfo = {}
      msgInfo.documentID = message.documentID
      msgInfo.message = message.message
      msgInfo.date = message.date ? message.date.getTime() : ""
      msgInfo.messageType = message.messageType
      msgInfo.channel = channel
      this.latestMessageCache[channel] = msgInfo
      this.saveLatestRecievedDate(channel, "" + msgInfo.date)
    }
  }

  initialize(){
    var self = this
    var db = DatabaseManager.instance.currentDatabase
    var latestMsgListView =  new DatabaseView(db, "Message", this.MSG_G_VIEW_NAME, "function(doc) { if(doc.type == 'Message') { emit(doc.date,doc);} }", ()=>{
      latestMsgListView.setOnDataChangeCallback((data)=>{
        var rows = []
        for(var i=0; i<data.length; i++){
          rows.push(data[i].value)
        }
        self.latestMsgListChanged(rows, false)
        self.latestMsgListView.stop()
      });
    });
    latestMsgListView.beforeUpdate = ()=>{
      latestMsgListView.limit = 50;
      latestMsgListView.descending = true;
    }

    this.latestMsgListView = latestMsgListView

    this.messageObserverKey = DatabaseManager.instance.currentDatabase.registerIntantObserver(["Message"], function(data){
      //console.log(data);
      self.latestMsgListChanged(data)
    })

    this.latestMsgLoaded = true
    this.checkLoadingStatus()
  }


  // logout(){
  //     if(this.latestMsgListView) this.latestMsgListView.stop()
  // }

  //消息列表最近一条消息
  searchAllHistoryMessages(datesMap){
    var dates = new Array();
    for (var item in datesMap) {
      dates.push(datesMap[item])
    }

    var self = this
    var db = DatabaseManager.instance.currentDatabase
    var userViewName = this.MSG_G_VIEW_NAME
    var body = {keys: dates}
    var url = Config.localURL+db.dbName+"/_design/"+userViewName+"/_view/"+userViewName

    fetch(url, {
        method: "POST",
        headers: {
          'Content-Type': "application/json"
        },
        body:JSON.stringify(body)
    })
    .then((response) => response.json())
    .then((data)=>{
      console.log(data)
      if(!data.error){
        var rows = []
        for(var i=0; i<data.rows.length; i++){
          rows.push(data.rows[i].value)
        }
        self.latestMsgListChanged(rows, true)
      }
    })

  }

  latestMsgListChanged(data, fromProfile){
    if(data.length > 0){
      var notifyListTypes = []
      for(var i=0; i < data.length; i++){
        if(data[i].channel || data[i].group){
          var msgData = data[i]
          var channel = msgData.channel || msgData.group
          if(!fromProfile){
            if((msgData.date && this.latestMessageCache[channel])){
              if(msgData.date < this.latestMessageCache[channel].date){
                continue
              }
            }
          }

          var msgInfo = {}
          msgInfo.documentID = msgData._id
          msgInfo.message = msgData.message ? msgData.message : ""
          msgInfo.date = msgData.date ? msgData.date : ""
          msgInfo.messageType = msgData.messageType
          msgInfo.channel = channel

          this.latestMessageCache[msgInfo.channel] = msgInfo

          //if(!this.profile.setting[channel] || this.profile.setting[channel] < msgInfo.date){
          if(!this.latestChannelMsgDates[channel] || this.latestChannelMsgDates[channel] < "" + msgInfo.date){

            //TODO 应该需要优化，否则每收到一条新消息都要save一下profile
            //改用storage
            //this.latestChannelMsgDates[channel] = "" + msgInfo.date
            this.saveLatestRecievedDate(channel, "" + msgInfo.date)

            //是否是用户发送的消息
            var isOthersMsg = msgData.from != User.currentUser.documentID
            if(isOthersMsg){
              //如果不是用户发送的消息才能标记为unread
              if(channel != this.currentChattingChannel){
                //可标记为红色
                this.setMsgChannelUnreadStatus(channel, true)
              }
            }

            //判断应该通知哪一个列表
            var listType = undefined
            //下面避免循环引用，直接写数字了
            if(msgData.group != null){
              listType = 1; //LatestMsgListDataSource.TYPE_CUSTOMER_MSG_LIST
            } else {
              var fromWho = UserCacheManager.instance.getUserInfo(msgData.from)
              var toWho = UserCacheManager.instance.getUserInfo(msgData.to)
              if(fromWho.documentID && toWho.documentID){
                var typeSum = fromWho.role_type + toWho.role_type
                switch (typeSum) {
                  case 3: //必定和客户聊天
                    listType = 1 //TYPE_CUSTOMER_MSG_LIST
                    break;
                  case 2: //必定和医生聊天
                    listType = 2 //TYPE_DOCTOR_MSG_LIST
                    break;
                  case 4: //必定和医生的助理聊天
                    listType = 3 //TYPE_DOCTORS_ASSISTANT_MSG_LIST
                    break;
                }
              }
            }
            if(listType){
              msgInfo.isNewMsg = true
              var exists = false
              for(var i=0; i<notifyListTypes.length; i++){
                if(notifyListTypes[i] == listType){
                  exists = true
                  break
                }
              }
              if(!exists){
                notifyListTypes.push(listType)
              }
            }
          }
        }
      }
      for(var i=0; i<notifyListTypes.length; i++){
        var listType = notifyListTypes[i]
        if(this.onMessageRecievedCallbacks[listType]){
          this.onMessageRecievedCallbacks[listType]()
        }
      }

      // if(!fromProfile){
      //   //this.lastMessageKey = data[0].key
      //   //console.log("update last message key!!!");
      // }
    }
  }

  //set to null to disable
  setCurrentChattingChannel(channel){
    this.currentChattingChannel = channel
  }

  //channel, readed: true means unread, false means readed
  setMsgChannelUnreadStatus(channel, readed){
    if(channel){
      var readedFlag = readed ? "true" : "false"
      var cacheKey = this.unreadPrefix + channel
      AsyncStorage.setItem(cacheKey, readedFlag)
      this.unreadMsgFlagCache[cacheKey] = readedFlag
      if(!readed && this.latestMessageCache[channel]){
         this.latestMessageCache[channel].unread = false
      }
    }
  }

  //返回该聊天channel的最近聊天信息
  getLatestChatInfo(channel){
    var msgInfo = this.latestMessageCache[channel]
    if(!msgInfo){
      msgInfo = {message:""}
    }
    var cacheKey = this.unreadPrefix + channel
    msgInfo.unread = this.unreadMsgFlagCache[cacheKey] == "true"
    return msgInfo
  }

}

var instance = new MessageManager();
MessageManager.instance = instance;

module.exports = MessageManager;
