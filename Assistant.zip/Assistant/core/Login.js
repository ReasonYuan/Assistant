/**
 *
 * 登录界面
 * @author reason 2015-12-07
 *
 */

'use strict';
var React = require('react-native');
var Config = require('../constant/Config.js');
var Tools = require('../utils/Tools.js');
var {w,h} = require('../utils/Porting');
var {fs} = require('../utils/Styles');
var {DatabaseManager} = require("./couchbase/Couchbase");
var {MessageDialog} = require('../widget/Dialog');
var { WebLink } = require("./Models");
var {Platform} = React;

var {
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableHighlight,
  AsyncStorage,
  Image,
  Alert
} = React;


var Button = require('../widget/Button');
var BaseComponent = require('./BaseComponent');

var Dimensions = require('Dimensions');
let screenWidth = Dimensions.get('window').width

var {LoginLogic} = require('../JSLibrary/Logic');
let loginLogic = new LoginLogic();

class Login extends BaseComponent {

  constructor(props){
    super(props)
    this.insertInited = false

    this.state = {phone_number:"",password:""}

    loginLogic.init({deleget:this});
    loginLogic.loadUser();
  }

  componentWillReceiveProps(nextProps){
    // this.setState({phone_number:this.state.phone_number,password:""})
  }

  setAccountState(phoneNumber,password){
    this.setState({phone_number:phoneNumber,password:password})
  }

  loginSuccess(p){
    this.checkInitData();
  }

  //登录按钮被点击，执行登录操作
  login(){
    if(this.checkStringIsNull(this.state.phone_number,"手机号不能为空"))return;
    if(this.checkStringIsNull(this.state.password,"密码不能为空"))return;
    loginLogic.login(this.state.phone_number,this.state.password,this.loginSuccess);
  }

  //做必要的初始化和检查
  checkInitData(){
    var Bootstrap = require('./Bootstrap')
    Bootstrap.loadedTypes = []
    Bootstrap.onBoot(function(loadedType){
      Bootstrap.loadedTypes.push(loadedType)
      var msgLoaded = false
      var userLoaded = false
      var currentUserFound = false

      for(var i=0; i<Bootstrap.loadedTypes.length; i++){
        if(Bootstrap.loadedTypes[i] == "msgLoaded") msgLoaded = true
        if(Bootstrap.loadedTypes[i] == "userLoaded") userLoaded = true
        if(Bootstrap.loadedTypes[i] == "currentUserFound") currentUserFound = true
      }

    });
    var Home = require("./Home");
    this.push(Home);
  }

  showloading(dismiss){
    // this.setState({showDialog:dimiss()})
    if(dismiss){
      this.showLoadingDialog(true,"登录中...");
      // NativeDialogManager.showLabelPBDialog("登录中...");
    }else{
      this.showLoadingDialog(false);
      // NativeDialogManager.dismissPBDialog();
    }
  }

  _render() {
    return (
      <View style={istyles.full}>
        <Image style={istyles.bgImage} source={require('../res/login_bg.png')}>

          <Text style={istyles.server}>{loginLogic.serverName}</Text>

          <Image
            resizeMode={'stretch'}
            style={istyles.logo}
            source={require('../res/login_logo.png')}/>

          <TextInput
            placeholderTextColor="#fff"
            style={[istyles.input]}
            textAlign={'center'}
            placeholder={"请输入用户名"}
            keyboardType={"numeric"}
            value={this.state.phone_number}
            onChangeText={(text) => this.setState({phone_number: text})}
          />

          <TextInput
            placeholderTextColor="#fff"
            style={[istyles.input]}
            textAlign={'center'}
            placeholder={"请输入密码"}
            secureTextEntry={true}
            value={this.state.password}
            onChangeText={(text) => this.setState({password: text})}
          />

          <Button
          fontSize={fs(Tools.fixWidth(12))}
            style={istyles.button}
            onTouch={()=>{ this.login()}}
            titleColor={'#61c1b5'}
            title={"登 录"}/>
          <MessageDialog message={"登录中..."} show={this.state.showDialog || false} />
        </Image>
        </View>
    );
  }
}

var istyles = StyleSheet.create({
  full:{
    flex:1,
  },
  server:{
    position:'absolute',
    left:5,
    top:22,
  },
  bgImage:{
    flex:1,
    width:Tools.screenWidth(),
    alignItems: 'center',
    backgroundColor:'transparent'
  },
  logo:{
    width:screenWidth - w(66),
    height:h(97),
    marginTop:h(80),
    marginBottom:h(127)
  },
  version:{
    color:'#fff',
    marginTop:h(16),
    marginBottom:h(80)
  },
  button:{
    justifyContent: 'center',
    width:screenWidth - w(66),
    height: h(34),
    backgroundColor: '#FFFFFF',
    alignItems: 'center',
    borderRadius: h(16),
    borderWidth:w(1),
    borderColor:'#bebebe',
    marginTop:h(30)
  },
  input:{
    height: h(35),
    marginTop: h(2),
    color:'#fff',
    fontSize:w(11),
    backgroundColor:'rgba(255, 255, 255, 0.2)',
  }
});

module.exports = Login;
