/**
 *
 * 首页table,管理客户消息列表和医生消息列表两个界面
 * @author reason 2015-12-07
 *
 */

'use strict';

var React = require('react-native');
var {
  StyleSheet,
  Text,
  View,
  Image,
  TouchableHighlight
} = React;

var MessageCount = require('./message/MessageCount')
var CustomerMsgList = require('./message/CustomerMsgList')
var MyDoctorMsgList = require('./message/MyDoctorMsgList')
// var DoctorList = require('./contacts/DoctorList')
var OtherDoctorMsgList = require('./message/OtherDoctorMsgList')

var{w,h,screenWidth} = require('../utils/Porting')
let mWidth = screenWidth()
class TabbarItem extends React.Component {
  constructor(props) {
    super(props);
    this.state={selected:this.props.selected || false,showRedIcon:this.props.showRedIcon};//this.props.showRedIcon
  }
  componentWillReceiveProps(nextProps){
    if(this.props.selected != nextProps.selected){
        this.setState({selected:nextProps.selected,showRedIcon:nextProps.showRedIcon});
    }else{
      this.setState({showRedIcon:nextProps.showRedIcon});
    }
  }
  onTableSelect(){
    this.setState({selected:true});
    if(this.props.onPress)this.props.onPress(this.props.index);
  }
  render(){
    var tintColor = {};
    if(this.state.selected && this.props.tintColor){
      tintColor.tintColor = this.props.tintColor;
    }
    return (
      <TouchableHighlight style={styles.tabbar_item} underlayColor="transparent" onPress={this.onTableSelect.bind(this)}>
        <View >
          <Image style={[styles.tabbar_item_icon,tintColor]} source={this.state.selected?(this.props.selectedIcon ? this.props.selectedIcon : this.props.icon):this.props.icon}>
          </Image>
          {
            (()=>{
              if(this.state.showRedIcon){
                return <View style={styles.point}/>
              }
            })()
          }
        </View>
      </TouchableHighlight>
    )

  }
}

class Home extends React.Component {
  constructor(props) {
    super(props);
    this.state = {index:0,currentIndex:0}
    MessageCount.changeListener = (type,isHave)=>{
      if(type == 1){
        this.setState({patientRead:isHave});
      }else if(type == 2){
        this.setState({doctorRead:isHave});
      }else{
        this.setState({assistantRead:isHave});
      }
    }
    this.views = this.getViews();
  }
  componentDidMount(){

  }
  getViews(){
    var views=[];
    views.push(this.wrapComponent(0,<CustomerMsgList navigator={this.props.navigator}/>));
    views.push(this.wrapComponent(1,<MyDoctorMsgList navigator={this.props.navigator}/>));
    views.push(this.wrapComponent(2,<OtherDoctorMsgList navigator={this.props.navigator}/>));
    return views;
  }
  wrapComponent(index,component){
    return (
      <View key={index} style={{width:mWidth}}>
        { component }
      </View>
    )
  }
  onSelectView(index){
    if(index != this.state.index){
      this.setState({index:index,currentIndex:index});
      // if(index == 2 && this.teamlist){
      //   this.teamlist.refreshAll();
      // }
    }
  }
  render() {
    return (
      <View {...this.props} style={[this.props.style,styles.tabGroup]}>
        <View style={styles.tabGroup}>
          <Tabar currentIndex={this.state.currentIndex} style={{flex:1}}>
           {
              this.views
           }
           </Tabar>
        </View>
        <View style={styles.line}/>
        <View style={styles.bottom_content}>
          <TabbarItem onPress={(index)=>this.onSelectView(index)} index={0} selected={this.state.index == 0} icon={require("../res/tab_patient.png")} selectedIcon={require("../res/tab_patient_s.png")} showRedIcon={this.state.patientRead}/>
          <TabbarItem onPress={(index)=>this.onSelectView(index)} index={1} selected={this.state.index == 1} icon={require("../res/tab_doctor.png")} selectedIcon={require("../res/tab_doctor_s.png")} showRedIcon={this.state.doctorRead}/>
          <TabbarItem onPress={(index)=>this.onSelectView(index)} index={2} selected={this.state.index == 2} icon={require("../res/tab_all_doctor.png")} selectedIcon={require("../res/tab_all_doctor_s.png")} showRedIcon={this.state.assistantRead}/>
        </View>
      </View>
    );
  }
}

class Tabar extends React.Component {

  constructor(props) {
    super(props);
    this.state = {renderPlaceholderOnly: true};
  }

  render(){

    return (
      <View style={{flex:1,flexDirection:'row',width:mWidth*this.props.children.count,left:-this.props.currentIndex*mWidth}}>
      {
        this.props.children
      }
      </View>
    )
  }
}

var styles = StyleSheet.create({
  tabGroup: {
    flex: 1,
  },
  gone:{
    height:0,
    overflow:'hidden',
  },
  line:{
    backgroundColor:"#C1C1C1",
    height:1
  },
  bottom_content:{
    height:h(49),
    flexDirection:'row',
  },
  tabbar_item:{
    flex:1,
    justifyContent:'center',
    alignItems:'center',
  },
  tabbar_item_icon:{
    width:w(24),
    height:w(24),
    resizeMode:'contain',
    backgroundColor:'transparent'
  },
  point:{
    position:'absolute',
    top:w(0),right:w(0),
    width:w(8),height:w(8),
    backgroundColor:'red',
    borderRadius:w(4),
    overflow:'visible',
  }
});

module.exports = Home;
