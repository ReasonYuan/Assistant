/**
 *
 * 聊天时呈现普通消息的Cell，即是文字消息
 *
 * @author reason 2015-12-08
 *
 **/

'use strict';

var React = require('react-native');
var {
  StyleSheet,
  Text,
  View,
  Image,
  TouchableHighlight,
} = React;

var ChatBaseCell = require("./CellBase")
var {User} = require('../Models')
var {w,h,f,screenWidth} = require('../../utils/Porting')
var {Color,fs} = require('../../utils/Styles')

let textWidth = screenWidth() - w(72)

class CellNormal extends ChatBaseCell {

  constructor(props){
      super(props)
      this.state = {width:0}
  }

componentDidMount(){
  this.mount = true
}

componentWillUnmount(){
  this.mount = false
}

  //渲染聊天的详细信息（不带头像的）
  renderContent(){

    if(React.Platform.OS === 'android'){
      var {requireNativeComponent} = React;
      var RNChatTextView = requireNativeComponent('RNChatTextViewManager', null);
      return(
        <View style={[istyles.contextView,(User.currentUser.documentID == this.msg.from) && istyles.meSayView]}>
          <RNChatTextView
            fontSize={fs('24')}
            margin={w(5)}
            style={[istyles.context,
            (User.currentUser.documentID == this.msg.from) && istyles.mesay]}>
            {this.msg.message}</RNChatTextView>
        </View>
      );
    }else{
      return(
        <View >
          <Text
          // ref={(c) => {this.reset(c)}}

          style={[istyles.context,
            (this.state.width!=0) && {width:this.state.width},
            (User.currentUser.documentID == this.msg.from) && istyles.mesay]}>
            {this.msg.message}</Text>
        </View>
      )
    }
  }

}

if(React.Platform.OS === 'android'){
  var istyles = StyleSheet.create({
    contextView:{
      borderWidth: w(1),
      borderRadius: h(7),
      borderColor: Color.chatBorder
    },
    context:{
      margin:w(5),
      color:'#666',
      fontSize:fs('24'),
      maxWidth:textWidth,
      borderColor: Color.chatBorder
    },
    meSayView:{
      backgroundColor:'#63c0b5',
      borderColor: 'transparent',
      overflow:'hidden'
    },
    mesay:{
      color:'#fff',
      backgroundColor:'#63c0b5',
      borderColor: 'transparent',
      overflow:'hidden'
    }
  });
}else{
  var istyles = StyleSheet.create({
    context:{
      color:'#666',
      paddingHorizontal:w(10),
      paddingVertical:w(10),
      maxWidth:textWidth,
      fontSize:fs('24'),
      borderWidth: w(1),
      borderRadius: h(7),
      borderColor: Color.chatBorder,
    },
    mesay:{
      color:'#fff',
      backgroundColor:'#63c0b5',
      borderColor: 'transparent',
      overflow:'hidden'
    }
  })
}

module.exports = CellNormal;
