/**
 *
 * 聊天的通知消息，例如：消息时间，新加成员等的基类
 * type-->0:消息的时间,1:群聊中加入某人
 * @author reason 2015-12-08
 *
 */

'use strict';

var React = require('react-native');

var {
  Text,
  View,
  Image,
  StyleSheet,
  TouchableHighlight
} = React;

// var Button = require('../../widget/Button');
var ChatBaseCell = require("./CellBase")
var ImageView = require('../../widget/ImageView')

var {w,h,f,screenWidth} = require('../../utils/Porting')
var {Color} = require('../../utils/Styles')

let carWidth = screenWidth() - w(120)

class CellCard extends ChatBaseCell {

	constructor(props){
    super(props)
    // this.msg.delete()
	}


  onMessageClick(){
    this.toProfileView(this.msg.message)
  }

  getDoctorIcon(doctor){

  }

	renderContent(){
    var doctor = this.msg.message
    var icon = doctor.headIcon?doctor.headIcon.objectKey:null;
      return(
        <View style={istyles.full}>
          <View style={istyles.iconContainer}>
            <ImageView style={istyles.icon} imageKey={icon}
              source={icon?null:require('../../res/head_doctor.png')}/>
            <Image style={istyles.logo} source={require('../../res/icon_card_logo.png')}/>
          </View>

          <View style={istyles.contentContainer}>
            <Text style={istyles.nameLabel} numberOfLines={1}>{doctor.name}</Text>
            <Text style={istyles.dspLabel} numberOfLines={1}>{doctor.department}</Text>
            <Text style={istyles.dspLabel} numberOfLines={1}>{doctor.hospital}</Text>
          </View>
        </View>
      )
	}
}

var istyles = StyleSheet.create({
  full:{
    flexDirection:'row',
    width:carWidth,
    height:w(72),
    padding:w(6),

    borderWidth: w(1),
    borderRadius: h(4),
    borderColor: Color.chatBorder,
  },
  iconContainer:{
    width:w(35),
    height:w(60),
    paddingRight:w(5),
    justifyContent:'center',
    alignItems:'center',
    borderRightWidth:w(0.5),
    borderColor:'#ecedee'
  },
  icon:{
    width:w(30),
    height:w(30),
    borderRadius:w(5),
    backgroundColor:'#777'
  },
  logo:{
    width:w(28),
    height:w(28),
    marginTop:h(2),
  },
  contentContainer:{
    flex:1,
    marginLeft:w(5),
    marginVertical:w(6),
  },
  nameLabel:{
    fontSize:f(14),
    marginBottom:w(7),
    color:'#333'
  },
  dspLabel:{
    fontSize:f(10),
    marginTop:w(2),
    color:"#999"
  },
});

module.exports = CellCard;
