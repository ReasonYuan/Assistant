/**
 *
 * 聊天时呈现资讯和服务消息的Cell，现在两种用同一个cell
 *
 * @author reason 2015-12-15
 *
 **/

'use strict';

var React = require('react-native');
var {
  StyleSheet,
  Text,
  View,
  Image,
  TouchableHighlight,
} = React;

var ChatBaseCell = require("./CellBase")

var Tools = require('../../utils/Tools')
var {w,h,f,screenWidth} = require('../../utils/Porting')
var {Color,Config} = require('../../utils/Styles')

let resWidth = screenWidth() - w(120)

class CellResource extends ChatBaseCell{

  constructor(props){
      super(props)
  }

  onMessageClick() {
    var ReadView = require("../readweb/ReadWebView")
    this.chatView.pushWidthComponent(
      <ReadView navigator={this.chatView.props.navigator} url={this.msg.message.url} title={"资讯"}/>)
  }

  renderIcon(url){
    if(url && url != ""){
      return <Image style={istyles.icon} source={{uri: url}}/>
    }else{
      return <Image style={istyles.icon} source={require('../../res/icon_def.png')}/>
    }
  }

  //渲染聊天的详细信息（不带头像的）
  renderContent(){
    var msg = this.msg.message
    return(
      <View style={istyles.cell}>
        <View style={istyles.content}>
          {this.renderIcon(msg.icon)}
          <Text numberOfLines={6} style={istyles.desContainer}>
            <Text numberOfLines={6} style={istyles.desLabel}>{msg.title}</Text>
          </Text>
        </View>
      </View>
    )
  }
}

var istyles = StyleSheet.create({
  cell:{
    width:resWidth,
    height:w(75),
    padding:w(6),

    borderWidth: w(1),
    borderRadius: h(4),
    borderColor: Color.chatBorder,
  },
  content:{
    flexDirection:'row',
  },
  icon:{
    width:w(40),
    height:w(40),
  },
  desContainer:{
    flex:1,
    marginLeft:w(5),
  },
  desLabel:{
    fontSize:f(10),
    color:'#666'
  }
});


module.exports = CellResource
