/**
 *
 * 用户聊天页面的父类。
 * 因为用户与客户或医生的聊天界面及功能上都差不多。
 * @author reason 2015-12-08
 *
 */

'use strict';

var React = require('react-native');

var {
  StyleSheet,
  TabBarIOS,
  Text,
  View,
  Image,
  ListView,
  ScrollView,
  TouchableHighlight,
  TextInput,
  ScrollView,
  Animated,
  ActionSheetIOS,
  PanResponder
} = React;

var {Styles,Button} = require('../../utils/Styles');//BaseComponent
var BaseComponent = require('../BaseComponent')
var Config = require("../../constant/Config")
var Models = require("../Models");
var ChatDataSource = require("./ChatDataSource")
var {User,Patient,FriendShip,Message,Service} = Models;
var SystemInfo = require('./SystemInfo');
var CellNormal = require("./CellNormal");
var CellResource = require('./CellResource')
var CellService = require('./CellService')
var CellImage = require('./CellImage');
var CellCard = require('./CellCard')
var CellForward = require('./CellForward')
var CellPatient = require('./CellPatient')
var UserCacheManager = require('../users/UserCacheManager')
var Constant = require('../../constant/Constant')

var ChatFeatures = require('./ChatFeatures');

var InvertibleScrollView = require('react-native-invertible-scroll-view');
var MessageManager = require("../message/MessageManager")

var FQListView = require('../../widget/FQListView')
var Tools = require('../../utils/Tools')
var {w,h,f,screenWidth} = require('../../utils/Porting')
var {Color} = require('../../utils/Styles')

var iconMore = require('../../res/icon_msg_more.png')

class BaseChatView extends BaseComponent{

  //聊天数据源
  chatDataSource:ChatDataSource;

  isHistory:Boolean;
  isFirstTime:Boolean;
  pullThrehold:Number;

  constructor(props) {
    super(props);

    this.count = 0;
    this.time = 0;
    this.featureType = 0; //下面扩展功能的类型，聊天对象不同，类型不同
    this.isFirstTime = true;
    this.lastScrollY = 0
    this.isTabBarChild = true;
    this.pullThrehold = 0

    this.state = {
      chatHistory:[],
      moveAnim: new Animated.ValueXY(),
      moveAnim2:new Animated.ValueXY(),
      navigatorBarConfig:{title:props.message.debugName||"",showBackIcon:true},
      dataSource:new ListView.DataSource({rowHasChanged: (r1, r2) => r1 !== r2})};
  }

  //的到单聊的聊天对象
  getSignTalker(){
    var message = this.props.message
    if(!message.talkers){//没有talkers,表示必须要从message.message里的from、to取聊天对象
      var id
      var msg = message.debugMessage;
      if(message.relationship.from != User.currentUser.documentID){
        id = message.relationship.from
      }else{
        id = message.relationship.to
      }
      if(!id){
        return null
      }

      var friend = UserCacheManager.instance.getUserInfo(id)
      if(!friend){
        friend = new User()
        friend.documentID = id
        friend.name = ""
      }else{
        friend.documentID = id
      }
      this.friend = friend
    }else{
      this.friend = message.talkers[0]
    }
    return this.friend
  }

  //是不是在和医生单聊
  getFeatureType(){
    return 0
  }

  componentDidUpdate(){
    // let listView = this.refs.chatList;
    // let scrollView = listView.refs.listviewscroll;
    // scrollView.scrollTo(0)
  }

  listToNewMessage(){
    let listView = this.refs.chatList;
    let scrollView = listView.refs.listviewscroll;
    if(scrollView)scrollView.scrollTo(0)
  }

  componentWillMount(){
    this._panResponder = PanResponder.create({
      onStartShouldSetPanResponder: (evt, gestureState) => { this.hideFeatures(); return false;},
      onStartShouldSetPanResponderCapture: (evt, gestureState) => {this.hideFeatures(); return false;},
    });
  }

  componentWillUnmount(){
    super.componentWillUnmount();
    if(this.chatDataSource){this.chatDataSource.stop()}
    MessageManager.instance.setCurrentChattingChannel(null)
  }

  //通过id的到用户
  getUserById(id){
    var user = UserCacheManager.instance.getUserInfo(id)
    return user
  }

  //得到参与聊天的所有用户
  getUsers(){
    var users = []
    if(this.group){
      var ids = this.group.members
      for(var i = 0; i < ids.length; i++){
        users.push(this.getUserById(ids[i]))
      }
    }else{
      users.push(this.friend)
      users.push(User.currentUser)
    }
    return users
  }

  isUserInById(id){
    if(this.group){
      var ids = this.group
      for(var i = 0; i < ids.length; i++){
        if(id == ids[i])return true
      }
      return false
    }else{
      if(User.currentUser.documentID == id)return true
      if(this.friend.documentID == id)return true
      return false
    }
  }

  //得到聊天里的医生
  getDoctor(){
    if(!this.doctor){
      if(this.group){
        var group = this.group
        for(var i = 0; i < group.members.length; i++){
          var user = this.getUserById(group.members[i])
          if(user.role_type == Constant.Role_Doctor){
            this.doctor = user
            break
          }
        }
      }else if(this.friend.role_type == Constant.Role_Doctor){
        this.doctor = this.friend
      }
    }
    return this.doctor
  }

  onDataChange(data){
    var lastMessage = data[0];
    for (var i = 0; i < data.length; i++) {
      var tmp = data[i];
      if( lastMessage.date.getTime() - tmp.date.getTime() > Config.message_time_line_interval){
        data.splice(i,0,{type:"SystemTime",date:lastMessage.date})
      }
      lastMessage = tmp;
    }

    this.messages = data
    this.setState({dataSource:this.state.dataSource.cloneWithRows(data)});
  }

  onLeftPress(){
    var Home = require('../Home')
    // var routes = this.props.navigator.getCurrentRoutes()
    //
    // for(var i = routes.length -1 ; i > 0; i--){
    //   var route = routes[i-1];
    //   if(route.component == Home){
    //     console.log(route.component);
    //     this.props.navigator.popToRoute(route)
    //     break;
    //   }
    // }
    // var Home = require('../Home2')
    var routes = this.props.navigator.getCurrentRoutes()

    for(var i = routes.length -1 ; i > 0; i--){
      var route = routes[i-1];
      var routeType = route.component;
      if (React.Platform.OS === 'android') {
         routeType = routeType.type;
      }
      if(routeType === Home){
        console.log(route.component);
        this.props.navigator.popToRoute(route)
        break;
      }
    }
  }

  KeyboardWillShow(e){
    this.isKeyboardIsShow = true;
    var height = -e.endCoordinates.height;
  }

  KeyboardWillHide(e){
    this.isKeyboardIsShow = false;
  }

  //发送一条普通信息
  sendMessage(){
    var text = this.inputText;
    if(text == ""){
      this.showToast("发送消息不能为空");
      return;
    }

    this.inputText = ""
    this.refs.input.clear()
    this.chatDataSource.sendSimpleMessage(text);
  }

  //发送一条自己定制的信息，可以是任何定制的
  sendInfoMessage(message,callback){
    // alert(JSON.stringify(message))
    this.chatDataSource.sendMessage(message,callback)
  }

  //渲染一个聊天cell
  renderRow(msg,sectionID,rowID){
    if(msg.type == "SystemTime"){
      msg.message = Tools.getDetailDateCompareToday(msg.date);//msg.date.format(format)
      return (<SystemInfo message={msg} chatView={this} type={0}/>)
    }
    switch(msg.messageType){
      case Constant.MSG_NORMAL: //普通消息
        return (<CellNormal key={msg.messageType} message={msg} chatView={this}/>)
      case Constant.MSG_IMAGE:  //图片
        return (<CellImage key={msg.messageType} message={msg} chatView={this}/>)
      case Constant.MSG_FORWARD:        //患者发的病案
        return (<CellForward key={msg.messageType} message={msg} chatView={this}/>)
      case Constant.MSG_RESOURCE: //资讯
        return (<CellResource key={msg.messageType} message={msg} chatView={this}/>)
      case Constant.MSG_SERVER:  //服务
        return (<CellService key={msg.messageType} message={msg} chatView={this}/>)
      case Constant.MSG_ADDMEMBER: //系统：加入群员
        return  (<CellCard key={msg.messageType} message={msg} chatView={this} type={1}/>)
      case Constant.MSG_PATIENT:
        return (<CellPatient key={msg.messageType} message={msg} chatView={this}/>)
      default:
        msg.message = "发来一条消息，请升级到最新版本后查看"
        return (<CellNormal key={msg} message={msg} chatView={this}/>)
    }
  }

  loadHistory(){
    var time = new Date().getTime()
    if(this.first){
      this.chatDataSource.pullHistoryMessages((data)=>{
          this.onDataChange(data);
      })
    }
  }

  onScrollTouchUp(){
    //console.log("on scroll touch up!!!")
    this.loadHistory()
  }

  onScroll(){
    if (this.refs.chatList.scrollProperties.offset + this.refs.chatList.scrollProperties.visibleLength >= this.refs.chatList.scrollProperties.contentLength){
        this.first = true
        this.refs.chatList.props.onEndReached();
    }
  }

  _render(){

    return (
      <View {...this._panResponder.panHandlers} style={istyles.tabContent}>
      <Animated.View style={[this.state.moveAnim.getLayout(),Styles.content]}>
        <FQListView
            ref="chatList"
            style={istyles.list}
            pageSize={10}
            initialListSize={10}
            renderScrollComponent={props => <InvertibleScrollView {...props} inverted />}
            onKeyboardWillShow={this.KeyboardWillShow.bind(this)}
            onKeyboardWillHide={this.KeyboardWillHide.bind(this)}
            dataSource={this.state.dataSource}
            renderRow={this.renderRow.bind(this)}
            onScroll={this.onScroll.bind(this)}
            onEndReached={this.loadHistory.bind(this)}
            onResponderRelease={this.onScrollTouchUp.bind(this)}/>

      </Animated.View>

      <Animated.View style={[{marginBottom:-ChatFeatures.Height},this.state.moveAnim2.getLayout()]}>
        {
          this.renderInputView()
        }
          <ChatFeatures navigator={this.props.navigator} chatView={this} />
      </Animated.View>
      </View>
    )
  }

  //聊天框
  renderInputView(){
    //multiline={true}  default
    //onFocus={this.inputFocus.bind(this)}
    return(
      <View>
      <View style={istyles.line}/>
        <View style={istyles.inputview}>
          <View style={istyles.inputBorder}>
          <TextInput
            ref='input'
            pageSize={10}
            initialListSize={10}
            style={istyles.input}
            placeholder={"输入聊天文字"}
            scrollEventThrottle = {20}
            onSubmitEditing={this.sendMessage.bind(this)}
            returnKeyType={"send"}
            onFocus={this.listToNewMessage.bind(this)}
            onChangeText={(text) => this.inputText=text}
          />
          </View>
          <TouchableHighlight
            underlayColor="transprent"
            onPress={this.showFeatures.bind(this)}>

            <Image style={istyles.moreIcon} source={iconMore}/>

          </TouchableHighlight>

        </View>
        </View>
    )
  }

  // <TouchableHighlight onPress={this.sendMessage.bind(this)} underlayColor="#bbb" style={istyles.sendbar}>
  //   <Text style={istyles.sendLabel}>发送</Text>
  // </TouchableHighlight>


  showFeatures(){
    if(this.isKeyboardIsShow) return;
    Animated.timing(
      this.state.moveAnim2,
      {toValue: {x: 0, y: -ChatFeatures.Height},duration: 200}
    ).start();
    Animated.timing(
      this.state.moveAnim,
      {toValue: {x: 0, y: -ChatFeatures.Height},duration: 200}
    ).start();
  }
  hideFeatures(){
    if(this.isKeyboardIsShow) return;
    Animated.timing(
      this.state.moveAnim2,
      {toValue: {x: 0, y: 0},duration: 200}
    ).start();
    Animated.timing(
      this.state.moveAnim,
      {toValue: {x: 0, y: 0},duration: 200}
    ).start();
  }

  onChatFeaturesPress(index){}

}

var istyles = StyleSheet.create({
  list:{
    marginTop:h(0),
    backgroundColor:'#fff'
  },
  line:{
    flex:1,
    height:w(1),
    backgroundColor:'#f0f0f0'
  },
  inputview:{
    flexDirection:'row',
    height:h(46),
    alignItems:"center"
  },
  tabContent: {
    flex: 1,
    alignItems: 'stretch',
  },
  input:{
    flex:1,
    height:h(30),
    fontSize:f(13),
    borderWidth:w(0),
    padding:0,
    marginLeft:w(2),
    marginRight:w(2),
    backgroundColor:'transparent'
  },
  inputBorder:{
    flex:1,
    height:h(30),
    borderWidth:w(0.7),
    marginLeft:w(12),
    borderColor:'#afafaf',
    borderRadius:5,
  },
  addbar:{
    height:w(30),
    width:w(30),
    borderWidth:w(0.6),
    borderColor:'#999',
    borderRadius:w(15),
    marginLeft:w(12),
    justifyContent:"center",
    alignItems:"center"
  },
  moreIcon:{
    height:w(30),
    width:w(30),
    marginLeft:w(12),
    marginRight:w(12),
    resizeMode:'cover'
  },
  addLabel:{
    fontSize:f(18),
    color:"#e96978",
    textAlign:'center',
    alignSelf:'center',
    lineHeight:f(18),
  }
});

module.exports = BaseChatView;
