/**
 *
 * 启动初始化程序
 * @author johnny 2015-12-12
 *
 */

'use strict';

var Models = require("./Models");
var Config = require("../constant/Config");
var {User,Group,Patient,FriendShip,Message,Service, WebLink} = Models;
var {DatabaseView,DatabaseManager, Database} = require("./couchbase/Couchbase");
var MessageManager = require("./message/MessageManager")
var UserCacheManager = require("./users/UserCacheManager")
var {AsyncStorage} = require("react-native")
var WebResLoader = require("./webres/WebResLoader")
var GroupCacheManager = require("./users/GroupCacheManager")
var DoctorFriendsList = require("./users/DoctorFriendsList")

var {Fetch} = require('../JSLibrary/Logic');

var Bootstrap = {
}

Bootstrap.onBoot = function(firstLoadingCallback){
  if(Bootstrap.relogin){
    UserCacheManager.instance = new UserCacheManager()
    GroupCacheManager.instance = new GroupCacheManager()
    DoctorFriendsList.instance = new DoctorFriendsList()
    ChatFriendShipManager.instance = new ChatFriendShipManager()
    Bootstrap.relogin = false
  }

  //1. start caching user info
  UserCacheManager.instance.startCachingUsersInfo(function(){
    if(firstLoadingCallback) firstLoadingCallback("userLoaded")
  }, function(currentUser){
    //found currentUser
    if(firstLoadingCallback) firstLoadingCallback("currentUserFound")
    User.currentUser = currentUser;
    currentUser.getProfile((p)=>{
      console.log(p);
    });
    //2. query red dots
    var firstRunKey = "is_first_" + User.currentUser.documentID
    AsyncStorage.getItem(firstRunKey, function(error, result){
      if(result != "false"){
        AsyncStorage.setItem(firstRunKey, "false")
        //enable database views
        new WebResLoader("WebResource", 1, null, 1) //1 means just for create view
        new WebResLoader("WebResource", 2, null, 1)
        new WebResLoader("WebService", 0, null, 1)
      }
    })
    //3. start watching message for global usage
    MessageManager.instance.startWatchingMessage(function(){
      if(firstLoadingCallback) firstLoadingCallback("msgLoaded")
    })
  })

}

//TODO==JP==singleton的全部需要重构成统一的装载释放
Bootstrap.logout = function(){
  UserCacheManager.instance.logout()
  GroupCacheManager.instance.logout()
  DoctorFriendsList.instance.logout()
  ChatFriendShipManager.instance.logout()
  UserStore.instance.logout()
  Bootstrap.relogin = true //退出重新登录
}

//只是初始化view，并不绑定任何回调
Bootstrap.createOneView = function(database, viewName, mapFunction){
  if(!database) throw new Error("no a database here");
  if(!(database instanceof Database)) throw new Error("first parameter no a instanceof Database");
  if(typeof(mapFunction) != "string" )  throw new Error("map function not string");
  var url = Config.localURL + database.dbName + "/_design/" + viewName;
  var views = {};
  views[viewName] = {
    "map" : mapFunction
  };
  fetch(url).then((response) => {
    if (response.status !== 200) {
      fetch(url, {
        method: "PUT",
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
          "language" : "javascript",
          "views" :views
        })
      }).then((response) => response.json())
        .then((data) => {
          //do nothig, just create the view
          console.log("view created: " + viewName)
        }).catch(function(error) {
          if(error){
            //TODO handle error
            var emsg = error
          }
        })
    } else {
       //do nothing, just check if the view exists
       console.log("view already created: " + viewName)
    }
  }).catch(function(error) {
    if(error){
      //TODO handle error
      var emsg = error
    }
  })
}

module.exports = Bootstrap;
