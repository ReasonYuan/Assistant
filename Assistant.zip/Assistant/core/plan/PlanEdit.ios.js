'use strict';

var React = require('react-native');
var {
  StyleSheet,
  Text,
  View,
  Alert,
  TextInput,
  TouchableHighlight,
  Navigator,
  ScrollView,
  DatePickerIOS,
} = React;

var BaseComponent = require('../BaseComponent')
var Button = require('../../widget/Button')
var {Plan} = require("../Models");
var DatePicker = require("../../widget/DatePicker")
var {w,h,f} = require('../../utils/Porting')
var {Tools} = require('../../utils/Styles')

class PlanEdit extends BaseComponent {
  constructor(props){
    super(props)
    this.isTabBarChild = true
    var plan = this.props.plan

    if(!plan){//从计划列表过来的数据按理说事不会为null的，这样写只是以防万一
      plan = new Plan()
      plan.isNew = true
      plan.title = ""
      plan.date = new Date()
    }else{
      plan.date = plan.date?new Date(+plan.date):new Date()
    }
    this.plan = new Plan()
    this.plan.setProperty(plan)
    var delTitle = (plan.isNew) ? "" : "删除"

    this.state = {navigatorBarConfig:{title:"详细信息",
          leftButtonTitle:"取消",rightButtonTitle:delTitle,rColor:'e63e5d'}}
  }

  onLeftPress(){
    this.props.navigator.pop();
  }

  onRightPress(){
    if(!this.plan.isNew){
      Alert.alert(
        '',
        '是否确定要删除这份计划？',
        [
          {text: '确定', onPress: () => this.delete()},
          {text: '取消'},//style: 'cancel'
        ]
      )
    }
  }

  delete(){
    var plan = new Plan()
    plan.setProperty(this.props.plan)
    plan.delete()
    this.props.navigator.pop();
  }

  onDateChange(date){
    this.plan.date = date
  }

  onSureClick(){
    if(this.plan.title == ""){
      this.showToast("计划内容不能为空！")
      return
    }

    if(Tools.charLen(this.plan.title) > 1000) {
      this.showToast("计划内容不能超过500字！");
      return;
    }

    this.props.plan.date = new Date(this.plan.date).getTime()+""
    this.props.plan.title = this.plan.title
    var plan = new Plan()
    plan.setProperty(this.props.plan)
    plan.save()
    this.pop();
  }

  _render() {
    return (
      <View style={istyles.container}>

      <DatePicker
        mode={"date"}
        date = {this.plan.date}
        onDateChange={(date)=>this.onDateChange(date)}/>

        <TextInput
          multiline={true}
          style={istyles.input}
          placeholder={"请输入健康计划最多500字"}
          maxLength={500}
          value={this.plan.title}
          onChangeText={(text) =>{this.plan.title=text}}
          />

        <Button
          title="确认"
          titleColor="#fff"
          style={istyles.sure}
          onTouch={()=>{this.onSureClick()}}/>

      </View>
    )
  }
}

  var istyles = StyleSheet.create({
    container:{
      flex:1,
    },
    picker:{
      // height:h(80),
      // backgroundColor:'#999'
    },
    input:{
      // height:h(100),
      flex:1,
      marginHorizontal:w(12),
      paddingHorizontal:w(3),
      paddingVertical:w(1),
      borderWidth:w(0.6),
      color:'#999',
      fontSize:f(14),
      backgroundColor:'#fff'
    },
    timeTitle:{
      marginTop:20,
      fontSize:16,
    },
    // planTime:{
    //   marginTop:30,
    //   height:45,
    //   borderRadius:0
    // },
    sure:{
      marginHorizontal:w(12),
      marginTop:w(28),
      marginBottom:w(50),
      height:h(35),
      backgroundColor:'#65c0b5'
    }
  });

module.exports = PlanEdit;
