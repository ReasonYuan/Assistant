/**
 *
 * 健康计划列表,用于客户(病人)个人信息中健康计划案项的展示内容
 * @author reason 2015-12-13
 *
 */

'use strict';

var React = require('react-native');

var {
  StyleSheet,
  Text,
  Image,
  View,
  ListView,
  TouchableHighlight
} = React;

var {Database, DatabaseView,DatabaseManager} = require("../couchbase/Couchbase");
var {Plan,User} = require("../Models");
var FQListView = require('../../widget/FQListView')
var {Color,len} = require('../../utils/Styles')
var {w,h,f} = require('../../utils/Porting')

class PlanList extends React.Component{

    constructor(props){
      super(props)
      this.isTabBarChild = true;

      this.state = {dataSource:new ListView.DataSource({rowHasChanged: (r1, r2) => r1 !== r2})}
    }

    loadData(){
      if(!this.patient)return
      var self = this
      var db = DatabaseManager.instance.currentDatabase;
      var planListView =  new DatabaseView(db,"Plan","PlanListView_"+this.patient.id,
      "function(doc) { if(doc.type == 'Plan' && doc.patient == '"+
        this.patient.id+"') emit(doc.date, doc) }",()=>{
        planListView.descending = true;
        planListView.setOnDataChangeCallback((data)=>{self.onDataChange(data)})
      });

      this.planListView = planListView;
    }

    componentWillUnmount(){
      if(this.planListView){
        this.planListView.stop()
        delete this.planListView;
      }
    }

    //当数据发生变化时，重新刷新UI
    onDataChange(data){
      if(!data)return
      // alert(JSON.stringify(data))
      this.setState({dataSource:this.state.dataSource.cloneWithRows(data)})
    }

    //设置当前病人
    setPatient(patient){
      this.patient = patient
      this.loadData()
    }

    //添加一个计划
    addPlanClick(){
      var plan = new Plan()
      plan.isNew = true
      plan.patient = this.patient.id
      plan.user = this.props.controller.customer.documentID
      plan.assistant = User.currentUser.documentID
      plan.date = new Date()
      plan.title = ""
      this.toPlanEditView(plan)
    }

    //某项cell被点击
    onItemClick(data){
      if(!data){
        addPlanClick()
      }else{
        this.toPlanEditView(data)
      }
    }

    toPlanEditView(plan){
      var Edit = require("./PlanEdit")
      this.props.controller.pushWidthComponent(
        <Edit navigator={this.props.controller.props.navigator} plan={plan}/>
      )
    }

    //渲染健康计划列表的cell
    renderRow(data){
      var plan = data.value
      var time = new Date(+plan.date).format("yyyy-MM-dd")
      return(
        <TouchableHighlight
          underlayColor={Color.itemClick}
          onPress={()=>this.onItemClick(plan)}>

          <View style={istyles.cell}>
            <Text style={istyles.titleLabel}>{time}</Text>
            <Text style={istyles.desLabel} numberOfLines={2}>{plan.title}</Text>
          </View>

        </TouchableHighlight>
      )
    }

    render(){
      return(
        <View style={istyles.full}>

        <TouchableHighlight
          style={istyles.addButton}
          underlayColor={Color.itemClick}
          onPress={()=>{this.addPlanClick()}}>
          <View style={istyles.addView}>
            <Image style={istyles.addIcon} source={require('../../res/icon_add.png')}/>
            <Text style={istyles.addLabel}>添加计划</Text>
          </View>
        </TouchableHighlight>
        <FQListView
          style={istyles.list}
          renderRow={this.renderRow.bind(this)}
          dataSource={this.state.dataSource}/>
        </View>
      )
    }
}

var istyles = StyleSheet.create({
  full:{
    flex:1
  },
  addButton:{
    marginHorizontal:w(12)
  },
  addView:{
    height:h(40),
    flexDirection:'row',
    borderBottomWidth:len('itemDivider'),
    justifyContent:'center',
    alignItems:'center',
    borderColor:Color.itemDivider,
  },
  addIcon:{
    width:w(12),
    height:w(12)
  },
  addLabel:{
    marginLeft:w(5),
    fontSize:12,
    color:'#e66071'
  },
  cell:{
    // height:h(60),
    marginHorizontal:w(15),
    paddingTop:h(10),
    borderBottomWidth:1,
    borderColor:Color.itemDivider,
  },
  titleLabel:{
    fontSize:f(16),
    color:Color.title,
  },
  desLabel:{
    marginTop:h(4),
    marginBottom:w(3),
    color:Color.des,
  }
});

module.exports = PlanList
