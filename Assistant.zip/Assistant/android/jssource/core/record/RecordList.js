/**
 *
 * 病历(档案)列表,用于客户(病人)个人信息中健康档案项的展示内容
 * @author reason 2015-12-13
 *
 */

'use strict';

var React = require('react-native');

var {
  StyleSheet,
  Text,
  Image,
  View,
  ListView,
  TouchableHighlight,
  Navigator
} = React;

var {Color,len} = require('../../utils/Styles')
var {w,h,f} = require('../../utils/Porting')
var Config = require("../../constant/Constant");
var LocalCache = require("../sync/LocalCache")
var FQListView = require('../../widget/FQListView')

var {Record} = require('../Models')
var ShowContextView = require('./ShowContextView')
var RecordExamInfo = require('./RecordExamInfo')


class RecordList extends React.Component{

    //每个病案的病历分页页号
    pages = {};
    pageSize = 10;

    constructor(props){
      super(props)
      this.records = {}
      this.state = {dataSource:new ListView.DataSource({rowHasChanged: (r1, r2) => r1 !== r2})}
    }

    componentDidMount(){
      this.show = true
    }
    componentWillUnmount(){
      this.show = false
    }

    loadData(){
      if(!this.patient)return

      var patientId = this.patient.id
      if(this.records[patientId]){
        this.onDataChange(this.records[patientId])
        return
      }else{
        this.onDataChange([])
      }

      if(!this.pages[patientId]){
        //第0页开始
        this.pages[patientId] = 0
      }

      var recordCacheKey = "record_cache_key_" + patientId + "_" + this.pages[patientId]
      var self = this
      //刚启动界面要读取缓存
      LocalCache.get(recordCacheKey, function(data){
        if(data && !data.error){
          self.onDataChange(data.rows)
        }
      })

      //restful 获取数据
      var self = this
      this.props.controller.post(
        "users/list_patient_records",
        {patientid:patientId, page:this.pages[patientId], pageSize:this.pageSize},
        (data)=>{
          if(data.error){
            self.props.controller.showToast(data.error)
          }else{
            self.records[patientId] = data
            self.onDataChange(data)

            //保存缓存，每次Load都是load的一个病案的记录
            LocalCache.save(recordCacheKey, {rows:data})
          }
        }
      )
    }

    //当数据发生变化时，重新刷新UI
    onDataChange(data){
      if(!data || data.length == 0)return
      var gs = []
      for(var i = 0; i < data.length; i++){
        if(data[i].value.status == 2){//只需要已经识别动病历数据
          var record = data[i].value
          if(Array.isArray(record.info) && record.info.length > 0){
            for(var j = 0; j < record.info.length; j++){
              var info =  record.info[j];
              var rcd = new Record();
              rcd.setProperty(record);
              rcd.info = info;
              gs.push(rcd);
            }
          }else{
            gs.push(record)
          }
        }
      }
      if(this.show)this.setState({dataSource:this.state.dataSource.cloneWithRows(gs)})
    }

    //设置当前病人
    setPatient(patient){
      this.patient = patient
      this.loadData()
    }

    //基本信息按钮被点击
    onInfoClick(){
      var PatientInfo = require("../profile/PatientInfo")
      this.pushWidthComponent(<PatientInfo
        navigator={this.props.controller.props.navigator}
        patient={this.patient}/>)
    }

    //某项cell被点击
    onItemClick(record){
      var RecordDetail = null
      if("化验记录" == record.recordType){
        RecordDetail = RecordExamInfo
      }else{
        RecordDetail = ShowContextView
      }

      this.pushWidthComponent(
        <RecordDetail navigator={this.props.controller.props.navigator}
          record={record} title={this.patient.value.name} />
      )
    }

    pushWidthComponent(C){
      this.props.controller.pushWidthComponent(C)
    }

    //渲染档案列表的cell
    renderRow(data){

      var date = ""
      try{
        var time = data.info.create_time;//data.info.record_time ? data.info.record_time:data.info.create_time
        if(time)date = time.substr(0,10)
        // if(time)date = new Date(time.replace(/-/g,"/")).format('yyyy-MM-dd')
      }catch(error){ }

      return(
        <TouchableHighlight
          underlayColor={Color.itemClick}
          onPress={()=>this.onItemClick(data)}>

          <View style={istyles.cell}>
            <Text style={istyles.timeLabel}>{date}</Text>
            <Text style={istyles.typeLabel} numberOfLines={1}>{data.recordType}</Text>
            <Text style={istyles.desLabel} numberOfLines={4}>{data.summary}</Text>
          </View>
        </TouchableHighlight>
      )
    }

    render(){
      return(
        <View style={istyles.full}>
        <TouchableHighlight
          style={istyles.infoButton}
          underlayColor={Color.itemClick}
          onPress={()=>{this.onInfoClick()}}>
          <View style={istyles.infoView}>
            <Image style={istyles.infoIcon} source={require('../../res/icon_patient.png')}/>
            <Text style={istyles.infoLabel}>基本信息</Text>
          </View>
        </TouchableHighlight>


          <FQListView
            style={istyles.list}
            renderRow={this.renderRow.bind(this)}
            dataSource={this.state.dataSource}/>
        </View>
      )
    }
}

var istyles = StyleSheet.create({
  full:{
    flex:1
  },
  infoButton:{
    marginHorizontal:w(12)
  },
  infoView:{
    height:h(40),
    flexDirection:'row',
    borderBottomWidth:len('itemDivider'),
    justifyContent:'center',
    alignItems:'center',
    borderColor:Color.itemDivider,
  },
  infoIcon:{
    width:w(12),
    height:w(12)
  },
  infoLabel:{
    marginLeft:w(5),
    fontSize:f(12),
    color:'#e66071'
  },
  cell:{
    marginHorizontal:w(12),
    paddingVertical:h(6),
    borderBottomWidth:len('itemDivider'),
    borderColor:Color.itemDivider,
  },
  timeLabel:{
    // marginTop:h(6),
    fontSize:f(13),
    color:Color.title
  },
  typeLabel:{
    marginTop:h(7),
    color:Color.title
  },
  desLabel:{
    marginTop:h(6),
    color:"#999",
    fontSize:f(12)
  }
});

module.exports = RecordList
