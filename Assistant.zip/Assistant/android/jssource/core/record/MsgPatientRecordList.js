

/**
 *
 * 聊天时医生发出的病案，点击后查看的详情页面(内容为病历列表)
 * @author reason 2015-12-08
 *
 */

'use strict';

var React = require('react-native');

var {
  Text,
  View,
  ListView,
  StyleSheet,
  TouchableHighlight
} = React;

var {Config,Color,fs,len} = require('../../utils/Styles')
var {w,h} = require('../../utils/Porting')
var Tools = require('../../utils/Tools')
var {fetchGet} = require("../../utils/SimpleFetch")

var {Record,Patient} = require("../Models")
var ImageView = require('../../widget/ImageView')
var BaseComponent = require('../BaseComponent')

class MsgPatientRecordList extends BaseComponent{
  constructor(props){
    super(props)
    this.patient = props.data.patient
    this.state = {
      navigatorBarConfig:{title:this.patient.name,showBackIcon:true},
      dataSource:new ListView.DataSource({rowHasChanged: (r1, r2) => r1 !== r2})
    }
  }

  onLeftPress(){
    this.pop()
  }

  componentWillMount(){
    var self = this

    var records = this.props.data.records
    for(var i = 0; i < records.length; i++){
      var obj = records[i]
      for(var j = 0; j < records.length; j++){
        if(records[i].id == records[j].id && i != j){
          records.splice(j,1);
          break;
        }
      }
    }

    var url = Config.webServerURL+"records/forward_view/?";
    url += "records="+JSON.stringify(records)

    fetchGet(url,
      (data)=>{
        if(data.error){
          self.props.controller.showToast(data.error)
        }else{
          // self.bills = data
          self.onDataChange(data.records)
          //保存缓存，每次Load都是load的一个病案的
          // LocalCache.save(billCacheKey, data)
        }
      }
    )
  }

  onDataChange(data){
    this.setState({dataSource:this.state.dataSource.cloneWithRows(data)})
  }

  onItemClick(record){
    // var ShowContextView = require('./ShowContextView')
    // this.pushWidthComponent({
    //   component:<ShowContextView navigator={this.props.navigator} record={record} title={record.recordType} />
    // })
  }

  renderRow(record){
    return(
      <TouchableHighlight
        underlayColor={Color.itemClick}
        onPress={()=>this.onItemClick(record)}>

        <View style={istyles.cell}>
          <Text style={istyles.timeLabel}>{Tools.getDateByMill(record.date)}</Text>
          <Text style={istyles.typeLabel} numberOfLines={1}>{record.recordType}</Text>
          <Text style={istyles.desLabel} numberOfLines={4}>{record.summary}</Text>
        </View>
      </TouchableHighlight>
    )
  }

  _render(){
    return(
      <ListView
        style={istyles.full}
        initialListSize={10}
        automaticallyAdjustContentInsets={false}
        dataSource={this.state.dataSource}
        renderRow={this.renderRow.bind(this)}/>
    )
  }

}

var istyles = StyleSheet.create({
  full:{
    flex:1
  },
  cell:{
    marginHorizontal:w(12),
    paddingTop:h(6),
    paddingBottom:h(20),
    borderBottomWidth:len('itemDivider'),
    borderColor:Color.itemDivider
  },
  timeLabel:{
    fontSize:fs('22'),
    color:Color.title
  },
  typeLabel:{
    marginTop:w(7),
    color:Color.title
  },
  desLabel:{
    marginTop:h(6),
    color:Color.info,
    fontSize:fs('20')
  }
})

module.exports = MsgPatientRecordList
