/**
 * 化验单类型的病历详情
 * @auth reason
 * @date 2016-01-12
 **/
'use strict';

var React = require('react-native');
var {
  StyleSheet,
  Text,
  View,
  ListView,
  ScrollView,
  TouchableHighlight,
} = React;

var {w,h,screenWidth} = require('../../utils/Porting')
var {Color,len,fs} = require('../../utils/Styles')
var BaseComponent = require('../BaseComponent')
var ImageView = require('../../widget/ImageView')
var {User} = require('../Models')

class RecordExamInfo extends BaseComponent {
  constructor(props){
    super(props)
    this.unNormal = false

    var title = props.title || props.record.recordType
    this.state = {
      navigatorBarConfig:{title:title,showBackIcon:true},
      // dataSource:new ListView.DataSource({rowHasChanged: (r1, r2) => r1 != r2})
    }
  }

  componentWillMount(){
    var record = this.props.record.info
    if(!record)return
    if((!record.examItems || record.examItems.length == 0) && record.other_txt){
      this.unNormal = true
    }

    try{
      var datas = null
      if(this.unNormal){
        datas = JSON.parse(record.other_txt)
        var count = datas[0].length
        // if(count == 0 || count > 3){
        //   //  this.itemWidth = this.cellWidth*count
        //    count = 3
        // }else{
        //   // this.itemWidth = screenWidth()-w(26)
        // }
        this.cellWidth = (screenWidth()-w(26))/count
        // this.setState({dataSource:this.state.dataSource.cloneWithRows(datas)})
      }else{
        datas = record.examItems
        this.cellWidth = (screenWidth()-w(26))/5//-w(24)-w(2)...分5份,分别为3:1:1
        this.itemWidth = screenWidth()-w(26)
        // this.setState({dataSource:datas})
      }
      this.setState({dataSource:datas})
    }catch(error){ }
  }

  onLeftPress(){
    this.pop()
  }

  //查看原图
  showImages(){
    var BrowseImages = require('../BrowseImages')
    var images = []
    var record = this.props.record;
    var userId = User.currentUser.documentID
    for (var i = 0; i < record.images.length; i++) {
      var img = {}
      img.userId = userId
      img.key = record.images[i].key
      images.push(img)
    }

    this.pushWidthComponent(<BrowseImages navigator={this.props.navigator}
      source={images} title={"查看原图"} />)
  }

  //非标准化验单标题栏
  renderUnNormalTitle(data){
    var views = []
    for(var i = 0; i < data.length; i++){
      views.push(
        <View style={{width:this.cellWidth}}>
          <Text style={styles.titleLabel} numberOfLines={1}>{data[i]}</Text>
        </View>
      )
    }
    return(
      <View style={styles.itemTitle}>
        {views}
      </View>
    )
  }

  //非标准化验单一行数据
  renderUnNormalItem(data){
    var views = []
    for(var i = 0; i < data.length; i++){
      var isb = (i != data.length - 1)
      views.push(
        <View style={[{width:this.cellWidth},styles.cell,isb&&styles.cellRight]}>
          <Text style={styles.label} numberOfLines={2}>{data[i]}</Text>
        </View>
      )
    }
    return(//{position:'absolute',top:30,left:0}
      <View style={styles.item}>
        {views}
      </View>
    )
  }

  //标准化验单标题栏
  renderTitle(){
    return(
      <View style={styles.itemTitle}>
        <View style={{width:this.cellWidth*3}}>
          <Text style={styles.titleLabel}>项目</Text>
        </View>
        <View style={{width:this.cellWidth}}>
          <Text style={styles.titleLabel}>结果</Text>
        </View>
        <View style={{width:this.cellWidth}}>
          <Text style={styles.titleLabel}>单位</Text>
        </View>
      </View>
    )
  }

  //标准化验单一行数据
  renderItem(data){
    var isb = ("H"==data.abnormal_value || "L"==data.abnormal_value)
    return(
      <View style={styles.item}>
        <View style={[{width:this.cellWidth*3},styles.cell,styles.cellRight]}>
          <Text style={[styles.label,isb&&styles.abnormalItem]} numberOfLines={2}>{data.item_name}</Text>
        </View>

        <View style={[{width:this.cellWidth},styles.cell,styles.cellRight]}>
          <Text style={[styles.label,isb&&styles.abnormalItem]} numberOfLines={2}>{data.exam_value}</Text>
        </View>

        <View style={[{width:this.cellWidth},styles.cell]}>
          <Text style={[styles.label,isb&&styles.abnormalItem]} numberOfLines={2}>{data.item_unit}</Text>
        </View>
      </View>
    )
  }

  renderUnNormalExamList(data){
    var views = []
    // views.push(this.renderUnNormalTitle(data[0]))
    for(var i = 1; i < data.length; i++){
      views.push(this.renderUnNormalItem(data[i]))
    }
    return views
  }

  renderNormalExamList(data){
    var views = []
    for(var i = 0; i < data.length; i++){
      views.push(this.renderItem(data[i]))
    }
    return views
  }

  //渲染化验单数据列表的标题
  renderListTitle(){
    var data = this.state.dataSource
    if(!data || data.length == 0)return
    // if(!this.unNormal){
    //   return this.renderTitle()
    // }
    if(this.unNormal){
      return this.renderUnNormalTitle(data[0])
    }else{
      return this.renderTitle()
    }
  }

  //渲染化验单数据列表
  renderList(){
    var data = this.state.dataSource
    if(!data || data.length == 0)return
    if(this.unNormal){
      return this.renderUnNormalExamList(data)
    }else{
      return this.renderNormalExamList(data)
    }
  }

  // renderUnNormalRow(data,s1,index){
  //   if(index == 0){
  //     return this.renderUnNormalTitle(data)
  //   }else{
  //     return this.renderUnNormalItem(data)
  //   }
  // }
  //
  // renderScrollView(){
  //   if(this.unNormal){
  //     return(
  //       <ListView
  //         style={styles.list}
  //         initialListSize={12}
  //         pageSize={12}
  //         horizontal={true}
  //         automaticallyAdjustContentInsets={false}
  //         contentContainerStyle={[styles.content]}
  //         dataSource={this.state.dataSource}
  //         renderRow={this.renderUnNormalRow.bind(this)}/>
  //     )
  //   }else{
  //     return(
  //       <View>
  //       {this.renderListTitle()}
  //
  //       <ScrollView
  //         style={styles.list}
  //         automaticallyAdjustContentInsets={false}>
  //         {this.renderList()}
  //       </ScrollView>
  //       </View>
  //     )
  //   }
  // }

  _render(){
    var record = this.props.record.info

    var image = null
    try{image = record.images[0].image_key}
    catch(error){}

    var names = record.exam_templates
    var name = "化验单名称："
    for(var i = 0; i < names.length; i++){
      name += names[i]
      if(i != names.length-1){
        name += "，"
      }
    }

    return(
      <View style={styles.full}>

        <View style={styles.titleView}>
          <Text style={styles.dateLabel}>{record.record_time}</Text>
          <Text style={styles.specimenLabel} numberOfLines={1}>{name}</Text>
          <Text style={styles.specimenLabel}>标本：{record.item_specimen}</Text>
        </View>

        <View style={styles.contentView}>

        {this.renderListTitle()}

        <ScrollView
          style={styles.list}
          automaticallyAdjustContentInsets={false}>
          {this.renderList()}
        </ScrollView>

          <TouchableHighlight style={styles.thumbnail} underlayColor={Color.itemClick} onPress={this.showImages.bind(this)} >
            <ImageView style={styles.img} imageKey={image} source={require('../../res/icon_def.png')}/>
          </TouchableHighlight>
        </View>

      </View>
    )
  }
}

// {this.renderListTitle()}

// <ScrollView
//   style={styles.list}
//   automaticallyAdjustContentInsets={false}>
//   {this.renderList()}
// </ScrollView>
// <ListView
//   style={styles.list}
//   initialListSize={12}
//   pageSize={12}
//   horizontal={true}
//   alwaysBounceVertical={true}
//   automaticallyAdjustContentInsets={false}
//   contentContainerStyle={[styles.content,{width:this.itemWidth}]}
//   dataSource={this.state.dataSource}
//   renderRow={this.renderRow.bind(this)}/>

// <ScrollView style={styles.list}
//   horizontal={true}
//   contentContainerStyle={{width:this.itemWidth,flexWrap:'wrap',flexDirection:'row'}}
//   automaticallyAdjustContentInsets={false}>
//   {this.renderList()}
// </ScrollView>

var styles = StyleSheet.create({
  full:{
    flex:1,
    paddingHorizontal:w(12),
    backgroundColor:'#f1f1f1',
  },
  titleView:{
    borderRadius:w(5),
    marginTop:w(9),
    marginBottom:w(9),
    paddingVertical:w(10),
    paddingHorizontal:w(8),
    backgroundColor:'#fff'
  },
  contentView:{
    flex:1,
    backgroundColor:'#fff'
  },
  dateLabel:{
    fontSize:fs('28'),
    marginTop:w(5),
    marginBottom:w(16)
  },
   specimenLabel:{
    fontSize:fs('23'),
    marginTop:w(6)
  },
  list:{
    flex:1,
    marginBottom:w(5)
  },
  content:{
    flexWrap:'wrap',
    flexDirection:'row',
  },
  itemTitle:{
    flexDirection:'row',
    backgroundColor:'#DEDFE0',
    height:w(25),
    alignItems:'center',
  },
  item:{
    flex:1,
    flexDirection:'row',
    alignItems:'center',
    justifyContent:'center',
    marginBottom:w(2),
    borderWidth:1,
    borderColor:'#f1f1f1',
  },
  hcenter:{
    alignItems:'center'
  },
  cell:{
    height:w(38),
    justifyContent:'center',
    alignItems:'center',
  },
  cellRight:{
    borderRightWidth:1,
    borderColor:'#f1f1f1',
  },
  titleLabel:{
    color:Color.title,
    fontSize:fs('26'),
    alignSelf:'center'
  },
  label:{
    color:Color.title,
    fontSize:fs('24'),
  },
  thumbnail:{
    width:w(50),
    height:w(50),
    marginLeft:w(5),
    marginBottom:w(5),
  },
  img:{
    width:w(50),
    height:w(50),
    resizeMode:'cover',
  },
  abnormalItem:{
    color:"#ec6876"
  }
})

module.exports = RecordExamInfo
