var React = require('react-native');
// var DBModel = require("./couchbase/DBModel")
//
// class Profile extends DBModel{
//   setting:Object;
//   user:User;
//   constructor() {
//     super("Profile");
//     this.setting = {};
//     this.user = User.currentUser.documentID;
//   }
//   set(key,value,cb){
//     if(!this.setting.store)this.setting.store={};
//     this.setting.store[key]=value;
//     this.save(cb);
//   }
//   get(key){
//     if(this.setting.store){
//       return this.setting.store[key];
//     }
//     return null;
//   }
// }
//
// //用户
// class User extends DBModel {
//   yiyi_number:String;//依依号
//   phone_number: Number;//电话号码
//   name:String;//名字
//   profile:Profile;
//   assistant:User;
//   //用户类型，0表示医生，1表示病人
//   role_type:Number;
//   password:String;
//   age:Number;
//   isVIP:Boolean;      //是否是vip
//   birthday:String;    //日期,格式“yyyy-MM-dd”
//   headIcon:Object;    //阿里云objectKey
//   gender:Number;
//   shareUrl:Array;
//   patient:Patient;      //我的病案
//   channel_id:String;    //第三方百度推送的channel_id
//   tags:[String];         //第三方百度推送的tags
//   payStart:String;          //有效期开始
//   payEnd:String;            //有效期结束
//   introduction:String;     //如果是医生，医生简介
//   accountId:String;        //银行账户的id
//   city:String;           //城市名
//   hospital:String;       //医院名
//   department:String;     //科室
//   departmentPY:String;   //科室的拼音
//   accountId:String;      //帐户的id
//   platform:String;       //用户使用的平台，android / ios
//   deviceId:String;      //用户的设备号
//   lastLoginTimeStamp:Number;     //设备登陆时间；
//   constructor() {
//     super("User");
//     this.password = "";
//     this.yiyi_number = "";
//     this.phone_number = "";
//     this.name = "";
//     this.role_type = 0;
//     this.shareUrl=[];
//     this.tags = [];
//     this.profile = null;
//     this.age = 0;
//     this.gender = 0;
//     this.payStart = null;
//     this.payEnd = null;
//     this.assistant = null;
//     this.headIcon = {};
//     this.channel_id = "";
//     this.birthday = "";
//     this.patient = null;
//     this.isVIP = false;
//     this.introduction = null;
//     this.accountId = ""
//     this.city = "";
//     this.hospital="";
//     this.departmentPY = "";
//     this.department="";
//     this.platform = "";
//     this.deviceId = "";
//     this.lastLoginTimeStamp = 0;
//   }
//   getProfile(cb){
//     if (this.profile instanceof Profile){
//       cb(this.profile);
//     } else if (typeof(this.profile) == 'string') {
//       var cb_func = cb;
//       var startTime = new Date().getTime();
//       var intervalId = setInterval(()=>{
//         require("./couchbase/DatabaseManager").instance.currentDatabase.getModel(this.profile,(p)=>{
//           if(p){
//             clearTimeout(intervalId);
//             this.profile = p;
//             if(cb_func){
//               cb_func(p);
//               cb_func = null;
//             }
//           }else if(cb_func && new Date().getTime() - startTime > 10000){
//             clearTimeout(intervalId);
//             this.profile = new Profile();
//             var cf = cb_func;
//             cb_func = null;
//             this.profile.save(()=>{
//               this.save();
//               cf(this.profile);
//             })
//           }
//         })
//       }, 500);
//     }else{
//       this.profile = new Profile();
//       this.profile.save(()=>{
//         this.save();
//         cb(this.profile);
//       })
//     }
//   }
// }
//
// var headIcons = {};
// headIcons.callbacks = {};
// User.getHeadIcon = function(id,cb){
//   // return;
//   if(headIcons[id]){
//     if(cb)cb(headIcons[id]);
//   } else{
//     if(headIcons.callbacks[id]){
//       headIcons.callbacks[id].push(cb);
//       return;
//     }
//     headIcons.callbacks[id] = [cb];
//     ((key)=>{
//       require("./couchbase/DatabaseManager").instance.currentDatabase.getModel(key,(model)=>{
//          if(model && model.type=="User" && model.headIcon){
//            if(model.headIcon.objectKey){
//              React.NativeModules.ImageHelper.getThumbnailImage(User.currentUser.documentID,model.headIcon.objectKey,200,(progress,data)=>{
//                if(data){
//                  headIcons[id] = data;
//                  Object.keys(headIcons.callbacks[id]).forEach((key)=>{
//                    if(headIcons.callbacks[id][key])headIcons.callbacks[id][key](data);
//                  })
//                  delete headIcons.callbacks[id];
//                }
//              });
//            }
//          }
//       });
//     })(id);
//   }
// }
//
// User.currentUser = null;
//
// //病案
// class Patient extends DBModel{
//   name:String;
//   user:User;
//   patient:User; //是否是真实的病人
//   info:Object;
//   relationship:String;
//   gender:Number; //性别
//   birthday:String;  //出生年月
//   address:String; //地址
//   isPay:Boolean; //是否成功付费
//   authorizer:[];  //授权的医生ids
//   constructor() {
//     super("Patient");
//     this.name = "";
//     this.user = null;
//     this.patient = null;
//     this.info = {};
//     this.relationship = "";
//     this.isPay = false;
//     this.gender = 0;
//     this.birthday = new Date().format("yyyy-MM-dd");
//     this.authorizer=[];
//     this.address = "";
//   }
// }
//
// //朋友关系
// class FriendShip extends DBModel{
//   from:User;  //请求的user id
//   fromType:Number; //请求的user type
//   to:User;    //邀请的user id
//   toType:Number;  //邀请的user type
//   accepted:Boolean; //是否接受请求
//   message:String; //邀请时发送的信息
//   constructor(from,to) {
//     super("FriendShip");
//     this.from = from;
//     this.to = to;
//     this.accepted = false;
//     //避免2个人同时建了同一个FriendShip，所以规定好id规则
//     this.documentID = Models.getChannle(this.from, this.to)
//   }
//   getMyId(){
//     var id = this.from;
//     if(User.currentUser.documentID != this.from){
//       id = this.to;
//     }
//     return id;
//   }
//   getFriendId(){
//     var id = this.from;
//     if(User.currentUser.documentID == this.from){
//       id = this.to;
//     }
//     return id;
//   }
// }
//
// //临时聊友, 当助理拉不是我的医生的医生，创建临时聊天聊友关系
// class ChatFriendShip extends DBModel{
//   from:User;  //请求的user id
//   to:User;    //邀请的user id
//   message:String; //邀请时发送的信息
//   name:String; //聊友临时聊天标题
//   fromType:Number; //请求的user type
//   toType:Number; //邀请的user type
//   constructor(from,to) {
//     super("ChatFriendShip");
//     this.from = from;
//     this.to = to;
//     this.name = ""
//     this.fromType = -1 //-1 means unknown
//     this.toType = -1 //-1 means unknown
//     //避免2个人同时建了同一个ChatFriendShip，所以规定好id规则
//     //**ChatFriendShip和FriendShip都是一样的id规则，实质是其doc.type不同，以后
//     //转换成FriendShip直接认为是同一个doc_id+rev put即可
//     //根据以后的逻辑，如果聊友变成好友，需要删除ChatFriendShip并且新建FriendShip
//     this.documentID = Models.getChannle(this.from, this.to)
//   }
//   getMyId(){
//     var id = this.from;
//     if(User.currentUser.documentID != this.from){
//       id = this.to;
//     }
//     return id;
//   }
//   getFriendId(){
//     var id = this.from;
//     if(User.currentUser.documentID == this.from){
//       id = this.to;
//     }
//     return id;
//   }
// }
//
// //标签
// class Tag extends DBModel{
//   name:String;
//   patient:Patient;
//   constructor() {
//     super("Tag");
//     this.name = "";
//   }
// }
//
// //记录
// class Record extends DBModel{
//   status:Number;//状态 0：上传中 。1：上传完成\识别中。2:识别完成
//   patient:Patient;
//   user:User;
//   info:String;//识别的信息
//   images:Array;//有几张图片，结构{“objectKey”："xx","status"：true}
//   upload:Number;//上传了几张图片
//   recordType:String;//记录的类型，"出院"，”入院”，”图片”
//   remark:String;//备注
//   changed:Boolean;//识别完成后是否编辑
//   useUserChannel:Boolean;//channel  是否属于user,默认属于patient
//   needToAMD:Boolean;
//   summary:String;
//   AMD_id:String;
//   constructor() {
//     super("Record");
//     this.status = 0;
//     this.info = {};
//     this.images = [];
//     this.upload = 0;
//     this.remark = "";
//     this.changed = false;
//     this.user = User.currentUser.documentID;
//     this.useUserChannel = false;
//     this.needToAMD = true;
//     this.patient = null;
//     this.recordType = "";
//     this.summary = "";
//   }
// }
//
// class Group extends DBModel{
//   name:String;//群名字
//   members:Array;//群成员
//   socialType:Number; //群聊的社交类型, 1: 医生圈群聊, 2: 助理或管家建立的群聊
//   owner:User; //群主
//   constructor(name) {
//     super("Group");
//     this.name = "";
//     this.socialType = 2
//     this.members = [];
//     this.owner = ""
//     if(name)this.name = name;
//   }
// }
//
// //健康计划
// class Plan extends DBModel {
//   title:String;  //标题
//   status:Number; //状态 0：未完成， 1：已完成
//   info:String;   //内容
//   user:User;     //是给谁添加的计划
//   patient:Patient; //是给哪个病案添加的计划
//   time:String; //计划的时间
//   assistant:User; //添加这个计划的助理是谁
//   constructor(patient) {
//     super("Plan")
//     this.title = "";
//     this.status = 0;
//     this.info = "";
//     this.user = User.currentUser.documentID;
//     this.patient = patient;
//   }
// }
//
// //服务和资讯扩展里面的message参数->{icon,description:简介 /*title*/}
// //对于图片的扩展参数->{width,height,objectKey:图片唯一名字,status:上传状态(0-未完成，1-上传完成)}
// class Message extends DBModel {
//   channel:String;
//   messageType:Number;//0:普通消息, 1:图片消息, 2:forward病案, 3:资讯, 4:服务, 5:(系统)加入医生
//   message:String;
//   from:String;      //谁发送的消息
//   to:String;       //消息接受方
//   group:Group;       //是否是群消息
//   constructor(channel) {
//     super("Message");
//     this.messageType = 0;
//     this.message = "";
//     this.group = null;
//     if(channel){
//       this.channel = channel;
//     }else{
//       this.channel = "";
//     }
//     this.from = "";
//     this.to = "";
//   }
// }
//
// class Service extends DBModel {
//   channel:String;
//   name:String; //服务名称
//   send:User; //谁发的服务，助手的id
//   from:User; //谁提供的服务，医生的id
//   to:User;   //给谁加的服务
//   price:Number; //价钱
//   judgment:String; //服务的评价
//   rating:Number; //评分
//   service_date:Date; //服务的日期
//   patient:Patient; //服务的对象
//   payStatus:Number; //付费的状态，3表示付费成功
//   group:Group;    //是否是群服务，和医生聊天
//   needPay:Number; //是否需要支付
//   messageType:Number; //发送服务也是用消息的形式，类型值为4
//   message:String; //服务也是消息
//   providerType:Number; //1: 公司提供的服务，2:医生提供的服务
//   constructor(send,from,to) {
//     super("Service")
//     this.messageType = 4; //服务的类型
//     this.name = "";
//     this.send = send || "";
//     this.from = from || "";
//     this.to = to || "";
//     this.price = 0;
//     this.rating = 0;
//     this.judgment = "";
//     this.payStatus = 0;
//     this.group = null;
//     this.needPay = 1;
//     this.message = "";
//     this.channel = null;
//     this.service_date = new Date();
//     this.patient = null;
//   }
// }
//
// //银行帐号
// class Account extends DBModel {
//   bankName:String;       //开户行
//   cardNumber:String;        //账号
//   accountName:String;    //账户姓名
//   userId:String;         //账号所属哪个人的id
//   constructor(patient) {
//     super("Account")
//     this.bankName = "";
//     this.cardNumber = "";
//     this.accountName = "";
//     this.userId = User.currentUser.documentID;
//   }
// }
//
// class WebLink extends DBModel {
//   constructor(){
//     super("WebLink")
//     this.providerType = 1
//   }
//   url:String;
//   icon:String;
//   title:String;
//   providerType:Number; //如果resource_type为ServiceLink，1: 公司提供的服务，2:医生提供的服务
//   price:Number;  //如果resource_type为ServiceLink，则表示服务价格
//   description:String;
//   resourceType:String; //ServiceLink, ResourceLink
// }
//
// class Order extends DBModel {
//   out_trade_no:String; //商户单号
//   total_fee:Number; //支付金额
//   pay_status:String;//支付状态: SUCCESS(支付成功) REFUND(转入退款) NOTPAY(未支付) CLOSED(已关闭)
//                     //REVOKED(已撤销-刷卡支付）USERPAYING(用户支付中) PAYERROR(支付失败)
//   order_category:Number; //订单分类，2（续费）3（服务）
//   service_id:String; //order_category为3时需要
//   user_id:String;    //order_category为2时需要
//   constructor(){
//     super("Order");
//     this.out_trade_no = "",
//     this.total_fee = 0,
//     this.pay_status = ""
//     this.order_category = 3
//     this.user_id = ""
//     this.service_id = ""
//   }
// }
//
// //仅为debug使用
// class RemoteLog extends DBModel {
//   constructor(){
//     super("RemoteLog")
//     this.message = ""
//     this.user = ""
//     this.device = ""
//     this.dateTime = ""
//     this.platform = ""
//     this.keywords = ""
//   }
//   message:String;
//   user:User;
//   device:String;
//   dateTime:String;
//   platform:String;
//   keywords:String;
// }
//
// var Models = {
//   "User":User,
//   "Patient":Patient,
//   "FriendShip":FriendShip,
//   "Tag":Tag,
//   "Record":Record,
//   "Message":Message,
//   "Group":Group,
//   "Plan":Plan,
//   "Service":Service,
//   "ChatFriendShip":ChatFriendShip,
//   "Account":Account,
//   "WebLink":WebLink,
//   "RemoteLog":RemoteLog,
// };
//
// Models.modelForType = function(type){
//   if(type){
//     var obj = eval("new "+type +"();");
//     return obj;
//   }else{
//     return {};
//   }
// }
//
// Models.getChannle = function(name1,name2){
//   var arr =[];
//   arr.push(name1);
//   arr.push(name2);
//   arr.sort();
//   return arr[0] + "_" + arr[1]
// }
//

var {Models} = require('../../../JSLibrary/Logic');

module.exports = Models;
