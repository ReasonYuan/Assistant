/**
 *
 * 缓存用户信息
 * @author johnny 2015-12-17
 *
 */

'use strict';

var {WebLink} = require("../Models");
var {DatabaseView,DatabaseManager} = require("../couchbase/Couchbase");

class WebResLoader {

  //onDataReadyCallback返回数据，然后立即刷行
  constructor(resourceType, providerType, onDataReadyCallback, limit){
    if(resourceType != "WebService" && resourceType != "WebResource"){
      throw new Error("resourceType is not supported: " + resourceType)
    }
    if(providerType != 1 && providerType != 2 && providerType != 0){
      throw new Error("providerType is not supported: " + providerType)
    }

    var weblinkView =  new DatabaseView(DatabaseManager.instance.currentDatabase,"WebLink","weblink_"+resourceType + "_" + providerType, "function(doc) { if(doc.type == 'WebLink' && doc.resourceType == \"" + resourceType + "\" && doc.providerType == \"" + providerType + "\") { emit(doc.date||'0', doc); } }",()=>{
      weblinkView.setOnDataChangeCallback(function(data){
        weblinkView.stop()
        if(onDataReadyCallback) onDataReadyCallback(data)
      });
    });
    weblinkView.beforeUpdate = ()=>{
      weblinkView.descending = true;
      weblinkView.limit = limit ? limit : null //just for init view, so it's 1
    }
  }

}

module.exports = WebResLoader
