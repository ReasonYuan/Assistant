/**
 * 每一个Store可以根据
 * @author Johnny
 * @date 2015-12-30
 *
 */

'use strict';

var keyMirror = require("keymirror")

module.exports = keyMirror({
    USER_CACHE_UPDATED: null,
    // CREATE_MESSAGE: null,
    // RECEIVE_RAW_CREATED_MESSAGE: null,
    // RECEIVE_RAW_MESSAGES: null
})
