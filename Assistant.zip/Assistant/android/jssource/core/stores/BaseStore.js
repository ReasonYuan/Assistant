/**
 * 可以按按数据类型监听
 * @author Johnny
 * @date  2015-12-31
 *
 */

"use strict"

var _prefix = 'ID_';

class BaseStore {

  Dispatcher;

  constructor(Dispatcher){
    this.Dispatcher = Dispatcher
    this._lastID = 1
    this._callbacks = {}
    this.dispatchToken = this.Dispatcher.register((function(action){
      this.__onDispatch(action)
    }).bind(this))
  }

  clearCallbacks(){
    this._callbacks = {}
  }

  getDispatchToken(){
    return this.dispatchToken
  }

  getDispatcher(){
    return Dispatcher
  }

  addStoreListener(callback){
    var id = _prefix + this._lastID++;
    this._callbacks[id] = callback;
    return id;
  }

  removeAllStoreListeners(){
    this._callbacks = {}
  }

  removeStoreListener(callbackID){
    delete this._callbacks[callbackID]
  }

  __emitChanges(data, dataType){
    for(var key in this._callbacks){
      var callback = this._callbacks[key]
      if(callback) callback(data, dataType, this)
    }
  }

  __onDispatch(action){
    throw new Error("Subclass mush override __onDispatch(action) of BaseStore!!!")
  }

}

module.exports = BaseStore
