/**
 * 一般用一个Dispatcher就够了，所以这里导出一个全局的dispatcher
 * @author Johnny
 * @date 2015-12-30
 *
 */

'use strict';

var Dispatcher = require('flux').Dispatcher;

module.exports = new Dispatcher();
