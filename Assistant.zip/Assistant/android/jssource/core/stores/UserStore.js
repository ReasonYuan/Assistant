/**
 * 负责用户以及相关信息的数据
 * @author Johnny
 * @date  2015-12-30
 */

"use strict"

var DataDispatcher = require("./DataDispatcher")

var Actions = require("./Actions")
var BaseStore = require("./BaseStore")

class UserStore extends BaseStore {

  __onDispatch(action){
    switch (action.type) {
      case Actions.USER_CACHE_UPDATED:
        this.__emitChanges(action.users)
        break;
      default:
    }
  }

  logout(){
    this.clearCallbacks()
  }
  
}

var instance = new UserStore(DataDispatcher)

UserStore.instance = instance

module.exports = UserStore
