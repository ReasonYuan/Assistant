/**
 *
 * (主页)展示用户消息列表界面的父类。
 * 因为客户的消息和医生的消息在布局和功能上都差不多。
 * @author reason 2015-12-08
 *
 */

'use strict';

var React = require('react-native');

var {
  Alert,
  StyleSheet,
  TextInput,
  View,
  TouchableHighlight,
} = React;

var BaseComponent = require('./BaseComponent')
var Button = require('../widget/Button')
var {Tools,Color,fs,len} = require('../utils/Styles')
var {w,h} = require('../utils/Porting')

class EditTextView extends BaseComponent {

  constructor(props){
    super(props)
    this.value = props.value
    this.maxLength = props.maxLength
    this.state={navigatorBarConfig:{title:props.title,showBackIcon:true}}
  }

  onLeftPress(){
    this.pop()
  }

  onSureClick(){
    if(this.value == ""){
      Alert.alert("","输入内容不能为空",[{text:'确定'}])
      return
    }
    if(this.value == this.props.value){
      this.pop();
      return
    }
    if(this.maxLength && Tools.charLen(this.value)>this.maxLength.max){
      Alert.alert("",this.maxLength.des,[{text:'确定',onPress:()=>console.log('Cancel Pressed!')}])
      return
    }
    if(this.props.onSureClick){
      this.props.onSureClick(this.value)
    }
    this.pop()
  }

  _render(){
    return(
      <View style={istyles.full}>
        <View style={istyles.contaienr}>
          <TextInput style={istyles.input}
            defaultValue={this.value}
            keyboardType={this.props.keyboardType&&this.props.keyboardType}
            maxLength={this.props.maxLength&&this.props.maxLength.max}
            onChangeText={(text)=>{this.value=text}}/>
          <View style={istyles.line}/>
        </View>

        <Button
          title="确认"
          titleColor="#fff"
          style={istyles.sure}
          onTouch={()=>{this.onSureClick()}}/>
      </View>
    )
  }

}

var istyles = StyleSheet.create({
  full:{
    flex:1,
    paddingHorizontal:w(12)
  },
  contaienr:{
    flex:1,
  },
  input:{
    height:w(40),
    fontSize:fs('24'),
    marginTop:w(10),
    color:"#999",
    backgroundColor:"transparent"
  },
  line:{
    height:len('itemDivider'),
    backgroundColor:Color.itemDivider
  },
  sure:{
    marginBottom:w(50),
    height:h(35),
    backgroundColor:'#65c0b5'
  }
});

module.exports = EditTextView
