/**
 *
 * 账单列表,用于客户(病人)个人信息中账单案项的展示内容
 * @author reason 2015-12-13
 *
 */

'use strict';

var React = require('react-native');
var LocalCache = require("../sync/LocalCache")

var {
  StyleSheet,
  Text,
  View,
  ListView,
} = React;

var Config = require("../../constant/Config");
var {w,h,f} = require("../../utils/Porting")
var {fetchPost} = require("../../utils/SimpleFetch")
var FQListView = require('../../widget/FQListView')

class BillList extends React.Component {

    totalPrice = 0;

    constructor(props){
      super(props)
      this.bills = {}
      this.billList = []
      this.page = 1
      // this.patients = {}
      this.loading = false

      this.patientId = props.controller.customer.documentID

      this.state = {dataSource:new ListView.DataSource({rowHasChanged: (r1, r2) => r1 !== r2})}
      this.loadData()
    }

    componentDidMount(){
      this.show = true
    }

    componentWillUnmount(){
      this.show = false
    }

    nextPage(){
      if(this.loading)return
      if(this.patient.bills.length % 20 != 0)return
      this.loadData()
    }

    loadData(){
      // var billCacheKey = "bill_cache_key_" + this.page
      var self = this

      //刚启动界面要读取缓存
      // LocalCache.get(billCacheKey, function(data){
      //   if(data && !data.error){
      //     this.page++
      //     self.onDataChange(data)
      //   }
      // })

      this.loading = true
      fetchPost(Config.webBaoshiServerURL + "service/get_user_service",
        {to:this.patientId,payStatus:3,
        page:this.page,pateSize:20},
        (data)=>{
          this.loading = false
          if(data.error){
            self.props.controller.showToast(data.error)
          }else{
            if(!data || !data.services || data.services.length == 0)return
            this.page++
            self.onDataChange(data)
            // LocalCache.save(billCacheKey, data)
          }
        }
      )
    }

    onDataChange(data){
      if(data == this.bills[this.page-1])return

      this.bills[this.page-1] = data

      this.billList = []
      var keys = Object.keys(this.bills)
      for(var i = 0; i < keys.length; i++){
        var key = keys[i]
        this.billList = this.billList.concat(this.bills[key].services)
      }

      for(var i = 0; i < this.billList.length; i++){
        this.totalPrice += this.billList[i].price
      }

      if(this.show)this.setState({dataSource:this.state.dataSource.cloneWithRows(this.billList)})
    }

    // loadData(){
    //   if(!this.patient)return
    //   var self = this
    //   var patient = this.patient
    //   var self = this
    //
    //   //restful 获取数据
    //   this.loading = true
    //   fetchPost(Config.webBaoshiServerURL + "service/get_user_service",
    //     {userId:patient.id,payStatus:3,
    //     page:patient.page,pateSize:20},
    //     (data)=>{
    //       this.loading = false
    //       if(data.error){
    //         self.props.controller.showToast(data.error)
    //       }else{
    //         if(!data || !data.services || data.services.length == 0)return
    //         this.page++
    //         self.onDataChange(data)
    //         LocalCache.save(billCacheKey, data)
    //       }
    //     }
    //   )
    // }

    //当数据发生变化时，重新刷新UI
    // onDataChange(data){
    //   if(data == this.patient.bMap[this.page-1])return
    //
    //   var patient = this.patient
    //   patient.bMap[patient.page-1] = data
    //
    //   patient.bills = []
    //   var keys = Object.keys(patient.bills)
    //   for(var i = 0; i < keys.length; i++){
    //     var key = keys[i]
    //     patient.bills = patient.bills.concat(patient.bMap[key].services)
    //   }
    //
    //   for(var i = 0; i < patient.bills.length; i++){
    //     this.totalPrice += patient.bills[i].price
    //   }
    //
    //   if(this.show)this.setState({dataSource:this.state.dataSource.cloneWithRows(patient.billList)})
    // }

    //设置当前病人
    setPatient(patient){
      // if(!this.patients[patient.id]){
      //   patient.page = 1
      //   patient.bills = []
      //   patient.bMap = {}
      //   this.patients[patient.id] = patient
      // }
      this.patient = patient
      // this.loadData()
    }

    renderTotal(){
      return(
        <Text style={istyles.totalLabel}>合计: ¥{this.totalPrice.toFixed(2)}</Text>
      )
    }

    //渲染账单列表的cell
    renderRow(data){
      // var bill = data.value
      var strDate = new Date(+data.date).format("yyyy-MM-dd")
      return(
        <View style={istyles.cell}>
          <Text style={istyles.date}>{strDate}</Text>
          <View style={istyles.contentContainer}>
            <View style={{flex:1}}>
            <Text numberOfLines={2} style={istyles.contentLabel}>{data.name}</Text>
            </View >
            <View style={{width:80, justifyContent:"flex-end"}}>
              <Text style={istyles.itemPrice}>¥{data.price.toFixed(2)}</Text>
            </View>
          </View>
          <View style={istyles.itemDivider}/>
        </View>
      )
    }

    render(){
      return(
        <FQListView
          style={istyles.list}
          renderRow={this.renderRow}
          dataSource={this.state.dataSource}
          renderFooter={this.renderTotal.bind(this)}/>
      )
    }
}

var istyles = StyleSheet.create({
  list:{
    flex:1,
    marginBottom:w(20),
    marginLeft:w(12),
    marginRight:w(12)
  },
  cell:{
    height:w(60),
    justifyContent:"space-between"
  },
  payContainer:{
    flex:1,
    flexDirection:'row',
  },
  contentLabel:{
    fontSize:f(11),
    color:"#666666"
  },
  payLabel:{
    textAlign:'right',
    marginLeft:w(10)
  },
  totalLabel:{
    flex:1,
    textAlign:'right',
    color:"#f4a024",
    fontSize:f(12),
    marginTop:w(18)
  },
  itemPrice:{
    textAlign:"right",
    color:"#666666",
    fontSize:f(10),
    alignSelf:"flex-end",
    marginBottom:w(16)
  },
  date:{
    marginTop:w(8),
    color:"#333333",
    fontSize:f(12)
  },
  itemDivider:{
    height:w(1),
    backgroundColor:'#F2F3F3'
  },
  contentContainer:{
    flexDirection:'row',
    marginTop:w(6),
    flex:1,
  }
});

module.exports = BillList
