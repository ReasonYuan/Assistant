/**
 *
 * 医生详细信息界面(由所有医生列表的子项点击过来)
 * @author reason 2015-12-08
 *
 */

'use strict';

var React = require('react-native');

var {
  AppRegistry,
  StyleSheet,
  Text,
  Image,
  View,
  ListView,
  TouchableHighlight,
  Navigator
} = React;

var BaseComponent = require('../BaseComponent')
var Header = require('./DoctorHead');
var Cell = require('./DoctorCell');
var FQListView = require('../../widget/FQListView')
var DoctorSpaceDataSource = require("./DoctorSpaceDataSource")

class DoctorProfile extends BaseComponent{

  doctorSace:DoctorSpaceDataSource;

  constructor(props){
    super(props)
    this.isTabBarChild = true;

    this.doctor = this.props.user;

    var title = this.doctor.name || "医生"
    var config = {title:title+"的分享",showBackIcon:true};
    var ds = new ListView.DataSource({rowHasChanged: (r1, r2) => r1 !== r2});

    this.state = {navigatorBarConfig:config,dataSource:ds};
  }

  componentWillMount(){
    this.doctorSace = new DoctorSpaceDataSource(this.doctor.documentID || this.doctor.id, 10, (data)=>{this.onSpaceData(data)})
    this.doctorSace.getNextPageData()
  }

  onSpaceData(data){
    if(!data)return
    // console.log(data)
    this.setState({dataSource:this.state.dataSource.cloneWithRows(data.shareMessages)})
  }

  onLeftPress(){
    this.pop()
  }

  //聊天
  // onRightPress(){
  //   var message = {}
  //   message.talkers = [this.doctor]
  //   message.debugName = this.doctor.name
  //   message.relationship = {type:'FriendShip'}
  //
  //   var CustomerChat = require("../chat/DoctorChatView");
  //   this.pushWidthComponent(<CustomerChat navigator={this.props.navigator} message={message}/>)
  // }

  //一条分享内容被点击
  onItemClick(rowData){
    var ReadView = require("../readweb/ReadWebView");
  	this.pushWidthComponent(<ReadView navigator={this.props.navigator} title={"分享详情"} url={rowData.url}/>)
  }

  //渲染‘医生的分享’页面的Head，即医生的简介信息
  renderHeader(){
    return(<Header profile={this}/>)
  }

  //渲染一个分享内容
  renderRow(rowData,s,i){
    return (
      <Cell
        space={rowData}
        onClick={()=>this.onItemClick(rowData)}/>
    )
  }

  _render(){
    return (
        <FQListView
            automaticallyAdjustContentInsets={false}
        		dataSource={this.state.dataSource}
            renderHeader={this.renderHeader.bind(this)}
         		renderRow={this.renderRow.bind(this)}
            onScroll={(e)=>{
              if(e.nativeEvent.contentOffset.y + e.nativeEvent.layoutMeasurement.height - e.nativeEvent.contentSize.height > 60){
                this.doctorSace.getNextPageData();
              }
            }}
        />
    )
  }
}

var istyles = StyleSheet.create({
  // list:{
  //   // paddingLeft:10,
  //   // paddingRight:10,
  // },
  // cell:{
  //   marginTop:20
  // }
});

module.exports = DoctorProfile;
