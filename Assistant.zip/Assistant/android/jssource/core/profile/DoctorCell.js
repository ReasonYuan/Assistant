/**
 *
 * 医生详细信息页面的个人简介cell，包括头像、姓名等
 * @author reason 2015-12-08
 *
 */

'use strict';

var React = require('react-native');

var {
  AppRegistry,
  StyleSheet,
  Text,
  View,
  Image,
  TouchableHighlight,
  Navigator
} = React;

var {BaseComponent} = require('../../utils/Styles');
var {Color,len} = require('../../utils/Styles')
var {w,h,f} = require('../../utils/Porting')

class DoctorCell extends React.Component{

	  constructor(props){
    		super(props)
	  }

    loadIcon(imageUrl){
      if(imageUrl){
        return(
          <Image
            style={istyles.itemImage}
            source={{uri: imageUrl}}/>
        )
      }
    }

    //渲染医生分享内容子项，根据是否有图片分为两种类型
    renderItemInfo(info){
      return(
        <View style={istyles.infoContainer}>
          {
            this.loadIcon(info.imageUrl)
          }
          <Text numberOfLines={3} style={istyles.itemLabel}>{info.title}</Text>
        </View>
      )
    }

	render(){
    var space = this.props.space
    var date = space.date||space.update_time || space.createAt
    var time = date?new Date(+date).format("yyyy-MM-dd HH:mm"):""

    return (
      <TouchableHighlight
        underlayColor={Color.itemClick}
        onPress={(data)=>this.props.onClick(data)}>

        <View style={istyles.itemContainer}>
          <Text style={istyles.timeLabel}>{time}</Text>
          {
            this.renderItemInfo(space)
          }
        </View>

      </TouchableHighlight>
    )
	}
}

var istyles = StyleSheet.create({
  itemContainer:{
    marginHorizontal:w(12),
    paddingVertical:w(10),
    borderBottomWidth:len('itemDivider'),
    borderColor:Color.itemDivider,
  },
  timeLabel:{
    fontSize:f(13),
    marginBottom:h(10),
    color:Color.title
  },
  itemLabel:{
    flex:1,
    fontSize:f(13),
    color:'#999'
  },
  infoContainer:{
    flexDirection:'row'
  },
  itemImage:{
    width:w(80),
    height:h(50),
    marginRight:w(10),
    backgroundColor:'#ddd'
  },
});

module.exports = DoctorCell;
