/**
 *
 * 客户(病人)详细信息界面(由所有客户列表的子项点击过来)
 * @author reason 2015-12-08
 *
 */

'use strict';

var React = require('react-native');
var LocalCache = require("../sync/LocalCache")

var {
  StyleSheet,
  Text,
  Image,
  View,
  ListView,
  TouchableHighlight
} = React;

var BaseComponent = require('../BaseComponent')
var RecordList = require("../record/RecordList")
var PlanList = require("../plan/PlanList")
var BillList = require("../bill/BillList")
var Config = require("../../constant/Config")
var ReadView = require('../readweb/ReadWebView')

var User = require('../Models')

var {Color,len} = require('../../utils/Styles')
var {w,h} = require('../../utils/Porting')
var {Fetch} = require('../../../../JSLibrary/Logic')
let icons = [[require('../../res/icon_plan.png'),require('../../res/icon_plan_s.png')],
            [require('../../res/icon_record.png'),require('../../res/icon_record_s.png')],
            [require('../../res/icon_bill.png'),require('../../res/icon_bill_s.png')],
            [require('../../res/icon_health.png'),require('../../res/icon_health.png')]]

class CustomerProfile extends BaseComponent{

  //刚进入时立即读取缓存
  isJustLoadPage = true;

  constructor(props){
    super(props)

    this.isTabBarChild = true;
    this.customer = props.user;  //当前客户(患者)

    var title = this.customer.name || ""

    var rightIcon = null
    if(!props.hiddenMsg){
      rightIcon = require('../../res/icon_msg.png')
    }
    this.state = {
      type:0,    //当前所查看的信息类型，例如：计划，档案，账单等等
      navigatorBarConfig:{title:title,showBackIcon:true,rightIcon:rightIcon},
      dataSource:new ListView.DataSource({rowHasChanged: (r1, r2) => this.patientChange(r1,r2)})}
  }

//客户下面病案人物改变时刷新被选中的UI
  patientChange(r1,r2){
    return true
    //==YY==某客户详情，点击改变病案人物时，刷新被选中的UI，需要优化算法
    // if(r2.selChanged){
    //   r2.selChanged = false
    //   return true
    // }
    // return false
  }

  componentWillMount(){
    var shouldCacheData = this.isJustLoadPage
    var patientProfileCacheKey = "p_cache_key_" + this.customer.documentID
    if(this.isJustLoadPage){
      this.isJustLoadPage = false
      //刚启动界面要读取缓存
      LocalCache.get(patientProfileCacheKey, function(data){
        if(data && !data.error){
          self.onDataChange(data.rows)
        }
      })
    }

    //fetch server data
    var self = this

    Fetch.post("users/list_user_patients",{userid:this.customer.documentID},(data) => {
        if(data.error){
          self.showToast("网络异常，请稍后再试！")
        } else {
          // alert(JSON.stringify(data))
          self.onDataChange(data)
          if(shouldCacheData){
            LocalCache.save(patientProfileCacheKey, {rows:data})
          }
        }
    },Config.webAssistantServerURL);

    // fetch(Config.webAssistantServerURL + "users/list_user_patients", {
    //   method: "POST",
    //   headers: {'Content-Type': 'application/json'},
    //   body:JSON.stringify({userid:this.customer.documentID})
    // })
    // .then((response) => response.json())
    // .then((data) => {
    //     if(data.error){
    //       self.showToast("网络异常，请稍后再试！")
    //     } else {
    //       // alert(JSON.stringify(data))
    //       self.onDataChange(data)
    //       if(shouldCacheData){
    //         LocalCache.save(patientProfileCacheKey, {rows:data})
    //       }
    //     }
    // })
  }

  onDataChange(data){
    if(!data|| data.length == 0)return

    this.patients = data;
    this.patient = this.patients[0]
    this.setState({dataSource:this.state.dataSource.cloneWithRows(this.patients)})

    //得到病人列表后刷新下方list
    this.updateCurrentList()
  }

  onLeftPress(){
    this.pop()
  }

  //聊天
  onRightPress(){
    if(this.props.hiddenMsg){return}
    var message = {}
    message.debugName = this.customer.name
    message.talkers = [this.customer]
    message.relationship = {type:'FriendShip'}

    var CustomerChat = require("../chat/CustomerChatView");
    this.pushWidthComponent(<CustomerChat navigator={this.props.navigator} message={message}/>)
  }

  //关系按钮被点击，如果所选关系与上一次不一样，则更新下方列表数据
  onRelationClick(patient){
    // alert(patient.relationship)
    if(patient != this.patient){
      // patient.selChanged = true   //被选中，状态发生变化
      // if(this.patient)this.patient.selChanged = true  //取消选中，状态发生变化

      this.patient = patient
      this.setState({dataSource:this.state.dataSource.cloneWithRows(this.patients)})
      //状态改变，此时会重新渲染，刷新UI
      this.updateCurrentList()
    }
  }

  //信息类型按钮被点击，如果所选类型与上一次不一样，则更新下方列表数据
  onTypeClick(type){
    if(type == 3){
      var url = Config.webBaoshiServerURL + "selftest/get_by_patient_id?patient_id="+
        this.patient.id+"&is_self_view=false"
      this.pushWidthComponent(<ReadView navigator={this.props.navigator} title={"健康自测"} url={url}/>)
      return
    }
    if(this.state.type != type){
      this.setState({type:type})
      //状态改变，此时会重新渲染，刷新UI
      this.updateCurrentList()
    }
  }

  updateCurrentList(){
    var list = null
    switch(this.state.type){
      case 0:list = this.refs.plan; break;
      case 1:list = this.refs.record; break;
      case 2:list = this.refs.bill; break;
      default:list = this.refs.bill; break;
    }

    list.setPatient(this.patient)
  }

  //改变查看的类型
  renderList(){
    switch (this.state.type) {
      case 0:
        return (<PlanList ref="plan" controller={this}/>)
      case 1:
        return (<RecordList ref="record" controller={this}/>)
      case 2:
        return (<BillList ref="bill" controller={this}/>)
      default:
        return (<BillList ref="bill" controller={this}/>)
    }
  }

//渲染病人列表，例如：我、父亲、母亲等等
  renderPatient(patient){
    return(
      <TouchableHighlight
        underlayColor='#63c0b5'
        onPress={()=>{ this.onRelationClick(patient)}}
        style={[istyles.relationBtn,this.patient==patient && istyles.relationSelected]}>
        <Text style={[istyles.relationLabel,this.patient==patient && istyles.selectLabel]}>
          {patient.value.relationship}
        </Text>
      </TouchableHighlight>
    )
  }

  //的到列表类型的icon
  getTypeIcon(type){
    var team = icons[type]
    var idx = type == this.state.type?1:0
    return team[idx]
  }

  _render(){
    if(!this.patient){
      return(<View style={istyles.full}/>)
    }else{
      return (
        <View style={istyles.full}>
          <View style={istyles.relationList}>
            <ListView
              horizontal={true}
              showsHorizontalScrollIndicator={false}
              dataSource={this.state.dataSource}
              renderRow={this.renderPatient.bind(this)}/>
          </View>

          <View style={istyles.listType}>
              <TouchableHighlight
                underlayColor='transprent'
                onPress={()=>{ this.onTypeClick(0)}}>
                <Image
                  source={this.getTypeIcon(0)}
                  style={istyles.typeImg}
                  />
              </TouchableHighlight>


              <TouchableHighlight
                underlayColor='transprent'
                onPress={()=>{ this.onTypeClick(1)}}>
                <Image
                  source={this.getTypeIcon(1)}
                  style={istyles.typeImg}
                  />
              </TouchableHighlight>

              <TouchableHighlight
                underlayColor='transprent'
                onPress={()=>{ this.onTypeClick(2)}}>
                <Image
                  source={this.getTypeIcon(2)}
                  style={istyles.typeImg}
                  />
              </TouchableHighlight>
          </View>
          {
            this.renderList()
          }
        </View>
      )
      // <TouchableHighlight
      //   underlayColor='transprent'
      //   onPress={()=>{ this.onTypeClick(3)}}>
      //   <Image
      //     source={this.getTypeIcon(3)}
      //     style={istyles.typeImg}
      //     />
      // </TouchableHighlight>
    }
  }
}

var istyles = StyleSheet.create({
  full:{
    flex:1
  },
  relationList:{
    height:h(60),
    flexDirection:'row',
    alignItems:'center',
    borderBottomWidth:1,
    borderColor:Color.itemDivider,
    marginHorizontal:w(12)
  },
  listType:{
    height:h(75),
    flexDirection:'row',
    borderBottomWidth:1,
    borderColor:Color.itemDivider,
    alignItems:'center',
    marginHorizontal:w(12)
  },
  relationBtn:{
    width:w(40),
    height:w(40),
    marginRight:w(25),
    borderRadius:w(20),
    borderWidth:w(1),
    borderColor:'#63c0b5',
    justifyContent:'center',
    alignItems:'center'
  },
  relationLabel:{
    fontSize:12,
    color:'#63c0b5'
  },
  relationSelected:{
    backgroundColor:'#63c0b5'
  },
  selectLabel:{
    color:'#fff'
  },
  typeImg:{
    width:w(50),
    height:w(50),
    marginRight:w(32),
  }
});

module.exports = CustomerProfile;
