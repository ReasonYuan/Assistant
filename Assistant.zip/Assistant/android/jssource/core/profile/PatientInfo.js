/**
 *
 * 病人个人信息，客户帐号下管理‘人’的详情
 * @author reason 2015-12-13
 *
 */

'use strict';

var React = require('react-native');

var {
  Text,
  View,
  StyleSheet
} = React

var {w,h,f} = require('../../utils/Porting')
var {Color} = require('../../utils/Styles')

var BaseComponent = require('../BaseComponent')

class PatientInfo extends BaseComponent{

  constructor(props){
    super(props)
    var patient = props.patient.value

    this.state = {navigatorBarConfig:{title:patient.relationship,showBackIcon:true}}
  }

  onLeftPress(){
    this.pop()
  }

  _render(){
    var patient = this.props.patient.value
    var gender = patient.gender == 0 ? '男':'女'
    return(
      <View style={istyles.container}>
        <View style={istyles.item}>
          <Text style={istyles.titleLabel}>姓名</Text>
          <Text style={istyles.desLabel}>{patient.name}</Text>
        </View>
        <View style={istyles.item}>
          <Text style={istyles.titleLabel}>性别</Text>
          <Text style={istyles.desLabel}>{gender}</Text>
        </View>
        <View style={istyles.item}>
          <Text style={istyles.titleLabel}>生日</Text>
          <Text style={istyles.desLabel}>{patient.birthday}</Text>
        </View>
      </View>
    )
    // <View style={istyles.item}>
    //   <Text style={istyles.titleLabel}>联系电话</Text>
    //   <Text style={istyles.desLabel}>{patient.phone}</Text>
    // </View>
  }
}

var istyles = StyleSheet.create({
  container:{
    flex:1,
    paddingHorizontal:h(12)
  },
  item:{
    height:h(50),
    alignItems:'center',
    justifyContent:'space-between',
    flexDirection:'row',
    borderBottomWidth:1,
    borderColor:'#f1f1f1'
  },
  titleLabel:{
    fontSize:f(15),
    color:Color.title
  },
  desLabel:{
    fontSize:f(13),
    color:'#999'
  }
});


module.exports = PatientInfo
