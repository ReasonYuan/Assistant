

/**
 *
 * 聊天的通知消息，例如：消息时间，新加成员等的基类
 * type-->0:消息的时间,1:群聊中加入某人
 * @author reason 2015-12-08
 *
 */

'use strict';

var React = require('react-native');

var {
  Text,
  View,
  Image,
  StyleSheet,
  TouchableHighlight
} = React;

// var Button = require('../../widget/Button');
var ChatBaseCell = require("./CellBase")

var {w,h,screenWidth} = require('../../utils/Porting')
var {Config,Color,fs} = require('../../utils/Styles')   //birthday

let carWidth = screenWidth() - w(120)

class CellPatient extends ChatBaseCell {

	constructor(props){
    super(props)
    // this.msg.delete()
	}

  onMessageClick(){
    var title = "病案详情"

    // var WebView = require('../WebView')
    // var url = Config.webServerURL+"records/forward_view/?";
    // url += "records="+JSON.stringify(this.msg.message.records)
    //
    // this.chatView.pushWidthComponent({
    //   component:<WebView navigator={this.chatView.props.navigator} title={title} url={url}/>
    // });

    var RecordList = require('../record/MsgPatientRecordList')
    this.chatView.pushWidthComponent({
      component:<RecordList navigator={this.chatView.props.navigator} data={this.msg.message}/>
    });

  }

	renderContent(){
    var patient = this.msg.message.patient
      return(
        <View style={istyles.full}>
          <View style={istyles.iconContainer}>
            <Image style={istyles.icon} source={require('../../res/head_my.png')}/>
          </View>

          <View style={istyles.contentContainer}>
            <Text style={istyles.nameLabel}>{patient.name}</Text>
            <Text style={istyles.dspLabel}>{patient.gender==0?"男":"女"}</Text>
            <Text style={istyles.dspLabel}>{patient.birthday}</Text>
          </View>
          <Image style={istyles.type} source={require('../../res/icon_msg_patient.png')}/>
        </View>
      )
	}
}

var istyles = StyleSheet.create({
  full:{
    flexDirection:'row',
    width:carWidth,
    height:w(72),
    padding:w(6),

    borderWidth: w(1),
    borderRadius: h(4),
    borderColor: Color.chatBorder,
    overflow:'hidden'
  },
  iconContainer:{
    width:w(35),
    height:w(60),
    paddingRight:w(5),
    justifyContent:'center',
    alignItems:'center',
    borderRightWidth:w(1),
    borderColor:'#ecedee'
  },
  icon:{
    width:w(30),
    height:w(30),
    // borderRadius:w(5),
    // backgroundColor:'#000'
  },
  logo:{
    width:w(28),
    height:w(28),
    marginTop:h(2),
  },
  contentContainer:{
    flex:1,
    marginLeft:w(5),
    marginVertical:w(6),
  },
  nameLabel:{
    fontSize:fs('24'),
    marginBottom:w(7),
    color:'#333'
  },
  dspLabel:{
    fontSize:fs('20'),
    marginTop:w(2),
    color:"#999"
  },
  type:{
    width:w(36),
    height:w(36),
    position:'absolute',
    right:0,
    bottom:0
  }
});

module.exports = CellPatient;
