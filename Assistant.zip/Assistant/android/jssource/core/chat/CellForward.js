/**
 *
 * 聊天时呈现普通消息的Cell，即是文字消息
 *
 * @author reason 2015-12-08
 *
 **/

'use strict';

var React = require('react-native');
var {
  StyleSheet,
  Text,
  View,
  Image,
  TouchableHighlight,
} = React;

var ChatBaseCell = require("./CellBase")
var {User} = require('../Models')
var {w,h,screenWidth} = require('../../utils/Porting')
var {Color,fs} = require('../../utils/Styles')

let textWidth = screenWidth() - w(122)

class CellForward extends ChatBaseCell {

  constructor(props){
      super(props)
      this.state = {width:0}
  }

  //渲染聊天的详细信息（不带头像的）
  renderContent(){
    return(
      <View style={istyles.container}>
        <Text style={istyles.content}>授权给医生 {this.chatView.getDoctor().name} 查看健康档案 </Text>
      </View>
    )
  }
}

  // <Text style={istyles.browLabel}>查看</Text>

var istyles = StyleSheet.create({
  container:{
    flexDirection:'row',
    width:textWidth,
    padding:w(10),
    borderWidth: w(1),
    borderRadius: h(7),
    borderColor: Color.chatBorder,
  },
  content:{
    flex:1,
    color:'#60bfb3',
    fontSize:fs('22')
  },
  // browContaienr:{
  //   width:w(30),
  //   alignItems:'center',
  //   justifyContent:'center',
  //   backgroundColor:'#222'
  // },
  browLabel:{
    width:w(40),
    color:'e66776',
    fontSize:fs('22'),
    alignSelf:'center',
    textAlign:'center',
  },
});


module.exports = CellForward;
