/**
 *
 * 用户和客户（患者）的聊天界面，继承至BaseChatView
 * @author reason 2015-12-08
 *
 */

'use strict';

var React = require('react-native');

var {
  AppRegistry,
  StyleSheet,
  Text,
  View,
  Navigator
} = React;

var {Styles,Button,BaseComponent} = require('../../utils/Styles');
var BaseChatView = require('./BaseChatView')
var ChatDataSource = require("./ChatDataSource")
var { User } = require("../Models");

class CustomerChatView extends BaseChatView{

  constructor(props){
    super(props)

    var friend = this.getSignTalker()

    if(friend.role_type == 2){
      this.featureType = 1
    }

    this.chatDataSource = new ChatDataSource(User.currentUser, friend,
      null, null,(data)=>this.onDataChange(data));
  }
}

module.exports = CustomerChatView;
