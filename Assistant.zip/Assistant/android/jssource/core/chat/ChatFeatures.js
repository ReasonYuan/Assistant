'use strict';

var React = require('react-native');
var {
  StyleSheet,
  Text,
  Image,
  View,
  TouchableHighlight,
  ActionSheetIOS,
} = React;

var {DatabaseManager} = require("../couchbase/Couchbase");
var {User,Record,Patient,Message} = require("../Models")
var UIImagePickerManager = require('NativeModules').UIImagePickerManager;

var {Color,len} = require('../../utils/Styles')
var {w,h,f,screenWidth} = require('../../utils/Porting')

var icons = [require('../../res/icon_chatfeature_img.png'),
             require('../../res/icon_chatfeature_res.png'),
             require('../../res/icon_chatfeature_doctor.png'),
             require('../../res/icon_chatfeature_server.png')]

let dv = (screenWidth() - w(24) - w(200))/3

class ChatFeatures extends React.Component {
  constructor(props){
    super(props)
    this.chatView = props.chatView
    this.initFeatureType()
    // this.state = {type:0}
  }

  //判读扩展功能的类型，当群里有3个人时，需要判断显不显示发送医生选项，
  //因为，当群里3个人时，只有助理可以拉医生进群，而管家不能拉医生
  initFeatureType(){
    if(this.chatView.featureType == 2) return

    var count = this.chatView.group?this.chatView.group.members.length:2//存在是群聊，不存在是单聊
    if(count == 4){
      this.chatView.featureType = 2
      return
    }else if(count == 3){
      var assistant
      var patient
      var users = this.chatView.getUsers()
      for(var i = 0; i < users.length; i++){
        var user = users[i]
        if(user.documentID != User.currentUser.documentID){
          if(user.role_type == 0) {
            this.chatView.featureType = 2
            return
          } else if(user.role_type == 1 && user.assistant == User.currentUser.documentID) {
            this.chatView.featureType = 2
          }
        }
      }
    }
  }

  //发送资讯()
  selectResources(){
		var ResourcesList = require("../chatinfos/ChatResourcesList");
    this.push(ResourcesList);
  }

  //发送服务
  selectServers(){
	   var ServerList = require("../chatinfos/ChatServerList");
     this.push(ServerList);
  }

  //选择发送医生
  selectDoctor(){
    var users = this.chatView.getUsers();
    if(users.length == 2){//单聊拉人
      var SelectDoctor = require("../contacts/SelectDoctorList");
      this.push(SelectDoctor)
    }else{//群聊拉人
      var doctor
      var patient
      for(var i = 0; i < users.length; i++){
        var user = users[i]
        if(user.documentID != User.currentUser.documentID){
          if(user.role_type == 1) {patient = user}
          else if(user.role_type == 0){doctor = user}
        }
      }

      // if(!patient){this.chatView.showToast("网络异常，请稍后再试");return;}

      if(doctor || (patient && patient.assistant == User.currentUser.documentID)){//我是病人的管家
        this.chatView.showToast("你不能再添加医生进群了")
      }else{//我不是病人的管家，说明我是医生的助理，这时可以把医生来进来
        var SelectDoctor = require("../contacts/SelectDoctorList");
        this.chatView.pushWidthComponent(
          <SelectDoctor chatView={this.chatView} mydoctors={true}/>
        );
      }
    }
  }

  push(C){
    this.chatView.pushWidthComponent(
      <C chatView={this.chatView}/>
    );
  }

  showImageAction(){
    if(React.Platform.OS === 'ios') {
      ActionSheetIOS.showActionSheetWithOptions({
        options: ["拍照","相册图片","取消"],
        cancelButtonIndex: 2,
      },
      (buttonIndex) => {
        if(buttonIndex!=2)this.sendImage(buttonIndex)
        // if(buttonIndex == 0){this.sendImage(buttonIndex)}
        // else if(buttonIndex == 1){this.sendImgByAlbum()}
      });
    }else if(React.Platform.OS === 'android'){

      var options = {
        title:"选择头像",
        cancelButtonTitle: '取消',
        takePhotoButtonTitle: '拍照', // specify null or empty string to remove this button
        chooseFromLibraryButtonTitle: '选择图片', // specify null or empty string to remove this button
        maxWidth: 600,
        maxHeight: 600,
        quality: 0.7,
        allowsEditing: false, // Built in iOS functionality to resize/reposition the image
        noData: false, // Disables the base64 `data` field from being generated (greatly improves performance on large photos)
        storageOptions: { // if this key is provided, the image will get saved in the documents directory (rather than a temporary directory)
          skipBackup: true, // image will NOT be backed up to icloud
          path: User.currentUser.documentID+'/Images' // will save image at /Documents/images rather than the root
        }
      };

      React.NativeModules.ActionSheet.showActionSheet(["拍照","选择图片"],"取消",(index)=>{
          React.NativeModules.AndroidSelectPhoto.selectPhoto(index,options,(response)=>{
            var message = new Message();//this.channel
            message.messageType = 1;
            message.message = {width:response.width,height:response.height,objectKey:response.fileName,status:0}; //本地图片名
            message.from = User.currentUser.documentID;
            // message.to = self.props.friend.getFriendId();
            this.chatView.sendInfoMessage(message,()=>{
              DatabaseManager.instance.currentDatabase.checkUploadFile();
            })
          })
        })
    }
  }

  //发送图片
  sendImage(index){
    var options = {
      maxWidth: 600,
      maxHeight: 600,
      quality: 0.7,
      allowsEditing: false, // Built in iOS functionality to resize/reposition the image
      noData: false, // Disables the base64 `data` field from being generated (greatly improves performance on large photos)
      storageOptions: { // if this key is provided, the image will get saved in the documents directory (rather than a temporary directory)
        skipBackup: true, // image will NOT be backed up to icloud
        path: User.currentUser.documentID+'/uploadImages' // will save image at /Documents/images rather than the root
      }
    }

    var self = this
    var selectImgCallback = function(didCancel, response){
     if (didCancel) return;
     var message = new Message();//this.channel
     message.messageType = 1;
     message.message = {width:response.width,height:response.height,objectKey:response.fileName,status:0}; //本地图片名
     message.from = User.currentUser.documentID;
     // message.to = self.props.friend.getFriendId();
     self.chatView.sendInfoMessage(message,()=>{
       DatabaseManager.instance.currentDatabase.checkUploadFile();
     })
   }


    if(index == 0){//从相册选图片发送
      UIImagePickerManager.launchCamera(options,
        (didCancel, response) => selectImgCallback(didCancel, response));
    }else{ //拍摄图片发送
      UIImagePickerManager.launchCustomImageLibrary(options,
        (didCancel, response) => selectImgCallback(didCancel, response));
    }
  }

  renderFeatures(){
    switch (this.chatView.featureType) {
      case 0:
        return this.renderCustomerFeatures();
      case 1:
        return this.renderDoctorFeatures();
      case 2:
        return this.renderGroupFeatures();
      default:
      return this.renderCustomerFeatures();
    }
  }

  render() {
    this.initFeatureType()
    return (
      <View>
        {this.renderFeatures()}
      </View>
    )
  }

  renderItem(title,index,press){
    return(
      <View style={index != 3 && istyles.item}>
          <TouchableHighlight
            underlayColor='#ccc'
            onPress={press}>
            <Image style={istyles.icon} source={icons[index]}/>
          </TouchableHighlight>
          <Text style={istyles.title}>{title}</Text>
      </View>
    )
  }

  //渲染和病人聊天时的附件
  renderCustomerFeatures(){
    return(
      <View style={istyles.featuresContainer}>
        {this.renderItem("图片", 0, this.showImageAction.bind(this))}
        {this.renderItem("资讯", 1, this.selectResources.bind(this))}
        {this.renderItem("医生", 2, this.selectDoctor.bind(this))}
        {this.renderItem("服务", 3, this.selectServers.bind(this))}
      </View>
    )
  }

  //渲染和医生聊天时的附件
  renderDoctorFeatures(){
    return(
      <View style={istyles.featuresContainer}>
        {this.renderItem("图片", 0, this.showImageAction.bind(this))}
      </View>
    )
  }
  //渲染群聊时的附件
  renderGroupFeatures(){
    return(
      <View style={istyles.featuresContainer}>
        {this.renderItem("图片", 0, this.showImageAction.bind(this))}
        {this.renderItem("资讯", 1, this.selectResources.bind(this))}
        {this.renderItem("服务", 3, this.selectServers.bind(this))}
      </View>
    )
  }
}

var istyles = StyleSheet.create({
  item:{
    marginRight:dv
  },
  featuresContainer:{
    height:w(80),
    paddingVertical:h(10),
    // paddingTop:h(10),
    paddingHorizontal:w(12),
    flexDirection:'row',
    // justifyContent:'space-between',
    alignItems:'flex-start',
    backgroundColor:'#f1f1f1',
  },
  icon:{
    width: w(50),
    height: w(50),
  },
  button : {
    width: w(50),
    height: w(50),
    // flex:1,
    // margin:10
  },
  title:{
    marginTop:w(4),
    fontSize:f(11),
    color:"#e96978",
    alignSelf:'center',
  }
})

ChatFeatures.Height = w(80);//217 / 2;

module.exports = ChatFeatures;
