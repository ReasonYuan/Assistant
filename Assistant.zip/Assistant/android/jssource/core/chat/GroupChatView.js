/**
 *
 * 用户和医生与病人创建组的聊天界面，继承至BaseChatView
 * @author reason 2015-12-08
 *
 */

'use strict';

var React = require('react-native');

var {
  View,
  Navigator
} = React;

var { User,Group,Message } = require("../Models");
var {BaseComponent} = require('../../utils/Styles');
var BaseChatView = require('./BaseChatView')
var ChatDataSource = require("./ChatDataSource")
var Constant = require('../../constant/Constant')
var UserCacheManager = require('../users/UserCacheManager')
var GroupCacheManager = require('../users/GroupCacheManager')

class GroupChatView extends BaseChatView{

  constructor(props){
    super(props)

    var talkers = props.message.talkers
    if(talkers){//有用户组，表示新建的群
      var group = new Group()
      group.name = props.message.debugName
      var ids = []
      for(var i = 0; i < talkers.length; i++){
        var talker = talkers[i]
        ids.push(talker.documentID)
      }
      ids.push(User.currentUser.documentID)

      //检查群成员是否全部在另外的一个群里存在，如果存在，则直接进入已经存在的群聊天
      var existsGroup = GroupCacheManager.instance.findSameMembersGroup(ids)
      if(existsGroup){
        console.log("open exists group(1):" + existsGroup);
        this.openExistsGroupChat(existsGroup)
      } else {

        var self = this
        //通知服务器新建群聊
        // group.name = props.message.debugName
        group.members = ids
        group.save(function(savedGroup){
          if(savedGroup){
            //建立聊群source
            self.chatDataSource = new ChatDataSource(User.currentUser, null,
              null, group,(data)=>self.onDataChange(data));

            //新建的群，在群建好以后需要发送邀请信息
            for(var i = 0; i < talkers.length;i++){
              if(talkers[i].role_type == Constant.Role_Doctor){//只发送拉入医生的名片
                var msg = new Message()
                var user = talkers[i]

                //不改底层的数据，自己new一个发送
                var usr = {documentID:user.documentID,name:user.name,
                          department:user.department,headIcon:user.headIcon,
                          hospital:user.hospital,role_type:Constant.Role_Doctor}

                msg.messageType = Constant.MSG_ADDMEMBER
                msg.message = usr
                self.sendInfoMessage(msg)
              }
              //User.currentUser.name + "邀请"+talkers[i].name+"进入本群"
            }
          } else {
            self.pop()
          }
        })
        this.group = group
      }
    }else {//已经存在的群
      var group = props.message.relationship
      if(!group){this.showToast("网络异常，请稍后重试");return}
      this.openExistsGroupChat(group)
    }
  }

  //根据已有的群来聊天
  openExistsGroupChat(group){
    var toOtherGroup = false

    if(this.chatDataSource){
      //如果是跳转到其他群，释放之前的数据和资源
      this.chatDataSource.stop()
      this.chatDataSource = null
      toOtherGroup = true
    }

    this.chatDataSource = new ChatDataSource(User.currentUser, null,
      null, group,(data)=>this.onDataChange(data));
    this.group = group
  }

  checkIfGroupExists(members){
    return GroupCacheManager.instance.checkIfGroupExists(members)
  }

  //在群聊中给群添加成员
  addMember(user){
    if(!user)return;
    var self = this

    // var tempMembers = [user.documentID]
    // for(var i=0; i<this.group.members.length; i++){
    //   tempMembers.push(this.group.members[i])
    // }

    //检查群成员是否全部在另外的一个群里存在，如果存在，则直接进入已经存在的群聊天
    // var existsGroup = GroupCacheManager.instance.findSameMembersGroup(tempMembers)
    var existsGroup = null

    if(existsGroup){
        console.log("open exists group(2): " + existsGroup);
        this.group = null
        this.openExistsGroupChat(existsGroup)
    } else {
      this.group.members.push(user.documentID)
      this.group.save(function(savedGroup){
        if(savedGroup){
          //添加成员，成功以后需要发送邀请信息
          var msg = new Message()

          //不改底层的数据，自己new一个发送
          var usr = {documentID:user.documentID,name:user.name,
                    department:user.department,headIcon:user.headIcon,
                    hospital:user.hospital,role_type:Constant.Role_Doctor}
          msg.messageType = Constant.MSG_ADDMEMBER
          msg.message = usr//User.currentUser.name + "邀请"+user.name+"进入本群"
          self.sendInfoMessage(msg)
        } else {
          self.showToast("添加成员失败，请稍后再试!")
        }
      })
    }
  }

}

module.exports = GroupChatView;
