/**
 *
 * 用户和医生的聊天界面，继承至BaseChatView
 * @author reason 2015-12-08
 *
 */

'use strict';

var React = require('react-native');

var {
  AppRegistry,
  StyleSheet,
  Text,
  View,
  Navigator
} = React;

var {Styles,Button,BaseComponent} = require('../../utils/Styles');
var BaseChatView = require('./BaseChatView')
var ChatDataSource = require("./ChatDataSource")
var {User, ChatFriendShip} = require("../Models");
var ChatFriendShipManager = require("../users/ChatFriendShipManager")

class DoctorChatView extends BaseChatView{

  constructor(props){
    super(props)

    //找到聊天的对象
    var chatFriend = this.getSignTalker()
    if(!chatFriend){
      this.showToast("服务器异常，请稍后重试")
      return
    }

    //根据聊天场景确定拉的聊天对象是医生还是这个医生的助理
    var doctor = null;
    //这里还要判断是否是我负责的医生，如果是我负责的医生，就不需要拉医生的助理
    if(chatFriend.assistant != null && chatFriend.assistant != User.currentUser.documentID){
      //doctor is friend
      doctor = chatFriend
      //实际上是和医生的助理聊天
      chatFriend = new User()
      chatFriend.role_type = 2
      chatFriend.documentID = doctor.assistant
      chatFriend.name = chatFriend.name + "的助理"

      //在chatDataSource里会创建ChatFriendShip，所以这里不要创建了，以下代码注释掉
      // //check the ChatFriendShip exists or not
      // var existsFriendShip = ChatFriendShipManager.instance.getChatFriendShipByMembers(User.currentUser.documentID, chatFriend.documentID)
      // if(!existsFriendShip){
      //   //必须创建一个ChatFriendShip
      //   var newChatFriendShip = new ChatFriendShip(User.currentUser.documentID, chatFriend.documentID)
      //   //两个都是助理
      //   newChatFriendShip.fromType = 2
      //   newChatFriendShip.toType = 2
      //   newChatFriendShip.save()
      // }
    }

    //判断是不是在和医生聊天
    this.featureType = 1;//(chatFriend.role_type == 0)?1:0

    //和医生聊天，(根据我是不是这个医生的好友)可能和他聊也可能和他助理聊，所以聊天的对象会不同
    this.friend = chatFriend

    this.chatDataSource = new ChatDataSource(User.currentUser, chatFriend,
      doctor, null,(data)=>this.onDataChange(data));
  }

  // getProfileView(){
  //   var doctorProfile = require("../profile/DoctorProfile");
  //   return doctorProfile
  // }

}

module.exports = DoctorChatView;
