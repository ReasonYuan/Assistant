/**
 *
 * 聊天时呈现图片消息的Cell，在显示图片时使用
 *
 * @author reason 2015-12-15
 *
 **/

'use strict';

var React = require('react-native');
var {
  StyleSheet,
  Text,
  View,
  Image,
  TouchableHighlight,
} = React;

var {User,Patient,FriendShip,Message} = require("../Models");
var Dimensions = require('Dimensions');
var ImageView = require('../../widget/ImageView')
var ChatBaseCell = require('./CellBase')
var Constant = require('../../constant/Constant')
var MessageImageView = require('./MessageImageView');

var {w,h} = require('../../utils/Porting')
var{Color} = require('../../utils/Styles')

class CellImage extends ChatBaseCell {
  maxlayout:0;

  constructor(props){

    super(props)

    let imageWidth = this.msg.message.width;
    let imageHeight = this.msg.message.height;
    let screenWidth = Dimensions.get('window').width;
    var maxlayout = screenWidth - 54 - 6*6;
    if(imageWidth < imageHeight){
      maxlayout = maxlayout / 2;
    }else{
      maxlayout = maxlayout * 2 / 3;
    }
    this.maxlayout = maxlayout;
    // return{
    //   head:null,
    //   progress:1,
    //   image:null,
    // }
  }


  onMessageClick(){
    var usrId = User.currentUser.documentID

    var index = 0
    var count = 0
    var imgs = []
    var msgs = this.chatView.messages;
    for(var i = msgs.length - 1; i > -1; i--){
      var msg = msgs[i]
      if(msg.messageType == Constant.MSG_IMAGE){
        var img = {userId:usrId}
        img.key = msg.message.objectKey
        imgs.push(img)

        if(msg == this.msg){//当前图片所在的序号
          index = count
        }
        count++
      }
    }

    var BrowseImages = require('../BrowseImages')
    this.chatView.pushWidthComponent(
      <BrowseImages navigator={this.chatView.props.navigator} source={imgs} index={index}/>
    );
  }

  renderContent(){
    let imageWidth = this.msg.message.width;
    let imageHeight = this.msg.message.height;
    var layoutWith = 0;
    var layoutHeight = 0;
    var maxlayout = this.maxlayout;
    if(imageWidth >= maxlayout){
      layoutWith = maxlayout;
      layoutHeight = imageHeight * (maxlayout / imageWidth);
    }else{
      layoutWith = imageWidth;
      layoutHeight = imageHeight;
    }

    return (
      <View>
        <MessageImageView
           resizeMode='cover'
           style={[styles.image,{width:layoutWith,height:layoutHeight}]}
           imageKey = {this.props.message.message.objectKey}
           message = {this.props.message}/>
       </View>
    )
      // <ImageView
      //    resizeMode='cover'
      //    style={[styles.image,{width:layoutWith,height:layoutHeight}]}
      //    imageKey = {this.msg.message}//this.props.message.message.objectKey
      //  />
    // }
  }
}

var styles = StyleSheet.create({
  // content: {
  //   flex: 1,
  //   alignItems: 'stretch',
  // },
  // context: {
  //   flex: 1,
  //   backgroundColor:'#F6F6F6',
  //   justifyContent:'center',
  //   alignItems:'center',
  //   margin:10,
  //   borderWidth: 1,
  //   borderRadius: 8,
  //   borderColor: '#CCC',
  //   padding:6
  // },
  image:{
    // margin:1,
    borderWidth: w(1),
    borderRadius: h(8),
    borderColor: Color.chatBorder,
    // borderRadius: 8,
  }
});

module.exports = CellImage;
