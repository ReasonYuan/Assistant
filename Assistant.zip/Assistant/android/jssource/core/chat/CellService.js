/**
 *
 * 聊天时呈现资讯和服务消息的Cell，现在两种用同一个cell
 *
 * @author reason 2015-12-15
 *
 **/

'use strict';

var React = require('react-native');
var {
  StyleSheet,
  Text,
  View,
  Image,
  TouchableHighlight,
} = React;

var ChatBaseCell = require("./CellBase")

var Tools = require('../../utils/Tools')
var {w,h,f,screenWidth} = require('../../utils/Porting')
var {Color,Config} = require('../../utils/Styles')

let resWidth = screenWidth() - w(120)

class CellService extends ChatBaseCell{

  constructor(props){
      super(props)
  }

  onMessageClick() {
    var Judge = require('../service/ServiceJudge')
    this.chatView.pushWidthComponent(
      <Judge navigator={this.chatView.props.navigator} service={this.msg.message}/>
    )

    // var url = Config.webBaoshiServerURL+"payment/pay_service?serviceId="+this.msg.message.serviceId;
    // var ReadView = require("../readweb/ReadWebView")
    // this.chatView.pushWidthComponent(
    //   <ReadView navigator={this.chatView.props.navigator} url={url}/>)
  }

  //渲染聊天的详细信息（不带头像的）
  renderContent(){
    var msg = this.msg.message

    return(
      <View style={istyles.cell}>
        <View style={istyles.content}>
          <Image style={istyles.icon} source={{uri: msg.icon}}/>
          <View style={istyles.full}>
              <Text numberOfLines={1} style={istyles.desLabel}>¥{msg.price.toFixed(2)}</Text>
              <Text numberOfLines={2} style={istyles.desLabel}>提供者:{msg.provider}</Text>
              <Text numberOfLines={3} style={istyles.desLabel}>{msg.title}</Text>
          </View>
        </View>
      </View>
    )
  }
}

var istyles = StyleSheet.create({
  full:{
    flex:1,
  },
  cell:{
    width:resWidth,
    height:w(75),
    padding:w(6),

    borderWidth: w(1),
    borderRadius: h(4),
    borderColor: Color.chatBorder,
  },
  content:{
    flexDirection:'row',
  },
  icon:{
    width:w(40),
    height:w(40),
  },
  desContainer:{
    flex:1,
    marginLeft:w(5),
  },
  desLabel:{
    flex:1,
    marginBottom:w(2),
    marginLeft:w(5),
    fontSize:f(10),
    color:'#666'
  }
});


module.exports = CellService
