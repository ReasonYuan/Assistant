'use strict';

var Models = require("../Models");
var {User,Group,Patient,FriendShip,Message,Service,ChatFriendShip} = Models;
var {DatabaseView,DatabaseManager} = require("../couchbase/Couchbase");
var DatabaseHelper = require("../helper/DatabaseHelper")
var Config = require("../../constant/Config")
var MessageManager = require("../message/MessageManager")

class ChatDataSource {

  //我自己
  me:User = null;
  //朋友
  friend:User = null;
  //聊友助理负责的医生
  doctor:User = null;
  //群聊group, group.members是组员
  group:Group = null;

  //数据channel
  channel = null;
  //first message key
  firstMessageKey:String;
  //history message begin with doc id, 不包括该docid
  historyKeyBefore:String;
  //history skip
  historySkip:Number = 0;

  //historyMsgBuffer
  historyMsgBuffer = [];
  //latest msg buffer
  latestMsgBuffer = [];
  //如果第一次显示的消息列表数小于第一次设置的limit，这一定没有历史消息
  hasHistoryMessages = true;

  FIRST_PULL_MESSAGE_SIZE = 10;
  //friend 和 group 中的一个必须为null, 如果me和friend只是聊友关系，doctor必不为空
  //3种参数形式：
  //a: 普通朋友： me, friend, null, null, callback
  //b: 医生助理聊友：me, friend, doctor, null, callback
  //c: 群聊: me, null, null, group, callback
  constructor(me, friend, doctor, group, updateMsgListCallback){
    if(friend != null && group != null){
      throw new Error("'friend, me' 和 group 中的一个必须为null")
    }
    //检测参数

    var assistantSubfix = "的助理"
    this.firstMessageKey = null
    this.historyKeyBefore = null
    this.me = me
    this.friend = friend
    this.group = group
    this.newCreatedChatFriendShip = null
    if(this.friend != null) {
      this.friend.documentID = (this.friend.documentID || this.friend._id || this.friend.id)
    }
    this.doctor = doctor
    if(doctor != null) this.chatfriendTitle = doctor.name + assistantSubfix

    //create channel view
    var self = this
    var initDatabaseViewAndChannel = function(){
      var db = DatabaseManager.instance.currentDatabase;
      var viewSearchSub = ""
      if(self.group){
        viewSearchSub = "doc.group == '" + self.group.documentID + "'"
      } else {
        viewSearchSub = "doc.channel == '" + self.channel + "'"
      }
      var channelMessageView =  new DatabaseView(db,"Message","MessageView_"+self.channel,"function(doc) { if((doc.type == 'Message') && ( " + viewSearchSub + " )) { emit(''+doc.date,doc);} }",()=>{
        channelMessageView.setOnDataChangeCallback(
          (data)=>{
            self.onDataChanged(data)
          });
      });
      channelMessageView.beforeUpdate = ()=>{
        if(!self.firstMessageKey){
          channelMessageView.limit = self.FIRST_PULL_MESSAGE_SIZE;
          channelMessageView.descending = true;
        }else{
          channelMessageView.startKey = self.firstMessageKey;
          channelMessageView.limit = null;
          channelMessageView.descending = null;
        }
      }
      self.channelMessageView = channelMessageView;
      MessageManager.instance.setCurrentChattingChannel(self.channel)
    }

    this.updateMsgListCallback = updateMsgListCallback
    if(this.friend != null && doctor != null){
      //是否存在这样的friendship, 如果不存在则建立临时聊友关系
      //如上情况是因为如果医生不是助理的朋友，助理也能够和医生的助理聊天，为了区分助理和医生的聊天记录，建立临时聊友关系
      var keystart = Models.getChannle(friend.documentID, me.documentID)
      DatabaseHelper.searchDocByKey(Config.bootDBViews.chatFriendShipView, keystart, function(data){
        self.channel = Models.getChannle(self.friend.documentID, self.me.documentID)
        if(data.error || data.status===404 || data.rows.length == 0){
          //聊友友关系
          var chatFriendShip = new ChatFriendShip(self.me.documentID, self.friend.documentID)
          chatFriendShip.name = doctor.name + assistantSubfix
          chatFriendShip.fromType = self.me.role_type
          chatFriendShip.toType = self.friend.role_type
          //不要save，除非用户开始说话，否则这个聊友关系不存在
          //chatFriendShip.save()
          self.newCreatedChatFriendShip = chatFriendShip
        } else {
          //查询出来发现已经有聊友关系了，什么也不用做
          //console.log("data: " + data)
          if(data.rows.length > 0) {
            self.chatfriendTitle = data.rows[0].value.name || ""
            //TODO update chat room title
          }
        }
        initDatabaseViewAndChannel()
      })
    } else if(group == null) {
      //朋友关系
      this.channel =  Models.getChannle(this.friend.documentID, this.me.documentID)
      initDatabaseViewAndChannel()
    } else {
      //群聊
      this.channel = this.group.documentID
      initDatabaseViewAndChannel()
    }

  }

  //该界面停止监听消息
  stop(){
    if(this.channelMessageView) this.channelMessageView.stop()
  }

  //pull history messages
  pullHistoryMessages(){
    if(!this.hasHistoryMessages){
      return
    }
    var _this = this;
    var ignoreFirstItem = this.historySkip == 0
    if(this.historyKeyBefore){
      this.channelMessageView.getHistoryDocs(this.historyKeyBefore, this.historySkip, 5, true, function(data){
        if(data.length > 0){
          _this.historySkip += data.length
        }

        var messages = [];
        for (var i = 0; i < data.length; i++) {
          if(i == 0 && ignoreFirstItem){
            continue;
          }
          var message = new Message();
          // if(data[i].value.type == 'Service'){
          //   message = new Service();
          // }
          message.setProperty(data[i].value);
          messages.push(message);
        }

        if(data.length > 0){
          _this.historyMsgBuffer = _this.historyMsgBuffer.concat(messages)
          _this.notifyOnMessagesChanged()
        } else {

        }
      })
    }
  }

  notifyOnMessagesChanged(){
    //TODO 需要优化，不要一起把所有消息拿去更新
    if(this.updateMsgListCallback){
      var concatedList = this.latestMsgBuffer.concat(this.historyMsgBuffer)
      if(concatedList.length > 0){
        //以下情况考虑到用户切换手机后消息列表未显示最近一条消息, 所以在这个channel看过之后才能显示最后一条消息
        MessageManager.instance.updateLatestMessageList(this.channel, concatedList[0])
      }
      this.updateMsgListCallback(concatedList)
    }
  }

  //发送简单文本消息
  sendSimpleMessage(text, onSentCallback){
    var msg = new Message()
    msg.message = text;
    this.sendMessage(msg, onSentCallback)
  }

  //发送消息, message的from, to, channel不需要提供， 其它信息需要参数message自己提供
  sendMessage(message, onSentCallback){
    if(this.newCreatedChatFriendShip != null){
      this.newCreatedChatFriendShip.save()
      this.newCreatedChatFriendShip = null
    }
    message.from = this.me.documentID
    if(this.friend){
      message.channel = this.channel
      message.to = this.friend.documentID
    } else {
      //group
      message.group = this.group.documentID
    }
    message.save(onSentCallback);
  }

  isValideDate(date){
    if ( isNaN( date.getTime() ) ) {  // d.valueOf() could also work
      // date is not valid
      return true
    }
    else {
      // date is valid
      return false
    }
  }

  onDataChanged(data){
    if(!this.firstMessageKey){
      if(data.length < this.FIRST_PULL_MESSAGE_SIZE){
        this.hasHistoryMessages = false
      }
      this.firstMessageKey = data[data.length - 1].key;
      this.historyKeyBefore = this.firstMessageKey
      this.channelMessageView.limit = null;
      this.channelMessageView.descending = null;
      this.channelMessageView.startKey = this.firstMessageKey;
      var sortFunc = function(a,b){
        return new Date(new Number(a.key)).getTime() - new Date(new Number(b.key)).getTime()
      }
      data.sort(sortFunc);
    }
    var messages = [];
    for (var i = 0; i < data.length; i++) {
      var message = new Message();
      if(data[i].value.type == 'Service'){
        message = new Service();
      }
      message.setProperty(data[i].value);
      messages.push(message);
    }
    messages.sort(function(a,b){
      return b.date.getTime() - a.date.getTime();
    })

    this.latestMsgBuffer = messages

    this.notifyOnMessagesChanged()
    //console.log("on msg list changed...")
  }

  getChatTitle(){
    if(this.isSimpleChat()){
      if(this.doctor != null){
        return this.chatfriendTitle
      } else {
        return this.friend.name == "" ? "#" : this.friend.name
      }
    } else {
      return this.group.name == "" ? "#" : this.group.name
    }
  }

  //是否是单聊
  isSimpleChat(){
    return this.group == null
  }

}

module.exports = ChatDataSource
