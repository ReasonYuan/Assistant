/**
 *
 * 聊天的通知消息，例如：消息时间，新加成员等的基类
 * type-->0:消息的时间,1:群聊中加入某人
 * @author reason 2015-12-08
 *
 */

'use strict';

var React = require('react-native');

var {
  Text,
  View,
  StyleSheet,
  TouchableHighlight
} = React;

// var Button = require('../../widget/Button');
var {w,f} = require('../../utils/Porting')

class SystemInfo extends React.Component{

	constructor(props){
    super(props)
	}

  //渲染新加成员
  renderMember(){
    // return(
      // <Button
      //   pressColor='#ccc'
      //   titleColor='#999'
      //   style={istyles.addButton}
      //   title={this.props.message.message}/>
    // )
  }

  //渲染消息时间
  renderTime(){
    return(
      <View style={istyles.timeContainer}>
        <Text style={istyles.contentLabel}>{this.props.message.message}</Text>
      </View>
    )
  }

  //名片写到另cellCard中了，这里不用了，目前只有系统时间
  // renderView(){
  //   switch (this.props.type) {
  //     case 0:
  //       return this.renderTime()
  //     case 1:
  //     default:
  //       return this.renderMember()
  //   }
  // }

	render(){
      return(
        <View style={istyles.timeContainer}>
          <Text style={istyles.contentLabel}>{this.props.message.message}</Text>
        </View>
        // <View style={istyles.full}>
        //   {
        //     this.renderView()
        //   }
        // </View>
      )
	}
}

var istyles = StyleSheet.create({
  // full:{
  //   flex:1
  // },
  timeContainer:{
    // height:22,
    marginTop:10,
    justifyContent:'center',
    alignItems:'center',
  },
  contentLabel:{
    // margin:10,
    fontSize:f(12),
    color:'#c1c1c1'
    // paddingLeft:5,
    // paddingRight:5,
    // borderRadius:5,
  },
  // addButton:{
  //   padding:10,
  //   width:200,
  //   height:45,
  //   justifyContent:'center',
  //   alignItems:'center',
  //   alignSelf:'center',
  //   marginTop:15,
  //   marginBottom:15,
  //   backgroundColor:'#0ff',
  //   borderRadius:5,
  // }
});

module.exports = SystemInfo;
