'use strict';

var React = require('react-native');
var {
  StyleSheet,
  Text,
  View,
  TouchableHighlight,
} = React;

var {User,Patient,FriendShip,Message} = require("../Models");

var Tools = require("../../utils/Tools")
var {Color,len} = require('../../utils/Styles')
var {w,h,f} = require('../../utils/Porting')

var ImageView = require('../../widget/ImageView')

class CellBase extends React.Component{

  constructor(props){
    super(props)
    this.msg = this.props.message;
    this.chatView = props.chatView;
  }

  // onReceiveProps(props){
  //   this.message = props.message;
  // }

  // componentDidMount(){
  //   alert(this.refs.cell)
  // }

//点击聊天对象的头像
  onHeadClicked(){
    var talker = this.chatView.getUserById(this.msg.from)
    this.toProfileView(talker)
    // if(talker.role_type == 2)return //助理、管家是不能看个人信息的
    // var ProfileView
    // if(talker.role_type == 0){//0是医生
    //   ProfileView = require("../profile/DoctorProfile")
    // }else if(talker.role_type == 1){//1是患者
    //   ProfileView = require("../profile/CustomerProfile")
    // }
    // this.chatView.pushWidthComponent(
    //   <ProfileView navigator={this.chatView.props.navigator} user={talker} hiddenMsg={true}/>
    // )
  }

  toProfileView(user){
    // if(user instantOf)
    if(user.role_type == 2)return //助理、管家是不能看个人信息的
    var ProfileView
    if(user.role_type == 0){//0是医生
      ProfileView = require("../profile/DoctorProfile")
    }else if(user.role_type == 1){//1是患者
      ProfileView = require("../profile/CustomerProfile")
    }
    this.chatView.pushWidthComponent(
      <ProfileView navigator={this.chatView.props.navigator} user={user} hiddenMsg={true}/>
    );
  }

  //这条消息被点击时触发的事件，由子类实现
  onMessageClick(){}

  //得到消息发送者得头像
  getHeadIcon(){
    var user = this.chatView.getUserById(this.msg.from)
    if(!user)user = UserCache.instance.getUserInfo(this.msg.from)

    if(user&&user.headIcon){
      return user.headIcon.objectKey
    }
    return null
  }

  //如果没有头像，则用默认头像
  getDefaultIcon(){
    return Tools.getHeadByUser(this.chatView.getUserById(this.msg.from))
  }

  //画聊天的详细信息（不带头像的）,由子类实现
  renderContent(){}

  render(){
    this.msg = this.props.message
    var icon = this.getHeadIcon()

    if(this.msg.from != User.currentUser.documentID){
      return (
        <View style ={[istyles.cell,istyles.cellOther]}>
          <TouchableHighlight
            underlayColor="transparent"
            onPress={this.onHeadClicked.bind(this)}>
            <ImageView style={istyles.head} imageKey={icon}
             defaultSource={this.getDefaultIcon()}
             source={this.getDefaultIcon()}/>
          </TouchableHighlight>

          <TouchableHighlight
            ref="content"
            onPress={this.onMessageClick.bind(this)}
            style={[istyles.msgContextOther]}
            underlayColor="transparent">
            { this.renderContent() }
          </TouchableHighlight>
        </View>
      )
    }
    return (
      <View style ={[istyles.cell,istyles.cellMe]}>
        <TouchableHighlight
          onPress={this.onMessageClick.bind(this)}
          style={[istyles.msgContextMe]}
          underlayColor="transparent">
          { this.renderContent() }
        </TouchableHighlight>

        <ImageView style={istyles.head} imageKey={icon}
          defaultSource={this.getDefaultIcon()}
          source={this.getDefaultIcon()}/>
      </View>
    )
  }
}



var istyles = StyleSheet.create({
  full:{
    // flex:1,
  },
  cell:{
    marginVertical:h(10),
    marginHorizontal:w(12),
    flexDirection:'row',
  },
  cellOther:{
    justifyContent:'flex-start',
  },
  cellMe:{
    justifyContent:'flex-end',
  },
  msgContextMe: {
    marginRight:w(8),
    // justifyContent:'center',
    // overflow:'hidden'
  },
  msgContextOther: {
    marginLeft:w(8),
    // justifyContent:'center',
  },
  head:{
    width:w(40),
    height:w(40),
    borderRadius:len('headRadius')
  }
});

module.exports = CellBase;
