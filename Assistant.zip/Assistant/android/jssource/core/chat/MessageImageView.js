//MessageManager
'use strict';

var React = require('react-native');
var {
  StyleSheet,
  Text,
  View,
  TouchableHighlight,
} = React;
var Models = require("../Models");
var {User,Patient,FriendShip,Message} = Models;
var {DatabaseView,DatabaseManager} = require("../couchbase/Couchbase");
var ImageView = require('../../widget/ImageView')

var Emitter = React.Platform.OS === "ios"?React.NativeAppEventEmitter:React.DeviceEventEmitter;

class MessageImageView extends React.Component {
  constructor(props) {
    super(props)
    this.state = {message:this.props.message,progress:0};
    this.addListener(this.props.message);
  }
  componentWillReceiveProps(nextProps){
    this.setState({message:nextProps.message,progress:0})
    this.addListener(nextProps.message);
  }
  removeListener(){
    if(this.listener){
      this.listener.remove();
      delete this.listener;
    }
  }
  addListener(message){
    this.removeListener();
    if(message.message.status != 1){
      this.listener = Emitter.addListener("NOTIFICATION_UPLOAD_IMAGE_PROGRESS",(data)=>{
        //data {key:imageKey,progress:0-1 }
        if(data.key == message.message.objectKey){
          this.setState({progress:data.progress});
        }
      });
    }
  }
  renderProgross(){
    if(this.state.message.message.status != 1){
      var flex = parseInt(this.state.progress*100);
      return (
        <View style={styles.full}>
          <View style={{flex:flex}} />
          <View style={{flex:100-flex,backgroundColor:'rgba(0,0,0,0.4)'}} />
          <View style={styles.overlay}>
           <Text style={styles.progress}>{flex+"%"}</Text>
          </View>
        </View>
      )
    }
  }
  render(){
    return (
      <ImageView {...this.props} imageKey = {this.state.message.message.objectKey}>
      {
        this.renderProgross()
      }
      </ImageView>
    )
  }
}

var styles = StyleSheet.create({
  full:{
    flex:1
  },
  overlay: {
    position: 'absolute',
    top: 0,
    bottom: 0,
    left: 0,
    right: 0,
    flex: 1,
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
  },
  progress:{
    fontSize:13,
    color:'white',
  },
});

module.exports = MessageImageView;
