// BrowerImages
'use strict';
var React = require('react-native');
var {
  StyleSheet,
  Text,
  View,
  Image,
  ListView,
  ScrollView,
  NativeModules,
  NativeAppEventEmitter,
} = React;

// var {ImageView,Styles,Color,BaseComponent,Tools} = require("../../Styles");
var BaseComponent = require('./BaseComponent')
var {w,h} = require('../utils/Porting')
var { requireNativeComponent } = React;
var GalleryView = requireNativeComponent('GalleryView', null);

/**
*source [{userId,key}]
**/
class BrowseImages extends BaseComponent {
  constructor(props) {
    super(props)
    var title = props.title || "图片"
    var config = {title:title,showBackIcon:true}
    this.state = {navigatorBarConfig:config}
  }
  componentWillMount(){
    this.listener = NativeAppEventEmitter.addListener("GalleryViewManager_onIndexChange",
      (index) => {
        if(this.props.onIndexChange)this.props.onIndexChange(this,index);
      }
    );
  }
  componentWillUnmount(){
    super.componentWillUnmount();
    if(this.listener)this.listener.remove();
  }
  onLeftPress(){
    this.pop();
  }
  _render(){
    return (
      <View style = {istyles.full} >
        <GalleryView
          style = {istyles.full}
          dataSource={ this.props.source}
          index={this.props.index || 0}/>
      </View>
    )
  }
}


var istyles = StyleSheet.create({
  full:{
    flex:1
  },
});


module.exports = BrowseImages;
