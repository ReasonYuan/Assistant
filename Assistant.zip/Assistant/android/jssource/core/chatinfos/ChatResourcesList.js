/**
 *
 * 用户和客户（患者）聊天时发送资讯的页面，继承至BaseInfoList
 * @author reason 2015-12-08
 *
 */

'use strict';

var React = require('react-native');

var {Config,Button,BaseComponent} = require('../../utils/Styles');
var Constant = require("../../constant/Constant")
var BaseChatView = require('./BaseInfoList')

var {fetchPost} = require("../../utils/SimpleFetch")

class ChatResourcesView extends BaseChatView{

  constructor(props){
    super(props)
    this.page = 1
    this.loading = false
    this.hasNextPage = false
    this.PAGE_SIZE = 10

    this.msgType = Constant.MSG_RESOURCE
  }

  getTitle(){
    return "资讯"
  }

  componentWillMount(){
    this.loadResources()
  }

  loadResources(){
    // var billCacheKey = "resources_cache_key_" + this.page
    var self = this
    this.loading = true

    fetchPost(Config.webBaoshiServerURL + "sharemessage/get_sharmessage_information",
      {page:this.page, pageSize:this.PAGE_SIZE},
      (data)=>{
        if(data.error){
          self.props.controller.showToast(data.error)
        }else{
          self.hasNextPage = (data.result.length == self.PAGE_SIZE)
          self.onDataChange(data.result,this.page)
          this.page++
          //LocalCache.save(billCacheKey, data)
        }
        self.loading = false
      }
    )
  }

  nextPage(){
    if(this.loading)return
    if(!this.hasNextPage)return
    this.loadResources()
  }

  scroll(e){
    if(e.nativeEvent.contentOffset.y + e.nativeEvent.layoutMeasurement.height - e.nativeEvent.contentSize.height > 50){
      this.nextPage();
    }
  }

}

module.exports = ChatResourcesView;
