/**
 *
 * 用户和客户（患者）聊天时发送服务的列表页面，继承至BaseInfoList
 * @author reason 2015-12-08
 *
 */

'use strict';

var React = require('react-native');

var {Styles,Button,BaseComponent} = require('../../utils/Styles')
var Constant = require("../../constant/Constant")
var BaseInfoList = require('./BaseInfoList')

var {User,Service} = require('../Models')
var WebResLoader = require('../webres/WebResLoader')

class ChatServerView extends BaseInfoList {

  constructor(props){
    super(props)

    this.msgType = Constant.MSG_SERVER
  }

  getTitle(){
    return "服务"
  }

  getProviderType(){
    if(this.props.chatView.group){
      var type = 1
      var doctor = this.props.chatView.getDoctor()
      if(doctor){
        type = 2
      }
      return type
    }
    return 1
  }

  componentWillMount(){
    var type = "WebService"
    new WebResLoader(type,this.getProviderType(),(data)=>{this.onDataChange(data,0)})
  }

  //点击一个信息子项，打开网页阅读
   onItemClicked(data){

     var service = new Service()
     service.name = data.title
     service.price = data.price
     service.providerType = data.providerType
     service.send = User.currentUser.documentID
     service.channel = this.props.chatView.chatDataSource.channel

     var doctor = null
     var users = this.props.chatView.getUsers()
     for(var i = 0; i < users.length; i++){
       var user = users[i]
       if(user.role_type == Constant.Role_Doctor){
         doctor = user
       }else if(user.role_type == Constant.Role_Care){
         service.patient = user.documentID
         service.to = user.documentID
         if(this.props.chatView.group){
           service.group = this.props.chatView.group
         }
       }
     }

     if(data.providerType == Constant.SER_PROVIDER_DOCTOR){//医生提供的服务
       if(doctor){
         service.from = doctor.documentID
         data.provider = doctor.name
       } else{ this.showMsg("发送服务失败")
         return }
     }else {
       service.from = User.currentUser.documentID   //公司提供的服务
       data.provider = "海苔健康"
     }

      service.save((ser)=>{
        if(!ser){
          this.showMsg("发送服务失败")
        }
        data.serviceId = ser.documentID
        this.sendMessage(data)
      })
   }


}

module.exports = ChatServerView;
