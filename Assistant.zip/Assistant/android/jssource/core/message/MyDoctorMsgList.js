/**
 *
 * (主页)展示医生消息列表的界面，继承至BaseMsgList
 * @author reason 2015-12-07
 *
 */

'use strict';

var React = require('react-native');

var {
  View,
  Text,
  Image,
  TouchableHighlight,
  StyleSheet,
} = React;

var BaseDoctorMsgList = require('./BaseDoctorMsgList')
var {Color,len,fs} = require('../../utils/Styles')
var {w,h} = require('../../utils/Porting')
var LatestMsgListDataSource = require('./LatestMsgListDataSource')

class MyDoctorMsgList extends BaseDoctorMsgList{

  constructor(props){
    super(props)
  }

  getTitle(){
    return "我的医生"
  }

  //获得消息列表时，logic需要传入的type类型，实现父类的方法
  getType(){
    return LatestMsgListDataSource.TYPE_DOCTOR_MSG_LIST
  }

  getRoleType(){
    return 0
  }

  //某条消息被点击
  // onItemClick(data){
  //   super.onItemClick(data)
  //
  //   //跳转到聊天界面
  //   var DoctorChat = require("../chat/DoctorChatView");
  //   this.props.navigator.push({
  //     component:<DoctorChat navigator={this.props.navigator} message={data}/>
  //   })
  // }

  //到所有医生的列表
  toDoctorList(){
    var DoctorList = require("../contacts/DoctorList");
    this.push(DoctorList)
  }

  renderHeader(){
    return(
      <TouchableHighlight
        underlayColor={Color.itemClick}
        onPress={()=>{this.toDoctorList()}}>
        <View style={{backgroundColor:'#FFFFFF'}}>
          <View style={istyles.content}>
            <Image style={istyles.icon} source={require('../../res/all_doctor.png')}/>
            <Text style={istyles.title}>所有医生</Text>
            <Image style={istyles.arrow} source={require('../../res/icon_arrow_right.png')}/>
          </View>
        </View>

      </TouchableHighlight>
    )
  }

}

var istyles = StyleSheet.create({
  content:{
    alignItems:'center',
    flexDirection:'row',
    height:h(60),
    marginHorizontal:w(12),
    borderBottomWidth:len('itemDivider'),
    borderColor:Color.itemClick
  },
  icon:{
    width:w(25),
    height:w(20),
    marginLeft:w(8),
  },
  title:{
    flex:1,
    marginLeft:w(19),
    fontSize:fs('28'),
    color:Color.title
  },
  arrow:{
    width:w(6),
    height:w(17),
  },
});

module.exports = MyDoctorMsgList;
