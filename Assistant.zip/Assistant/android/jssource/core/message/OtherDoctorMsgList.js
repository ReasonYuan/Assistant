/**
 *
 * (主页)展示医生消息列表的界面，继承至BaseMsgList
 * @author reason 2015-12-07
 *
 */

'use strict';

var React = require('react-native');

var {
  View,
  Text,
  Image,
  TouchableHighlight,
  StyleSheet,
} = React;

var BaseDoctorMsgList = require('./BaseDoctorMsgList');
var LatestMsgListDataSource = require('./LatestMsgListDataSource');
var UserIcon = require('../../widget/UserIcon');

var {w,h} = require('../../utils/Porting');
var {Color,len,fs} = require('../../utils/Styles');
var {User} = require('../Models');

class OtherDoctorMsgList extends BaseDoctorMsgList{

  getTitle(){
    return "医生助理"
  }

  //获得消息列表时，logic需要传入的type类型，实现父类的方法
  getType(){
    return LatestMsgListDataSource.TYPE_DOCTORS_ASSISTANT_MSG_LIST
  }

  getRoleType(){
    return 2
  }

  toMe(){
    var Me = require('../me/Me')
    this.push(Me)
  }

  renderHeader(){
    // var icon
    // var head = User.currentUser.headIcon
    // if(head){
    //   if(React.Platform.OS === 'android'){
    //     if(typeof(head) === 'string') {
    //       icon = head.substring(head.indexOf('=')+1,head.indexOf(','));
    //     }else{
    //       icon = head.objectKey;
    //     }
    //   }
    // }else if(React.Platform.OS === 'ios'){
    //   icon = head.objectKey;
    // }
    return(
      <TouchableHighlight
        underlayColor={Color.itemClick}
        onPress={()=>{this.toMe()}}>
        <View style={{backgroundColor:'#FFFFFF'}}>
          <View style={istyles.content}>
          <UserIcon style={istyles.icon} user={User.currentUser} defaultSource={require('../../res/head_assistant.png')}/>
          <Text style={istyles.title}>我</Text>
          <Image style={istyles.arrow} source={require('../../res/icon_arrow_right.png')}/>
          </View>
        </View>

      </TouchableHighlight>
    )
  }
}

var istyles = StyleSheet.create({
  content:{
    alignItems:'center',
    flexDirection:'row',
    height:h(60),
    marginHorizontal:w(12),
    borderBottomWidth:len('itemDivider'),
    borderColor:Color.itemClick
  },
  icon:{
    width:w(40),
    height:w(40),
    borderRadius:w(5),
  },
  title:{
    flex:1,
    marginLeft:w(19),
    fontSize:fs('28'),
    color:Color.title
  },
  arrow:{
    width:w(6),
    height:w(17),
  },
})

module.exports = OtherDoctorMsgList;
