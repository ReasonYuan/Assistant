/**
 *
 * 用户和医生的聊天界面，继承至BaseChatView
 * @author reason 2015-12-08
 *
 */

'use strict';

var React = require('react-native');

var {
  AppRegistry,
  StyleSheet,
  Text,
  View,
  Navigator
} = React;

var {Styles,Button,BaseComponent} = require('../../utils/Styles');
var BaseChatView = require('./BaseChatView')
var ChatDataSource = require("./ChatDataSource")
var {User} = require("../Models");

class CustomerChatView extends BaseChatView{

  constructor(props){
    super(props)

    //根据聊天场景确定拉的聊天对象
    var chatFriend = this.friend
    var doctor = null;
    //这里还要判断是否是我负责的医生，如果是我负责的医生，就不需要拉医生的助理
    if(chatFriend.role_type == 0 && chatFriend.assistant != null && chatFriend.assistant != User.currentUser.documentID){
      chatFriend = new User()
      chatFriend.role_type = 2
      chatFriend.documentID = this.friend.assistant
      chatFriend.name = this.friend.name + "的助理"
      //doctor is friend
      doctor = this.friend
    }

    this.chatDataSource = new ChatDataSource(User.currentUser, chatFriend,
      doctor, null,(data)=>this.onDataChange(data));
  }

  // getParams(){
  //   return {customer:this.friend,doctor:null,group:null}
  // }

  // getKeyByRow(rowData){
  //   retur this.friend._id;
  // }

  getProfileView(){
    var doctorProfile = require("../profile/DoctorProfile");
    return doctorProfile
  }

}

module.exports = CustomerChatView;
