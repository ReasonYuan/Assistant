/**
 *
 * (主页)展示客户的消息列表界面
 * @author reason 2015-12-07
 *
 */

'use strict';

var React = require('react-native');

var {
  View,
  Text,
  Image,
  StyleSheet,
  TouchableHighlight,
} = React;


var BaseMsgList = require('./BaseMsgList');
var {Color,len,fs} = require('../../utils/Styles')
var {w,h} = require('../../utils/Porting')
var LatestMsgListDataSource = require('./LatestMsgListDataSource')


class CustomerMsgList extends BaseMsgList {

  constructor(props) {
    super(props)
  }

  //view的标题
  getTitle(){
    return "我的客户"
  }

  //所要获得数据的类型，这里是和客户聊天的类型
  getType(){
    return LatestMsgListDataSource.TYPE_CUSTOMER_MSG_LIST
  }

  getRoleType(){
    return 1
  }

  //到所有客户的列表
  toCustomerList(){
    var customerList = require("../contacts/CustomerList");
    this.push(customerList)
  }

  //某一个信息被点击，跳转到聊天界面
  onItemClick(data){
    super.onItemClick(data)

    var ChatView;
    var relation = data.relationship
    if(relation.type ==  "Group"){//群聊
      ChatView = require("../chat/GroupChatView");
    }else{//单聊
      ChatView = require("../chat/CustomerChatView");
    }

    this.props.navigator.push({
      component:<ChatView navigator={this.props.navigator} message={data}/>
    })
  }

  //渲染消息列表
  renderHeader(){
    return(
        <TouchableHighlight
          underlayColor={Color.itemClick}
          onPress={()=>{this.toCustomerList()}}>
          <View style={{backgroundColor:'#FFFFFF'}}>
            <View style={istyles.content}>
              <Image style={istyles.icon} source={require('../../res/all_patient.png')}/>
              <Text style={istyles.title}>所有客户</Text>
              <Image style={istyles.arrow} source={require('../../res/icon_arrow_right.png')}/>
            </View>
          </View>

        </TouchableHighlight>
    )
  }
}

var istyles = StyleSheet.create({
  content:{
    alignItems:'center',
    flexDirection:'row',
    height:h(60),
    marginHorizontal:w(12),
    borderBottomWidth:len('itemDivider'),
    borderColor:Color.itemClick
  },
  icon:{
    width:w(20),
    height:w(20),
    marginLeft:w(8),
  },
  title:{
    flex:1,
    marginLeft:w(24),
    fontSize:fs('28'),
    color:Color.title
  },
  arrow:{
    width:w(6),
    height:w(17),
  },
});

module.exports = CustomerMsgList;
