/**
 *
 * (主页)展示用户消息列表界面的父类。
 * 因为客户的消息和医生的消息在布局和功能上都差不多。
 * @author reason 2015-12-08
 *
 */

'use strict';

var React = require('react-native');


var BaseMsgList = require('./BaseMsgList');

var LatestMsgListDataSource = require('./LatestMsgListDataSource')



class BaseDoctorMsgList extends BaseMsgList {

  //某条消息被点击
  onItemClick(data){
    super.onItemClick(data)

    //跳转到聊天界面
    var DoctorChat = require("../chat/DoctorChatView");
    this.props.navigator.push({
      component:<DoctorChat navigator={this.props.navigator} message={data}/>
    })
  }
}

module.exports = BaseDoctorMsgList;
