/**
 *
 * (主页)展示用户消息列表界面的父类。
 * 因为客户的消息和医生的消息在布局和功能上都差不多。
 * @author reason 2015-12-08
 *
 */

'use strict';

var React = require('react-native');

var {
  StyleSheet,
  ListView,
  View
} = React;

// var {BaseComponent} = require('../../utils/Styles')
var FQListView = require('../../widget/FQListView');
var BaseComponent = require('../BaseComponent');

var LatestMsgListDataSource = require('./LatestMsgListDataSource');
var MessageCell = require('./MessageCell');
var MessageManager = require('./MessageManager');

var MessageCount = require('./MessageCount');
// var UserStore = require("../stores/UserStore")


class BaseMsgList extends BaseComponent {

  // friend:User;
  chatLatestMsgList:LatestMsgListDataSource;

  constructor(props) {
    super(props);
    this.isTabBarChild = true;
    this.state = {
      navigatorBarConfig:{title:this.getTitle()},
      dataSource:new ListView.DataSource({rowHasChanged: (r1, r2) => this.compare(r1, r2)})}
  }

  //得到view的title，由子类实现
  getTitle(){}

  //获得消息列表时，logic需要传入的type类型，子类分别实现
  getType(){}

  //获得列表类型
  getRoleType(){}


  compare(r1, r2){
    // if(r2.debugMessage.isNewMsg){
    //   r2.debugMessage.isNewMsg = false
    //   return true
    // }
    // return false
    //TODO 先用全部刷新
    return true
  }

  componentWillMount(){
    var self = this
    // this._userStoreListenerID = UserStore.instance.addStoreListener((data)=>{
    //   if(self.dataSource && self.dataSource.length > 0){
    //     self.setState({dataSource:self.state.dataSource.cloneWithRows(self.dataSource)})
    //   }
    // })

    this.chatLatestMsgList = new LatestMsgListDataSource(this.getType(),
      (data)=>{this.onDataChanged(data)}, (data)=>{this.onDataChanged(data)})
  }

  componentWillUnmount(){
    super.componentWillUnmount()
    if(this.chatLatestMsgList) this.chatLatestMsgList.stop()
    // if(this._userStoreListenerID){
    //   UserStore.instance.removeStoreListener(this._userStoreListenerID)
    // }
  }

  onDataChanged(data){
    if(!data){return}
    // console.log(JSON.stringify(data));
    for(var i = 0; i < data.length; i++){
      if(data[i].debugMessage.unread){
        MessageCount.add(this.getType(),data[i].debugMessage.channel)
      }
    }
    this.dataSource = data
    this.setState({dataSource:this.state.dataSource.cloneWithRows(data)})
  }

  //某条消息被点击
  onItemClick(data){
    if(data.debugMessage.unread){
      data.debugMessage.unread = false;
      data.debugMessage.isNewMsg = true;
      MessageCount.remove(this.getType(),data.debugMessage.channel)
      this.setState({dataSource:this.state.dataSource.cloneWithRows(this.dataSource)})

      MessageManager.instance.setMsgChannelUnreadStatus(data.debugMessage.channel,false)
    }
  }

  //渲染联系人入口按钮，由子类实现
  renderHeader(){}

  renderRow(data){
    return(
      <MessageCell
        key={data}
        roleType={this.getRoleType()}
        message={data}
        itemClick={()=>this.onItemClick(data)}/>
    )
  }

  _render(){
    return(
      <View style={istyles.full}>
        {this.renderHeader()}

        <FQListView
          automaticallyAdjustContentInsets={false}
          renderRow={this.renderRow.bind(this)}
          dataSource={this.state.dataSource}
        />
      </View>
    )
  }
}

var istyles = StyleSheet.create({
  full:{
    flex:1,
    backgroundColor:'#F1F1F1'
  },
});

module.exports = BaseMsgList;
