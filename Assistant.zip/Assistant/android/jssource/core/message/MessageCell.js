/**
 *
 * (主页)展示客户的消息列表界面
 * 聊天对象talker分类-->0:和病人聊；1:和我的医生好友聊；2:和不是我的医生好友聊；3:群聊
 * @author reason 2015-12-07
 *
 */

'use strict';

var React = require('react-native');

var {
  StyleSheet,
  Text,
  View,
  TouchableHighlight,
} = React;

var {Color,len,fs} = require('../../utils/Styles')
var {w,h} = require('../../utils/Porting')
var Tools = require('../../utils/Tools')
var UserIcon = require('../../widget/UserIcon')

var GroupHeadView = require('../../widget/GroupHeadView')
// var userCache = require('../users/UserCacheManager')

class MessageCell extends React.Component{

  constructor(props) {
    super(props)

    this.state = {data:props.message}
    // this.data = props.message
  }

  componentWillReceiveProps(nextProps) {
    // if(this.props != nextProps){
    //   this.data = nextProps.message
    // }
    this.setState({data:nextProps.message})
    // this.data = nextProps.message
  }

  // shouldComponentUpdate(nextProps,nextState){
  //   if(!this.props.message.debugMessage)return true
  //   return this.props.message.debugMessage != nextProps.message.debugMessage
  // }

  //的到消息发送者得头像
  getHeadIcon(){
    if(this.state.data.relationship.type=="Group"){
      return null
    }else{
      var user = this.state.data.relationship.friend;
      if(user && user.headIcon){
        return user.headIcon.objectKey
      }
      return null
    }
  }

  getDefaultIcon(){
    return Tools.getHeadByRoleType(this.state.data.relationship.friend.role_type)
  }

  //如果是为读的信息，渲染其提示小红点
  renderUnReadPoint(unread){
    if(unread){
      return (<View style={istyles.unread}/>)
    }
  }

  renderIcon(){
    var data = this.state.data
    if(data.relationship.type == 'Group'){
      return(<GroupHeadView style={istyles.head} ids={data.relationship.members}/>)
    }else{
      return(
        <UserIcon style={istyles.head}
          user={this.state.data.relationship.friend}
          defaultSource={this.getDefaultIcon()}
          source={this.getDefaultIcon()}/>
      )
    }
  }

  render(){

    var data = this.state.data
    var msg = data.debugMessage
    var time = msg.date?Tools.getDateByMesc(+msg.date):""
    var name = data.debugName||data.relationship.friend.name||data.relationship.friend.phone_number

    var content = ""
    switch(msg.messageType){
      case 0:content = msg.message; break;
      case 1:content = "[图片]"; break;
      case 2:content = "[授权档案]"; break;
      case 3:content = "[资讯]";  break;
      case 4:content = "[服务]";  break;
      case 5:content = "[名片]";  break;
      case 6:content = "[名片]";  break;
      case 7:content = "[分享病案]";  break;
      default: content = ""
    }

    return(

      <TouchableHighlight underlayColor={Color.itemClick} onPress={this.props.itemClick}>
        <View style={{backgroundColor:'#FFFFFF'}}>
          <View style={istyles.container}>
            <View style={istyles.headContainer}>
              {this.renderIcon()}
              {this.renderUnReadPoint(msg.unread)}
            </View>

            <View style={istyles.infoView}>
              <View style={istyles.nameContainer}>
                <Text numberOfLines={1} style={istyles.nameLabel}>{name}</Text>
                <Text style={istyles.timeLabel}>{time}</Text>
              </View>
              <Text numberOfLines={1} style={istyles.msgLabel}>{content}</Text>
            </View>
          </View>
        </View>
      </TouchableHighlight>
    )
  }
}


var istyles = StyleSheet.create({
  container:{
    alignItems:'center',
    flexDirection:'row',
    marginHorizontal:w(10),
    height:h(60),
    borderBottomWidth:len('itemDivider'),
    borderColor:Color.itemClick,
  },
  infoView:{
    flex:1,
    height:h(42),
    marginLeft:w(10),
    marginTop:h(3),
  },
  headContainer:{
    width:w(40),
    height:w(40),
    flexDirection:'row',
  },
  head:{
    width:w(40),
    height:w(40),
    borderRadius:w(5)
  },
  unread:{
    position:'absolute',
    width:w(8),
    height:w(8),
    left:w(35),
    top:w(-2),
    borderRadius:w(4),
    backgroundColor:'#f00'
  },
  nameContainer:{
    flex:1,
    flexDirection:'row',
    paddingTop:h(9),
    justifyContent:'space-between',
  },
  nameLabel:{
    flex:1,
    fontSize:fs('24'),
    color:Color.title
  },
  timeLabel:{
    fontSize:fs('20'),
    marginLeft:w(3),
    color:Color.title
  },
  msgLabel:{
    fontSize:fs('20'),
    color:'#999',
    marginBottom:h(1),
    marginRight:w(60),
  }
});

module.exports = MessageCell;
