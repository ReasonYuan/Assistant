/**
 *
 * 为(主页)展示消息列表界面提供数据来源
 * @author johnny 2015-12-14
 *
 */

'use strict';

var Models = require("../Models");
var {User,Group,Patient,FriendShip,Message,Service,ChatFriendShip} = Models;
var {DatabaseView,DatabaseManager} = require("../couchbase/Couchbase");
var DatabaseHelper = require("../helper/DatabaseHelper")
var Config = require("../../constant/Config")
var UserCacheManager = require("../users/UserCacheManager")
var MessageManager = require("./MessageManager")
var UserStore = require("../stores/UserStore")
//var StackTrackTool = require("../../utils/StackTraceTool")

class LatestMsgListDataSource {

  listType:Number;
  onListChangedCallback = null;
  onNewMessageRecievedCallback = null;
  databaseView = null;
  latestList = [];
  _notFoundUserIDList; //还未同步好的用户id列表

  //构造函数
  //listType：列表类型（定义见本js末尾），
  //onListChangedCallback: {"reletionship":聊天关系信息, ""}
  //onNewMessageRecievedCallback: 当列表中有新消息时通知
  constructor(listType, onListChangedCallback, onNewMessageRecievedCallback){
    var self = this
    this.listType = listType
    this.onListChangedCallback = onListChangedCallback
    this.onNewMessageRecievedCallback = onNewMessageRecievedCallback
    this._notFoundUserIDList = []
    this._lastDataRowFromDB = []
    this._userStoreListenerID = UserStore.instance.addStoreListener((data)=>{
      self.onNewUserInfoFound(data)
    })

    var db = DatabaseManager.instance.currentDatabase;
    switch (listType) {
      case LatestMsgListDataSource.TYPE_CUSTOMER_MSG_LIST:
        {
          //FriendShip里fromType|toType只要有patiant的, 则必是和客户聊天，否则和医生聊天
          var latestMsgListView =  new DatabaseView(db,["FriendShip","Group","Message"],"LATEST_LIST_CUSTOMER3","function(doc) { if((doc.type == 'FriendShip' && ( (doc.fromType == 1 && doc.toType != 0) || (doc.toType == 1 && doc.fromType != 0))) || doc.type=='Group') { emit(doc.date||'0',doc);} }",()=>{
            latestMsgListView.setOnDataChangeCallback((data)=>self.latestMsgListChanged(data));
          });
          this.databaseView = latestMsgListView
        }
        break;
      case LatestMsgListDataSource.TYPE_DOCTOR_MSG_LIST:
        {
          //StackTrackTool.printStackTrace(new Error("for debug!!!"))
          //FriendShip里fromType|toType只要有doctor的, 则必是和医生朋友聊天，否则和客户聊天
          var latestMsgListView =  new DatabaseView(db,["FriendShip","Message"],"LATEST_LIST_MYDOCTOR","function(doc) { if(doc.type == 'FriendShip' && (doc.fromType == 0 || doc.toType == 0)) { emit(doc.date||'0',doc);} }",()=>{
            latestMsgListView.setOnDataChangeCallback((data)=>self.latestMsgListChanged(data));
          });
          this.databaseView = latestMsgListView
        }
        break
      case LatestMsgListDataSource.TYPE_DOCTORS_ASSISTANT_MSG_LIST:
        {
          //不是我的医生朋友，只能和医生的助理成为聊友聊天
          var latestMsgListView =  new DatabaseView(db,["ChatFriendShip","Message"],"LATEST_LIST_OTHERDOCTORS","function(doc) { if(doc.type == 'ChatFriendShip') { emit(doc.date,doc);} }",()=>{
            latestMsgListView.setOnDataChangeCallback((data)=>self.latestMsgListChanged(data));
          });
          this.databaseView = latestMsgListView
        }
        break;
      default:
        throw new Error("unknown list type: " + listType);
        break;
    }
    MessageManager.instance.setOnMessageRecievedCallback(listType, function(){
      console.log("message recieved of this list");
      if(onNewMessageRecievedCallback && self.latestList.length > 0){
        for(var i=0; i<self.latestList.length; i++){
            self.latestList[i].updateValues()
        }
        self.sortList(self.latestList)
        onNewMessageRecievedCallback(self.latestList)
      }
    })
  }

  /**
   * 用户信息新同步过来或者用户资料更新
   */
  onNewUserInfoFound(data){
    console.log("new user found!!!");
    //是否在消息列表里的用户需要更新
    if(this._notFoundUserIDList.length > 0){
      var exists = false
      for(var key in data){
        if(this._notFoundUserIDList.contains(key)){
          exists = true
          break
        }
      }
      if(exists){
        this.latestMsgListChanged(this._lastDataRowFromDB)
      }
    } else {
      var updatedUsers = []
      for(var key in data){
        updatedUsers.push(data[key].documentID)
      }
      //列表中的Friendship成员是否包含这个更新的user
      for(var i=0; i<this._lastDataRowFromDB.length; i++){
        var item = this._lastDataRowFromDB[i].value
        if(item.type != "Group"){
          if(updatedUsers.contains(item.from) || updatedUsers.contains(item.to)){
            this.latestMsgListChanged(this._lastDataRowFromDB)
            break
          }
        }
      }
    }
  }

  stop(){
    if(this._userStoreListenerID){
      UserStore.instance.removeStoreListener(this._userStoreListenerID)
    }
    MessageManager.instance.setOnMessageRecievedCallback(this.listType, null)
    if(this.databaseView) this.databaseView.stop()
  }

  findUserCached4Relation(relation, tmpNotFoundIDlist){
      var fromUser = UserCacheManager.instance.getUserInfo(relation.from)
      var toUser = UserCacheManager.instance.getUserInfo(relation.to)
      var bothExists = !fromUser.notFound && !toUser.notFound
      if(bothExists){
        relation.friend = fromUser.documentID == User.currentUser.documentID ? toUser : fromUser
      } else {
        if(fromUser.notFound) tmpNotFoundIDlist.push(fromUser.documentID)
        if(toUser.notFound) tmpNotFoundIDlist.push(toUser.documentID)
      }
      return bothExists
  }

  latestMsgListChanged(data){
    this._lastDataRowFromDB = data
    var tmpNotFoundIDlist = []
    var msgChannelList = []
    for(var i=0; i<data.length; i++){
      var item = data[i]
      if(item.value.type == "FriendShip"){
        var friendShip = new FriendShip(item.value.from, item.value.to)
        friendShip.setProperty(item.value)
        var item = {
          relationship:friendShip,
          getMessage:function(){
            var channel = Models.getChannle(this.relationship.from, this.relationship.to)
            return MessageManager.instance.getLatestChatInfo(channel)
          },
          getName:function(){
            return UserCacheManager.instance.getUserInfo(this.relationship.getFriendId()).name
          },
          updateValues:function(){
            this.debugName = this.getName()
            this.debugMessage = this.getMessage()
          }
        }
        item.updateValues()
        if(this.findUserCached4Relation(item.relationship, tmpNotFoundIDlist)){
          msgChannelList.push(item)
        }
      } else if(item.value.type == "Group"){
        var group = new Group(item.value.name)
        group.setProperty(item.value)
        var item = {
          relationship:group,
          getMessage:function(){
            var channel = this.relationship.documentID
            return MessageManager.instance.getLatestChatInfo(channel)
          },
          getName:function(){
            return this.relationship.name
          },
          updateValues:function(){
            this.debugName = this.getName()
            this.debugMessage = this.getMessage()
          }
        }
        item.updateValues()
        msgChannelList.push(item)
      } else if(item.value.type == "ChatFriendShip"){
        var friendShip = new ChatFriendShip(item.value.from, item.value.to)
        friendShip.setProperty(item.value)
        var item = {
          relationship:friendShip,
          getMessage:function(){
            var channel = Models.getChannle(this.relationship.from, this.relationship.to)
            return MessageManager.instance.getLatestChatInfo(channel)
          },
          getName:function(){
            return UserCacheManager.instance.getUserInfo(this.relationship.getFriendId()).name
          },
          updateValues:function(){
            this.debugName = this.getName()
            this.debugMessage = this.getMessage()
          }
        }
        item.updateValues()
        if(this.findUserCached4Relation(item.relationship, tmpNotFoundIDlist)){
          //if(!item.imMessage.noAnyMsg){
            msgChannelList.push(item)
          //}
        }
      }
    }

    this.latestList = msgChannelList
    this.sortList(this.latestList)
    if(this.onListChangedCallback) this.onListChangedCallback(this.latestList)
	  //在最后更新
    this._notFoundUserIDList = tmpNotFoundIDlist
  }

  sortList(msgList){
    msgList.sort(function(a, b){
      // try{
      //   var aTime = a.debugMessage.date != undefined ? +a.debugMessage.date : 0
      //   var bTime = b.debugMessage.date != undefined ? +b.debugMessage.date : 0
      //   return aTime > bTime ? -1 : (aTime == bTime ? 0 : 1)
      // }catch(error){
      //   return 0
      // }
      var aTime = a.debugMessage.date != undefined ? +a.debugMessage.date : 0
      var bTime = b.debugMessage.date != undefined ? +b.debugMessage.date : 0
      return aTime > bTime ? -1 : (aTime == bTime ? 0 : 1)
    })
  }
}

//顾客聊天记录和群聊
LatestMsgListDataSource.TYPE_CUSTOMER_MSG_LIST = 1
//和我的医生聊天记录
LatestMsgListDataSource.TYPE_DOCTOR_MSG_LIST = 2
//和我不是我的医生的助理的聊天记录
LatestMsgListDataSource.TYPE_DOCTORS_ASSISTANT_MSG_LIST = 3

module.exports = LatestMsgListDataSource
