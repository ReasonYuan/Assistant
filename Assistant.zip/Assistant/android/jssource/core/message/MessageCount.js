/**
 *
 * (主页)未读消息的管理类，类观察者模式，判断TabbarItem是否显示红点
 * TabbarItem需要实现接口
 *
 * @author reason 2015-12-07
 *
 */

'use strict';
// var LatestMsgListDataSource = require('./LatestMsgListDataSource')

var MessageCount = {};

//存放未读信息的id。1，2，3分别表示病人聊天列表，医生聊天列表，助理聊天列表
MessageCount.allNoReadMessage = { 1:[],2:[],3:[] }

MessageCount.changeListener = null;
// MessageCount.addCount = function(id,count){
//     MessageCount.allNoReadMessage[id] = count;
//     var allCount = 0;
//     var keys = Object.keys(MessageCount.allNoReadMessage);
//     keys.forEach(function (key) {
//         allCount += MessageCount.allNoReadMessage[key];
//     })
//     if(MessageCount.changeListener)MessageCount.changeListener(allCount);
// }

MessageCount.add = function(type,id){
  if(!id)return
  var ids = MessageCount.allNoReadMessage[type]
  if(!isContains(ids,id)){
    ids.push(id)
  }
  if(ids.length == 1){
    if(MessageCount.changeListener)MessageCount.changeListener(type,true);
  }
}

MessageCount.remove = function(type,id){
  if(!id)return
  var ids = MessageCount.allNoReadMessage[type]
  for(var i = 0; i < ids.length; i++){
    if(ids[i] == id){
      ids.splice(i,1);
      break;
    }
  }
  if(ids.length == 0){
    if(MessageCount.changeListener)MessageCount.changeListener(type,false);
  }
}

var isContains = function(ary,obj) {
    var i = ary.length;
    while (i--) {
        if (ary[i] == obj) {
            return true;
        }
    }
    return false;
}


module.exports = MessageCount;
