/**
 *
 * 客户对服务评价，支付的页面
 * @author  reason 2015-12-08
 *
 */

'use strict';

var React = require('react-native');

var {
  StyleSheet,
  View,
  Text,
  Image,
  TextInput,
  TouchableHighlight,
} = React;

var {w,h,screenWidth,screenHeight} = require('../../utils/Porting')
var {fs,Color,Config} = require('../../utils/Styles');
var {fetchPost} = require("../../utils/SimpleFetch")
var BaseComponent = require('../BaseComponent')

var stars = [require('../../res/icon_judge_star_n.png'),
             require('../../res/icon_judge_star_y.png')]


class Start extends React.Component{
  constructor(props){
    super(props)
  }

  render(){
    return(
      <TouchableHighlight
        underlayColor='transprent'
        onPress={()=>{this.props.onClick(this.props.index)}}>

        <Image style={istyles.star}
          source={stars[this.props.selected]}/>
      </TouchableHighlight>
    )
  }
}

class ServiceJudge extends BaseComponent {

  constructor(props){
    super(props)
    this.state={selectedIndex:0,
      service:props.service,
      navigatorBarConfig:{title:"服务",showBackIcon:true}}
  }

  componentWillMount(){
    //121.41.43.230 Config.webBaoshiServerURL
    if(this.state.service.type != "Service"){
      fetchPost(Config.webBaoshiServerURL + "service/get_service_by_id",
        {serviceId:this.state.service.serviceId},
        (data)=>{
          if(data.error){
            self.props.controller.showToast(data.error)
          }else{
            data.service.provider = this.state.service.provider
            this.setState({service:data.service,selectedIndex:data.service.rating})
          }
        }
      )
    }
  }

  onLeftPress(){
    this.pop();
  }


  onStarClick(index){
    this.setState({selectedIndex:index})
  }

//评论的星星列表
  getStars(){
    var views = []
    for(var i = 1; i < 6; i++){
      var selected = i > this.state.selectedIndex?0:1;
      views.push(<Image style={istyles.star} source={stars[selected]}/>)
    }
    return views
  }

//支付方才有点击星星的功能
  //onClick={(index)=>{this.editable&&this.onStarClick(index)}}

  renderStar(){
    return(
      <View style={istyles.starContainer}>
        { this.getStars() }
      </View>
    )
  }

  renderJudge(){
    var service = this.state.service
    if(service.type == "Service"){
      if(service.payStatus == 3){
        return(
          <View style={istyles.judgeContainer}>
            <TextInput
              // multiline={true}
              numberOfLines={5}
              style={istyles.input}
              editable={false}
              placeholderTextColor="#c1c1c1"
              defaultValue={service.judgment}
              multiline={React.Platform.OS !== 'ios'}
              textAlignVertical='top'
              placeholder={"请输入对本次服务的评价..."}/>

            <View style={istyles.startView}>{this.renderStar()}</View>
          </View>
        )
      }else{
        return( <Text style={istyles.noPay}>用户还未付费评论</Text> )
      }
    }
  }


  _render(){
    var service = this.state.service
    return(
      <View>
        <Image style={istyles.full} source={require('../../res/bg_pay.jpg')}/>

        <View style={istyles.container}>
          <Image style={istyles.logo} source={require('../../res/icon_logo.png')}/>
          <Text style={istyles.title}>海苔全家健康服务</Text>
          <Text style={istyles.des}>¥ {service.price.toFixed(2)}</Text>
          <Text style={istyles.des}>提供者：{service.provider}</Text>

          {this.renderJudge()}

        </View>
      </View>
    )
  }
}

// {
//   ()=>{
//     if(this.editable){
//       <TouchableHighlight style={istyles.btnPay} underlayColor="#ccc">
//         <Text style={istyles.btnTitle}>支付</Text>
//       </TouchableHighlight>
//     }
//   }
// }

var istyles = StyleSheet.create({
  full:{
    flex:1,
  },
  container:{
    position:'absolute',
    left:(screenWidth()-w(250))/2,
    top:0,
    width:w(250),
    height:screenHeight()-64,
    alignItems:'center',
    backgroundColor:'transprent',
  },
  logo:{
    width:w(250),
    height:w(94),
    marginTop:w(40),
    resizeMode:'contain',
  },
  title:{
    marginTop:w(30),
    marginBottom:w(30),
    fontSize:fs('36'),
    color:'#61c4b2'
  },
  des:{
    fontSize:fs('26'),
    marginBottom:w(10),
    color:Color.des,
  },
  judgeContainer:{
    flex:1,
    width:w(250)
  },
  input:{
    flex:1,
    padding:w(9),
    borderWidth:1,
    borderColor:'#b6dbd4',
    backgroundColor:'#fff',
    color:'#c1c1c1',
    fontSize:fs('24')
  },
  startView:{
    alignSelf:'flex-end',
    marginBottom:w(23),
    marginTop:w(20),
  },
  starContainer:{
    height:w(20),
    flexDirection:'row',
    alignItems:'flex-end',
  },
  star:{
    width:w(20),
    height:w(24),
    marginLeft:w(6),
    resizeMode:'contain'
  },
  noPay:{
    marginTop:w(50),
    fontSize:24,
    color:'#aaa'
  }
  // btnPay:{
  //   width:w(250),
  //   height:w(35),
  //   backgroundColor:'#67bfb5',
  //   alignItems:'center',
  //   justifyContent:'center',
  //   borderRadius:w(5),
  //   marginBottom:w(35)
  // },
  // btnTitle:{
  //   fontSize:fs('28'),
  //   color:'#f5eff1'
  // },
});


module.exports = ServiceJudge
