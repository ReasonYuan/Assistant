'use strict';
var React = require('react-native');

var {
  StyleSheet,
  Text,
  View,
  Image
} = React;

var BaseComponent = require('./BaseComponent');
var Login = require('./Login');
var Tools = require('../utils/Tools.js');
var TimerMixin = require('react-timer-mixin');


class Welcome extends BaseComponent{

  componentDidMount() {
    var self = this;
    this.timer = setTimeout(
      () => {
        self.replace(Login);
        console.log('把一个定时器的引用挂在this上');
      },
      1000
    );
  }

  componentWillUnmount() {
    this.timer && clearTimeout(this.timer);
  }

  render() {
    return (
      <View style={istyles.full}>
        <Image style={istyles.bgImage} source={require('../res/launch.jpg')} />
      </View>
    )
  }
}

var istyles = StyleSheet.create({
  full:{
    flex:1
  },
  bgImage:{
    flex:1,
    width:Tools.screenWidth(),
    alignItems: 'center',
    backgroundColor:'transparent'
  }
});

module.exports = Welcome;
