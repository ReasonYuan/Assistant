/**
 *
 * 医生列表界面(由医生消息列表的“所有医生”按钮点击过来)
 * @author reason 2015-12-07
 *
 */

'use strict';

var React = require('react-native');
var Config = require('../../constant/Config.js');
var {DatabaseManager, DatabaseView} = require("../couchbase/Couchbase");
var LocalCache = require("../sync/LocalCache");
var FQListView = require('../../widget/FQListView');

var {Fetch} = require('../../../../JSLibrary/Logic');

var {
  StyleSheet,
  Text,
  View,
  ListView,
  ScrollView,
  TouchableHighlight,
  InteractionManager
} = React;

var BaseComponent = require('../BaseComponent')
var ImageView = require('../../widget/ImageView')
var Tools = require('../../utils/Tools')
var {w,h} = require('../../utils/Porting')
var {Color,fs} = require('../../utils/Styles')


class DoctorList extends BaseComponent{

  constructor(props){
    super(props)
    this.isTabBarChild = true;
    this.page = 1;
    this.isLoading = false;
    this.allDoctors = {};
    // this.doctorCount = 0;

    var config = {title:"所有医生",showBackIcon:true}
    var ds = new ListView.DataSource({
      getSectionHeaderData: this.getSectionData,
      getRowData: this.getRowData,
      rowHasChanged: (r1, r2) => this.rowHasChanged(r1,r2),
      sectionHeaderHasChanged: (s1, s2) => s1 !== s2
    })

    this.state = {navigatorBarConfig:config,dataSource:ds,renderPlaceholderOnly:true};
  }

  //医生被选中后判断是否重新刷新UI
  rowHasChanged(r1,r2){
    return r1 !== r2
  }

  componentDidMount(){
    InteractionManager.runAfterInteractions(() => {
      this.setState({renderPlaceholderOnly: false});
    });
    this.getDoctorList()
  }

  // var db = DatabaseManager.instance.currentDatabase;
  // var doctorListView =  new DatabaseView(db,"User","DoctorListView","function(doc) { if(doc.type == 'User' && doc.role_type == 0) emit(doc.name, doc) }",()=>{
  //     doctorListView.descending = false;
  //     doctorListView.setOnDataChangeCallback((data)=>this.onDataChange(data));
  // });
  // this.doctorListView = doctorListView;

  //获得医生的列表
  getDoctorList(){
    var doctorListCacheKey = "doctor_list_cache_key" + this.page;
    //刚启动界面要读取缓存
    var self = this
    LocalCache.get(doctorListCacheKey, function(data){
      if(data && !data.error){
        self.onDataChange(data.rows)
      }
    })

    this.isLoading = true
    //调用restful接口获得数据，这是所有医生，以后通过查询功能得到
    var params = {page:this.page, pageSize:30} //TODO 根据实际页面修改参数
    var url = Config.webBaoshiServerURL + "users/get_doctors"
    var _this = this;

    Fetch.post("",params,(data) => {
        this.isLoading = false
          if(data.error){
            //获取失败
            _this.showToast(data.error)
          } else {
            //排好序的数据
            // console.log(JSON.stringify(data))
            this.onDataChange(data.doctors)
            //保存缓存，每次Load都是load的一个病案的
            LocalCache.save(doctorListCacheKey, {rows:data.doctors})
            this.page++;
          }
    },url);

    // fetch(url, {
    //       method: "POST",
    //       headers: {'Content-Type': 'application/json'},
    //       body: JSON.stringify(params)
    // })
    // .then((response) => response.json())
    // .then((data) => {
    //     this.isLoading = false
    //       if(data.error){
    //         //获取失败
    //         _this.showToast(data.error)
    //       } else {
    //         //排好序的数据
    //         // console.log(JSON.stringify(data))
    //         this.onDataChange(data.doctors)
    //         //保存缓存，每次Load都是load的一个病案的
    //         LocalCache.save(doctorListCacheKey, {rows:data.doctors})
    //         this.page++;
    //       }
    // }).catch(function(error) {
    //   if(error){
    //   }
    // })
  }

  //请求下一页的数据
  loadNextPage(){
    if(!this.isLoading){
      this.getDoctorList();
    }
  }

  // componentWillUnmount(){
  //   super.componentWillUnmount();
  //   if(this.doctorListView) {
  //     this.doctorListView.stop();
  //     delete this.doctorListView;
  //   }
  // }

  //列表头部数据
  getSectionData(dataBlob, sectionId){
    return sectionId;
  }
  //列表组内数据
  getRowData(dataBlob, sectionId,rowId){
    return dataBlob[sectionId][rowId]
  }

  onDataChange(data){
    if(!data || data.length == 0)return

    //组装以前的数据
    this.allDoctors[this.page] = data;
    var keys = Object.keys(this.allDoctors).sort();
    var doctors = [];
    keys.forEach((key)=>{
      doctors =  doctors.concat(this.allDoctors[key])
    })
    // this.doctorCount = doctors.length;

    var groups = {};
    var sectionIds = [];
    var rowIds = [];

    var getGroup = function(key){
      if(!groups[key])groups[key] = [];
      return groups[key];
    }

    //分组
    for (var i = 0; i < doctors.length; i++) {
        var doctor = doctors[i].userInfo;
        if(!doctor.documentID) doctor.documentID = doctor.id
        var key = doctor.department || "其他"

        var group = getGroup(key);
        group.push(doctor);
    }

    //将＃移到最后
    sectionIds = Object.keys(groups);
    for(var i = 0; i < sectionIds.length; i++){
      if(sectionIds[i] == "其他"){
        sectionIds.splice(i,1);
        sectionIds.push("其他");
      }
    }
    // sectionIds = Object.keys(groups).sort(function(a,b){
    //   return a > b;
    // });

    sectionIds.forEach((key)=>{
      var oneGroup = groups[key];
      rowIds.push(Object.keys(oneGroup));
    })

    this.groups = groups
    this.sectionIds = sectionIds
    this.rowIds = rowIds
    this.setState({dataSource:this.state.dataSource.cloneWithRowsAndSections(groups,sectionIds,rowIds)});
  }

  onLeftPress(){
    this.pop()
  }

  //客户信息被点击
  onItemClick(rowData){
    var PatientProfile = require("../profile/DoctorProfile")
    this.pushWidthComponent(<PatientProfile navigator={this.props.navigator} user={rowData}
      showMsg={true}/>);
  }

  //用户列表的Header，即姓氏首字母大写
  renderSectionHeader(sectionData,sectionID){
    return(
      <View style={istyles.groupContainer}>
        <Text style={istyles.groupLabel}>{sectionData}</Text>
      </View>
    )
  }

  //得到医生头像
  getDoctorIcon(doctor){
    if(doctor.headIcon){
      return doctor.headIcon.objectKey
    }
    return null
  }

  //完成选择医生radioButton，由选择医生子类实现
  renderSelectView(doctor){}

  renderRow(rowData,sectionID,rowID){
    // rowData.hospital = "仁济医院"
    var icon = this.getDoctorIcon(rowData)
    return(
      <TouchableHighlight
        key={rowData.id}
        underlayColor="rgba(221, 221, 221, 0.5)"
        onPress={()=>this.onItemClick(rowData,sectionID,rowID)}>

          <View>
          <View style={istyles.line}/>
          <View style={istyles.itemContainer}>
            <ImageView style={istyles.head}
             imageKey={icon}
             defaultSource={Tools.getHeadByUser(rowData)}/>

            <View style={istyles.infoContainer}>
              <Text style={istyles.nameLabel}>{rowData.name}</Text>
              <Text style={istyles.nameHospital}>{rowData.hospital}</Text>
            </View>
            {this.renderSelectView(rowData)}
          </View>
          </View>
      </TouchableHighlight>
    )
  }

  onScroll(){
    if (this.refs.listview.scrollProperties.offset + this.refs.listview.scrollProperties.visibleLength >= 50) {//this.refs.listview.scrollProperties.contentLength){
        this.refs.listview.props.onEndReached();
    }
  }

  _renderPlaceholderView() {
    return (
      <View style={{flex:1,justifyContent:'center',alignItems: 'center'}}>
        <Text>Loading...</Text>
      </View>
    );
  }

  _render(){

    if (this.state.renderPlaceholderOnly) {
      return this._renderPlaceholderView();
    }

    return (
      <View style={istyles.full}>
        <FQListView style={istyles.list}
          ref="listview"
          automaticallyAdjustContentInsets={false}
          onScroll={this.onScroll.bind(this)}
          onEndReached={this.loadNextPage.bind(this)}
          dataSource={this.state.dataSource}
          renderRow={this.renderRow.bind(this)}
          renderSectionHeader={this.renderSectionHeader.bind(this)}
        />
      </View>
    )
  }
}

var istyles = StyleSheet.create({
  full:{
    flex:1
  },
  groupContainer:{
    height:w(40),
    justifyContent:'center',
    marginHorizontal:w(12),
    // borderBottomWidth:h(1),
    // borderColor:'#F2F3F3'
    // backgroundColor:'rgba(125,125,125,0.7)'
  },
  groupLabel:{
    margin:w(10),
    marginLeft:w(0),
    fontSize:fs('24'),
    color:"#52BCAE"
  },
  // groupDivider:{
  //   height:1,
  //   backgroundColor:'#F2F3F3'
  // },
  itemContainer:{
    height:w(60),
    flexDirection:'row',
    alignItems:'center',
    paddingTop:w(10),
    paddingBottom:w(10),
    marginHorizontal:w(12),
    // borderTopWidth:w(0.1),
    // borderColor:'#F2F3F3'
  },
  line:{
    flex:1,
    height:w(0.8),
    marginHorizontal:w(12),
    backgroundColor:'#F2F3F3'
  },
  infoContainer:{
    flex:1,
    paddingLeft:w(12),
    height:w(40),
    justifyContent:"space-between",
    marginRight:w(2)
  },
  head:{
    width:w(40),
    height:w(40),
    resizeMode:"cover",
    borderRadius:w(5)
  },
  nameLabel:{
    marginLeft:w(1),
    color:Color.title,
    fontSize:fs('24'),
    justifyContent:"flex-start",
    marginTop:w(8)
  },
  nameHospital:{
    marginLeft:w(1),
    color:'#999',
    fontSize:fs('20'),
    justifyContent:"flex-end"
  },
});

module.exports = DoctorList;
