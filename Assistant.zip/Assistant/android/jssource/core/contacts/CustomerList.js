/**
 *
 * 客户列表界面(由客户消息列表的“所有客户”按钮点击过来)
 * @author reason 2015-12-07
 *
 */

'use strict';

var React = require('react-native');

var {
  StyleSheet,
  Text,
  View,
  ListView,
  TouchableHighlight,
  Navigator,
  InteractionManager
} = React;

var BaseComponent = require('../BaseComponent')
var ImageView = require('../../widget/ImageView')
var Tools = require('../../utils/Tools')
var {DatabaseManager,DatabaseView} = require('../couchbase/Couchbase');
var {w,h} = require('../../utils/Porting')
var {Color,fs} = require('../../utils/Styles')
var {User} = require('../Models')
var FQListView = require('../../widget/FQListView')

class CustomerList extends BaseComponent{

  constructor(props){
    super(props)
    this.isTabBarChild = true;

    var config = {title:"所有客户",showBackIcon:true}

    var ds = new ListView.DataSource({
      getSectionHeaderData: this.getSectionData,
      getRowData: this.getRowData,
      rowHasChanged: (r1, r2) => r1 !== r2,
      sectionHeaderHasChanged: (s1, s2) => s1 !== s2
    })

    this.state = {navigatorBarConfig:config,dataSource:ds,renderPlaceholderOnly: true};
  }

  //列表头部数据
  getSectionData(dataBlob, sectionId){
    return sectionId;
  }
  //列表组内数据
  getRowData(dataBlob, sectionId,rowId){
    return dataBlob[sectionId][rowId]
  }

  //获得患者的列表
  componentDidMount(){
    super.componentDidMount();
    InteractionManager.runAfterInteractions(() => {
      this.setState({renderPlaceholderOnly: false});
    });
    var db = DatabaseManager.instance.currentDatabase;
    var myUserId = User.currentUser.documentID
    var customerListView =  new DatabaseView(db,"User","MyCustomerListView","function(doc) { if(doc.type == 'User' && doc.role_type == 1 && doc.assistant == '" + myUserId + "') emit(doc.name || '', doc) }",()=>{
        customerListView.descending = false;
        customerListView.setOnDataChangeCallback((data)=>this.onDataChange(data));
    });
    this.customerListView = customerListView;
  }

  componentWillUnmount(){
    super.componentWillUnmount();
    if(this.customerListView) {
      this.customerListView.stop();
      delete this.customerListView;
    }
  }

  onDataChange(data){
    if(!data)return

    var groups = {};
    var sectionIds = [];
    var rowIds = [];

    var getGroup = function(key){
      if(!groups[key])groups[key] = [];
      return groups[key];
    }

    var pinyin = require("../../utils/pinyin/pinyinTool")
    //分组
    for (var i = 0; i < data.length; i++) {
        var customer = data[i].value;
        var name = customer.name
        var key = "其他"

        if(name && name!=""){
          if(name.length > 1){
            name = name.charAt(0)
          }

          //如果不是拼音则转为拼音
          var asca = name.charCodeAt();
          if((asca > 64 && asca < 91) || (asca > 96 && asca < 123)){
            key = name;
          }else{
            key = pinyin(name)[0][0];
          }
          if(key.length > 1){
            key = key.charAt(0);
          }

          //判断是否已经转为拼音，如果不是则默认为‘＃’
          asca = key.charCodeAt()
          if((asca > 64 && asca < 91) || (asca > 96 && asca < 123)){
            key = key.toUpperCase()
          }else{
            key = "其他";
          }
        }else{
          customer.name = ""
        }

        var group = getGroup(key);
        group.push(customer);
    }

    //分组
    sectionIds = Object.keys(groups).sort(function(a,b){
      return a > b;
    });
    for(var i = 0; i < sectionIds.length; i++){
      if(sectionIds[i] == "其他"){
        sectionIds.splice(i,1);
        sectionIds.push("其他");
      }
    }

    sectionIds.forEach((key)=>{
      var oneGroup = groups[key];
      rowIds.push(Object.keys(oneGroup));
    })

    this.setState({dataSource:this.state.dataSource.cloneWithRowsAndSections(groups,sectionIds,rowIds)});
  }

  onLeftPress(){
    this.pop()
  }

  //客户信息被点击,点击后查看该用户的详细信息
  onItemClick(rowData){
    if(!rowData.documentID)rowData.documentID = rowData._id
    var PatientProfile = require("../profile/CustomerProfile")
    this.pushWidthComponent(<PatientProfile navigator={this.props.navigator} user={rowData}/>);
  }

  //用户列表的Header，即姓氏首字母大写
  renderSectionHeader(sectionData,sectionID){
    return(
      <View style={istyles.groupContainer}>
        <Text style={istyles.groupLabel}>{sectionData}</Text>
      </View>
    )
  }

  //得到医生头像
  getCustomerIcon(user){
    if(user.headIcon){
      return user.headIcon.objectKey
    }
    return null
  }

  renderRow(rowData,sectionID,rowID){
    // var icon = this.getCustomerIcon(rowData)
    return(
      <TouchableHighlight
      key={rowData.id}
      underlayColor="rgba(221, 221, 221, 0.5)"
      onPress={()=>this.onItemClick(rowData)}>

          <View>
          <View style={istyles.line}/>
          <View style={istyles.itemContainer}>
            <ImageView
              style={istyles.head}
              imageKey={this.getCustomerIcon(rowData)}
              defaultSource={Tools.getHeadByUser(rowData)}/>

            <Text style={istyles.nameLabel}>{rowData.name||rowData.phone_number}</Text>
          </View>
          </View>
      </TouchableHighlight>
    )
  }

  _renderPlaceholderView() {
    return (
      <View style={{flex:1,justifyContent:'center',alignItems: 'center'}}>
        <Text>Loading...</Text>
      </View>
    );
  }

  _render(){

    if (this.state.renderPlaceholderOnly) {
      return this._renderPlaceholderView();
    }

    return (
      <View style={istyles.full}>
        <FQListView
          automaticallyAdjustContentInsets={false}
          dataSource={this.state.dataSource}
          renderRow={this.renderRow.bind(this)}
          renderSectionHeader={this.renderSectionHeader.bind(this)}
        />
      </View>
    )
  }

}

var istyles = StyleSheet.create({
  full:{
    flex:1
  },
  groupContainer:{
    height:w(40),
    justifyContent:'center',
    marginHorizontal:w(12),
    // borderBottomWidth:h(1),
    // borderColor:'#F2F3F3'
    //backgroundColor:'rgba(125,125,125,0.7)'
  },
  groupLabel:{
    marginLeft:w(12),
    fontSize:fs('24'),
    color:"#52BCAE"
  },
  itemContainer:{
    height:w(60),
    flexDirection:'row',
    alignItems:'center',
    paddingTop:w(10),
    paddingBottom:w(10),
    marginHorizontal:w(12),
  },
  line:{
    flex:1,
    height:w(1),
    marginHorizontal:w(12),
    backgroundColor:'#f1f1f1'
  },
  head:{
    width:w(40),
    height:w(40),
    resizeMode:"cover",
    borderRadius:w(5)
  },
  nameLabel:{
    marginLeft:w(12),
    color:Color.title,
    fontSize:fs('24')
  }
});

module.exports = CustomerList;
