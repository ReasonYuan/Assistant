/**
 *
 * 选择医生的列表界面(给客户（患者）推荐医生时的选择医生的界面，只能选择一个医生）
 * @author reason 2015-12-07
 *
 */

'use strict';

var React = require('react-native');

var {
  StyleSheet,
  Text,
  Image,
  View,
  ListView,
  ScrollView,
  TouchableHighlight,
  InteractionManager
} = React;

var DoctorList = require('./DoctorList')
var Config = require('../../constant/Config.js');
var {Group,User} = require("../Models");
var DoctorFriendsList = require('../users/DoctorFriendsList')
var Constant = require("../../constant/Constant")
var {w,h,f} = require('../../utils/Porting')
var LocalCache = require("../sync/LocalCache");

let unsel = require('../../res/btn_radio_n.png')
let sel = require('../../res/btn_radio_y.png')

class SelectDoctorList extends DoctorList{

  constructor(props){
    super(props)
    this.doctor = null
    this.state.navigatorBarConfig = {title:"医生",
      leftButtonTitle:"返回",rightButtonTitle:"确认",rColor:'#68c3b7'}
  }

  onLeftPress(){
    this.props.chatView.pop()
  }

  //医生被选中后判断是否重新刷新UI
  rowHasChanged(r1,r2){
    if(r2.changed){
      r2.changed = false
      return true
    }
    return false
    // return (r2.userInfo == this.oldSelect) || (r2.userInfo == this.doctor)
  }

  componentDidMount(){
    InteractionManager.runAfterInteractions(() => {
      this.setState({renderPlaceholderOnly: false});
    });
    if(this.props.mydoctors){
      this.getMyDoctorList()
    }else{
      this.getDoctorList()
    }
  }

  //请求下一页的数据
  loadNextPage(){
    if(!this.isLoading && !this.props.mydoctors){//只有在得到所有医生列表才能分页
      this.isLoading = true;
      this.getDoctorList(()=>{this.isLoading = false;});
    }
  }

  //得到我的医生的列表
  getMyDoctorList(){

    var doctorListCacheKey = "mydoctor_list_cache_key" + this.page;
    //刚启动界面要读取缓存
    var self = this
    LocalCache.get(doctorListCacheKey, function(data){
      if(data && !data.error){
        self.onDataChange(data.rows)
      }
    })

    this.isLoading = true
    //调用restful接口获得数据，这是我的医生，以后通过查询功能得到
    var params = {userid:User.currentUser.documentID}
    var url = Config.webAssistantServerURL + "users/list_assistant_doctor_friends"
    fetch(url, {
          method: "POST",
          headers: {'Content-Type': 'application/json'},
          body: JSON.stringify(params)
    })
    .then((response) => response.json())
    .then((data) => {
        this.isLoading = false
          if(data.error){
            //获取失败
            self.showToast(data.error)
          } else {
            //排好序的数据
            // console.log(JSON.stringify(data))
            this.onMyDoctorDataChange(data)
            //保存缓存，每次Load都是load的一个病案的
            LocalCache.save(doctorListCacheKey, {rows:data.doctors})
            this.page++;
          }
    }).catch(function(error) {
      if(error){
      }
    })

    // var data = DoctorFriendsList.instance.getDoctorFriendsList()
    // if(data || data.length != 0){
    //   this.onMyDoctorDataChange(data)
    // }else{
    //   this.showToast("你还没有医生好友")
    // }
  }

  onMyDoctorDataChange(data){
    if(!data || data.length == 0){return}
    var doctors = []
    for(var i = 0; i < data.length; i++){
      var ds = {}
      ds.userInfo = data[i].value
      ds.userInfo.documentID = data[i].id
      doctors.push(ds)
    }
    this.onDataChange(doctors)
  }

  onItemClick(dc,sectionID,rowID){
    var doctor = this.getRowData(this.groups,sectionID,rowID)
    if(!doctor)doctor = dc
    if(doctor != this.doctor){
      doctor.changed = true   //状态发生变化
      if(this.doctor)this.doctor.changed = true //状态发生变化

      this.doctor = doctor
      this.setState({dataSource:this.state.dataSource.cloneWithRowsAndSections(this.groups,this.sectionIds,this.rowIds)});
    }
  }

  onRightPress(){
    if(!this.doctor){
      this.showToast("请先选择一个医生")
      return
    }


    if (this.props.chatView.isUserInById[this.doctor.documentID]){
      this.showToast("该医生已经在这个群了")
      return
    }else if(this.props.chatView.isUserInById[this.doctor.assistant] && this.doctor.assistant != User.currentUser.documentID){
      this.showToast("该医生的助理已经在这个群了")
      return
    }

    //创建一个群，为聊天里的人的集合
    var friend
    var chatView = this.props.chatView
    var users = chatView.getUsers();

    if(users.length == 2){//单聊,新建一个群,要考虑所拉医生的助理是不是我自己
      var talkers = []//群里面除我以外所有人的集合
      //判断所加的医生的助理是不是我自己，
      //如果没有给医生分配助理，那么默认这个助理是当前助理
      var doctor
      if(!this.doctor.assistant){
        this.doctor.assistant = User.currentUser.documentID
      }
      //需要判断这个医生的助理是不是我，是我则把这个医生拉进群，不是则把这个医生的助理拉进群
      if(this.doctor.assistant == User.currentUser.documentID){
        this.doctor.documentID = this.doctor.id
        doctor = this.doctor //因为是用restfull请求的，所以唯一码为id
      }else{
        doctor = new User()  //其实创建的是这个医生的助理，要把他拉进群
        doctor.role_type = Constant.Role_Assistant
        doctor.documentID = this.doctor.assistant
        doctor.name = this.doctor.name+"的助理"
        doctor.id = this.doctor.assistant
        // doctor.doctor = this.doctor//只有真正发医生的时候才发名片
      }
      talkers.push(doctor)

      var name = doctor.name+"、"
      for(var i = 0; i < users.length; i++){
        var user = users[i]
        if(user.documentID != User.currentUser.documentID){
          talkers.push(user)
          name += user.name
          break;
        }
      }

      //要传递过去的参数
      var message = {}
      message.debugName = name
      message.talkers = talkers
      message.relationship = {type:'Group'}
      //到新的聊天界面
      var GroupChat = require("../chat/GroupChatView")
      chatView.pushWidthComponent(<GroupChat navigator={chatView.props.navigator} message={message}/>)

    }else {//群聊，拉人进群，这种情况只会是助理拉医生进群
      chatView.addMember(this.doctor)
      chatView.pop();
    }
  }

  renderSelectView(doctor){
    return(
      <Image
      style={istyles.icon}
      source={this.doctor==doctor?sel:unsel}/>
    )
  }

}

var istyles = StyleSheet.create({
  icon:{
    width:w(15),
    height:w(15),
  },
  select:{
    alignSelf:'flex-end',
    justifyContent:'flex-end'
  }
})

module.exports = SelectDoctorList;
