// /**
//  *
//  * 选择医生的列表界面(给客户（患者）推荐医生时的选择医生的界面，只能选择一个医生）
//  * @author reason 2015-12-07
//  *
//  */
//
// 'use strict';
//
// var React = require('react-native');
// var Config = require('../../constant/Config.js');
//
// var {
//   StyleSheet,
//   Text,
//   Image,
//   View,
//   ListView,
//   TouchableHighlight
// } = React;
//
// var BaseComponent = require('../BaseComponent')
// var {Button} = require('../../utils/Styles');
// var {Group,User} = require("../Models");
// var Constant = require("../../constant/Constant")
// var DoctorList = require('../users/DoctorFriendsList')
// var DoctorFriendsList = require('../users/DoctorFriendsList')
//
// class SelectDoctorList_old extends BaseComponent{
//
//   constructor(props){
//     super(props)
//
//     this.page = 0;
//     this.isLoading = false;
//     this.allDoctors = {};
//     this.isTabBarChild = true;
//
//     var config = {title:"医生",leftButtonTitle:"返回",rightButtonTitle:"确认"}
//     var ds = new ListView.DataSource({rowHasChanged:(r1,r2)=>this.rowHasChanged(r1,r2)});//this.rowHasChanged(r1,r2)
//     this.state = {navigatorBarConfig:config,dataSource:ds,doctor:null}
//   }
//
//   componentWillMount(){
//     if(this.props.mydoctors){
//       this.getMyDoctorList()
//     }else{
//       this.getAllDoctorList()
//     }
//   }
//
//   //医生被选中后判断是否重新刷新UI
//   rowHasChanged(r1,r2){
//     if(r2.userInfo.changed){
//       r2.userInfo.changed = false
//       return true
//     }
//     return false
//     // return (r2.userInfo == this.oldSelect) || (r2.userInfo == this.doctor)
//   }
//
//   //得到我的医生的列表
//   getMyDoctorList(){
//     var data = DoctorFriendsList.instance.getDoctorFriendsList()
//     if(data || data.length != 0){
//       this.onMyDoctorDataChange(data)
//     }else{
//       this.showToast("你还没有医生好友")
//     }
//   }
//
//   //得到所有医生的列表
//   getAllDoctorList(callback){
//     //调用restful接口获得数据，这是所有医生，以后通过查询功能得到
//     var params = {page:this.page, pageSize:200} //TODO 根据实际页面修改参数
//     var url = Config.webBaoshiServerURL + "users/get_doctors"
//     var _this = this;
//     fetch(url, {
//           method: "POST",
//           headers: {'Content-Type': 'application/json'},
//           body: JSON.stringify(params)
//     })
//     .then((response) => response.json())
//     .then((data) => {
//       if(data.error){
//         //获取失败
//         _this.showToast(data.error)
//       } else {
//         // console.log(JSON.stringify(data))
//         this.onDataChange(data.doctors)
//         this.page++;
//         if(callback)callback();
//       }
//     }).catch(function(error) {
//       if(error){
//         //TODO handle login error
//       }
//     })
//   }
//
//   //请求下一页的数据
//   loadNextPage(){
//     if(!this.isLoading && !this.props.mydoctors){//只有在得到所有医生列表才能分页
//       this.isLoading = true;
//       this.getAllDoctorList(()=>{this.isLoading = false;});
//     }
//   }
//
//   onMyDoctorDataChange(data){
//     if(!data || data.length == 0){return}
//     this.doctors = []
//     for(var i = 0; i < data.length; i++){
//       var ds = {}
//       ds.userInfo = data[i]
//       this.doctors.push(ds)
//     }
//     this.setState({dataSource:this.state.dataSource.cloneWithRows(this.doctors)})
//   }
//
//   //更新数据
//   onDataChange(data){
//     if(!data)return
//
//     //组装以前的数据
//     this.allDoctors[this.page] = data;
//     var keys = Object.keys(this.allDoctors).sort();
//     var doctors = [];
//     keys.forEach((key)=>{
//       doctors =  doctors.concat(this.allDoctors[key])
//     })
//     this.doctors = doctors
//     this.setState({dataSource:this.state.dataSource.cloneWithRows(doctors)})
//   }
//
//   onLeftPress(){
//     this.props.chatView.pop()
//   }
//
//   onRightPress(){
//     if(!this.doctor){
//       this.showToast("请先选择一个医生")
//       return
//     }
//
//     if (this.props.chatView.userMap[this.doctor.documentID]){
//       this.showToast("该医生已经在这个群了")
//       return
//     }else if(this.props.chatView.userMap[this.doctor.assistant] && this.doctor.assistant != User.currentUser.documentID){
//       this.showToast("该医生的助理已经在这个群了")
//       return
//     }
//
//     //创建一个群，为聊天里的人的集合
//     var friend
//     var chatView = this.props.chatView
//     var userMap = chatView.userMap;
//     var keys = Object.keys(userMap)
//
//     if(keys.length == 2){//单聊,新建一个群,要考虑所拉医生的助理是不是我自己
//       var talkers = []//群里面除我以外所有人的集合
//       //判断所加的医生的助理是不是我自己，
//       //如果没有给医生分配助理，那么默认这个助理是当前助理
//       var doctor
//       if(!this.doctor.assistant){
//         this.doctor.assistant = User.currentUser.documentID
//       }
//       //需要判断这个医生的助理是不是我，是我则把这个医生拉进群，不是则把这个医生的助理拉进群
//       if(this.doctor.assistant == User.currentUser.documentID){
//         this.doctor.documentID = this.doctor.id
//         doctor = this.doctor //因为是用restfull请求的，所以唯一码为id
//       }else{
//         doctor = new User()  //其实创建的是这个医生的助理，要把他拉进群
//         doctor.role_type = Constant.Role_Assistant
//         doctor.documentID = this.doctor.assistant
//         doctor.name = this.doctor.name+"的助理"
//         doctor.id = this.doctor.assistant
//       }
//       talkers.push(doctor)
//
//       var name = doctor.name+"、"
//       for(var i = 0; i < keys.length; i++){
//         var key = keys[i]
//         if(key != User.currentUser.documentID){
//           talkers.push(userMap[key])
//           name += userMap[key].name
//           break;
//         }
//       }
//
//       //要传递过去的参数
//       var message = {}
//       message.debugName = name
//       message.talkers = talkers
//       message.relationship = {type:'Group'}
//       //到新的聊天界面
//       var GroupChat = require("../chat/GroupChatView")
//       chatView.pushWidthComponent(<GroupChat navigator={chatView.props.navigator} message={message}/>)
//
//     }else {//群聊，拉人进群，这种情况只会是助理拉医生进群
//       chatView.addMember(this.doctor)
//       chatView.pop();
//     }
//   }
//
//   //得到医生头像
//   getDoctorIcon(doctor){
//     return doctor ? require('image!gy') : require('image!myhead');
//   }
//
//   onItemClick(doctor){
//
//     if(doctor != this.doctor){
//       doctor.changed = true   //状态发生变化
//       if(this.doctor)this.doctor.changed = true //状态发生变化
//       // this.oldSelect = this.doctor
//       this.doctor = doctor
//       this.setState({dataSource:this.state.dataSource.cloneWithRows(this.doctors)})
//     }
//   }
//
//   renderSelect(doctor){
//     if(doctor == this.doctor){
//       return(<View style={istyles.radio_y}/>)
//     }else{
//       return(<View style={istyles.radio_n}/>)
//     }
//   }
//
//   renderRow(rowData){
//     var doctor = rowData.userInfo
//     return(
//       <TouchableHighlight
//         key={doctor.id}
//         underlayColor="rgba(221, 221, 221, 0.5)"
//         onPress={()=>{this.onItemClick(doctor)}}>
//         <View style={istyles.contentContainer}>
//
//
//         <View
//           style={[doctor==this.doctor && istyles.radio_y,doctor!=this.doctor && istyles.radio_n]}/>
//
//         <Image style={istyles.icon}
//          source={this.getDoctorIcon(doctor)}/>
//
//           <View style={istyles.infoContainer}>
//               <View style={istyles.nameContainer}>
//                 <Text>{doctor.name}</Text>
//                 <Text style={istyles.depatLabel}>{doctor.department}</Text>
//               </View>
//             <Text>长江医院</Text>
//           </View>
//
//         </View>
//       </TouchableHighlight>
//     )
//   }
//
//   onScroll(){
//     if (this.refs.listview.scrollProperties.offset + this.refs.listview.scrollProperties.visibleLength >= this.refs.listview.scrollProperties.contentLength){
//         this.refs.listview.props.onEndReached();
//     }
//   }
//
//   _render(){
//     return (
//       <ListView
//         ref="listview"
//         onScroll={this.onScroll.bind(this)}
//         onEndReached={this.loadNextPage.bind(this)}
//         dataSource={this.state.dataSource}
//         renderRow={this.renderRow.bind(this)}
//       />
//     )
//   }
// }
//
// var istyles = StyleSheet.create({
//   contentContainer:{
//     height:60,
//     paddingLeft:20,
//     alignItems:'center',
//     flexDirection:'row'
//   },
//   radio_n:{
//     width:15,
//     height:15,
//     borderWidth:1,
//     // backgroundColor:'#999'
//   },
//   radio_y:{
//     width:15,
//     height:15,
//     backgroundColor:'#f00'
//   },
//   icon:{
//     width:40,
//     height:40,
//     marginLeft:10
//   },
//   infoContainer:{
//     paddingLeft:15
//   },
//   nameContainer:{
//     flexDirection:'row',
//     marginBottom:3
//   },
//   depatLabel:{
//     marginLeft:12
//   }
// });
//
// module.exports = SelectDoctorList_old;
