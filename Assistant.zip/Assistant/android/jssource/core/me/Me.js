'use strict';

var React = require('react-native');
var {
  StyleSheet,
  Alert,
  Text,
  Image,
  View,
  TextInput,
  TouchableHighlight,
  AsyncStorage
} = React;

var {Color,Tools,len,fs} = require('../../utils/Styles');
var UIImagePickerManager = require('NativeModules').UIImagePickerManager;
var {User} = require("../Models");
var {DatabaseManager} = require("../couchbase/Couchbase");
var {w,h,screenWidth} = require('../../utils/Porting')
// var ImageView = require('../../widget/ImageView')
var BaseComponent = require('../BaseComponent')

var LastLoginKey = "lastLoginUser"
var {LoginLogic} = require('../../../../JSLibrary/Logic');
let loginLogic = new LoginLogic();

class Me extends BaseComponent {
  constructor(props){
    super(props);
    // this.name = User.currentUser.name;
    var config = {title:"基本信息",showBackIcon:true};
    this.state = {navigatorBarConfig:config,userName:User.currentUser.name};
    React.NativeModules.CouchbaseHelper.getVersion((v)=>{
      this.setState({version:v});
    })
  }

  onLeftPress(){
    // if(!this.name || this.name == ""){
    //   this.showMsg("姓名不能为空!")
    //   return
    // }
    //已经修改为在其他页面修改并保存名字了。见下面editText()方法：
    // if(User.currentUser.name != this.name){
    //   User.currentUser.name = this.name
    //   User.currentUser.save()
    // }

    this.pop()
  }

  selectHead(){
    var self = this;
    var options = {
      title:"选择头像",
      cancelButtonTitle: '取消',
      takePhotoButtonTitle: '拍照', // specify null or empty string to remove this button
      chooseFromLibraryButtonTitle: '选择图片', // specify null or empty string to remove this button
      maxWidth: 600,
      maxHeight: 600,
      quality: 0.7,
      allowsEditing: false, // Built in iOS functionality to resize/reposition the image
      noData: false, // Disables the base64 `data` field from being generated (greatly improves performance on large photos)
      storageOptions: { // if this key is provided, the image will get saved in the documents directory (rather than a temporary directory)
        skipBackup: true, // image will NOT be backed up to icloud
        path: User.currentUser.documentID+'/Images' // will save image at /Documents/images rather than the root
      }
    };

    if(React.Platform.OS === 'ios'){
      UIImagePickerManager.showImagePicker(options, (didCancel, response) => {
        if (didCancel) {
        }
        else {
          User.currentUser.headIcon = {objectKey:response.fileName,status:0};
          User.currentUser.save(()=>{
              DatabaseManager.instance.currentDatabase.checkUploadFile();
          });
        }
      });
      }else if (React.Platform.OS === 'android') {
            React.NativeModules.ActionSheet.showActionSheet(["拍照","选择图片"],"取消",(index)=>{
              React.NativeModules.AndroidSelectPhoto.selectPhoto(index,options,(response)=>{
                User.currentUser.headIcon = {objectKey:response.fileName,status:0};
                User.currentUser.save(()=>{
                    DatabaseManager.instance.currentDatabase.checkUploadFile();
                });
              })
            })
        }


  }

  //退出帐号
  exit(){
    // var Login = require('../Login');
    LoginLogic.Logout(this.props.navigator,false);
  }

  // onNameChange(text){
  //   if(text.length > 15){
  //     text = text.substr(0,15)
  //   }
  //   this.setState({userName:text});
  //   this.name=text;
  // }

  editText(){
    var EditText = require('../EditTextView');
    var self = this;
    this.pushWidthComponent(
      <EditText navigator={this.props.navigator}
        title={"姓名"}
        value={User.currentUser.name}
        maxLength={{max:30,des:"姓名不能超过15个字"}}
        onSureClick={(name)=>{
          User.currentUser.name = name;
          User.currentUser.save();
          self.setState({userName:name});}
        } />
    )
  }

  _render() {
    return(
      <View style={styles.container}>

        <TouchableHighlight onPress={()=>this.selectHead()} underlayColor={Color.itemClick}>
            <View style={styles.item}>
                <Text style={[styles.title,styles.container]}>头像</Text>
                <Image source={require('../../res/icon_arrow_right.png')} style={styles.itemArror} />
            </View>
        </TouchableHighlight>

        <TouchableHighlight onPress={()=>{this.editText()}} underlayColor={Color.itemClick}>
          <View style={styles.item}>
            <Text style={styles.title}>姓名</Text>
            <Text style={styles.input} numberOfLines={1}>{this.state.userName}</Text>
          </View>
        </TouchableHighlight>

        <View style={styles.line} />

        <View style={styles.item}>
            <Image  source={require('../../res/icon_version.png')} style={styles.itemImage}/>
            <Text style={styles.title}>版本号</Text>
            <Text style={styles.version}>{this.state.version}</Text>
        </View>

        <TouchableHighlight onPress={()=>this.exit()} underlayColor={Color.itemClick}>
          <View style={styles.item}>
            <Image  source={require('../../res/icon_exit.png')} style={styles.itemImage}/>
            <Text style={styles.title}>退出登录</Text>
          </View>
        </TouchableHighlight>

      </View>
    )
  }
}

// <View style={styles.item}>
//   <Text style={styles.title}>姓名</Text>
//   <TextInput
//     style={styles.input}
//     maxLength={15}
//     textAlign={React.Platform.OS === 'ios'?'right':'end'}
//     value={this.state.userName}
//     onChange={(text)=>{this.onNameChange(text.nativeEvent.text)}}/>
// </View>

var styles = StyleSheet.create({
  container:{
    flex:1,
  },
  item:{
    height:w(50),
    flexDirection:'row',
    marginHorizontal:w(12),
    alignItems:'center',
    borderBottomWidth:len('itemDivider'),
    borderColor:Color.itemDivider,
  },
  title:{
    // flex:1,
    fontSize:fs('28'),
    color:Color.title,
    width:w(70),
  },
  itemArror:{
    width:w(7),
    height:w(15),
    tintColor:"#999",
    justifyContent:'flex-end'
  },
  input:{
    flex:1,
    // height:w(48),
    fontSize:fs('24'),
    marginLeft:w(10),
    marginVertical:w(1),
    color:"#999",
    textAlign:'right'
  },
  line:{
    marginTop:w(50),
    backgroundColor:Color.itemDivider,
    height:len('itemDivider'),
    marginHorizontal:w(12),
  },
  itemImage:{
    width:w(15),
    height:w(15),
    marginRight:w(10)
  },
  version:{
    flex:1,
    fontSize:fs('28'),
    color:"#bbb",
    textAlign:'right',
  }
})

module.exports = Me;
