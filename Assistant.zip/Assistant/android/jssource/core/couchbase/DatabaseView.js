'use strict';
//
// var Config = require("../../constant/Config");
// var Database = require("./Database");
//
// class DatabaseView {
//   viewName:String;
//   //本地数据库是否创建
//   created:Boolean;
//   database:Database;
//   //是否run(每隔一段时间查看view是否更新)
//   running:Boolean;
//   //数据发生变化的回调
//   onViewDataChangeCallback:Function;
//   key:String;//fitter key
//   limit:Number;
//   descending:Boolean;//是否倒序
//   type:String;//关心的数据类型
//   startKey:String;
//   beforeUpdate:Function;
//   //创建view,指定database，type,name，mapFunction,type(关心的数据类型)
//   constructor(database,type,name,mapFunction,initCallback) {
//     this.viewName = name;
//     this.rows = [];
//     if(!this.viewName) throw new Error("database view name can't be null");
//     this.database = database;
//     this.type = type;
//     if(!this.database) throw new Error("no a database here");
//     if(!(database instanceof Database)) throw new Error("first parameter no a instanceof Database");
//     if(typeof(mapFunction) != "string" )  throw new Error("map function not string");
//     var url = Config.localURL+this.database.dbName+"/_design/"+this.viewName;
//     var views = {};
//     views[this.viewName] = {
//       "map" : mapFunction
//     };
//     fetch(url).then((response) => {
//       if (response.status !== 200) {
//         fetch(url, {
//           method: "PUT",
//           headers: {'Content-Type': 'application/json'},
//           body: JSON.stringify({
//             "language" : "javascript",
//             "views" :views
//           })
//         }).then((response) => response.json())
//           .then((data) => {
//             this.onCreated(initCallback);
//           });
//       } else {
//          this.onCreated(initCallback);
//       }
//     })
//   }
//
//   onCreated(initCallback){
//     this.created = true;
//     if(this.type)this.database.addChangeCallback(this.type,this,this.update.bind(this));
//     if(initCallback)initCallback();
//   }
//   stop(){
//     this.database.removeChangeCallback(this.type,this);
//   }
//   //设置数据发生变化时的回调函数
//   setOnDataChangeCallback(callback){
//     if(typeof(callback) != "function") throw new Error("callback not a function");
//     this.onViewDataChangeCallback = callback;
//     this.update();
//   }
//   update(doc){
//     if(!this.onViewDataChangeCallback) return;
//     if(this.beforeUpdate)this.beforeUpdate();
//     fetch(this.getRowsUrl()).then(
//       (response) => response.json()
//     )
//     .then((data)=>{
//       // console.log(data.total_rows);
//
//         // if(this.viewName == "MessageView_doctor_rr5_doctor_rr78"){
//         //   console.log("~~~~~~",typeof(this.onViewDataChangeCallback),null);
//         // }
//         if(this.onViewDataChangeCallback)this.onViewDataChangeCallback(data.rows);
//         // console.dblog("----- "+ this.viewName +" view data:"+JSON.stringify(data));
//     });
//   }
//   getHistoryDocs(startKey, skip, limit, descending, onHistoryViewDataCallback){
//     var url = this.getUrl()
//     var parameters = [];
//     if(limit){
//       parameters.push("limit="+limit);
//     }
//     if(descending){
//       parameters.push("descending="+descending);
//     }
//     if(skip){
//       parameters.push("skip="+skip);
//     }
//     if(startKey){
//       parameters.push("startkey=\""+startKey+"\"");
//     }
//     //不读取endkey_docid自己
//     //parameters.push("inclusive_end="+false);
//
//     var filtter = "";
//     for (var i = 0; i < parameters.length; i++) {
//       if(i == 0){
//         filtter = "?" + parameters[i];
//       }else{
//         filtter = filtter + "&" + parameters[i];
//       }
//     }
//     url = url + filtter
//     //console.log("---view :"+this.viewName+" url:"+url+filtter);
//     fetch(url).then((response) => response.json())
//     .then((data)=>{
//       // console.log(data.total_rows);
//
//         // if(this.viewName == "MessageView_doctor_rr5_doctor_rr78"){
//         //   console.log("~~~~~~",typeof(this.onViewDataChangeCallback),null);
//         // }
//         if(onHistoryViewDataCallback)onHistoryViewDataCallback(data.rows);
//         // console.dblog("----- "+ this.viewName +" view data:"+JSON.stringify(data));
//     });
//   }
//   getUrl(){
//     return  Config.localURL+this.database.dbName+"/_design/"+this.viewName+"/_view/"+this.viewName;
//   }
//   //返回访问view的url
//   getRowsUrl(){
//       var url = this.getUrl();
//       var parameters = [];
//       if(this.key){
//         parameters.push("key=\""+this.key+"\"");
//       }
//       if(this.limit){
//         parameters.push("limit="+this.limit);
//       }
//       if(this.descending){
//         parameters.push("descending="+this.descending);
//       }
//       if(this.startKey){
//         parameters.push("startkey=\""+this.startKey+"\"");
//       }
//       var filtter = "";
//       for (var i = 0; i < parameters.length; i++) {
//         if(i == 0){
//           filtter = "?" + parameters[i];
//         }else{
//           filtter = filtter + "&" + parameters[i];
//         }
//       }
//       console.log("---view :"+this.viewName+" url:"+url+filtter);
//       return url+filtter;
//   }
// }
//
var DatabaseView = require('../../../../JSLibrary/logic/couchbase/DatabaseView');
module.exports = DatabaseView;
