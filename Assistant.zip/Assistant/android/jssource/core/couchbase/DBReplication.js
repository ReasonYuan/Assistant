'use strict';

var Config = require("../../constant/Config");
var DatabaseFilter = require("./DatabaseFilter");

class DBReplication {
  type:String;//PUSH/PULL
  database:Database;
  sessionId:String;
  loginSession:String;//登陆需要的session
  constructor(database) {
    this.database = database;
  }
  start(){
    throw new Error("😊😊😊😊,abstract function");
  }
  onError(e){
    console.log("socket error",e);
    //出错重连
    this.start();
  }
  setSession(session){
    this.loginSession  = session;
  }
}


class DBPullReplication extends DBReplication{
  filterName:String;
  filterParams:String;
  constructor(database) {
    super(database)
    this.type = "PULL";
  }
  start(){
    var headers =  { };
    if(this.loginSession){
      headers.Cookie = this.loginSession.cookie_name+"="+this.loginSession.session_id
    }
    fetch(Config.localURL + "_replicate", {
      method: "POST",
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({
        "create_target": false,
        "source": {
          "url":Config.serverURL+Config.serverBucket,
          "headers":headers
        },
        "target": this.database.dbName,
        "continuous": true
      })
    }).then(
      (response) => response.json()
    ).then((data) => {
      console.log("PULL Data",data);
      this.sessionId = data.session_id;
      return Promise.resolve(true);
    }).catch((e) => {
      this.onError(e);
    });
  }
  setFilter(name,filterFunc,filterParams,callback){
    //创建filter
    this.filterParams = name;
    this.filterParams = filterParams;
    new DatabaseFilter(this.database,name,filterFunc,()=>{
        // console.error("dd");
    });
  }
}


class DBPushReplication extends DBReplication{
  constructor(database) {
    super(database);
    this.type = "PUSH";
  }
  start(){
    var headers =  { };
    if(this.loginSession){
      headers.Cookie = this.loginSession.cookie_name+"="+this.loginSession.session_id
    }
    fetch(Config.localURL + "_replicate", {
      method: "POST",
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({
        "create_target": false,
        "target": {
          "url":Config.serverURL+Config.serverBucket,
          "headers":headers
        },
        "source": this.database.dbName,
        "continuous": true
      })
    }).then(
      (response) => response.json()
    ).then((data) => {
      console.log("PUSH Data",data);
      this.sessionId = data.session_id;
      return Promise.resolve(true);
    }).catch((e) => {
      this.onError(e);
    });
  }
}

module.exports = {"DBPullReplication":DBPullReplication,"DBPushReplication":DBPushReplication};
