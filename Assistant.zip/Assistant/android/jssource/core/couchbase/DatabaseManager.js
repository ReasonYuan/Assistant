'use strict';
// var Database = require("./Database")
//
// class DatabaseManager {
//   currentDatabase:Database;
//   //为每一个用户创建一个数据库，currentDatabase是当前登录的用户
//   databaseNamed(name,callback) {
//     var self = this;
//     this.currentDatabase = new Database(name,()=>{
//         // self.currentDatabase =  self[name];
//         if(callback) callback(  this.currentDatabase);
//       });
//     // if(!this[name]){
//     //   self[name] = new Database(name,function(){
//     //     self.currentDatabase =  self[name];
//     //     if(callback) callback(self[name]);
//     //   });
//     // }else{
//     //   self.currentDatabase =  self[name];
//     //   if(callback) callback(self[name]);
//     // }
//   }
//   clean(){
//       if(this.currentDatabase)this.currentDatabase.clean()
//   }
// }
//
//
// var instance = new DatabaseManager();
// DatabaseManager.sharedInstance = instance;
// DatabaseManager.instance = instance;
//
var DatabaseManager = require('../../../../JSLibrary/logic/couchbase/DatabaseManager');
module.exports = DatabaseManager;
