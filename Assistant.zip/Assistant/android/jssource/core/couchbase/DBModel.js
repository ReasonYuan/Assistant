'use strict';
// class DBModel {
//   documentID:String;
//   rev:String;
//   type:String;
//   channels:[String];
//   _attachments:[String];
//   date:Date;
//   constructor(type) {
//     this.type = type;
//     this.channels = [];
//     this.date = new Date();
//   }
//
//   //返回一个object保存到数据库是去除无用的的属性，documentID，rev
//   getSaveModel(){
//     var clone = require('../Models').modelForType(this.type); //clone ,去除无用的属性
//     clone.setProperty(this)
//     var obj = {};
//     for (var key in clone) {
//       var value = clone[key];
//       if(value instanceof DBModel){ //必须要有rev才是保存到数据库的
//         obj[key] = value.documentID;
//         // obj[key] = {"documentID":value.documentID,type:value.type};
//       }else if (key == "date") {
//         obj[key] = clone[key].getTime().toString();
//       }else {
//         obj[key] = clone[key];
//       }
//     }
//     delete obj.documentID;
//     delete obj.rev;
//     return obj;
//   }
//
//   setProperty(otherObject){
//     if(otherObject){
//       for (var key in this) {
//         var tmp = otherObject[key];
//         if(tmp || typeof(tmp) == "number"){
//           if(key == "date"){
//             this.date = new Date(new Number(tmp));
//           }else{
//             this[key] = tmp;
//           }
//         }
//       }
//     }
//     if(otherObject._id) this.documentID = otherObject._id;
//     if(otherObject._rev) this.rev = otherObject._rev;
//     return this;
//   }
//
//   save(callback){
//     var DatabaseManager = require("./DatabaseManager")
//     var db = DatabaseManager.instance.currentDatabase;
//     if(db){
//       db.saveModel(this,callback);
//     }else{
//       console.error("don't created Database on save model");
//     }
//   }
//
//   delete(){
//     var DatabaseManager = require("./DatabaseManager")
//     var db = DatabaseManager.instance.currentDatabase;
//     if(db && this.documentID){
//       db.deleteModel(this);
//     }else{
//       console.error("don't created Database on save model");
//     }
//   }
//
//   //添加附件，document，附件名，附件，回调（true/false）
//   addAttachment(attachmentId,contentType,data,callback){
//     var DatabaseManager = require("./DatabaseManager")
//     var db = DatabaseManager.instance.currentDatabase;
//     if(db && this.documentID){
//       db.addAttachment(this,attachmentId,contentType,data,callback);
//     }else{
//       console.error("don't created Database on save model");
//     }
//   }
//
//   //获取附件，document，附件名，回调（null/data）
//   getAttachment(attachmentId,callback){
//     var DatabaseManager = require("./DatabaseManager")
//     var db = DatabaseManager.instance.currentDatabase;
//     if(db && this.documentID){
//       db.getAttachment(this,attachmentId,callback);
//     }else{
//       console.error("don't created Database on save model");
//     }
//   }
// }
//
//
var DBModel = require('../../../../JSLibrary/logic/couchbase/DBModel');
module.exports = DBModel;
