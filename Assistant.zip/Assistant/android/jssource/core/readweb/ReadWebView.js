/**
 *
 * 阅读网页时打开的View
 * @author reason 2015-12-08
 *
 */

'use strict';

var React = require('react-native');

var {
  StyleSheet,
  View,
} = React;

var IOSWebView = React.WebView;

var BaseComponent = require('../BaseComponent')

class ReadWebView extends BaseComponent{

  constructor(props) {
    super(props);
    var title = props.title || "网页浏览"
    this.isTabBarChild = true;
    this.state = {navigatorBarConfig:{title:title,leftButtonTitle:"返回"}}
  }

  onLeftPress(){
    this.pop();
  }

  _render(){
    return (
        <View style ={istyles.webContainer}>
            <IOSWebView
              automaticallyAdjustContentInsets={false}
              style={istyles.full}
              url={this.props.url||'https:www.baidu.com'}
              javaScriptEnabledAndroid={true}
              startInLoadingState={true}
              scalesPageToFit={true}
            />
        </View>
    );
  }
}

var istyles = StyleSheet.create({
  full:{
    flex:1
  },
  webContainer:{
    flex:1,
    alignItems:'stretch',
  }
});

module.exports = ReadWebView;
