/**
 *
 * 界面基础类
 *
 * @author reason  2015-12-17
 *
 **/
'use strict';

var React = require('react-native');
var TimerMixin = require('react-timer-mixin');
var reactMixin = require('react-mixin');

var {
  View,
  Text,
  StyleSheet,
  LayoutAnimation,
  Animated,
  InteractionManager
} = React;

var NavigationBar = require('./NavigationBar')
var NetInfo = require('../utils/NetInfo');
var Config = require('../constant/Config');
var {w,h,f} = require('../utils/Porting')

var NAVIGATION_BAR_HEIGHT = React.Platform.OS === 'ios'?64:44;

var {Fetch} = require('../../../JSLibrary/Logic')

class BaseComponent extends React.Component{
  isShowNoNetworkLayer:Boolean;
  unmounted:Boolean;
  isWarningAnimFinish = true;
  constructor(props) {
    super(props);
    this.unmounted = false;
    this.isShowNoNetworkLayer = !NetInfo.isConnected;
  }
  // setTimeout(cb,interval){
  //   if(!this.unmounted)this.mixins.push(TimerMixin.setTimeout(cb,interval));
  // }
  showNoNetworkLayer(){
    if(this.isShowNoNetworkLayer) return;
    this.isShowNoNetworkLayer = true;
    LayoutAnimation.configureNext(LayoutAnimation.Presets.linear);
    this.setState({isShowNoNetworkLayer:this.isShowNoNetworkLayer});
  }
  hideNoNetworkLayer(){
    if(this.isShowNoNetworkLayer){
      this.isShowNoNetworkLayer = false;
      LayoutAnimation.configureNext(LayoutAnimation.Presets.linear);
      this.setState({isShowNoNetworkLayer:this.isShowNoNetworkLayer});
    }
  }

  isConnected(){
    return NetInfo.isConnected;
  }

  componentDidMount(){
    NetInfo.addChangeListener(this._handleConnectivityChange.bind(this));
    this.mixins = [];
  }
  componentWillUnmount(){
    this.unmounted = true;
    NetInfo.removeChangeListener(this._handleConnectivityChange.bind(this));
    TimerMixin.clearTimeout(this.mixins);
  }
  _handleConnectivityChange(isConnected) {
    if(isConnected){
      this.hideNoNetworkLayer();
    }else{
      this.showNoNetworkLayer();
    }
  }

  //导航左边按钮被点击
  onLeftPress(){ }
  //导航右边按钮被点击
  onRightPress(){ }

  _render(){
    // throw new Error("not implement");
  }

  // let networkViewHieght = this.isShowNoNetworkLayer ? 20 : 0;
  // <View style={{backgroundColor:'black',height:networkViewHieght}}>
  // </View>

  _renderPlaceholderView() {
    return (
      <View style={{flex:1,justifyContent:'center',alignItems: 'center'}}>
        <Text>Loading...</Text>
      </View>
    );
  }

  render(){

    return (
      <View style={[istyles.full]}>
        {
          (()=>{
            var navigatorBarConfig = this.state ? this.state.navigatorBarConfig : null;
            if(navigatorBarConfig){
              return(
                  <NavigationBar
                    title={navigatorBarConfig.title}
                    showBackIcon={navigatorBarConfig.showBackIcon}
                    leftButtonTitle={navigatorBarConfig.leftButtonTitle}
                    rightIcon={navigatorBarConfig.rightIcon}
                    rightButtonTitle={navigatorBarConfig.rightButtonTitle}
                    rColor={navigatorBarConfig.rColor}
                    onLeftPress={()=>this.onLeftPress()}
                    onRightPress={()=>this.onRightPress()}
                    />
                )
            }
          })()
        }

        { this._render() }

        { this.renderWarningMsg() }
      </View>
    )
  }

  renderWarningMsg(){
    // if(this.state.waringMsg){
    //   let warningHeight = this.state.warningMsg ? NAVIGATION_BAR_HEIGHT : 0;
    //   return(
    //     <View style={[istyles.warning,{height:warningHeight}]}>
    //       <View style={istyles.warningContainer}>
    //         <Text style={istyles.warningLabel} > {this.state.warningMsg} </Text>
    //       </View>
    //     </View>
    //   )
    // }
    if(this.state.warningMsg && this.state.warning != '') {
        return (
          <Animated.View
            style={[istyles.warning,{transform:[
             {translateY: this.state.anim},
           ]}]}>
              <Text style={{color:'white',fontSize:14,marginLeft:20,marginRight:20}} > {this.state.warningMsg} </Text>
          </Animated.View>
        );
    }
  }

  showWarning(msg){
    if(msg instanceof Error){
      msg = msg.message;
    }
    if(!msg || "" == msg || !this.isWarningAnimFinish) return;
    this.isWarningAnimFinish = false;
    this.setState({warningMsg:msg,anim:new Animated.Value(0)});
    Animated.spring(          // Uses easing functions
       this.state.anim,    // The value to drive
       {toValue: NAVIGATION_BAR_HEIGHT}
     ).start(()=>{
       this.setState({anim:new Animated.Value(NAVIGATION_BAR_HEIGHT)});
       this.state.anim.setValue(NAVIGATION_BAR_HEIGHT);
       Animated.spring(          // Uses easing functions
          this.state.anim,    // The value to drive
          {toValue: 0}
        ).start(()=>{
          this.setState({warningMsg:null});
          this.isWarningAnimFinish = true;
        });
     });
  }

  showToast(msg){
    this.showWarning(msg)
    // React.NativeModules.CouchbaseHelper.showToast(msg);
  }
  push(C){
    this.props.navigator.push({
      component:<C navigator={this.props.navigator}/>
    })
  }
  replace(C){
    this.props.navigator.replace({
      component:<C navigator={this.props.navigator}/>
    })
  }
  pushWidthComponent(C){
    this.props.navigator.push({component:C})
  }
  pop(){
    this.props.navigator.pop()
  }
  //调用服务器(Config.webServerURL)接口，
  post(route,parameters,cb){
    console.log("HTTP请求:",parameters,"url:"+Config.webAssistantServerURL+route);
    BaseComponent.post(route,parameters,cb,Config.webAssistantServerURL)
  }

  static post(route,parameters,cb,baseurl){
    // var url = (baseurl || Config.webAssistantServerURL) + route
    // console.log("HTTP请求:",parameters,"url:"+url);
    // fetch(url, {
    //   method: "POST",
    //   headers: {
    //     'Accept': 'application/json',
    //     'Content-Type': 'application/json'
    //   },
    //   body: JSON.stringify(parameters)
    // }).then((response) => response.json())
    // .then((data) => {
    //   console.log("HTTP返回:",data,"url:"+url);
    //   if(cb)cb(null,data);
    // }).catch((e)=>{
    //   console.log("-->","Http errer:",e,"url:"+url);
    //   if(cb)cb(e);
    // })
    Fetch.post(route,parameters,cb,baseurl);
  }

  checkStringIsNull(str,errorMessage){
    var isNUll = (function(){
      if(typeof(str) == 'string'){
        if(str == ''){
          return true;
        }
        return false;
      }
      return true;
    })();
    if(isNUll && errorMessage){
      this.showToast(errorMessage)
    }
    return isNUll;
  }
}

reactMixin(BaseComponent.prototype, TimerMixin);

var istyles = StyleSheet.create({
  full:{
    flex:1
  },
  warning:{
    position:'absolute',
    left:0,
    top:-NAVIGATION_BAR_HEIGHT,
    right:0,
    height:NAVIGATION_BAR_HEIGHT,
    backgroundColor:'#CB4A5C',
    justifyContent:'center',
    alignItems:'center'
  },
  warningContainer:{
    flex:1,
    alignItems:'center',
    justifyContent:'center',
    marginTop:15,
    backgroundColor:"transparent"
  },
  warningLabel:{
    color:'white',
    fontSize:f(14),
    marginLeft:w(20),
    marginRight:w(20),
    textAlign:'center',
    // backgroundColor:'#00f'
  }
})

module.exports = BaseComponent
