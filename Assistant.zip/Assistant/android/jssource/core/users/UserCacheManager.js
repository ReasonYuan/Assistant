/**
 *
 * 缓存用户信息
 * @author johnny 2015-12-14
 *
 */

'use strict';

var Models = require("../Models")
var {User,Group,Patient,FriendShip,Message,Service,ChatFriendShip} = Models;
var {Database, DatabaseView,DatabaseManager} = require("../couchbase/Couchbase");
var Config = require("../../constant/Config")
var DataDispatcher = require("../stores/DataDispatcher")
var UserStore = require("../stores/UserStore")
var Actions = require("../stores/Actions")

class UserCacheManager {

  usersInCache = {};
  userUpdateView:DatabaseView;
  isFirstLoad = true;
  isFirstLoadComplete = false;
  firstLoadingCallback = null;
  needCheckCurrentUser;
  loginUserFoundCallback;

  //TODO 监听用户变化
  startCachingUsersInfo(firstLoadingCallback, loginUserFoundCallback){
    var self = this
    var db = DatabaseManager.instance.currentDatabase
    var userViewName = "SearchUser"
    var self = this
    this.isFirstLoad = true
    this.isFirstLoadComplete = false
    this.firstLoadingCallback = firstLoadingCallback
    this.needCheckCurrentUser = true
    this.loginUserFoundCallback = loginUserFoundCallback
    this.usersInCache = {}

    var userUpdateView =  new DatabaseView(db,"User",userViewName,"function(doc) { if(doc.type == 'User') { emit(doc._id, doc); } }",()=>{
      userUpdateView.setOnDataChangeCallback((data)=>{
        var rows = []
        for(var i=0; i<data.length; i++){
          rows.push(data[i].value)
        }
        self.onUserListChanged(rows, true)
      });
	  });
    userUpdateView.beforeUpdate = ()=>{
      if(self.isFirstLoad){
        self.isFirstLoad = false
        userUpdateView.limit = null;
        userUpdateView.descending = true;
      } else {
        userUpdateView.limit = 50; //TODO 需要优化， 如果一次变动超过10个人就会出错
        userUpdateView.descending = true;
      }
    }
    this.userUpdateView = userUpdateView

	  this.intantUserObserverId = DatabaseManager.instance.currentDatabase.registerIntantObserver(["User"], function(data){
      self.onUserListChanged(data, false)
    })
  }

  logout(){
    if(this.userUpdateView) {
      this.userUpdateView.stop()
      this.userUpdateView = null
    }
    if(this.intantUserObserverId){
      DatabaseManager.instance.currentDatabase.unregisterIntantObserver(this.intantUserObserverId)
      this.intantUserObserverId = null
    }
  }

  onUserListChanged(dataRows, bySearch){
  	var updatedUsers = {}
    var loginUser = null
    for(var i = 0; i < dataRows.length; i++){
      if(dataRows[i].type){
        var object = Models.modelForType(dataRows[i].type);
        object.setProperty(dataRows[i]);
        if(!object.documentID){
          console.log("warnning: not doucment id: " + JSON.stringify(object));
        } else {
          if(this.needCheckCurrentUser){
            if(object.documentID == User.currentLoginUserId){
              this.needCheckCurrentUser = false
              loginUser = object
            }
          }
          updatedUsers[object.documentID] = object
        }
        this.usersInCache[dataRows[i]._id] = object
      }
    }
    if(this.loginUserFoundCallback && loginUser){
      this.loginUserFoundCallback(loginUser)
    }
    if(!this.isFirstLoadComplete){
      this.isFirstLoadComplete = true
      //TODO loading proccess
      if(this.firstLoadingCallback) this.firstLoadingCallback()
    }
    if(dataRows.length > 0){
      DataDispatcher.dispatch({type:Actions.USER_CACHE_UPDATED, users:updatedUsers})
    }
    //第一次用查询，以后都是监听
    if(bySearch){
      this.userUpdateView.stop()
      this.userUpdateView = null
    }
  }

  getUserInfo(userid){
    if(!this.usersInCache[userid]){
      //this.requestUserInfo(userid, null)
      //role_type: 0 意味着没有role
      return {documentID:userid, name:"", notFound:true}
    }
    return this.usersInCache[userid];
  }

  requestUserInfo(userid, callback){
    if(this.usersInCache[userid]){
      if(callback) callback(this.usersInCache[userid])
    } else {
      var db = DatabaseManager.instance.currentDatabase
      var user = db.getModel(userid, function(data){
        if(callback) callback(data)
      });
    }
  }

}

var instance = new UserCacheManager();
UserCacheManager.instance = instance;

module.exports = UserCacheManager;
