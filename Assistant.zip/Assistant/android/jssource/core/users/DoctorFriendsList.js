/**
 *
 * 缓存医生朋友列表信息
 * @author johnny 2015-12-14
 *
 */

'use strict';

var Models = require("../Models")
var {User, FriendShip} = Models;
var {Database, DatabaseView,DatabaseManager} = require("../couchbase/Couchbase");
var UserCacheManager = require("./UserCacheManager")

class DoctorFriendsList {

  doctorListView:DatabaseView;

  doctorFriendsCache = {};

  doctorFriendShipCache = {};

  isFirstLoad = true;

  constructor(){
    var self = this
    var db = DatabaseManager.instance.currentDatabase
    var doctorListView = new DatabaseView(db,"FriendShip","LATEST_LIST_MYDOCTOR","function(doc) { if(doc.type == 'FriendShip' && (doc.fromType == 0 || doc.toType == 0) && (doc.fromType == 2 || doc.toType == 2)) { emit(doc.date||'0',doc);} }",()=>{
      doctorListView.setOnDataChangeCallback((data)=>self.onDoctorListChanged(data));
    });
    doctorListView.beforeUpdate = ()=>{
      if(self.isFirstLoad){
        self.isFirstLoad = false
        doctorListView.limit = null;
        doctorListView.descending = true;
      } else {
        //doctorListView.limit = 10; //TODO 需要优化， 如果一次变动超过10个人就会出错
        doctorListView.descending = true;
      }
    }
    this.doctorListView = doctorListView
  }

  logout(){
    if(this.doctorListView){
      this.doctorListView.stop()
    }
  }

  getDoctorFriendsList(){
    var results = []
    for(var item in this.doctorFriendShipCache){
      var fs = this.doctorFriendShipCache[item]
      var doctor = UserCacheManager.instance.getUserInfo(fs.getFriendId())
      if(doctor && doctor.documentID){
        results.push(doctor)
      }
    }
    return results
  }

  onDoctorListChanged(data){
    for(var i=0; i<data.length; i++){
      var item = data[i]
      var friendShip = new FriendShip(item.value.from, item.value.to)
      friendShip.setProperty(item.value)
      //http://114.215.196.3:7080/browse/HPAT-61?jql=project%20in%20(HDOC%2C%20HASS%2C%20HPAT)%20AND%20status%20in%20(%22In%20Progress%22%2C%20%22To%20Do%22)%20AND%20assignee%20in%20(currentUser())
      //根据上面这个jira issue, 由于没有复现，仅做如下优化
      if(friendShip.from == User.currentUser.documentID || friendShip.to == User.currentUser.documentID){
        this.doctorFriendShipCache[friendShip.documentID] = friendShip
      }
    }
  }


}

var doctorFriendsList = new DoctorFriendsList()
DoctorFriendsList.instance = doctorFriendsList

module.exports = DoctorFriendsList
