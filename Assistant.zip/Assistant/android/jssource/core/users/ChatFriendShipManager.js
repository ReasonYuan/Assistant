/**
 *
 * 缓存用户信息
 * @author johnny 2015-12-14
 *
 */

'use strict';

var Models = require("../Models")
var {User, FriendShip} = Models;
var {Database, DatabaseView,DatabaseManager} = require("../couchbase/Couchbase");
var UserCacheManager = require("./UserCacheManager")

//TODO 何以和DoctorFriendsList合并抽象一个父类
class ChatFriendShipManager {

  chatFriendListView:DoctorListView;

  chatFriendsCache = {};

  isFirstLoad = true;

  constructor(){
    var self = this
    var db = DatabaseManager.instance.currentDatabase
    var chatFriendListView = new DatabaseView(db,"ChatFriendShip","CHAT_DOCTOR_FRIENDSHIP_LIST","function(doc) { if(doc.type == 'ChatFriendShip') { emit(doc.date,doc);} }",()=>{
      chatFriendListView.setOnDataChangeCallback((data)=>self.onChatFriendListChanged(data));
    });
    chatFriendListView.beforeUpdate = ()=>{
      if(self.isFirstLoad){
        self.isFirstLoad = false
        chatFriendListView.limit = null;
        chatFriendListView.descending = true;
      } else {
        chatFriendListView.limit = 10; //TODO 需要优化， 如果一次变动超过10个人就会出错
        chatFriendListView.descending = true;
      }
    }
    this.chatFriendListView = chatFriendListView
  }

  logout(){
    if(this.chatFriendListView){
      this.chatFriendListView.stop()
    }
  }

  onChatFriendListChanged(data){
    for(var i=0; i<data.length; i++){
      var item = data[i]
      var friendShip = new ChatFriendShip(item.value.from, item.value.to)
      friendShip.setProperty(item.value)
      //ChatFriendShip的id规则就是channel规则
      this.chatFriendsCache[friendShip.documentID] = friendShip
    }
  }

  getChatFriendShipByMembers(from, to){
    var channel = Models.getChannle(from, to)
    //ChatFriendShip的id规则就是channel规则
    var friendShip = this.chatFriendsCache[channel]
    return friendShip
  }

}

var instance = new ChatFriendShipManager()
ChatFriendShipManager.instance = instance

module.exports = ChatFriendShipManager
