/**
 *
 * 缓存用户信息
 * @author johnny 2015-12-14
 *
 */

'use strict';

var Models = require("../Models")
var {User, FriendShip, Group} = Models;
var {Database, DatabaseView,DatabaseManager} = require("../couchbase/Couchbase");
var UserCacheManager = require("./UserCacheManager")

class GroupCacheManager {

  groupListView:DatabaseView;

  groupsCache = {};

  isFirstLoad = true;

  constructor(){
    var self = this
    var db = DatabaseManager.instance.currentDatabase
    var groupListView = new DatabaseView(db,"Group","ALL_GROUPS_VIEW","function(doc) { if(doc.type == 'Group') { emit(doc.date,doc);} }",()=>{
      groupListView.setOnDataChangeCallback((data)=>self.onDoctorListChanged(data));
    });
    groupListView.beforeUpdate = ()=>{
      if(self.isFirstLoad){
        self.isFirstLoad = false
        groupListView.limit = null;
        groupListView.descending = true;
      } else {
        groupListView.limit = 10; //TODO 需要优化， 如果一次变动超过10个人就会出错
        groupListView.descending = true;
      }
    }
    this.groupListView = groupListView
  }

  logout(){
    if(this.groupListView){
      this.groupListView.stop()
    }
  }

  //检查成员是否有相同的组
  findSameMembersGroup(members){
    for(var k in this.groupsCache){
      var g = this.groupsCache[k]
      var allSame = true
      if(g.members.length != members.length){
        allSame = false
      } else {
        for(var i=0; i<members.length; i++){
          var mid = members[i]
          var exists = false
          for(var j=0; j<g.members.length; j++){
            if(g.members[j] === mid){
              exists = true
              break
            }
          }
          if(!exists){
            allSame = false
          }
        }
      }
      if(allSame){
        return g
      }
    }
    return null
  }

  onDoctorListChanged(data){
    for(var i=0; i<data.length; i++){
      var item = data[i]
      var group = new Group(item.value.name)
      group.setProperty(item.value)
      this.groupsCache[group.documentID] = group
    }
    console.log("group cache data!");
  }

}

var groupCacheManager = new GroupCacheManager()
GroupCacheManager.instance = groupCacheManager

module.exports = GroupCacheManager
