'use strict';

var Models = require("../Models");
var Config = require("../../constant/Config");
var {User,Group,Patient,FriendShip,Message,Service} = Models;
var {DatabaseView,DatabaseManager, Database} = require("../couchbase/Couchbase");

var DatabaseHelper = {
}

//获得和非医生好友的医生助理的聊天记录
DatabaseHelper.getChatFriendshipList = function(){

}

DatabaseHelper.searchDocByKey = function(viewName, keystart, onSearchCallback){

  var database = DatabaseManager.instance.currentDatabase;

  var url = Config.localURL + database.dbName + "/_design/" + viewName + "/_view/" + viewName + "?keystart=" + keystart

  fetch(url, {
    method: "GET",
    headers: {'Content-Type': 'application/json'}
  })
  .then((response) => response.json())
  .then((data) => {
      //do nothig, just create the view
      console.log("doc found: " + data)
      if(onSearchCallback) onSearchCallback(data)
  }).catch(function(error) {
      if(error){
        //TODO handle error
        var emsg = error

      }
      //if(onSearchCallback) onSearchCallback(null)
  })

}

module.exports = DatabaseHelper;
