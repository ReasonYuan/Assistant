/**
 *
 * 界面导航栏
 *
 * @author reason  2015-12-17
 *
 **/
'use strict';

var React = require('react-native');

var {
  TouchableHighlight,
  Text,
  View,
  StyleSheet,
  Image,
} = React;

var {w,h,f} = require('../utils/Porting')
var ISIOS = React.Platform.OS === 'ios'
var NAVIGATION_BAR_HEIGHT = React.Platform.OS === 'ios'?64:44;
// var barHeight = NAVIGATION_BAR_HEIGHT

class NavigationBar extends React.Component{

  constructor(props) {
    super(props);
  }

  //渲染左边按钮
  renderLeft(){
    if(this.props.showBackIcon || this.props.leftButtonTitle){
      return(
        <TouchableHighlight
          style={istyles.leftContainer}
          underlayColor="transprent"
          onPress={this.props.onLeftPress}>
          {this.renderLeftContent()}
        </TouchableHighlight>
      )
    }
  }

  //左边按钮的内容
  renderLeftContent(){
    if(this.props.showBackIcon){
      return(<Image style={istyles.leftImg} source={require('../res/icon_arrow_left.png')}/>)
    }else if(this.props.leftButtonTitle){
      return(
        <Text style={istyles.leftTitle}>
          {this.props.leftButtonTitle}
        </Text>
      )
    }
  }

  //渲染右边按钮
  renderRight(){
    if(this.props.rightIcon || this.props.rightButtonTitle){
      return(
        <TouchableHighlight
          style={istyles.rightContainer}
          underlayColor="transprent"
          onPress={this.props.onRightPress}>
          {this.renderRightContent()}
        </TouchableHighlight>
      )
    }
  }

  //左边按钮的内容
  renderRightContent(){
    if(this.props.rightIcon){
      return(<Image style={istyles.rightImg} source={this.props.rightIcon}/>)
    }else if(this.props.rightButtonTitle){
      return(
        <Text style={[istyles.rightTitle,this.props.rColor&&{color:this.props.rColor}]}>
          {this.props.rightButtonTitle}
        </Text>
      )
    }
  }

  render(){
    return (
      <View style={istyles.topbar}>
      {this._renderNofity()}
        <View style={istyles.content}>
          <View style={istyles.btnContainer}>{this.renderLeft()}</View>

          <Text numberOfLines={1}
            style={istyles.titleContainer}>
            <Text
              numberOfLines={1}
              style={istyles.title}>
                {this.props.title}
            </Text>
          </Text>
          <View style={istyles.btnContainer}>{this.renderRight()}</View>
          </View>
          <Image style={istyles.line} source={require('../res/line_nav_bar.png')}/>
        </View>
    )
  }
  _renderNofity(){
       if(ISIOS){
         return (<View style={istyles.notify} />);
       }
     }
}

var istyles = StyleSheet.create({
  topbar:{
    height:NAVIGATION_BAR_HEIGHT,
    // borderBottomWidth:1,
    // borderColor:'#DAD8D9',
  },
  notify:{
    height:20//不自适应是因为各个屏幕都是20
  },
  content:{
    height:41,//42.5-2 2是下面线的宽度
    flexDirection:'row',
    justifyContent:'center',
    backgroundColor:'#fff'
  },
  btnContainer:{
    width:w(50),
  },
  leftContainer:{
    flex:1,
    paddingLeft:w(12),
    justifyContent:'center',
  },
  rightContainer:{
    flex:1,
    paddingRight:w(12),
    alignItems:'flex-end',
    justifyContent:'center',
  },
  titleContainer:{
    flex:1,
    textAlign:'center',
    alignSelf:'center',
    alignItems:'center',
    marginHorizontal:w(5),
    justifyContent:'center',
    // backgroundColor:'#444'
  },
  title:{
    flex:1,
    color:"#000",
    fontSize:f(19),
    fontWeight:'400',
  },
  leftTitle:{
    justifyContent:'center',
    // marginLeft:w(15),
    fontSize:f(15)
  },
  rightTitle:{
    justifyContent:'center',
    // marginRight:w(15),
    fontSize:f(15)
  },
  rightImg:{
    width:w(17),
    height:w(15),
    resizeMode:'cover',
  },
  leftImg:{
    width:w(6),
    height:w(17),
    resizeMode:'cover',
  },
  line:{
    height:2
  }
});


NavigationBar.propTypes = {
  title:React.PropTypes.string,
  leftButtonTitle:React.PropTypes.string,
  rightButtonTitle:React.PropTypes.string,
  onLeftPress:React.PropTypes.func,
  onRightPress:React.PropTypes.func
}

NavigationBar.defaultProps = {
  leftButtonTitle:null,
  rightButtonTitle:null,
  title:"",
}


module.exports = NavigationBar
