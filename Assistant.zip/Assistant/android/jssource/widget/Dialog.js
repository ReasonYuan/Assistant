'use strict';
var React = require('react-native');
var {Styles} = require("../utils/Styles")
var Dimensions = require('Dimensions');
var {
  TouchableHighlight,
  Text,
  View,
  StyleSheet,
  Image,
  Animated,
} = React;

var styles = StyleSheet.create({
  messageText:{
    fontSize:20,
    textAlign:'center',
  }
});

//Dialog
class Dialog extends React.Component {
  width:Number;
  constructor(props) {
    super(props)
    this.width = Dimensions.get('window').width * 4 / 5;
    this.state = {scale:new Animated.Value(1),show:this.props.show}
  }
  componentWillReceiveProps(nextProps){
    var toScale = 1;
    if(nextProps.show){
      this.setState({show:nextProps.show});
      this.state.scale.setValue(0);
    }else{
      this.state.scale.setValue(1);
      toScale = 0;
    }
    if(toScale == 1){
      Animated.spring(
        this.state.scale,
        {
          toValue: toScale,
        }
      ).start((c)=>{
        if(toScale == 0)this.setState({show:nextProps.show});
      })
    }else{
      Animated.timing(
        this.state.scale,
        {
          toValue: toScale,
          duration:40,
        },
      ).start((c)=>{
        if(toScale == 0)this.setState({show:nextProps.show});
        if(this.props.dismissCallback)this.props.dismissCallback();
      })
    }

  }
  _render(){
    return (
      <View></View>
    )
  }
  render(){
    if(!this.state.show){
      return <View/>;
    }
    return(
      <View style={[Styles.overlay,Styles.center]}>
        <Animated.View style={[istyles.dialog,{width:this.width},{transform: [{scale: this.state.scale}]}]}>
          <View style={{margin:20}}>
          {
            this._render()
          }
        </View>
        </Animated.View>
      </View>
    )
  }
}

Dialog.propTypes = {
  message:React.PropTypes.string,
  show:React.PropTypes.bool,   //是否显示
}

Dialog.defaultProps = {
  message:"",
  show:false,
}

class MessageDialog extends Dialog {
  constructor(props) {
    super(props)
  }
  _render(){
    return (
      <View style={istyles.full}>
        <Text sytle={styles.messageText}>
          {
            this.props.message
          }
        </Text>
      </View>
    )
  }
}

var istyles = StyleSheet.create({
  full:{
    flex:1,
    alignItems:'center'
  },
  dialog:{
    backgroundColor:'white',
    borderWidth:1,
    borderRadius:20,
    borderColor:"#c4c5c6"
  }
});

module.exports = {
  "Dialog":Dialog,
  "MessageDialog":MessageDialog,
};
