'use strict';
var React = require('react-native');

var{
  View,
  ListView
} = React

class FQListView extends ListView {

  constructor(props) {
    super(props)
  }

  render(){
    if(this.props.renderHeader||
      this.props.renderFooter||
      this.props.dataSource.getRowCount() > 0){
      return super.render();
    }else{
      return <View {...this.props}/>
    }
  }
}

module.exports = FQListView
