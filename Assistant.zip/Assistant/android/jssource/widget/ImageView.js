/**
 *
 * 图片控件，能够自动导入本地及下载网络图片
 *
 * @author reason  2015-12-17
 *
 **/
'use strict';

var React = require('react-native');

var {
  View,
  Image,
} = React;

var {screenWidth} = require('../utils/Porting')

class ImageView extends React.Component {
  constructor(props) {
    super(props)
    this.state = {imageData:null,defaultSource:props.defaultSource};
  }
  componentWillMount(){
    this.setImage(this.props.imageKey)
    var {DatabaseManager,Database} = require("../core/couchbase/Couchbase");
    this.db = DatabaseManager.instance.currentDatabase;
    this.listener = this.onUserChange.bind(this);
    this.db.addImageStatusChangeCallback(this.listener);
  }
  componentWillUnmount(){
    this.db.removeImageStatusChangeCallback(this.listener);
  }
  onUserChange(imageKey){
    if(imageKey && imageKey == this.imageKey){
      var {User} = require('../core/Models');
      React.NativeModules.ImageHelper.getThumbnailImage(User.currentUser.documentID,imageKey,width,(progress,data)=>{
        if(data){
          self.setState({
            imageData:data,
          })
        }
      });
    }
  }
  componentWillReceiveProps(nextProps) {
    if(this.props.imageKey !== nextProps.imageKey){
      this.clear = true
      this.setState({defaultSource:nextProps.defaultSource})
      this.setImage(nextProps.imageKey);
    }
  }
  setImage(imageKey){
    if(imageKey && this.imageKey != imageKey){
      var self = this;
      var width = screenWidth();
      if(this.props.thumbnailWidth) width = this.props.thumbnailWidth;
      this.setState({imageData:null});
      if(imageKey){
        var {User} = require('../core/Models');
        React.NativeModules.ImageHelper.getThumbnailImage(User.currentUser.documentID,imageKey,width,(progress,data)=>{
          if(data){
            self.setState({
              imageData:data,
            })
          }
        });
      }
    }else{
      this.setState({imageData:null});
    }
    this.imageKey = imageKey;
  }
  setNativeProps(nativeProps) {
    if(React.Platform.OS==="ios")this._root.setNativeProps(nativeProps);
    // this._root.setNativeProps(nativeProps);
  }

  render(){
    var imageUri = null;
    if(this.imageKey && this.state.imageData){
      imageUri = "data:image/jpg;base64," + this.state.imageData;
    }else{
      return (
      <Image
        {...this.props}
        key={imageUri}
        ref={component => this._root = component}
        source={this.props.source||this.state.defaultSource}/>)
    }
    return(
        <Image
          {...this.props}
          key={imageUri}
          ref={component => this._root = component}
          defaultSource={this.state.defaultSource}
          source={imageUri && {uri:imageUri}}/>
    )
  }

}

ImageView.propTypes = {
  ...Image.propTypes,
  imageKey:React.PropTypes.string,//阿里云上的key
}

ImageView.defaultProps = {
  imageKey:null,
}


module.exports = ImageView
