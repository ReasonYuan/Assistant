/**
 *
 * ios版时间组件,封装了react提供的iOS方的日期时间组件
 * @author reason 2015-12-13
 *
 */
'use strict';

var React = require('react-native');

var {
  StyleSheet,
  View,
  DatePickerIOS,
} = React;

var {h} = require('../utils/Porting')

class DatePicker extends React.Component{

  constructor(props){
    super(props)
    this.isTabBarChild = true

    this.mode = this.props.mode || "datetime"
    this.timezone = this.props.timezone || (-1) * (new Date()).getTimezoneOffset() / 60
    var date = this.props.date || new Date()

    // var time = (-1) * (new Date()).getTimezoneOffset() / 60
    this.state = {date:date}
  }


  // getDefaultProps () {
  //     return {
  //       date: new Date(),
  //       timeZoneOffsetInHours: (-1) * (new Date()).getTimezoneOffset() / 60,
  //     }
  //   }
  //
  //   getInitialState() {
  //     return {
  //       date: this.props.date,
  //       timeZoneOffsetInHours: this.props.timeZoneOffsetInHours,
  //     }
  //   }

    onDateChange(date) {
      // alert(date)
      this.setState({date: date});
      if(this.props.onDateChange){
        this.props.onDateChange(date)
      }
    }

    onTimezoneChange(event) {
      var offset = parseInt(event.nativeEvent.text, 10);
      if (isNaN(offset)) {
        return;
      }
      // this.setState({timeZoneOffsetInHours: offset});
    }



  render(){
    return(
      <View>
        <DatePickerIOS
          style={istyles.picker}
          date={this.state.date}
          mode={this.mode}
          timeZoneOffsetInMinutes={this.timezone * 60}
          onDateChange={this.onDateChange.bind(this)}
        />
      </View>
    )
  }
}



var istyles = StyleSheet.create({
  // container:{
  //   // height:h(80),
  //   justifyContent:'center',
  //   // height:h(100),
  //   backgroundColor:'#333'
  // },
  picker:{
    overflow:'hidden',
    alignSelf:'center',
    // backgroundColor:'#333'
  }
})


// Counter.propTypes = { initialCount: React.PropTypes.number };
// DatePicker.defaultProps = {date:new Date(),timeZoneOffsetInHours: 120};

module.exports = DatePicker
