/**
 *
 * 按钮，封装的RN的TouchableHighlight
 *
 * @author reason  2015-12-17
 *
 **/
'use strict';

var React = require('react-native');

var {
  View,
  Text,
  StyleSheet,
  TouchableHighlight
} = React;

class Button extends React.Component {
  constructor(props) {
    super(props)
  }
  _renderNormal(){
    return (
      <TouchableHighlight
        {...this.props}
        onPress={()=>{if(this.props.onPress)this.props.onPress();if(this.props.onTouch)this.props.onTouch();}}
        style={[
          istyles.default,
          {width:this.props.width,height:this.props.height},
          this.props.style
        ]}
        underlayColor={this.props.pressColor}
        >
        <Text style={{color:this.props.titleColor,fontSize:this.props.fontSize}}>{this.props.title}</Text>
      </TouchableHighlight>
    )
  }
  _renderDisable(){
    return (
      <TouchableHighlight
        {...this.props}
        onPress={()=>{ }}
        style={[
          Styles.center,
          {width:this.props.width,height:this.props.height},
          {backgroundColor:this.props.pressColor,borderColor:this.props.pressColor,borderWidth: 1,borderRadius: 4},
          this.props.style
        ]}
        underlayColor={this.props.pressColor}
        >
        <Text style={{color:this.props.titleColor,fontSize:this.props.fontSize}}>{this.props.title}</Text>
      </TouchableHighlight>
    )
  }
  render(){
    if(this.props.disable){
      return this._renderDisable();
    }
    return this._renderNormal();
  }
}

var istyles = StyleSheet.create({
  default:{
    alignItems:'center',
    justifyContent:'center',
    backgroundColor: '#48BBEC',
    borderColor: 'transparent',
    borderWidth: 1,
    borderRadius: 4,
  }
})

Button.propTypes = {
  ...TouchableHighlight.propTypes,
  width:React.PropTypes.number,
  height:React.PropTypes.number,
  onTouch:React.PropTypes.func,
  title:React.PropTypes.string,
  titleColor:React.PropTypes.string,
  titleFontSize:React.PropTypes.number,
  pressColor:React.PropTypes.string,
  disable:React.PropTypes.bool,
}

Button.defaultProps = {
  height:60,
  title:"",
  titleColor:'white',
  fontSize:16,
  pressColor:'gray',
  disable:false,
}


module.exports = Button
