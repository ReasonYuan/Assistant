/**
 *
 * 用户的头像，为了能随时的更新用户头像
 * @author  reason 2015-12-08
 *
 */

'use strict';

var React = require('react-native');
var {DatabaseManager} = require('../core/couchbase/Couchbase');
var ImageView = require('./ImageView');
var Tools = require('../utils/Tools')

class UserIcon extends React.Component {
  constructor(props){
    super(props);
    this.state={imageKey:this.props.user.headIcon?this.props.user.headIcon.objectKey:null}
  }
  componentWillMount(){
    DatabaseManager.instance.currentDatabase.addChangeCallback("User",this,(body)=>{
      for (var i = 0; i < body.length; i++) {
          var item = body[i];
          if(item._id == this.props.user.documentID){
            this.setState({imageKey:item.headIcon?item.headIcon.objectKey:null});
          }
      }
    })
  }
  componentWillUnmount(){
    DatabaseManager.instance.currentDatabase.removeChangeCallback("User",this);
  }

  componentWillReceiveProps(nextProps){
    this.state={imageKey:nextProps.user.headIcon?nextProps.user.headIcon.objectKey:null}
  }

  render(){
    return <ImageView {...this.props}
            key={this.state.imageKey}
            imageKey={this.state.imageKey}
            defaultSource={Tools.getHeadByUser(this.props.user)}/>
  }
}

module.exports = UserIcon;
