/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 */
'use strict';

// require('./android/jssource/index');

var React = require("react-native")
var {StyleSheet, AppRegistry, Navigator,BackAndroid,ToastAndroid} = React
var Login = require("./core/Login")
var Welcome = require("./core/Welcome")

var _navigator;
var firstTime = 0;//点击两次退出 首次点击时间记录
var fTime = 0;//防止点快了 返回到登录界面
var time = 0;//点击次数
BackAndroid.addEventListener('hardwareBackPress', () => {


  var routes = _navigator.getCurrentRoutes();
  var routesLength = routes.length;

  console.log(routesLength);

  if (_navigator && routesLength > 2) {
    var sTime = new Date().getTime();


    // var Profile = require('./Profile');
    var Home = require('./core/Home');
    var routeType = routes[routes.length-1].component;
    routeType = routeType.type;
    // if(routeType === Profile || routeType === Home){
      if(routeType === Home){
      if (sTime - fTime > 800) {//如果两次按键时间间隔大于800毫秒，则不退出
        ToastAndroid.show('再按一次退出程序', ToastAndroid.SHORT);
        firstTime = sTime;//更新firstTime
      }else{
        BackAndroid.exitApp();//否则退出程序
      }
      return true;
    }

    if (sTime - fTime > 500){//两次点击事件大于500毫秒让返回，否则会出BUG
      fTime = sTime;
      _navigator.pop();
    }

    return true;
  }else if (_navigator && routesLength <= 2) {
    var secondTime = new Date().getTime();

    if (secondTime - firstTime > 800) {//如果两次按键时间间隔大于800毫秒，则不退出
      ToastAndroid.show('再按一次退出程序', ToastAndroid.SHORT);
      firstTime = secondTime;//更新firstTime
    }else{
      BackAndroid.exitApp();//否则退出程序
    }
    return true;
  }
  return false;
});

//TODO==JP==以后版本稳定后可以不加这个remotelog
//DEV模式下允许
if(__DEV__){
  var setRemoteErrorHandler = require("./utils/RemoteErrorUtils").setUpErrorHandler
  setRemoteErrorHandler()
}

class GuideAndroid extends React.Component {
  renderScene(route, navigator){
    _navigator = navigator;
    if(route.component){
      return  route.component;
    }else{
      return <Welcome navigator={navigator}/>
    }
  }
  render() {
    return (
      <Navigator
        ref="navigator"
        style={styles.container}
        initialRoute={{

        }}
        configureScene={(route) => {
          return Navigator.SceneConfigs.HorizontalSwipeJump;
        }}
        renderScene={this.renderScene}
      />
    );
  }
}

var styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'stretch',
  }
});

AppRegistry.registerComponent('Assistant', () => GuideAndroid);
