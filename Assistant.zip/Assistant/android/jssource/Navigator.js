'use strict';

var React = require('react-native');
var {NavigatorIOS} = React;
var RCNavigator = React.Navigator;
var isIOS = React.Platform.OS === 'ios'



//导航栏，如果是ios用的是NavigatorIOS 其他用的是Navigator
class Navigator extends React.Component{
  constructor(props) {
    super(props);
  }
  push(route){
    if(route && route.component){
      var tmpProps = {...route.component.props} ;
      var passProps = tmpProps || {};
      passProps.navigator = this;
      this.refs.navigator.push({
        component:route.component.type,
        title:"",
        passProps:passProps
      })
    }else{
      throw new Error("no component");
    }
  }
  pop(){
    this.refs.navigator.pop();
  }
  popToTop(){
    this.refs.navigator.popToTop();
  }
  popN(n){
    if(isIOS){
      this.refs.navigator.popToTop(n);
    }else{
      throw new Error("not implement yet!");
    }
  }
  popToRoute(route){
    this.refs.navigator.popToRoute(route);
  }
  getCurrentRoutes(){
    if(isIOS){
      return this.refs.navigator.state.routeStack;
    }else{
      return this.refs.navigator.getCurrentRoutes();
    }
  }
  render(){
    if(isIOS){
      return (
        <NavigatorIOS
          ref="navigator"
          {...this.props}
          navigationBarHidden={true}
          initialRoute={{
            title:"",
            component:this.props.initialRoute.component,
            passProps: { navigator: this },
          }}
        />
      );
    }else{
      return (
        <RCNavigator
          ref="navigator"
          {...this.props}
        />
      );
    }
  }
}

module.exports = Navigator;
