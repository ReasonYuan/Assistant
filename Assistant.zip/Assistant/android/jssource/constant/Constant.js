'use strict';

//0:普通消息, 1:图片消息, 2:forward病案, 3:资讯, 4:服务, 5:(名片)加入医生

module.exports = {
  Role_Doctor:0,     //角色:医生
  Role_Care:1,       //角色:病人(客户)
  Role_Assistant:2,  //角色:管家、助理

  MSG_NORMAL:0,        //聊天:普通消息
  MSG_IMAGE:1,         //聊天:发送图片
  MSG_FORWARD:2,       //聊天:患者发送病历
  MSG_RESOURCE:3,      //聊天:发送资讯
  MSG_SERVER:4,        //聊天:普通服务
  MSG_ADDMEMBER:5,     //聊天:通知群中加入新成员
  MSG_REMOVEMEMBER:6,  //聊天:移除群成员
  MSG_PATIENT:7,       //聊天:医生发送病案


  SER_PROVIDER_YIYI:1,    //公司(管家)提供的服务
  SER_PROVIDER_DOCTOR:2,  //医生提供的服务
}
