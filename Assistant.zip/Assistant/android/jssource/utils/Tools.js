'use strict';

var React = require('react-native');
var {
  AsyncStorage,
} = React;

var Constant = require("../constant/Constant")
var {User} = require('../core/Models')

let DESIGN_WIDTH = 320;  //设计尺寸宽dp
let DESIGN_HEIGTH = 568;  //设计尺寸高dp
var Screen = require('Dimensions').get('window');
let TARGET_WIDTH = Screen.width;
let TARGET_HEIGHT = Screen.height;
let scaleWidth =  TARGET_WIDTH / DESIGN_WIDTH;
let scaleHeight = TARGET_HEIGHT / DESIGN_HEIGTH;

let TIMES = ["凌晨","上午","下午","晚上"]

class Tools {

    static screenWidth(){
      return TARGET_WIDTH
    }

    static screenHeight(){
      return TARGET_HEIGHT
    }

    static fixWidth(s){
      return s * scaleWidth;
    }

    static fixHeight(s){
      return s * scaleHeight;
    }

    //的到与今天相比的时间，如果不是今天,返回日期，
    //如果是今天则返回相对应的上下午
    static getDetailDateCompareToday(date){
      if(!date)return ''
      var format = 'yyyy-MM-dd'
      var temp = date.format(format)
      var today = new Date()
      if(today.format(format) == temp){
        var hour = date.getHours()
        temp = TIMES[Math.floor(hour/6)]
        return temp+date.format("HH:mm")
      }else{
        return date.format('yyyy-MM-dd HH:mm')
      }
    }

    //的到与今天相比的时间，如果不是今天,返回日期，
    //如果是今天则返回相对应的上下午
    static getDateCompareToday(date){
      if(!date)return ''
      var format = 'yyyy-MM-dd'
      var temp = date.format(format)
      var today = new Date()
      if(today.format(format) == temp){
        var hour = date.getHours()
        temp = TIMES[Math.floor(hour/6)]
        return temp+date.format("HH:mm")
      }else{
        return temp
      }
    }

    //通过毫秒数得到与今天相比的时间
    static getDateByMesc(longDate){
      return Tools.getDateCompareToday(new Date(longDate))
    }

    //通过毫秒数获取其详细时间的字符串类型,
    //format:所需要的时间格式，没有则默认为'yyyy-MM-dd'
    static getDateByMill(mill,format){
      if(!mill || mill == 0)return "未知时间"
      if(!format)format="yyyy-MM-dd"
      try{
        return new Date(+mill).format(format)
      }catch(E){
        return "未知时间"
      }
    }

    //根据role_type: 1,2,3...返回role name
    static getRoleName (role_type){
      switch(role_type){
        case 0:
          return "doctor";
        case 1:
          return "patient";
        case 2:
          return "assistant";
        default:
          return "doctor";
      }
    }

    //约定userid为rolename_username
    static generateUserId(role_type, username){
      return this.getRoleName(role_type) + "_" + username
    }

    static getHeadByUser(user){
      var type = Constant.Role_Assistant
      if(user)type = user.role_type
      return Tools.getHeadByRoleType(type)
    }

    static getHeadByRoleType(type){
      if(type == null) type = Constant.Role_Assistant
      switch (type) {
        case Constant.Role_Doctor:return require('../res/head_doctor.png');
        case Constant.Role_Care:return require('../res/head_patient.png');
        case Constant.Role_Assistant:return require('../res/head_assistant.png');
        default:return require('../res/head_patient.png');
      }
    }

    static getMyHead(){
      return require('../res/head_my.png');
    }

    static getResIcon(){
      return require('../res/icon_def.png');
    }



    //保存Storage数据
    //value  String 类型数据
    static saveStorageData(key,value){
      if(!key || !value)return
      try{
        AsyncStorage.setItem(key, value);
      }catch(error){
        console.log("--save Storage error-->key:"+key+" error:"+error);
      }
    }

    //得到保存的Storage数据
    static getStorageData(key,cb){
      if(!key || !cb)return
      try{
        AsyncStorage.getItem(key,(error,result)=>{
          if(!error || result){
            cb(result)
          }else{
            cb(null)
          }
        });
      }catch(error){
        cb(null)
      }
    }


    //判读字符的长度，因为一个中文为2个英文
    static charLen(s) {
     var l = 0;
     var a = s.split("");
     for (var i=0;i<a.length;i++) {
      if (a[i].charCodeAt(0)<299) {
       l++;
      } else {
       l+=2;
      }
     }
     return l;
    }

}

module.exports = Tools;
