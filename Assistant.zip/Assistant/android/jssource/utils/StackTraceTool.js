/**
 *
 * 图片管理工具
 * @author johnny 2015-12-25
 *
 */


'use strict';

var StackTrace = require('stacktrace-js')

var StackTrackTool = {
}

var printStackTraceLines = function(stackframes) {
  var stringifiedStack = stackframes.map(function(sf) {
    return sf.toString();
  }).join('\n');
  console.log(stringifiedStack);
};

var errback = function(err) { console.log(err.message); };

StackTrackTool.printStackTrace = function(error){
  if(error){
    // callback is called with an Array[StackFrame]
    StackTrace.fromError(error).then(printStackTraceLines).catch(errback);
  } else {
    StackTrace.get().then(printStackTraceLines).catch(errback)
  }
}

module.exports = StackTrackTool
