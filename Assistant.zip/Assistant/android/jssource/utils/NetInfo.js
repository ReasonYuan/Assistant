/**
 *
 * 网络数据。。。。
 * @author min.liao sometime
 *
 */

'use strict';
var React = require('react-native');

class NetInfo {

}

NetInfo.isConnected = false;
NetInfo.listeners = [];
NetInfo.addChangeListener = function(callback:func){
  NetInfo.listeners.push(callback);
  if(React.Platform.OS === 'ios'){
    React.NetInfo.isConnected.addEventListener(
      'change',
      callback
    );
  }
}

NetInfo.removeChangeListener = function(callback:func){
  var index = NetInfo.listeners.indexOf(callback);
  if(index > 0) NetInfo.listeners.splice(index,1);
  if(React.Platform.OS === 'ios'){
    React.NetInfo.isConnected.removeEventListener(
      'change',
      callback
    );
  }
}


if(React.Platform.OS === 'ios'){
  React.NetInfo.isConnected.fetch().done((isConnected) => {
    var current = NetInfo.isConnected;
    NetInfo.isConnected = isConnected;
    if(current != isConnected){
      for (var i = 0; i < NetInfo.listeners.length; i++) {
        var callback =  NetInfo.listeners[i];
        callback(isConnected);
      }
    }
  });
}else if (React.Platform.OS === 'android') {

}

module.exports = NetInfo;
