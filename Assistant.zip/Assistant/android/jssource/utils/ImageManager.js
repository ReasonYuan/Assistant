/**
 *
 * 图片管理工具
 * @author min.liao sometime
 *
 */

var REFRENCE_COUNT = "refrenceCount"
var IMAGE = "image"
/*
*图片管理
*/
class ImageManager {
  images:Object//格式{"objectKey":{refrenceCount:0,image:"base64Image"}}
  constructor() {

  }
  //获取默认图片，一般头像使用
  getDefaultImage(cb){

  }
  //获取阿里云上的图片
  getImage(objectKey,cb){
    var cache = this.images[objectKey];
    if(cache && cache[IMAGE]){
      cb(cache[IMAGE]);
    }else{ //TODO

    }
  }
  //加引用
  retain(objectKey){
    var img = this.images[objectKey];
    var refrenceCount = img[REFRENCE_COUNT];
    if(img && refrenceCount){
      var ref = ++refrenceCount;
      img[REFRENCE_COUNT] = ref;
    }
  }
  //删除引用
  release(objectKey){
    var img = this.images[objectKey];
    var refrenceCount = img[REFRENCE_COUNT];
    if(img && refrenceCount){
      var ref = --refrenceCount;
      if(ref <=0 ){
        delete  this.images[objectKey]
      }else{
        img[REFRENCE_COUNT] = ref
      }
    }
  }
}

var instance = null;
ImageManager.getInstance = function(){
  if(!instance){
    instance = new ImageManager();
  }
  return instance;
}


module.exports = ImageManager
