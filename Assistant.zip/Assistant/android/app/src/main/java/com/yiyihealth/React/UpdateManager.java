package com.yiyihealth.React;

import android.content.Context;
import android.os.Environment;
import android.util.Log;

import com.facebook.react.LifecycleState;
import com.facebook.react.ReactInstanceManager;
import com.facebook.react.bridge.JSBundleLoader;
import com.facebook.react.bridge.JSCJavaScriptExecutor;
import com.facebook.react.bridge.JavaScriptExecutor;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.facebook.react.shell.MainReactPackage;
import com.yiyihealth.hitales.servant.BuildConfig;
import com.yiyihealth.hitales.servant.MainActivity;

import java.io.File;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/**
 * Created by Monkey on 16/3/4.
 */
public class UpdateManager{

    public static final String JS_BUNDLE_LOCAL_FILE = "index.android.bundle";
    private final String TAG = "UpdateManager";
//    private ReactInstanceManager mReactInstanceManager;
//    private Context mContext;


//    public UpdateManager(ReactApplicationContext reactContext) {
//        super(reactContext);
//        this.mContext = reactContext;
//        iniReactRootView();
//    }
//
//    @Override
//    public String getName() {
//        return "UpdateManager";
//    }

    private String getLocalPath(Context context) {
        String mDocumentDir;
        String status = Environment.getExternalStorageState();
        if (status.equals(Environment.MEDIA_MOUNTED)) {
            mDocumentDir = Environment.getExternalStorageDirectory()+ "/Android/data/data/" + context.getPackageName()+"/Document/Update/" + JS_BUNDLE_LOCAL_FILE;
        }else{
            mDocumentDir = "/data/data/" + context.getPackageName()+"/Document//Update/" + JS_BUNDLE_LOCAL_FILE;
        }
        return mDocumentDir;
    }

//    @ReactMethod
//    public void checkUpdate(int version){
//        Log.i(TAG, "The version is : " + version  + " path : " + getLocalPath());
//        reBundleLoaded();
//    }

    public void reBundleLoaded(Context content,ReactInstanceManager mReactInstanceManager) {

        String filePath = getLocalPath(content);
        Log.i(TAG,filePath);
        File file = new File(filePath);
        if (!file.exists()){
            return;
        }

//        iniReactRootView();
        try {
            Class<?> RIManagerClazz = mReactInstanceManager.getClass();
            Method method = RIManagerClazz.getDeclaredMethod("recreateReactContextInBackground",
                    JavaScriptExecutor.class, JSBundleLoader.class);
            method.setAccessible(true);
            method.invoke(mReactInstanceManager,
                    new JSCJavaScriptExecutor(),
                    JSBundleLoader.createFileLoader(content, getLocalPath(content)));
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        }
    }

//    private void iniReactRootView() {
//
//        mReactInstanceManager = ReactInstanceManager.builder()
//                .setApplication(MainActivity.instance.getApplication())
//                .setJSMainModuleName("index.android.bundle")
//                .addPackage(new MainReactPackage())
//                .setUseDeveloperSupport(BuildConfig.DEBUG)
//                .setInitialLifecycleState(LifecycleState.RESUMED)
//                .build();
//
//    }
}
