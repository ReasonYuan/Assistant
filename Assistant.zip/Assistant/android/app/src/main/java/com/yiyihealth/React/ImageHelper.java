package com.yiyihealth.React;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import android.util.Log;

import com.facebook.react.bridge.Callback;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.facebook.react.bridge.ReadableMap;
import com.facebook.react.bridge.WritableMap;
import com.facebook.react.bridge.WritableNativeMap;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.Response;
import com.yiyihealth.hitales.servant.MainActivity;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Created by liaomin on 15/11/8.
 */
public class ImageHelper extends ReactContextBaseJavaModule {

    public static String DOWNLOAD_ENDPOINT_FROM_AMD ="http://img.yiyihealth.com";

    private static final OkHttpClient mOkHttpClient = new OkHttpClient();

    public static ImageHelper instance;

    public static String OSS_ACCESS_KEY = Constans.OSS_ACCESS_KEY;
    public static String OSS_SECRET_KEY = Constans.OSS_SECRET_KEY;
    public static String OSS_UPLOAD_ENDPOINT = Constans.OSS_UPLOAD_ENDPOINT;
    public static String OSS_BUCKET_NAME = Constans.OSS_BUCKET_NAME;
    public static String DOWNLOAD_ENDPOINT = Constans.DOWNLOAD_ENDPOINT;


    public static final String DIR_UDLOAD_IMAGE = "uploadImages";
    public static final String DIR_THUMBNAIL_IMAGE = "thumbnailImages";
    public static final String DIR_IMAGE = "Images";
    public static final String NOTI_UPLOAD_IMAGE_PROGRESS = "NOTIFICATION_UPLOAD_IMAGE_PROGRESS";
    public static final String NOTI_UPLOAD_IMAGE_COMPLETE = "NOTIFICATION_UPLOAD_IMAGE_COMPLETE";
    public static final String NOTI_DOWNLOADLOAD_IMAGE_PROGRESS = "NOTIFICATION_DOWNLOADLOAD_IMAGE_PROGRESS";
    public static final String NOTI_DOWNLOAD_IMAGE_COMPLETE = "NOTIFICATION_DOWNLOAD_IMAGE_PROGRESS";
    public static final String NOTI_UPLOAD_COUNT_CHANGE = "NOTI_UPLOAD_COUNT_CHANGE";
    public static final String NOTI_IMAGE_STATE_CHANGE = "NOTI_IMAGE_STATE_CHANGE";

    public static ReactApplicationContext context;
    public static UploadImageTask mTask;

    public ImageHelper(ReactApplicationContext reactContext) {
        super(reactContext);
        context = reactContext;
        instance = this;
    }
    @Override
    public String getName() {
        return "ImageHelper";
    }

    @Override
    public Map<String, Object> getConstants() {
        final Map<String, Object> constants = new HashMap<String, Object>();
        constants.put("NOTI_UPLOAD_COUNT_CHANGE", NOTI_UPLOAD_COUNT_CHANGE);
        constants.put("NOTI_DOWNLOAD_IMAGE_COMPLETE", NOTI_DOWNLOAD_IMAGE_COMPLETE);
        constants.put("NOTI_DOWNLOADLOAD_IMAGE_PROGRESS", NOTI_DOWNLOADLOAD_IMAGE_PROGRESS);
        constants.put("NOTI_UPLOAD_IMAGE_COMPLETE", NOTI_UPLOAD_IMAGE_COMPLETE);
        constants.put("NOTI_UPLOAD_IMAGE_PROGRESS", NOTI_UPLOAD_IMAGE_PROGRESS);
        constants.put("NOTI_IMAGE_STATE_CHANGE", NOTI_IMAGE_STATE_CHANGE);
        return constants;
    }

    @ReactMethod
    public void getLeftUploadImageCount(final Callback callback) {
        //TODO 获取上传图片剩余张数
        callback.invoke(mTask.size());
    }

    @ReactMethod
    public void uploadImage(String userId, String imageKey) {
        //TODO 上传图片到阿里云
        mTask.addImage(imageKey);
    }

    private static Map<String,Map<String,ArrayList<Callback>>> mDowns= new HashMap<String,Map<String,ArrayList<Callback>>>();

    private synchronized void getLocalImage(final String userId,final String imageKey,final int expectWidth,final Callback callback){
        getReactApplicationContext().runOnJSQueueThread(new Runnable() {
            @Override
            public void run() {
                int width = expectWidth > 0 ? expectWidth : MainActivity.SCREEN_WIDTH*2/3;
                String path = FileHelper.getLocalImagePath(userId, imageKey);
                if(path != null){
                    Bitmap bitmap = BitmapManager.decodeBitmap2Scale(path, width);
                    if(bitmap != null){
                        String base64Image = ImageHelper.bitmapToBase64(bitmap);
                        if(callback != null)callback.invoke(1,base64Image);
                        if(mDowns.get(userId) != null && mDowns.get(userId).get(imageKey) != null){
                            ArrayList<Callback> callbacks = mDowns.get(userId).get(imageKey);
                            for (int i = 0; i < callbacks.size(); i++) {
                                Callback c = callbacks.get(i);
                                if(c != null)c.invoke(1,base64Image);
                            }
                            callbacks.clear();
                        }
                    }
                }
            }
        });
    }

    @ReactMethod
    public void getThumbnailImage(final String userId,final String imageKey,final boolean fromAMD,final int expectWidth ,final Callback callback) {
        if(imageKey == null || imageKey == "")return;
        int width = expectWidth > 0 ? expectWidth : MainActivity.SCREEN_WIDTH*2/3;
        String path = FileHelper.getLocalImagePath(userId, imageKey);//getLocalImagePath
        do{
            if(path != null){
                this.getLocalImage(userId,imageKey,expectWidth,callback);
                break;
            }
            //下载图片
            if(mDowns.get(userId) != null && mDowns.get(userId).get(imageKey) != null){
                mDowns.get(userId).get(imageKey).add(callback);
                break;
            }
            if(mDowns.get(userId) == null){
                Map<String,ArrayList<Callback>> im = new HashMap<String,ArrayList<Callback>> ();
                mDowns.put(userId, im);
            }
            if(mDowns.get(userId).get(imageKey) == null){
                ArrayList<Callback> callbacks = new ArrayList<Callback>();
                mDowns.get(userId).put(imageKey,callbacks);
            }
            mDowns.get(userId).get(imageKey).add(callback);
            String url = (fromAMD?DOWNLOAD_ENDPOINT_FROM_AMD:DOWNLOAD_ENDPOINT) +"/"+imageKey+"@"+width+"w_1l";
            Log.e("", "getThumbnailImage: " + url);
            Request request = new Request.Builder().url(url).build();
            mOkHttpClient.newCall(request).enqueue(new com.squareup.okhttp.Callback() {
                @Override
                public void onFailure(Request request, IOException e) {

                }

                @Override
                public void onResponse(Response response) throws IOException {
                    if(response.isSuccessful()){
                        try {
                            if(FileHelper.writeDataToPath(userId,imageKey,response.body().bytes())){
                                ImageHelper.this.getLocalImage(userId,imageKey,expectWidth,null);
                            }
                        }catch (Exception e){
                            e.printStackTrace();
                        }
                    }
                }
            });

        }while (false);

    }


    @ReactMethod
    public void getImage(String userId, String imageKey,boolean fromAMD, Callback callback) {
        getThumbnailImage(userId,imageKey,fromAMD, MainActivity.SCREEN_WIDTH*2/3,callback);
    }




    /**
     * bitmap转为base64
     * @param bitmap
     * @return
     */
    public static String bitmapToBase64(Bitmap bitmap) {

        String result = null;
        ByteArrayOutputStream baos = null;
        try {
            if (bitmap != null) {
                baos = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);

                baos.flush();
                baos.close();

                byte[] bitmapBytes = baos.toByteArray();
                result = Base64.encodeToString(bitmapBytes, Base64.DEFAULT);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (baos != null) {
                    baos.flush();
                    baos.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return result;
    }

    /**
     * base64转为bitmap
     * @param base64Data
     * @return
     */
    public static Bitmap base64ToBitmap(String base64Data) {
        byte[] bytes = Base64.decode(base64Data, Base64.DEFAULT);
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
    }


    /**
     * 把bitmap转化成文件
     * @param bitmap
     * @param options
     * @return
     */
    public static WritableMap saveBitmap(Bitmap bitmap,ReadableMap options) {
        WritableMap response = new WritableNativeMap();
//        Map<String,Object> response = new HashMap<>();
        if (bitmap != null && options != null) {
            if (options.hasKey("maxWidth")) {
                int width = options.getInt("maxWidth");
                bitmap = BitmapManager.scaleBitmap(bitmap, width);
                if (options.hasKey("storageOptions")) {
                    ReadableMap storageOptions = options.getMap("storageOptions");
                    String path = storageOptions.getString("path");
                    String imageName = UUID.randomUUID() + ".jpg";
                    String fullPath = FileHelper.mDocumentDir + path + "/" + imageName;
                    response.putInt("width", bitmap.getWidth());
                    response.putInt("height", bitmap.getHeight());
                    response.putString("fileName", imageName);
                    response.putString("uri", fullPath);
                    BitmapManager.saveToLocal(bitmap, FileHelper.mDocumentDir + path, imageName, true);
                }
//            }
            }

        }
        return response;
    }

    public static BitmapFactory.Options getBitmapOptions(String path){
        BitmapFactory.Options options = new BitmapFactory.Options();

        /**
         * 最关键在此，把options.inJustDecodeBounds = true;
         * 这里再decodeFile()，返回的bitmap为空，但此时调用options.outHeight时，已经包含了图片的高了
         */
        options.inJustDecodeBounds = true;
        Bitmap bitmap = BitmapFactory.decodeFile("/sdcard/test.jpg", options); // 此时返回的bitmap为null
        /**
         *options.outHeight为原始图片的高
         */
        Log.e("Test", "Bitmap Height == " + options.outHeight);
        return options;
    }

    public static Bitmap decodeSampledBitmapFromFile(String path, int size)
    {
        final BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(path, options);
        options.inPreferredConfig = Bitmap.Config.RGB_565;
        options.inSampleSize = size;
        options.inJustDecodeBounds = false;
        try {
            return BitmapFactory.decodeFile(path, options);
        } catch (OutOfMemoryError e) {
            //递归每次x2,保证能装在图片
            return decodeSampledBitmapFromFile(path, size*2);
        }
    }

    public static WritableMap saveBitmap2(Bitmap bitmap, ReadableMap option) {
        WritableMap response = new WritableNativeMap();
        if (bitmap != null && option != null) {
            if (option.hasKey("maxWidth")) {
                int width = option.getInt("maxWidth");
                bitmap = BitmapManager.scaleBitmap(bitmap, width);
            }
            if(option.hasKey("storageOptions")){
                ReadableMap storageOptions = option.getMap("storageOptions");
                String path = storageOptions.getString("path");
                String imageName = UUID.randomUUID()+".jpg";
                String fullPath = FileHelper.mDocumentDir+path+"/"+imageName;
                response.putInt("width", bitmap.getWidth());
                response.putInt("height", bitmap.getHeight());
                response.putString("fileName", imageName);
                response.putString("uri", fullPath);
                BitmapManager.saveToLocal(bitmap, FileHelper.mDocumentDir + path, imageName, true);
                boolean vertical = (bitmap.getWidth()< bitmap.getHeight()) ? true : false;
                response.putBoolean("isVertical", vertical);
            }

        }

        return response;
    }
}
