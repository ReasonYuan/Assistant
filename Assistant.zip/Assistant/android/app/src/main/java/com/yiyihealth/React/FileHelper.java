package com.yiyihealth.React;

import android.app.Activity;
import android.os.Environment;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

/**
 * Created by liaomin on 16/1/16.
 */
public class FileHelper {

    //相当于ios的DocumentDir
    public static String mDocumentDir;

    public static void init(Activity context){
        String status = Environment.getExternalStorageState();
        if (status.equals(Environment.MEDIA_MOUNTED)) {
            mDocumentDir = Environment.getExternalStorageDirectory()+ "/Android/data/data/" + context.getPackageName()+"/Document/";
        }else{
            mDocumentDir = "/data/data/" + context.getPackageName()+"/Document/";
        }
    }

    public static String getLocalImagePath(String userId, String objectKey){
        String path;
        String searchPath[] = {ImageHelper.DIR_UDLOAD_IMAGE, ImageHelper.DIR_IMAGE, ImageHelper.DIR_THUMBNAIL_IMAGE};
        int i = 0;
        while (i < searchPath.length){
            path = mDocumentDir+userId+"/"+searchPath[i]+"/"+objectKey;
            File file = new File(path);
            if(file.exists())return path;
            i++;
        }
        return null;
    }

    public static boolean writeDataToPath(String userId,String objectKey,byte[] data){
        FileHelper.CreateFolderIfNotExist(mDocumentDir + userId + "/" + ImageHelper.DIR_THUMBNAIL_IMAGE + "/");
        String path =  mDocumentDir+userId+"/"+ ImageHelper.DIR_THUMBNAIL_IMAGE+"/"+objectKey;
        File file = new File(path);
        try {
            FileOutputStream fos = new FileOutputStream(file);
            fos.write(data);
            fos.close();
            return  true;
        }catch (Exception e){
            e.printStackTrace();
        }
        return false;
    }

    public static void CreateFolderIfNotExist(String path){
        File file = new File(path);
        if(!file.exists()){
            file.mkdirs();
        }
    }




    /**
     * 保存对象到本地
     */
    public synchronized static void saveSerializableObject(Object object, String path) {
        File parentFile = new File(path.substring(0, path.lastIndexOf('/')));
        if (!parentFile.exists())
            parentFile.mkdirs();
        File dataFile = new File(path);
        if (!dataFile.exists()) {
            try {
                dataFile.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        ObjectOutputStream oos = null;
        try {
            oos = new ObjectOutputStream(new FileOutputStream(dataFile));
            oos.writeObject(object);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                oos.close();
            } catch (IOException e) {
            }
        }
    }

    /**
     * load本地对象
     */
    public synchronized static Object loadSerializableObject(String filePath) {
        File dataFile = new File(filePath);
        if (dataFile.exists()) {
            ObjectInputStream ois = null;
            try {
                ois = new ObjectInputStream(new FileInputStream(dataFile));
                Object data = ois.readObject();
                return data;
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                try {
                    if (ois != null)
                        ois.close();
                } catch (IOException e) {
                }
            }
        }
        return null;
    }
}
