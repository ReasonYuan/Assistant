package com.yiyihealth.React;

import com.facebook.react.bridge.JavaScriptModule;
import com.facebook.react.bridge.NativeModule;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.shell.MainReactPackage;
import com.facebook.react.uimanager.ViewManager;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * Created by liaomin on 15/11/8.
 */
public class CouchbaseHelperPackage extends MainReactPackage {
    @Override
    public List<NativeModule> createNativeModules(
            ReactApplicationContext reactContext) {
        List<NativeModule> modules = new ArrayList<NativeModule>();
        modules.add(new CouchbaseHelper(reactContext));
        modules.add(new AlertTextInput(reactContext));
        modules.add(new ReactActionSheet(reactContext));
        modules.add(new CameraHelper(reactContext));
        modules.add(new AndroidSelectPhoto(reactContext));
        modules.add(new ImageHelper(reactContext));
        modules.add(new DatePicker(reactContext));
        modules.add(new DialogManager(reactContext));
        modules.add(new Tools(reactContext));
        modules.add(new ResourceManager(reactContext));
        return modules;
    }

    @Override
    public List<Class<? extends JavaScriptModule>> createJSModules() {
        return Collections.emptyList();
    }

    @Override
    public List<ViewManager> createViewManagers(ReactApplicationContext reactContext) {
        return Arrays.<ViewManager>asList(
                new ReactCamera(),
                new RNTableViewManager(),
                new ReactGalleryView(),
                new NavigatorAndroid(),
                new RNChatTextViewManager()
        );
    }


}