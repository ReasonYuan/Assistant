package com.yiyihealth.React;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;

import com.facebook.react.bridge.Callback;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.facebook.react.bridge.ReadableMap;
import com.facebook.react.bridge.WritableMap;
import com.yiyihealth.hitales.servant.MainActivity;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;


/**
 * Created by liaomin on 15/11/10.
 */
public class AndroidSelectPhoto  extends ReactContextBaseJavaModule {

    public static final int TYPE_CAMERA = 1;

    public static final int TYPE_PHOTO = 2;

    public static final int TYPE_TAKE_PATIENT_CAMEA = 3;

    public static final int TYPE_TAKE_PATIENT_PHOTO = 4;

    public AndroidSelectPhoto(ReactApplicationContext reactContext) {
        super(reactContext);
    }

    public static ReadableMap option;

    public static Callback takePhotosCallback;

    private File tempFile = null;

    @Override
    public String getName() {
        return "AndroidSelectPhoto";
    }

    @ReactMethod
    public void selectPhoto(int type, final ReadableMap options,final Callback callback) {
        this.option =  options;
        takePhotosCallback = callback;
        MainActivity.Callback callback1 = new MainActivity.Callback() {
            @Override
            public void doCallback(int resultCode, Intent data) {
                Bitmap image = null;

                if(resultCode == TYPE_CAMERA){
                    Bitmap bitmap = BitmapManager.decodeBitmap2Scale(tempFile.getAbsolutePath(), 600);
                    if(bitmap!=null){
                        image = bitmap;
                    }

                    int degree = BitmapRotaTools.getBitmapDegree(tempFile.getAbsolutePath());
                    image = BitmapRotaTools.rotateBitmapByDegree(image, degree);
                }else{
                    if(data == null) return;
                    Uri mImageCaptureUri = data.getData();
                    scanFile(Environment.getExternalStorageDirectory() + "/", getReactApplicationContext());
                    if (mImageCaptureUri != null) {
                        try {
                            //这个方法是根据Uri获取Bitmap图片的静态方法
                            String path = BitmapRotaTools.getImageAbsolutePath(MainActivity.instance,mImageCaptureUri);
                            int degree = BitmapRotaTools.getBitmapDegree(path);
                            Bitmap bitmap = BitmapManager.decodeBitmap2Scale(path, 600);
                            if(bitmap!=null){
                                image = bitmap;
                            }
                            image = BitmapRotaTools.rotateBitmapByDegree(image, degree);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }else{
                        Bundle extras = data.getExtras();
                        if (extras != null) {
                            //这里是有些拍照后的图片是直接存放到Bundle中的所以我们可以从这里面获取Bitmap图片
                            image = extras.getParcelable("data");
                        }
                    }
                }

                if(image != null && callback != null){
                    final WritableMap res = ImageHelper.saveBitmap(image, options);
                    getReactApplicationContext().runOnNativeModulesQueueThread(new Runnable() {
                        @Override
                        public void run() {
                            callback.invoke(res);
                        }
                    });
                }
            }
        };

        if(type == 0){//拍照

            File path = new File(Environment.getExternalStorageDirectory() +"/海苔健康");
            if(!path.exists()){
                path.mkdirs();
            }
            tempFile= new File(path,getPhotoFileName());

            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            intent.setAction(MediaStore.ACTION_IMAGE_CAPTURE);
            intent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(tempFile));

            MainActivity.instance.resultsCallback.put(TYPE_CAMERA, callback1);
            MainActivity.instance.startActivityForResult(intent, TYPE_CAMERA);
        }else if(type == 3){//病案拍照
            Intent intent = new Intent();
            intent.setClass(getReactApplicationContext(),ReactCamera.class);
            MainActivity.instance.resultsCallback.put(TYPE_TAKE_PATIENT_CAMEA,callback1);
            MainActivity.instance.startActivityForResult(intent, TYPE_TAKE_PATIENT_CAMEA);
        }else{
            Intent intent = new Intent();
            intent.setType("image/*");
            intent.setAction(Intent.ACTION_GET_CONTENT);
            MainActivity.instance.resultsCallback.put(TYPE_PHOTO, callback1);
            MainActivity.instance.startActivityForResult(intent, TYPE_PHOTO);
        }

    }



    // 使用系统当前日期加以调整作为照片的名称
    private String getPhotoFileName() {
        Date date = new Date(System.currentTimeMillis());
        SimpleDateFormat dateFormat = new SimpleDateFormat(
                "'IMG'_yyyyMMdd_HHmmss");
        return dateFormat.format(date) + ".jpg";

    }

    public static void scanFile(String path,Context context) {

        MediaScannerConnection.scanFile(context,
                new String[]{path}, null,
                new MediaScannerConnection.OnScanCompletedListener() {

                    public void onScanCompleted(String path, Uri uri) {
                        Log.i("TAG", "Finished scanning " + path);

                    }
                });
    }
}
