package com.yiyihealth.React;

import com.facebook.react.bridge.Callback;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.yiyihealth.hitales.servant.HotRefresh;

/**
 * Created by wangxi on 16/3/8.
 */
public class ResourceManager extends ReactContextBaseJavaModule {

    private HotRefresh mHotRefresh = null;

    public ResourceManager(ReactApplicationContext reactContext) {
        super(reactContext);
    }



    @Override
    public String getName() {
        return "ResourceManager";
    }


    @ReactMethod
    public void downloadJSBoundle(String url, final String fileName,String unZipBoundleName,Callback callback){
        try {
            mHotRefresh = new HotRefresh(url,fileName,unZipBoundleName);
            mHotRefresh.run();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
