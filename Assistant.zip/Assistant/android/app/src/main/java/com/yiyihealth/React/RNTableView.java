package com.yiyihealth.React;

import android.content.Context;
import android.widget.ListView;

/**
 * Created by liaomin on 16/1/17.
 */
public class RNTableView extends ListView{

    public RNTableView(Context context) {
        super(context);
    }
}
