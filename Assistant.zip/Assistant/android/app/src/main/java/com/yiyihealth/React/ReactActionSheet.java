package com.yiyihealth.React;

import com.baoyz.actionsheet.ActionSheet;
import com.facebook.react.bridge.Callback;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.facebook.react.bridge.ReadableArray;
import com.yiyihealth.hitales.servant.MainActivity;


/**
 * Created by liaomin on 15/11/9.
        */
public class ReactActionSheet  extends ReactContextBaseJavaModule {


    public ReactActionSheet(ReactApplicationContext reactContext) {
        super(reactContext);
    }

    @Override
    public String getName() {
        return "ActionSheet";
    }


    @ReactMethod
    public void showActionSheet(final ReadableArray itmes, final String cannelTitle, final Callback callback) {
        getReactApplicationContext().runOnUiQueueThread(new Runnable() {
            @Override
            public void run() {
                String[] titles = new String[itmes.size()];
                for (int i = 0; i < itmes.size(); i++) {
                    titles[i] = itmes.getString(i);
                }
                ActionSheet.createBuilder(MainActivity.instance, MainActivity.instance.getSupportFragmentManager())
                        .setCancelButtonTitle(cannelTitle)
                        .setOtherButtonTitles(titles)
                        .setCancelableOnTouchOutside(true)
                        .setListener(new ActionSheet.ActionSheetListener() {
                            @Override
                            public void onDismiss(ActionSheet actionSheet, boolean isCancel) {

                            }

                            @Override
                            public void onOtherButtonClick(ActionSheet actionSheet, final  int index) {
                                if (callback != null) {
                                    ReactActionSheet.this.getReactApplicationContext().runOnNativeModulesQueueThread(new Runnable() {
                                        @Override
                                        public void run() {
                                            callback.invoke(index);
                                        }
                                    });
                                }
                            }
                        }).show();
            }
        });


    }

}