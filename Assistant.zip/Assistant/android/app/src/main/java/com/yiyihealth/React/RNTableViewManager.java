package com.yiyihealth.React;

import com.facebook.react.uimanager.SimpleViewManager;
import com.facebook.react.uimanager.ThemedReactContext;

/**
 * Created by liaomin on 15/11/9.
 */
public class RNTableViewManager extends SimpleViewManager<RNTableView> {

    private ThemedReactContext context;


    @Override
    public String getName() {
        return "RNTableView";
    }

    @Override
    protected RNTableView createViewInstance(ThemedReactContext reactContext) {
        RNTableView cameraView = new RNTableView(reactContext);
        context = reactContext;
        return cameraView;
    }


}
