package com.yiyihealth.React;

import com.android.datetimepicker.date.DatePickerDialog;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.facebook.react.bridge.WritableMap;
import com.facebook.react.bridge.WritableNativeMap;
import com.facebook.react.modules.core.DeviceEventManagerModule;
import com.yiyihealth.hitales.servant.MainActivity;

import java.util.Calendar;

/**
 * Created by liaomin on 15/11/8.
 */
public class DatePicker extends ReactContextBaseJavaModule implements DatePickerDialog.OnDateSetListener {

    private ReactApplicationContext context;

    public DatePicker(ReactApplicationContext reactContext) {
        super(reactContext);
        context = reactContext;
    }

    @Override
    public String getName() {
        return "DatePicker";
    }


    @ReactMethod
    public void showDatePicker(final int year,final int month,final int day) {
        context.runOnUiQueueThread(new Runnable() {
            @Override
            public void run() {
                DatePickerDialog.newInstance(DatePicker.this, year, month, day).show(MainActivity.instance.getFragmentManager(), "datePicker");
            }
        });

    }

    @Override
    public void onDateSet(DatePickerDialog dialog, int year, int monthOfYear, int dayOfMonth){
        WritableMap params = new WritableNativeMap();
        params.putInt("year",year);
        params.putInt("month", monthOfYear);
        params.putInt("day", dayOfMonth);
        Calendar calendar = Calendar.getInstance();
        calendar.set(year, monthOfYear, dayOfMonth);
        params.putString("time",calendar.getTimeInMillis()+"");
        context.getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter.class)
                .emit("Android_Date_Picker", params);
    }

}
