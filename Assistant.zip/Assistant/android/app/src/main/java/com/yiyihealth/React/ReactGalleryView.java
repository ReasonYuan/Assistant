package com.yiyihealth.React;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.BaseAdapter;
import android.widget.Gallery;
import android.widget.ImageView;

import com.facebook.react.bridge.Callback;
import com.facebook.react.bridge.ReadableArray;
import com.facebook.react.uimanager.ReactProp;
import com.facebook.react.uimanager.SimpleViewManager;
import com.facebook.react.uimanager.ThemedReactContext;
import com.yiyihealth.hitales.servant.MainActivity;


import org.json.JSONArray;
import org.json.JSONObject;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;

/**
 * Created by liaomin on 15/11/11.
 */
public class ReactGalleryView extends SimpleViewManager<Gallery> {


    private ThemedReactContext reactContext;
    private int index = 0;

    @Override
    public String getName() {
        return "GalleryView";
    }

    @Override
    protected Gallery createViewInstance(ThemedReactContext reactContext) {
        Gallery scrollGalleryView =  new Gallery(reactContext);
        this.reactContext = reactContext;
        return scrollGalleryView;

    }

    @ReactProp(name = "index", defaultInt = 0)
    public void setIndex(Gallery view,int index) {
        Log.i("index setIndex", String.valueOf(index));
        this.index = index;
    }

    @ReactProp(name = "dataSource")
    public void setDataSource(final  Gallery view, final ReadableArray src) {
        MainActivity.instance.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                final ArrayList<Bitmap> images = new ArrayList<Bitmap>();
                try {
                    String json = src.toString();
                    JSONArray array = new JSONArray(json);
                    for (int i = 0 ; i < array.length() ; i++){
                        JSONObject tmp = array.optJSONObject(i);
                        System.out.println("tmp ------------------" + i + tmp.toString());
                        final  String userId = tmp.optString("userId");
                        final  String imageKey = tmp.optString("key");
                        final boolean fromAMD = tmp.optBoolean("fromAMD");
                        String path = FileHelper.getLocalImagePath(userId, imageKey);
                        if(path != null){
//                            int scale = calculateInSampleSize(path);
                            Bitmap bitmap = BitmapManager.decodeBitmap2ScaleTo(path, 1024);
                            images.add(bitmap);
                        }else {
                            images.add(null);
                            final  int index = i;
                            ImageHelper.instance.getImage(userId, imageKey,fromAMD, new Callback() {
                                @Override
                                public void invoke(Object... args) {
                                    String path = FileHelper.getLocalImagePath(userId, imageKey);
                                    if(path != null){
                                        int scale = calculateInSampleSize(path);
                                        Bitmap bitmap = BitmapManager.decodeBitmap2Scale(path, scale);
                                        images.remove(index);
                                        images.add(index, bitmap);
//                                        ImageAdapter adapter = new ImageAdapter(MainActivity.instance,images);
//                                        view.setAdapter(adapter);
                                        ((BaseAdapter)view.getAdapter()).notifyDataSetChanged();
                                    }
                                }
                            });
                        }
                    }
                    ImageAdapter adapter = new ImageAdapter(MainActivity.instance,images);
                    view.setAdapter(adapter);
                    view.setSelection(index);
                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        });

    }

    class  ImageAdapter extends BaseAdapter{
        private Context mContext;
        private ArrayList<Bitmap> images;
        private int width;
        public ImageAdapter(Context c,ArrayList<Bitmap> images) {
            mContext = c;
            WindowManager wm = (WindowManager) c.getSystemService(Context.WINDOW_SERVICE);
            int screenWidth = wm.getDefaultDisplay().getWidth();
            width = screenWidth;
            this.images = images;
        }
        @Override
        public int getCount() {
            return images.size();
        }

        @Override
        public Object getItem(int position) {
            return position;
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            ImageView i = new ImageView (mContext);
            Bitmap bitmap = images.get(position);
            i.setImageBitmap(bitmap);
            i.setScaleType(ImageView.ScaleType.FIT_CENTER);
            i.setLayoutParams(new Gallery.LayoutParams(width, Gallery.LayoutParams.MATCH_PARENT));
            return i;
        }

    };

    /**
     * 压缩图片显示
     * @param path
     * @return
     */
    private static int calculateInSampleSize(String path) {

        int reqWidth = MainActivity.SCREEN_WIDTH*2/3;
        int reqHeight = MainActivity.SCREEN_HEIGHT*2/3;
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        try {
            BitmapFactory.decodeStream(new FileInputStream(path), null, options);
            // Raw height and width of image
            final int height = options.outHeight;
            final int width = options.outWidth;
            int inSampleSize = 1;

            if (height > reqHeight || width > reqWidth) {

                final int halfHeight = height / 2;
                final int halfWidth = width / 2;
                while ((halfHeight / inSampleSize) > reqHeight
                        && (halfWidth / inSampleSize) > reqWidth) {
                    inSampleSize *= 2;
                }
            }

            return inSampleSize;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        return 1;

    }
}

