package com.yiyihealth.React;

/**
 * Created by chenjie on 16/2/29.
 */
public class Constans {

    public static int LOCAL_PROT = 5962;
    public final static String SERVER_URL = "121.41.43.230";



    //服务器环境 0：开发 1：测试 2：bug 3：预生产 4：生产
    public final static int ENV = 0;

    //开发环境
    public static String OSS_ACCESS_KEY = "cJZqJhQgMJz9DFIS";
    public static String OSS_SECRET_KEY = "bZjZJbth2ncsRx21Vhqt8STBSUSSZV";
    public static String OSS_UPLOAD_ENDPOINT = "http://oss-cn-hangzhou.aliyuncs.com";
    public static String OSS_BUCKET_NAME = "yiyihealth-test";
    public static String DOWNLOAD_ENDPOINT = "http://imgtest.yiyihealth.com";

    static {
        switch(ENV){
            case 1:
                OSS_ACCESS_KEY = "QP0VPN6AKcgVKBOc";
                OSS_SECRET_KEY = "2aSD13myX2snrKjLO0ZA1QZcWIlFhF";
                OSS_UPLOAD_ENDPOINT = "http://oss-cn-hangzhou.aliyuncs.com";
                OSS_BUCKET_NAME = "hitales-test";
                DOWNLOAD_ENDPOINT = "http://hitalestest.yiyihealth.com";

                break;
            case 2:
                OSS_ACCESS_KEY = "QP0VPN6AKcgVKBOc";
                OSS_SECRET_KEY = "2aSD13myX2snrKjLO0ZA1QZcWIlFhF";
                OSS_UPLOAD_ENDPOINT = "http://oss-cn-hangzhou.aliyuncs.com";
                OSS_BUCKET_NAME = "hitales-test";
                DOWNLOAD_ENDPOINT = "http://hitalestest.yiyihealth.com";
                break;
            case 3:
            case 4:
                OSS_ACCESS_KEY = "QP0VPN6AKcgVKBOc";
                OSS_SECRET_KEY = "2aSD13myX2snrKjLO0ZA1QZcWIlFhF";
                OSS_UPLOAD_ENDPOINT = "http://oss-cn-hangzhou.aliyuncs.com";
                OSS_BUCKET_NAME = "hitless-live";
                DOWNLOAD_ENDPOINT = "http://hetaleslive.yiyihealth.com";

                break;

        }

    }





}
