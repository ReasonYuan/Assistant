package com.yiyihealth.hitales.servant;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v4.app.FragmentActivity;
import android.view.KeyEvent;

import com.baidu.android.pushservice.PushConstants;
import com.baidu.android.pushservice.PushManager;
import com.couchbase.lite.Manager;
import com.couchbase.lite.View;
import com.couchbase.lite.android.AndroidContext;
import com.couchbase.lite.javascript.JavaScriptViewCompiler;
import com.couchbase.lite.listener.LiteListener;
import com.couchbase.lite.util.Log;
import com.facebook.react.LifecycleState;
import com.facebook.react.ReactInstanceManager;
import com.facebook.react.ReactRootView;
import com.facebook.react.modules.core.DefaultHardwareBackBtnHandler;
import com.facebook.react.shell.MainReactPackage;
import com.yiyihealth.React.Constans;
import com.yiyihealth.React.CouchbaseHelperPackage;
import com.yiyihealth.React.FileHelper;

import java.util.HashMap;

public class MainActivity extends FragmentActivity implements DefaultHardwareBackBtnHandler {

    public interface Callback{
        public void doCallback(int resultCode, Intent data);
    }

    //onActivityResult 的回调,key为requestCode
    public HashMap<Integer,Callback> resultsCallback = new HashMap<Integer,Callback>();

    public static ReactInstanceManager mReactInstanceManager;
    private ReactRootView mReactRootView;
    private SharedPreferences mPreferences;

    public static int SCREEN_WIDTH;
    public static int SCREEN_HEIGHT;
    public static Manager mDBManager;
    public static MainActivity instance;
    private static String BAIDU_API_KEY = "YOnIg4XzWHDpFBuddLDAgTlr";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = mPreferences.edit();
        editor.putString("debug_http_host", "192.168.0.101:8081");
        editor.putBoolean("reload_on_js_change", true);
//        editor.putBoolean("fps_debug", true);
//        editor.putBoolean("js_dev_mode_debug", true);
//        editor.putBoolean("animations_debug",true);
        editor.commit();

        instance = this;
        SCREEN_WIDTH = getWindowManager().getDefaultDisplay().getWidth();
        SCREEN_HEIGHT = getWindowManager().getDefaultDisplay().getHeight();
        FileHelper.init(instance);
        View.setCompiler(new JavaScriptViewCompiler());

        try {
            Manager.enableLogging(Log.TAG, Log.VERBOSE);
            Manager.enableLogging(Log.TAG_SYNC, Log.VERBOSE);
            Manager.enableLogging(Log.TAG_QUERY, Log.VERBOSE);
            Manager.enableLogging(Log.TAG_VIEW, Log.VERBOSE);
            Manager.enableLogging(Log.TAG_CHANGE_TRACKER, Log.VERBOSE);
            Manager.enableLogging(Log.TAG_BLOB_STORE, Log.VERBOSE);
            Manager.enableLogging(Log.TAG_DATABASE, Log.VERBOSE);
            Manager.enableLogging(Log.TAG_LISTENER, Log.VERBOSE);
            Manager.enableLogging(Log.TAG_MULTI_STREAM_WRITER, Log.VERBOSE);
            Manager.enableLogging(Log.TAG_REMOTE_REQUEST, Log.VERBOSE);
            Manager.enableLogging(Log.TAG_ROUTER, Log.VERBOSE);
            mDBManager = new Manager(new AndroidContext(this), Manager.DEFAULT_OPTIONS);
            LiteListener listener = new LiteListener(mDBManager, Constans.LOCAL_PROT, null);
            Constans.LOCAL_PROT = listener.getListenPort();
            listener.start();
        } catch (Exception e) {
            e.printStackTrace();
        }


        mReactRootView = new ReactRootView(this);

        if(!HotRefresh.loadLocalBundleFile().equals("")){
            System.out.println("------加载新的bundle-------");
            mReactInstanceManager = ReactInstanceManager.builder()
                    .setApplication(getApplication())
                    .setJSBundleFile(HotRefresh.loadLocalBundleFile())
                    .setJSMainModuleName("index.android")
                    .addPackage(new MainReactPackage())
                    .addPackage(new CouchbaseHelperPackage())
                    .setUseDeveloperSupport(BuildConfig.DEBUG)
                    .setInitialLifecycleState(LifecycleState.RESUMED)
                    .build();
            System.out.println("bundlel路径：---"+HotRefresh.loadLocalBundleFile());
        }else{
            System.out.println("------加载Assets的bundle-------");
            mReactInstanceManager = ReactInstanceManager.builder()
                    .setApplication(getApplication())
                    .setBundleAssetName("index.android.bundle")
                    .setJSMainModuleName("index.android")
                    .addPackage(new MainReactPackage())
                    .addPackage(new CouchbaseHelperPackage())
                    .setUseDeveloperSupport(BuildConfig.DEBUG)
                    .setInitialLifecycleState(LifecycleState.RESUMED)
                    .build();
        }

        mReactRootView.startReactApplication(mReactInstanceManager, "Assistant", null);
        setContentView(mReactRootView);
        PushManager.startWork(getApplicationContext(), PushConstants.LOGIN_TYPE_API_KEY, BAIDU_API_KEY);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Callback callback = this.resultsCallback.get(requestCode);
        if(callback != null){
            callback.doCallback(requestCode,data);
        }
    }

    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_MENU && mReactInstanceManager != null) {
            mReactInstanceManager.showDevOptionsDialog();
            return true;
        }
        return super.onKeyUp(keyCode, event);
    }

    @Override
    public void onBackPressed() {
      if (mReactInstanceManager != null) {
        mReactInstanceManager.onBackPressed();
      } else {
        super.onBackPressed();
      }
    }

    @Override
    public void invokeDefaultOnBackPressed() {
      super.onBackPressed();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (mReactInstanceManager != null) {
            mReactInstanceManager.onPause();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (mReactInstanceManager != null) {
            mReactInstanceManager.onResume(this,this);
        }
    }
}
