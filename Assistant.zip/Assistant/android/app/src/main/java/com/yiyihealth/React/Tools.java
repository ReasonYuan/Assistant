package com.yiyihealth.React;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;

import com.facebook.react.bridge.Callback;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;

/**
 * Created by chenjie on 16/1/27.
 */
public class Tools extends ReactContextBaseJavaModule {

    public Tools(ReactApplicationContext reactContext){
        super(reactContext);
    }

    @Override
    public String getName() {
        return "Tools";
    }

    @ReactMethod
    public void isNetworkConnected(Callback callback){
        ConnectivityManager cm = (ConnectivityManager)getCurrentActivity().getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo ni = cm.getActiveNetworkInfo();

        if(ni != null && ni.isConnectedOrConnecting()){
            callback.invoke("true");
        }else{
            callback.invoke("false");
        }


    }

    /**
     * 获取当前网络类型
     * @return 0：没有网络   1：WIFI网络   2：WAP网络    3：NET网络
     */

    public static final int NETTYPE_WIFI = 0x01;
    public static final int NETTYPE_CMWAP = 0x02;
    public static final int NETTYPE_CMNET = 0x03;
    @ReactMethod
    public int getNetworkType() {
        int netType = 0;
        ConnectivityManager connectivityManager = (ConnectivityManager) getCurrentActivity().getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        if (networkInfo == null) {
            return netType;
        }
        int nType = networkInfo.getType();
        if (nType == ConnectivityManager.TYPE_MOBILE) {
            String extraInfo = networkInfo.getExtraInfo();
            if(!extraInfo.isEmpty()){
                if (extraInfo.toLowerCase().equals("cmnet")) {
                    netType = NETTYPE_CMNET;
                } else {
                    netType = NETTYPE_CMWAP;
                }
            }
        } else if (nType == ConnectivityManager.TYPE_WIFI) {
            netType = NETTYPE_WIFI;
        }
        return netType;
    }

    @ReactMethod
    public void jumpAppStore(int roleType,int env){

        String url = "http://fir.im/";
        if (env == 4){
            switch (roleType){
                case 0:url += "htys";
                    break;
                case 1:url += "htjt";
                    break;
                case 2:url += "htzs";
                    break;
            }
        }else{
            if (1 == env || 0 == env) {
                switch (roleType) {
                    case 0: url += "acys"; break;
                    case 1: url += "acjk"; break;
                    case 2: url += "aczs"; break;
                }
            }else if (3 == env){
                switch (roleType) {
                    case 0: url += "ayys"; break;
                    case 1: url += "ayjk"; break;
                    case 2: url += "ayzs"; break;
                }
            }
        }
        Uri uri = Uri.parse(url);
        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
        getCurrentActivity().startActivity(intent);


    }

}
