package com.yiyihealth.React;

import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.kaopiz.kprogresshud.KProgressHUD;
import com.yiyihealth.hitales.servant.MainActivity;

/**
 * Created by wangxi on 16/3/14.
 */
public class DialogManager extends ReactContextBaseJavaModule {

    private KProgressHUD hud;
    public DialogManager(ReactApplicationContext reactContext) {
        super(reactContext);
    }

    @Override
    public String getName() {
        return "DialogManager";
    }

    @ReactMethod
    public void showLabelPBDialog(final String label){
        MainActivity.instance.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                hud  = KProgressHUD.create(MainActivity.instance)
                        .setStyle(KProgressHUD.Style.SPIN_INDETERMINATE)
                        .setLabel(label)
                        .show();
            }
        });
    }

    @ReactMethod
    public void dismissPBDialog(){

                MainActivity.instance.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if(hud != null && hud.isShowing()){
                        hud.dismiss();
                        hud = null;
                        }
                    }
                });

    }
}
