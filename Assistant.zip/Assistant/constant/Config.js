'use strict';
var React = require('react-native');
var {Platform} = React
var CouchbaseHelper = React.NativeModules.CouchbaseHelper;
let env = CouchbaseHelper.ENV;
var local_port = CouchbaseHelper.LOCAL_PORT;
var server = CouchbaseHelper.SERVER_URL;

let boundleVersion = "1.0.8";


let ROLE_TYPE = 2;

var server_name = "开发环境"
var server_syncgateway = "121.41.43.230:4984/";
var server_assistant = "121.41.43.230:3100/";
var server_baoshi = "121.41.43.230:5000/";
var server_yiyi = "121.41.43.230:3000/";
var server_dongtai = "121.41.43.230:3001/";
var server_bucket = "test";
var PAY_DEBUG = true;
if(env == 1){
  //测试服务器
  server_name = "测试环境"
  server_syncgateway = "121.196.244.95:4984/";
  server_assistant = "120.55.189.100:3100/";
  server_baoshi = "120.27.199.93:5000/";
  server_yiyi = "120.27.199.222:3000/";
  server_dongtai = "120.27.199.165:3001/";
  server_bucket = "test";
  PAY_DEBUG = true;
}else if (env == 2) {
  //bug重现环境
  server_name = "bug重现环境"
  server_syncgateway = "121.196.232.71:4984/";
  server_assistant = "121.196.232.71:3100/";
  server_baoshi = "121.196.232.71:5000/";
  server_yiyi = "121.196.232.71:3000/";
  server_dongtai = "121.196.232.71:3001/";
  server_bucket = "test";
  PAY_DEBUG = true;
}else if (env == 3) {
  // 预生产环境
  server_name = "生产环境" //预生产环境
  server_syncgateway = "114.55.35.31:4984/";
  server_assistant = "114.55.35.31:3100/";
  server_baoshi = "114.55.35.31:5000/";
  server_yiyi = "114.55.35.31:3000/";
  server_dongtai = "114.55.35.31:3001/";
  server_bucket = "production";
}else if (env == 4) {
  // 生产环境
  server_name = "生产环境"
  server_syncgateway = "120.55.240.23:4984/";
  server_assistant = "121.196.244.147:3100/";
  server_baoshi = "121.196.244.146:5000/";
  server_yiyi = "121.196.227.133:3000/";
  server_dongtai = "120.55.188.146:3001/";
  server_bucket = "production";
  PAY_DEBUG = false;
}else if (env == 0) {
  //开发环境
  server_name = "开发环境"
  server_syncgateway = "121.41.43.230:4984/";
  server_assistant = "121.41.43.230:3100/";
  server_baoshi = "121.41.43.230:5000/";
  server_yiyi = "121.41.43.230:3000/";
  server_dongtai = "121.41.43.230:3001/";
  server_bucket = "test";
  PAY_DEBUG = true;
}

// DEMO环境
// let server_name = "demo环境"
// let server_syncgateway = "121.199.16.216:4984/";
// let server_assistant = "121.199.16.216:3100/";
// let server_baoshi = "121.199.16.216:5000/";
// let server_yiyi = "121.199.16.216:3000/";
// let server_dongtai = "121.199.16.216:5001/";
// let server_bucket = "demo";
// let PAY_DEBUG = true;


var rest_api_server = server_yiyi;
switch (ROLE_TYPE) {
  case 1:
    rest_api_server = server_baoshi;
    break;
  case 2:
    rest_api_server = server_assistant;
    break;
  default:
}


module.exports = {
  env:env,
  boundleVersion:boundleVersion,
  serverType:server_name,
  localURL:"http://127.0.0.1:"+local_port+"/",
  serverURL:"http://"+server_syncgateway,
  serverBucket:server_bucket,
  webServerURL:"http://"+server_assistant,
  webAssistantServerURL:"http://"+server_assistant, //宝时助手服务器接口
  webBaoshiServerURL:"http://"+server_baoshi, //宝时服务器接口
  webShowForwardServerURL:"http://"+server_yiyi, //Yiyi forward Server
  role_type:ROLE_TYPE,
  message_time_line_interval:60*5*1000,

  //data base views on boot
  bootDBViews:{
    chatFriendShipView:"ChatFriendShipView"
  },
  dbDocPrefix:{
    chatfriend: "chatfriend_"
  }
}

var { NativeAppEventEmitter,DeviceEventEmitter } = require('react-native');

var subscription = NativeAppEventEmitter.addListener(
  'EventReminder',
  (reminder) => console.log("--->",reminder)
);


DeviceEventEmitter.addListener('EventReminder', function(e: Event) {
    // handle event.
    console.log("--->",e)
});
