
module.exports = {
  default_color:"#3F8A7F",
  navigation_bar_title_color:"#333333",
  white_border_color:"#f1f1f1", //背景为白色的描边色
  itemDivider:'#f1f1f1',    //item分隔线颜色
  itemBorder:'#f1f1f1',      //聊天框的颜色
  itemClick: '#f6f6f6',     //item被点击颜色
  headIcon:'transparent',          //message用户头像背景色
  title:'#333',             //通常title的颜色
  des:'#666',               //描述的颜色
  info:'#999',
  text_dark_gary:'#666666',
  text_light_gary:'#999999',
  chatBorder:'#f1f1f1'      //聊天框的颜色
}
