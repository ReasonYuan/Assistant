/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 */
'use strict';

var React = require('react-native');
var {
  AppRegistry,
  StyleSheet,
  View,
  // Navigator,
} = React;

var Login = require("./core/Login")
var Navigator = require('./Navigator')

//TODO==JP==以后版本稳定后可以不加这个remotelog
//DEV模式下允许
if(__DEV__){
  var setRemoteErrorHandler = require("./utils/RemoteErrorUtils").setUpErrorHandler
  setRemoteErrorHandler()
}

// __DEV__ = false
class Servant extends React.Component {
  renderScene(route, navigator){
    if(route.component){
      return  route.component;
    }else{
      return <Login navigator={navigator}/>
    }
  }
  render() {

    // return (
    //   <Navigator
    //     style={styles.container}
    //     initialRoute={{
    //       component:Login
    //     }}
    //   />
    // )
    return (
      <Navigator
        style={styles.container}
        initialRoute={{
          component:Login
        }}

      />
    );
  }
}

var styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'stretch',
  }
});

AppRegistry.registerComponent('Assistant', () => Servant);
