/**
 * 便捷的fetch类
 * @author johnny
 * @date  2015-12-30
 */

var {Fetch} = require('../JSLibrary/Logic')

var fetchRequest = function(url, method, requestData, callback){
  if(method == "GET"){
    // fetch(url).then((response) => response.json())
    // .then((data) => {
    //   if(callback) callback(data)
    // }).catch((error) => {
    //   if(callback) callback({error:error})
    // })
    Fetch.get(url, callback);
  } else {
    // requestData = JSON.stringify(requestData)
    // fetch(url, {
    //   method: method,
    //   headers: {
    //     'Content-Type': "application/json"
    //   },
    //   body: requestData
    // }).then((response) => response.json())
    // .then((data) => {
    //   if(callback) callback(data)
    // }).catch((error) => {
    //   if(callback) callback({error:error})
    // })
    Fetch.post("",requestData,callback,url);
  }
}

var SimpleFetch = {
  fetchGet:function(url, callback){
    fetchRequest(url, "GET", null, callback)
  },
  fetchPost:function(url, postData, callback){
    fetchRequest(url, "POST", postData, callback)
  },
  fetchPut:function(url, putData, callback){
    fetchRequest(url, "PUT", putData, callback)
  },
  fetchDelete:function(url, callback){
    fetchRequest(url, "DELETE", {}, callback)
  }
}

module.exports = SimpleFetch
