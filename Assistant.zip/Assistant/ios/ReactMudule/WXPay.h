//
//  WXPay.h
//  Care
//
//  Created by 王曦 on 16/1/26.
//  Copyright © 2016年 Facebook. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RCTBridgeModule.h"
@interface WXPay : NSObject<RCTBridgeModule>

+(RCTResponseSenderBlock)getPayBlock;
//获取当前订单商品的号
+(NSString*)getCurrenTRransactionId;
@end
