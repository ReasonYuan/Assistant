//
//  CameraScannerViewManager.m
//  Care
//
//  Created by 廖敏 on 15/12/22.
//  Copyright © 2015年 Facebook. All rights reserved.
//

#import "CameraScannerViewManager.h"
#import "CameraScannerView.h"

@interface CameraScannerViewManager()<CameraScannerViewDelegate>
{
  CameraScannerView* scannerView;
}
@end


@implementation CameraScannerViewManager

RCT_EXPORT_MODULE()

-(void)onImagePerview
{
  [self.bridge.eventDispatcher sendAppEventWithName:@"CameraScannerView_onPerview"
                                               body:@{}];
}

- (UIView *)view
{
  if(!scannerView)scannerView = [[CameraScannerView alloc] init];
  scannerView.scannerViewDelegate = self;
  return scannerView;
}

RCT_EXPORT_METHOD(usePerviewPhoto:(NSDictionary*)option  callBack:(RCTResponseSenderBlock)callback){
  dispatch_sync(dispatch_get_main_queue(), ^{
    if(scannerView){
      NSMutableDictionary *response = [[NSMutableDictionary alloc] init];
      UIImage* image = scannerView.currentPerviewImage;
#if TARGET_IPHONE_SIMULATOR
      image = [UIImage imageNamed:@"test.png"];
#endif
      if(image && option[@"use"] && option[@"path"]){ //保存图片
        NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
        NSString *documentsDirectory = [paths objectAtIndex:0];
        NSString *newPath = [documentsDirectory stringByAppendingPathComponent:[option objectForKey:@"path"]];
        NSString *ImageUUID = [[NSUUID UUID] UUIDString];
        NSString *ImageName = [ImageUUID stringByAppendingString:@".jpg"];
        NSString* path = [newPath stringByAppendingPathComponent:ImageName];
        [self checkFileDir:path];
        
        
        [response setObject:@(image.size.width) forKey:@"width"];
        [response setObject:@(image.size.height) forKey:@"height"];
        [UIImageJPEGRepresentation(image, 1.0) writeToFile:path atomically:YES];
        [response setObject:path forKey:@"uri"];
        [response setObject:ImageName forKey:@"fileName"];
        
        BOOL vertical = (image.size.width < image.size.height) ? YES : NO;
        [response setObject:@(vertical) forKey:@"isVertical"];
      }
      callback(@[response]);
      [scannerView hidePreview];
    }
  });
}

RCT_EXPORT_METHOD(takePhoto){
  dispatch_sync(dispatch_get_main_queue(), ^{
#if TARGET_IPHONE_SIMULATOR
    [self onImagePerview];
    return ;
#endif
    if(scannerView){
      @try {
        [scannerView takePhotoAndShear];
      }
      @catch (NSException *exception) {
        NSLog(@"%@",exception);
      }
      @finally {
      }
    }
  });
}


-(void)checkFileDir:(NSString *)fullPath
{
  @try {
    NSRange range = [fullPath rangeOfString:@"/" options:NSBackwardsSearch];
    if (range.location == NSNotFound) {
      return;
    }
    NSString* dir = [fullPath substringToIndex:range.location];
    NSFileManager* fileManager = [NSFileManager defaultManager];
    if(![fileManager fileExistsAtPath:dir]){
      [fileManager createDirectoryAtPath:dir withIntermediateDirectories:YES attributes:nil error:nil];
    }
  }
  @catch (NSException *exception) {
    
  }
  @finally {
    
  }
  
}


@end

