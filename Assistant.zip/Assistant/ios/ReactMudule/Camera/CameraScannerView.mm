//
//  CameraScannerView.m
//  Care
//
//  Created by 廖敏 on 15/12/20.
//  Copyright © 2015年 Facebook. All rights reserved.
//

#import "CameraScannerView.h"
#import <opencv2/opencv.hpp>
#import "CameraScanner.h"
#import "VideoCameraCover.h"

@interface CameraScannerView()
{
  std::vector<cv::Point> rect; //计算剪切所得到的矩形区域
  UIImageView *previewImage;
  VideoCameraCover *_coverView;
  BOOL isTakePhoto;
}
@end

@implementation CameraScannerView

+(void)addChildViewFullInParent:(UIView *)child parent:(UIView *)parent
{
  if(child && parent && !child.superview){
    [child setTranslatesAutoresizingMaskIntoConstraints:NO];
    [parent addSubview:child];
    [parent addConstraint:[NSLayoutConstraint constraintWithItem:child attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:parent attribute:NSLayoutAttributeTop multiplier:1 constant:0]];
    [parent addConstraint:[NSLayoutConstraint constraintWithItem:child attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:parent attribute:NSLayoutAttributeBottom multiplier:1 constant:0]];
    [parent addConstraint:[NSLayoutConstraint constraintWithItem:child attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:parent attribute:NSLayoutAttributeLeft multiplier:1 constant:0]];
    [parent addConstraint:[NSLayoutConstraint constraintWithItem:child attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:parent attribute:NSLayoutAttributeRight multiplier:1 constant:0]];
  }
}

-(void)setup{
  [super setup];
  isTakePhoto = false;
  previewImage = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 600, 600)];
  previewImage.contentMode = UIViewContentModeScaleAspectFit;
  [previewImage setBackgroundColor:[UIColor blackColor]];
  _coverView = [[VideoCameraCover alloc] init];
  [_coverView setBackgroundColor:[UIColor clearColor]];
  [CameraScannerView addChildViewFullInParent:_coverView parent:self];
  [CameraScannerView addChildViewFullInParent:previewImage parent:self];
  previewImage.hidden = YES;
}

-(void)didMoveToWindow
{
  [super didMoveToWindow];
  if(self.window){ //加载到屏幕上了
    [self startPreview];
    self.delegate = self;
  }else{//移除屏幕
    [self stop];
    self.delegate = nil;
  }
}

-(void)hidePreview
{
  previewImage.hidden = YES;
  previewImage.image = nil;
}

-(void)onImageShear:(UIImage*)image{
  previewImage.hidden = NO;
  [previewImage setImage:image];
  self.currentPerviewImage = image;
  if(self.scannerViewDelegate)[self.scannerViewDelegate onImagePerview];
}


- (void)processImage:(CVImageBufferRef)imagebuffer
{
  if(isTakePhoto) {
    std::vector<cv::Point2f> points;
    [_coverView setPoints:points Larged:false arcLength:0];
    return;
  };
  UIImage* image = [self imageFromSampleBuffer:imagebuffer];
  cv::Mat src = cv::CameraScanner::cvMatFromUIImage(image);
  [self adjust:src];
  _coverView.iamgeSize = image.size;
  image = nil;
  cv::Mat dst = src.clone();
  cv::cvtColor(dst, dst ,CV_BGR2GRAY);//转化为灰度空间
  cv::resize(src,src,cv::Size(288,352));
  std::vector<cv::Point> square;
  cv::CameraScanner::findLargeSquare(src, square);
  _coverView.calculateImageSize =  CGSizeMake(src.cols, src.rows);
  float lenth = fabs(arcLength(cv::Mat(square),true));
  BOOL isLarged = lenth > 622;
  std::vector<cv::Point2f> points;
  rect = square;
  if(square.size() > 0){
    for (int i = 0; i < square.size(); i++) {
      cv::Point p = square[i];
      points.push_back(cv::Point2f(p.x,p.y));
    }
    
    do{
      cv::Size srcSize = src.size();
      cv::Size dstSize = dst.size();
      float wScale = dstSize.width / (float)srcSize.width;
      float hScale = dstSize.height / (float)srcSize.height;
      std::vector<cv::Point2f> square2;
      for (int i = 0; i < square.size(); i++) {
        square2.push_back(cv::Point2f(square[i].x*wScale,square[i].y*hScale));
      }
      cv::Point2f center(0,0);
      for (int i = 0; i < square2.size(); i++)
        center += square2[i];
      center *= (1. / square2.size());
      cv::CameraScanner::sortCorners(square2, center);
      if(square2.size() != 4){
        points.clear();
        break;
      }
      [_coverView setPoints:points Larged:isLarged arcLength:lenth];
      
      if([_coverView canShear]){
        dispatch_async(dispatch_get_main_queue(), ^{
          [self takePhotoAndShear];
        });
      }
    }while (0) ;
  }else{
    [_coverView setPoints:points Larged:isLarged arcLength:lenth];
  }
}



-(void)takePhotoAndShear{
  if(isTakePhoto && !previewImage.isHidden) return;
  isTakePhoto = true;
  [self takePhoto:^(UIImage * image) {
    if(!image)return;
    cv::Mat src = cv::CameraScanner::cvMatFromUIImage(image);
    [self adjust:src];
    cv::Mat dst = src;
    cv::cvtColor(dst, dst ,CV_BGR2GRAY);//转化为灰度空间
    cv::resize(src,src,cv::Size(288,352));
    _coverView.calculateImageSize =  CGSizeMake(src.cols, src.rows);;
    auto shear = [&](std::vector<cv::Point>& square){
      std::vector<cv::Point2f> points;
      if(square.size() > 0){
        for (int i = 0; i < square.size(); i++) {
          cv::Point p = square[i];
          points.push_back(cv::Point2f(p.x,p.y));
        }
        do{
          cv::Size srcSize = src.size();
          cv::Size dstSize = dst.size();
          float wScale = dstSize.width / (float)srcSize.width;
          float hScale = dstSize.height / (float)srcSize.height;
          std::vector<cv::Point2f> square2;
          for (int i = 0; i < square.size(); i++) {
            square2.push_back(cv::Point2f(square[i].x*wScale,square[i].y*hScale));
          }
          cv::Point2f center(0,0);
          for (int i = 0; i < square2.size(); i++)
            center += square2[i];
          center *= (1. / square2.size());
          cv::CameraScanner::sortCorners(square2, center);
          if(square2.size() != 4){
            points.clear();
            break;
          }
          CGSize siz = getShearImageSize2(square2);
          cv::Mat quad = cv::Mat::zeros(siz.height, siz.width, CV_8UC3);
          std::vector<cv::Point2f> quad_pts;
          quad_pts.push_back(cv::Point2f(0, 0));
          quad_pts.push_back(cv::Point2f(quad.cols, 0));
          quad_pts.push_back(cv::Point2f(quad.cols, quad.rows));
          quad_pts.push_back(cv::Point2f(0, quad.rows));
          cv::Mat transmtx = cv::getPerspectiveTransform(square2, quad_pts);
          cv::warpPerspective(dst, quad, transmtx, quad.size());
          dispatch_async(dispatch_get_main_queue(), ^{
            UIImage* cImage = cv::CameraScanner::UIImageFromCVMat(quad);
            [self onImageShear:cImage];
          });
          return true;
        }while (0) ;
        
      }
      return false;
    };
    
    std::vector<cv::Point> square;
    cv::CameraScanner::findLargeSquare(src, square);
    if(!shear(square)){
      if(!shear(rect)){
        dispatch_async(dispatch_get_main_queue(), ^{
          UIImage* cImage = cv::CameraScanner::UIImageFromCVMat(dst);
          [self onImageShear:cImage];
        });
      }
    }
    isTakePhoto = false;
  } playSound:NO];
}

CGSize getShearImageSize2(std::vector<cv::Point2f>& points){
  return CGSizeMake(fabs(points[0].x-points[1].x),fabs(points[1].y-points[2].y));
}

-(void)adjust:(cv::Mat&)src
{
  CGSize frameSize = self.frame.size;
  CGSize imageSize = CGSizeMake(src.cols, src.rows);
  if(frameSize.width / imageSize.width != frameSize.height / imageSize.height){
    CGFloat dstY = imageSize.width*frameSize.height/frameSize.width;
    CGFloat offset = (imageSize.height - dstY) / 2.f;
    if(offset < 0){
      CGFloat dstX = frameSize.width * imageSize.height / frameSize.height;
      offset = (imageSize.width - dstX) / 2.f;
      src = cv::Mat(src,cv::Range(0,src.rows),cv::Range(offset,src.cols-offset));
    }else {
      src = cv::Mat(src,cv::Range(offset,src.rows - offset),cv::Range(0,src.cols));
    }
  }
}

@end
