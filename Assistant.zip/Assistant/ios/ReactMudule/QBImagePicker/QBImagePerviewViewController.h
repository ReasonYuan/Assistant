//
//  QBImagePerviewViewController.h
//  QBImagePicker
//
//  Created by 廖敏 on 15/12/4.
//  Copyright © 2015年 Katsuma Tanaka. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Photos/Photos.h>

@class QBImagePickerController;

@interface QBImagePerviewViewController : UIViewController

@property (nonatomic, weak) QBImagePickerController *imagePickerController;

@property (nonatomic, weak) PHAsset *asset;

@end
