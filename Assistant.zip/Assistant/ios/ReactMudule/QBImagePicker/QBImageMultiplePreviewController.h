//
//  QBImageMultiplePreviewController.h
//  Practice
//
//  Created by 廖敏 on 15/12/30.
//  Copyright © 2015年 Facebook. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Photos/Photos.h>

@class QBImagePickerController;

@interface QBImageMultiplePreviewController : UIViewController

@property (nonatomic, weak) QBImagePickerController *imagePickerController;

@property (nonatomic, strong) NSArray *assets;

@end
