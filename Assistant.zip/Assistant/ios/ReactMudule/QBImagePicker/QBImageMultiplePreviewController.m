//
//  QBImageMultiplePreviewController.m
//  Practice
//
//  Created by 廖敏 on 15/12/30.
//  Copyright © 2015年 Facebook. All rights reserved.
//

#import "QBImageMultiplePreviewController.h"
#import "CMFGalleryCell.h"
#import "QBImagePickerController.h"

@interface QBImageMultiplePreviewController () <UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout>

@property (nonatomic, weak) UICollectionView* collectionView;

@end

@implementation QBImageMultiplePreviewController

- (void)viewDidLoad {
  [super viewDidLoad];
  NSArray *arrayOfViews = [[NSBundle mainBundle] loadNibNamed:@"GalleryView" owner:self options:nil];
  [QBImageMultiplePreviewController addChildViewFullInParent:[arrayOfViews objectAtIndex:0] parent:self.view];
  [self.collectionView registerClass:[CMFGalleryCell class] forCellWithReuseIdentifier:@"cellIdentifier"];
  
  UICollectionViewFlowLayout *flowLayout = [[UICollectionViewFlowLayout alloc] init];
  [flowLayout setScrollDirection:UICollectionViewScrollDirectionHorizontal];
  [flowLayout setMinimumInteritemSpacing:0.0f];
  [flowLayout setMinimumLineSpacing:0.0f];
  [self.collectionView setPagingEnabled:YES];
  [self.collectionView setCollectionViewLayout:flowLayout];
//
//  UIBarButtonItem *rightSpace = [[UIBarButtonItem alloc] initWithTitle:@"" style:UIBarButtonItemStylePlain target:self action:@selector(perviewSend)];
//  [rightSpace setTintColor:[UIColor grayColor]];
//  NSDictionary *attributes = @{ NSForegroundColorAttributeName: [UIColor blackColor] };
//  UIBarButtonItem *infoButtonItem =[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:NULL];
//  infoButtonItem.enabled = NO;
//  [infoButtonItem setTitleTextAttributes:attributes forState:UIControlStateNormal];
//  [infoButtonItem setTitleTextAttributes:attributes forState:UIControlStateDisabled];
//  self.toolbarItems = @[infoButtonItem, rightSpace];
  [self.navigationController setToolbarHidden:YES animated:NO];
}

-(void)viewWillDisappear:(BOOL)animated{
  [self.navigationController setToolbarHidden:NO animated:YES];
  [super viewWillDisappear:animated];
}

-(void)perviewSend {
//  QBImagePickerController *imagePickerController = self.imagePickerController;
//  if(self.assets){
//    if(self.assets && self.assets.count > 1){
//      if ([imagePickerController.delegate respondsToSelector:@selector(qb_imagePickerController:didFinishPickingAssets:)]) {
//        [imagePickerController.delegate qb_imagePickerController:imagePickerController didFinishPickingAssets:self.assets];
//      }
//    }
//    
//  }
}

-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
  return 1;
}

-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
  return self.assets ? [self.assets count] : 0;
}

-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
  CMFGalleryCell *cell = (CMFGalleryCell *)[collectionView dequeueReusableCellWithReuseIdentifier:@"cellIdentifier" forIndexPath:indexPath];
  PHAsset* asset = [self.assets objectAtIndex:indexPath.row];
  cell.tag = indexPath.item;
  [[PHCachingImageManager defaultManager] requestImageForAsset:asset
                               targetSize:self.collectionView.frame.size
                              contentMode:PHImageContentModeAspectFill
                                  options:nil
                            resultHandler:^(UIImage *result, NSDictionary *info) {
                              if (cell.tag == indexPath.item) {
                                  cell.image = result;
                                }
                              }];
  return cell;
}

-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
  return self.collectionView.frame.size;
}



+(void)addChildViewFullInParent:(UIView *)child parent:(UIView *)parent
{
  if(child && parent && !child.superview){
    [child setTranslatesAutoresizingMaskIntoConstraints:NO];
    [parent addSubview:child];
    [parent addConstraint:[NSLayoutConstraint constraintWithItem:child attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:parent attribute:NSLayoutAttributeTop multiplier:1 constant:0]];
    [parent addConstraint:[NSLayoutConstraint constraintWithItem:child attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:parent attribute:NSLayoutAttributeBottom multiplier:1 constant:0]];
    [parent addConstraint:[NSLayoutConstraint constraintWithItem:child attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:parent attribute:NSLayoutAttributeLeft multiplier:1 constant:0]];
    [parent addConstraint:[NSLayoutConstraint constraintWithItem:child attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:parent attribute:NSLayoutAttributeRight multiplier:1 constant:0]];
  }
}

@end
