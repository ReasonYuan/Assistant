//
//  AlertTextInput.m
//  Practice
//
//  Created by 廖敏 on 15/10/29.
//  Copyright © 2015年 Facebook. All rights reserved.
//

#import "AlertTextInput.h"
#import <UIKit/UIKit.h>

@implementation AlertTextInput
{
  RCTResponseSenderBlock callback;
}
@synthesize bridge = _bridge;

RCT_EXPORT_MODULE();

RCT_EXPORT_METHOD(showTextInputAlertView:(NSString*)title placeholder:(NSString*)holder Callback:(RCTResponseSenderBlock)back)
{
  callback = back;
  dispatch_sync(dispatch_get_main_queue(), ^{
    UIAlertView *dialog = [[UIAlertView alloc] initWithTitle:title message:nil delegate:self cancelButtonTitle:@"添加" otherButtonTitles:@"取消",nil];
    [dialog setAlertViewStyle:UIAlertViewStylePlainTextInput];
    [[dialog textFieldAtIndex:0] setPlaceholder:holder];
    [dialog show];
  });
  
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
  if(buttonIndex == 0){
    if(callback){
      NSString* text = [alertView textFieldAtIndex:0].text;
      callback(@[text]);
    }
  }
  callback = nil;
}


@end
