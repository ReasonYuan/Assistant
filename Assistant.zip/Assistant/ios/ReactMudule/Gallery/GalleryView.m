//
//  GalleryView.m
//  UICollectionGallery
//
//  Created by 廖敏 on 15/11/1.
//  Copyright © 2015年 Charismatic Megafauna Ltd. All rights reserved.
//

#import "GalleryView.h"
#import <UIKit/UIKit.h>
#import "CMFGalleryCell.h"
#import "ImageHelper.h"
#import "Task.h"

@interface GalleryView()<UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout>

@end

@implementation GalleryView
{
    
}

@synthesize collectionView;


-(id)init{
    self =  [super init];
    if (self) {
        [self setupCollectionView];
    }
    return self;
}

-(id)initWithFrame:(CGRect)frame{
    self =  [super initWithFrame:frame];
    if (self) {
        [self setupCollectionView];
    }
    return self;
}

-(void)setupCollectionView {
    NSArray *arrayOfViews = [[NSBundle mainBundle] loadNibNamed:@"GalleryView" owner:self options:nil];
    [GalleryView addChildViewFullInParent:[arrayOfViews objectAtIndex:0] parent:self];
    [self.collectionView registerClass:[CMFGalleryCell class] forCellWithReuseIdentifier:@"cellIdentifier"];
    
    UICollectionViewFlowLayout *flowLayout = [[UICollectionViewFlowLayout alloc] init];
    [flowLayout setScrollDirection:UICollectionViewScrollDirectionHorizontal];
    [flowLayout setMinimumInteritemSpacing:0.0f];
    [flowLayout setMinimumLineSpacing:0.0f];
    [self.collectionView setPagingEnabled:YES];
    [self.collectionView setCollectionViewLayout:flowLayout];
  [self setBackgroundColor:[UIColor redColor]];
}

+(void)addChildViewFullInParent:(UIView *)child parent:(UIView *)parent
{
  if(child && parent && !child.superview){
    [child setTranslatesAutoresizingMaskIntoConstraints:NO];
    [parent addSubview:child];
    [parent addConstraint:[NSLayoutConstraint constraintWithItem:child attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:parent attribute:NSLayoutAttributeTop multiplier:1 constant:0]];
    [parent addConstraint:[NSLayoutConstraint constraintWithItem:child attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:parent attribute:NSLayoutAttributeBottom multiplier:1 constant:0]];
    [parent addConstraint:[NSLayoutConstraint constraintWithItem:child attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:parent attribute:NSLayoutAttributeLeft multiplier:1 constant:0]];
    [parent addConstraint:[NSLayoutConstraint constraintWithItem:child attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:parent attribute:NSLayoutAttributeRight multiplier:1 constant:0]];
  }
}

-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return 1;
}

-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return [self.dataArray count];
}

-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    CMFGalleryCell *cell = (CMFGalleryCell *)[collectionView dequeueReusableCellWithReuseIdentifier:@"cellIdentifier" forIndexPath:indexPath];
    NSDictionary* att = [self.dataArray objectAtIndex:indexPath.row];
//    NSData *imageData = [CouchbaseHelper getAttachmentInDB:att[@"dbName"] doumnetId:att[@"documentID"] attachmentId:att[@"attachmentID"]];
//    NSString *imageString = [[NSString alloc] initWithData:imageData  encoding:NSUTF8StringEncoding];
    UIImage  *image = [ImageHelper getLoacalImage:att[@"userId"] imageKey:att[@"key"] expectWidth:cell.frame.size.width];
    cell.image = image;
    cell.tag = indexPath.row;
  NSString* userId = att[@"userId"];
  NSString* key = att[@"key"];
  if(!image && key && userId){
     NSFileManager* fileManager = [NSFileManager defaultManager];
    NSString* documentDir = [ImageHelper getDocumentPath];
    NSString* dirPath = [NSString stringWithFormat:@"%@/%@/%@",documentDir,userId,DIR_IMAGE];
    if(![fileManager fileExistsAtPath:dirPath]){
      [fileManager createDirectoryAtPath:dirPath withIntermediateDirectories:YES attributes:nil
                                   error:nil];
    }
    NSString* path = [NSString stringWithFormat:@"%@/%@/%@",userId,DIR_IMAGE,key];
    NSString* fullPath = [NSString stringWithFormat:@"%@/%@",documentDir,path];
    [ImageHelper downloadImage:key filePath:fullPath expectWidth:0 progressBlock:nil completeBlock:^(NSError *error) {
      UIImage *iImage = [ImageHelper createThumbnailImageFromFile:fullPath MaxWidth:[UIScreen mainScreen].bounds.size.width];
      if(cell.tag == indexPath.row && iImage){
        cell.image = iImage;
      }
    }];
  }
    return cell;
}

-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
    return self.collectionView.frame.size;
}


- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
  CGPoint currentOffset = [self.collectionView contentOffset];
  self.currentIndex = currentOffset.x / self.collectionView.frame.size.width;
  if(self.delegate){
    [self.delegate onIndexChange:self.currentIndex];
  }
}

-(NSInteger)getCurrentIndex{
  CGPoint currentOffset = [self.collectionView contentOffset];
  _currentIndex = currentOffset.x / self.collectionView.frame.size.width;
  return _currentIndex;
}

-(void)setIndex:(NSInteger)currentIndex
{
  dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
    CGFloat offset =  self.collectionView.frame.size.width*currentIndex;
    [self.collectionView setContentOffset:CGPointMake(offset, 0)];
    self.currentIndex = currentIndex;
  });

}

#pragma mark -
#pragma mark Rotation handling methods


-(void)willRotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:
(NSTimeInterval)duration {
    
    // Fade the collectionView out
    [self.collectionView setAlpha:0.0f];
    
    // Suppress the layout errors by invalidating the layout
    [self.collectionView.collectionViewLayout invalidateLayout];
    
    // Calculate the index of the item that the collectionView is currently displaying
    CGPoint currentOffset = [self.collectionView contentOffset];
    self.currentIndex = currentOffset.x / self.collectionView.frame.size.width;
}

-(void)didRotateFromInterfaceOrientation:(UIInterfaceOrientation)fromInterfaceOrientation {
    
    // Force realignment of cell being displayed
    CGSize currentSize = self.collectionView.bounds.size;
    float offset = self.currentIndex * currentSize.width;
    [self.collectionView setContentOffset:CGPointMake(offset, 0)];
    
    // Fade the collectionView back in
    [UIView animateWithDuration:0.125f animations:^{
        [self.collectionView setAlpha:1.0f];
    }];
}

-(void)reloadData
{
  if(self.dataArray){
    [self.collectionView reloadData];
  }
}

-(void)onButtonClick:(UIButton*)pSender{
  self.currentIndex = pSender.tag;
  [self.collectionView setContentOffset:CGPointMake(self.currentIndex * self.collectionView.frame.size.width, 0) animated:YES];
}


-(void)setDataArray:(NSArray *)dataArray{
  _dataArray = dataArray;
  [self reloadData];
  dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
    CGPoint currentOffset = [self.collectionView contentOffset];
    self.currentIndex = currentOffset.x / self.collectionView.frame.size.width;
  });
  
}

@end
