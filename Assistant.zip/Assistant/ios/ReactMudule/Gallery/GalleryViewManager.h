//
//  GalleryViewManager.h
//  Practice
//
//  Created by 廖敏 on 15/11/1.
//  Copyright © 2015年 Facebook. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RCTViewManager.h"

@interface GalleryViewManager : RCTViewManager

@end
