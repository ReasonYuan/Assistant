//
//  AppleIPAddress.h
//  Care
//
//  Created by 王曦 on 16/1/27.
//  Copyright © 2016年 Facebook. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AppleIPAddress : NSObject
+ (NSString *)getIPAddress;
@end
