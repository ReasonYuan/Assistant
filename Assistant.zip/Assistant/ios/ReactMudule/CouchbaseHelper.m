//
//  Attachment.m
//  ct1
//
//  Created by 廖敏 on 15/10/27.
//  Copyright © 2015年 Facebook. All rights reserved.
//
#import "AppDelegate.h"
#import "CouchbaseHelper.h"
#import <CouchbaseLite/CouchbaseLite.h>
#import "RCTEventDispatcher.h"
#import "BPush.h"
#import "SequenceTask.h"
#import "ImageHelper.h"
#import "UIView+Toast.h"

@interface CouchbaseHelper()
{
  NSString* currnetUserId;
  NSArray* currnetUserTargs;
  NSInteger fileCount;
  NSTimer* timer;
  CBLReplication *push;
  CBLReplication *pull;
}

@end

@implementation CouchbaseHelper
@synthesize bridge = _bridge;

RCT_EXPORT_MODULE();



- (NSDictionary *)constantsToExport
{
  return @{@"LOCAL_PORT":@LOCAL_PORT,@"ENV":@ENV,@"DOWNLOAD_ENDPOINT":DOWNLOAD_ENDPOINT};
}


-(void)onDBChanged:(NSNotification*) notification
{
  NSArray* changes = notification.userInfo[@"changes"];
  CBLDatabase* db = notification.object;
  NSString* dbName = db.name;
  NSMutableArray* docChaneges = [[NSMutableArray alloc] init];
  for (CBLDatabaseChange* change in changes){
    CBLDocument* doc = [db documentWithID:change.documentID];
    NSDictionary* properties = doc.properties;
    if(properties){
      NSString* type = properties[@"type"];
      if(type){    //Document 发生变化
        [docChaneges addObject:properties];
        if([change.documentID isEqualToString:currnetUserId]){ //用户tag发生变化
          [self registerUserBaiduTags];
        }
      }
    }else{//删除了document
      [docChaneges addObject:@{@"delete":@YES,@"_id":change.documentID}];
    }
  }
  if(docChaneges.count > 0)
    [self.bridge.eventDispatcher sendAppEventWithName:[NSString stringWithFormat:@"%@_changes",dbName]
                                                 body:docChaneges];
}

-(void)downThumbnailImage:(NSString*)key{
  NSInteger width = [UIScreen mainScreen].bounds.size.width;
  [[SequenceTask getDownloadImageSequenceTask] addDownloadTaskUserId:currnetUserId ObjectKey:key expectWidth:width];
}


RCT_EXPORT_METHOD(getVersion:(RCTResponseSenderBlock)callback){
  NSString* version = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"];
  if(callback)callback(@[version]);
}

//获取百度channelID
RCT_EXPORT_METHOD(getBaiduChannelId:(RCTResponseSenderBlock)callback){
  NSString* baiduChannel = [AppDelegate getBaiduChannelId];
  if(baiduChannel)callback(@[baiduChannel]);
  else callback(@[@""]);
}

//获取百度channelID
RCT_EXPORT_METHOD(setAppNotifitionCount:(NSInteger)count){
  //  [[UIApplication sharedApplication] setApplicationIconBadgeNumber:count];
}

//获取DeviceId
RCT_EXPORT_METHOD(getDeviceId:(RCTResponseSenderBlock)callback){
  NSString *uuid = [AppDelegate getDeviceId];
  callback(@[uuid]);
}

//解除百度推送的绑定
RCT_EXPORT_METHOD(unBindBaiDuPush:(RCTResponseSenderBlock)callback){
  dispatch_async(dispatch_get_main_queue(), ^{
    [BPush unbindChannelWithCompleteHandler:^(id result, NSError *error) {
      NSLog(@"%@",result);
      callback(@[result]);
    }];
  });
}

RCT_EXPORT_METHOD(BindBaiDuPush:(RCTResponseSenderBlock)callback){
  dispatch_async(dispatch_get_main_queue(), ^{
    [BPush bindChannelWithCompleteHandler:^(id result, NSError *error) {
      NSLog(@"%@",result);
      if(!error)callback(@[result]);
    }];
  });
}



-(void)registerUserBaiduTags
{
  if(currnetUserId){
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
      dispatch_sync(dispatch_get_main_queue(), ^{
        CBLDatabase* db = [[CBLManager sharedInstance] databaseNamed:currnetUserId error:nil];
        if(db){
          CBLDocument* doc = [db documentWithID: currnetUserId];
          NSDictionary* properties = doc.properties;
          if(properties){
            NSArray* tags = properties[@"tags"];
            if(tags && ![tags isEqualToArray:currnetUserTargs]){
              [BPush setTags:tags withCompleteHandler:^(id result, NSError *error) {
                
              }];
              currnetUserTargs = tags;
            }
          }
        }
      });
    });
  }
}


//创建或者获取数据库
RCT_EXPORT_METHOD(registerDBNamed:(NSString *)userId callback:(RCTResponseSenderBlock)callback){
  dispatch_sync(dispatch_get_main_queue(), ^{
    CBLDatabase* db = [[CBLManager sharedInstance] databaseNamed:userId error:nil];
    if(db){
      currnetUserId = userId;
      [db compact:nil];
      [self registerUserBaiduTags];
      [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onDBChanged:) name:kCBLDatabaseChangeNotification object:db];
      callback(@[]);
    }
  });
}


RCT_EXPORT_METHOD(setSession:(NSString*)session dbName:(NSString*)name ServerUrl:(NSString*)serverUrl bucketName:(NSString*)bucket){
  dispatch_sync(dispatch_get_main_queue(), ^{
    NSString* url = [NSString stringWithFormat:@"%@%@",serverUrl,bucket];
    NSURL* uri = [NSURL URLWithString:url];
    CBLDatabase* database = [[CBLManager sharedInstance] databaseNamed:currnetUserId error:nil];
    if(push)[push stop];
    if(pull)[push stop];
    push = [database createPushReplication: uri];
    pull = [database createPullReplication: uri];
    push.continuous = pull.continuous = YES;
    [pull setCookieNamed:@"SyncGatewaySession" withValue:session path:nil expirationDate:nil secure:NO];
    [push setCookieNamed:@"SyncGatewaySession" withValue:session path:nil expirationDate:nil secure:NO];
    push.continuous = pull.continuous = YES;
    NSNotificationCenter* nctr = [NSNotificationCenter defaultCenter];
    [nctr addObserver: self selector: @selector(replicationProgress:)
                 name: kCBLReplicationChangeNotification object: pull];
    [nctr addObserver: self selector: @selector(replicationProgress:)
                 name: kCBLReplicationChangeNotification object: push];
    [pull start];
    [push start];
  });
  
}


- (void) replicationProgress: (NSNotificationCenter*)n {
  if (pull.status == kCBLReplicationActive || push.status == kCBLReplicationActive) {
    // Sync is active -- aggregate the progress of both replications and compute a fraction:
    unsigned completed = pull.completedChangesCount + push.completedChangesCount;
    unsigned total = pull.changesCount+ push.changesCount;
    NSLog(@"SYNC progress: %u / %u", completed, total);
    // Update the progress bar, avoiding divide-by-zero exceptions:
//    [self.rootViewController showSyncStatus: (completed / (float)MAX(total, 1u))];
    } else {
      // Sync is idle -- hide the progress bar and show the config button:
      NSLog(@"SYNC idle");
//    [self.rootViewController hideSyncStatus];
    }
  
  // Check for any change in error status and display new errors:
//  NSError* error = pull.lastError ? pull.lastError : push.lastError;
//  if (error != _syncError) {
//    _syncError = error;
//    if (error) {
//      [self showAlert: @"Error syncing" error: error fatal: NO];
//    }
//  }
}

RCT_EXPORT_METHOD(stopReplication){
  if(push)[push stop];
  if(pull)[push stop];
}

//添加附件
RCT_EXPORT_METHOD(addAttachmnet:(NSString *)dbName documentId:(NSString*)documentId attachmentId:(NSString*)attachmentId contentType:(NSString*)contentType data:(NSString*)data callback:(RCTResponseSenderBlock)callback){
  dispatch_sync(dispatch_get_main_queue(), ^{
    @try {
      NSError* e;
      CBLDatabase* db = [[CBLManager sharedInstance] databaseNamed:dbName error:&e];
      CBLDocument* doc = [db documentWithID: documentId];
      CBLUnsavedRevision* revision = [doc.currentRevision createRevision];
      [revision setAttachmentNamed:attachmentId withContentType:contentType content:[data dataUsingEncoding:NSUTF8StringEncoding]];
      CBLSavedRevision* rev = [revision save:&e];
      if(rev){
        callback(@[rev.revisionID]);
      }
    }
    @catch (NSException *exception) {
      
    }
    @finally {
      
    }
  });
}

-(void)dealloc{
  [[NSNotificationCenter defaultCenter] removeObserver:self];
}

RCT_EXPORT_METHOD(getAttachment:(NSString *)dbName doumnetId:(NSString *)documentId attachmentId:(NSString *)attachmentId callback:(RCTResponseSenderBlock)callback){
  dispatch_sync(dispatch_get_main_queue(), ^{
    CBLDatabase* db = [[CBLManager sharedInstance] databaseNamed:dbName error:nil];
    if(db){
      CBLDocument* doc = [db documentWithID: documentId];
      CBLRevision* revision = doc.currentRevision;
      CBLAttachment* att = [revision attachmentNamed: attachmentId];
      if(att){
        NSString *imageString = [[NSString alloc] initWithData:att.content  encoding:NSUTF8StringEncoding];
        callback(@[imageString]);
      }
    }
  });
}

+(NSData*)getAttachmentInDB:(NSString *)dbName doumnetId:(NSString *)documentId attachmentId:(NSString *)attachmentId {
  CBLDatabase* db = [[CBLManager sharedInstance] databaseNamed:dbName error:nil];
  if(db){
    CBLDocument* doc = [db documentWithID: documentId];
    CBLRevision* revision = doc.currentRevision;
    CBLAttachment* att = [revision attachmentNamed: attachmentId];
    if(att){
      return att.content;
    }
  }
  
  return nil;
}

RCT_EXPORT_METHOD(showToast:(NSString*)toast){
  dispatch_sync(dispatch_get_main_queue(), ^{
    AppDelegate* delete = [UIApplication sharedApplication].delegate;
    [delete.window makeToast:toast];
  });
}


@end






