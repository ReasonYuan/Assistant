//
//  AlertTextInput.h
//  Practice
//
//  Created by 廖敏 on 15/10/29.
//  Copyright © 2015年 Facebook. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RCTBridgeModule.h"


@interface AlertTextInput : NSObject<RCTBridgeModule>

@end
