//
//  Attachment.h
//  ct1
//
//  Created by 廖敏 on 15/10/27.
//  Copyright © 2015年 Facebook. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RCTBridgeModule.h"

@interface CouchbaseHelper : NSObject <RCTBridgeModule>

+(NSData*)getAttachmentInDB:(NSString*)db doumnetId:(NSString*)documentId attachmentId:(NSString*)attachmentId ;


@end
