//
//  RatingBarViewManager.m
//  Care
//
//  Created by 廖敏 on 15/12/5.
//  Copyright © 2015年 Facebook. All rights reserved.
//

#import "RatingBarViewManager.h"
#import "RatingBar.h"

@interface RatingBarViewManager() <RatingDelegate>
{
//  RatingBar* _bar;
//  RCTResponseSenderBlock callback;
  NSInteger _rating;
}
@end

@implementation RatingBarViewManager

RCT_EXPORT_MODULE()


- (UIView *)view
{
//  if(!_bar){
   RatingBar* _bar = [[RatingBar alloc] initWithFrame:CGRectMake(0, 0,300,60)];
    _bar.delegate = self;
//  }
  _rating = 0;
  _bar.starNumber = _rating;
  return _bar;
}


RCT_EXPORT_METHOD(getRating:(RCTResponseSenderBlock)callBack){
  callBack(@[[NSNumber numberWithInteger:_rating]]);
}

-(void) setRating:(NSInteger)rating isHuman:(BOOL) isHuman
{
  _rating = rating;
}

RCT_CUSTOM_VIEW_PROPERTY(size, NSArray, RatingBar)
{
  NSDictionary* params  = json;
  if(params[@"width"] && params[@"height"]){
    NSNumber* widthN = params[@"width"];
    NSInteger width = [widthN integerValue];
    NSNumber* heightN = params[@"height"];
    NSInteger height = [heightN integerValue];
    [view setFrame:CGRectMake(0, 0, width, height)];
  }
}

@end
