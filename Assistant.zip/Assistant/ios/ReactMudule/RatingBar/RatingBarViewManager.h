//
//  RatingBarViewManager.h
//  Care
//
//  Created by 廖敏 on 15/12/5.
//  Copyright © 2015年 Facebook. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "RCTViewManager.h"

@interface RatingBarViewManager : RCTViewManager


@end
