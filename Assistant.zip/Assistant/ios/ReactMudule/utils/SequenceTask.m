//
//  SequenceTask.m
//  Practice
//
//  Created by 廖敏 on 15/11/20.
//  Copyright © 2015年 Facebook. All rights reserved.
//

#import "SequenceTask.h"

static DownloadImageSequenceTask* dist = nil;
static UploadImageSequenceTask* uist = nil;

@implementation SequenceTask{
  NSMutableArray* tasks;
  BOOL isRunning;
}

+(DownloadImageSequenceTask*)getDownloadImageSequenceTask
{
  if(!dist){
    dist = [[DownloadImageSequenceTask alloc] init];
  }
  return dist;
}

+(UploadImageSequenceTask*)getUploadImageSequenceTask
{
  if(!uist){
    uist = [[UploadImageSequenceTask alloc] init];
  }
  return uist;

}


-(instancetype)init
{
  self = [super init];
  if (self) {
    tasks = [[NSMutableArray alloc] init];
    isRunning = NO;
  }
  return self;
}

-(void)taskComplete:(Task *)task error:(NSError *)error
{
  dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
    @try {
      NSInteger index = [tasks indexOfObject:task];
      if(error){ //有错误，task任务未完成
        index++;
      }
      [tasks removeObject:task];
      if((tasks.count <= 0) || (tasks.count <= index)){ //全部完成
        isRunning = NO;
      }else{
        Task* next = [tasks objectAtIndex:index];
        next.sequenceTask = self;
        [next run];
      }
    }
    @catch (NSException *exception) {
      NSLog(@"%@,  %lu",exception,(unsigned long)tasks.count);
    }
    @finally {
      
    }
  });
}

-(void)addTask:(Task *)task
{
  if(task && ![tasks containsObject:task]){
    [tasks addObject:task];
  };
  [self resume];
}

-(void)cleanTask
{
  [tasks removeAllObjects];
}

-(void)stop
{
  isRunning = NO;
}

-(void)resume
{
  if(isRunning)return;
  isRunning = YES;
  if([tasks count] == 0){
    isRunning = NO;
    return;
  }
  dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
      Task* next = [tasks objectAtIndex:0];
      next.sequenceTask = self;
      [next run];
  });

}


-(NSInteger)taskCount
{
  return tasks.count;
}

@end



@implementation DownloadImageSequenceTask

-(void)addDownloadTaskUserId:(NSString *)userId ObjectKey:(NSString *)key expectWidth:(NSInteger)width
{
  DownloadImageTask* task = [[DownloadImageTask alloc] initWidthUserId:userId ObjectKey:key expectWidth:width];
  [self addTask:task];
}

@end



@implementation UploadImageSequenceTask

-(void)addUploadTaskUserId:(NSString *)userId ObjectKey:(NSString *)key
{
  UploadImageTask* uploadTask = [[UploadImageTask alloc] initWidthUserId:userId ObjectKey:key];
  [self addTask:uploadTask];
}


@end