//
//  Task.m
//  Practice
//
//  Created by 廖敏 on 15/11/20.
//  Copyright © 2015年 Facebook. All rights reserved.
//

#import "Task.h"
#import <AliyunOSSiOS/OSSService.h>
#import "AFNetworking.h"
#import "ImageHelper.h"
#import "SequenceTask.h"
#import "ImageHelper.h"

@implementation Task
@synthesize delegate;

-(BOOL)isEqual:(Task *)other
{
  @throw [NSException exceptionWithName:NSInternalInconsistencyException
                                 reason:[NSString stringWithFormat:@"You must override %@ in a subclass", NSStringFromSelector(_cmd)]
                               userInfo:nil];
  return NO;
}

-(void)run{
  @throw [NSException exceptionWithName:NSInternalInconsistencyException
                                 reason:[NSString stringWithFormat:@"You must override %@ in a subclass", NSStringFromSelector(_cmd)]
                               userInfo:nil];
}

@end


@implementation DownloadImageTask
@synthesize dir,objectKey,fullPath;

-(instancetype)initWidthUrl:(NSString *)objectKey1 downloadDir:(NSString *)dir1 expectWidth:(NSInteger)width
{
  self = [super init];
  if(self){
    self.dir = dir1;
    self.objectKey = objectKey1;
    self.fullPath = [NSString stringWithFormat:@"%@/%@",dir1,objectKey1];
    self.expectWidth = width;
  }
  return self;
}

-(BOOL)checkFile:(NSString*)key ExistsinSearchPath:(NSArray*)searchPaths DocumentsDirectory:(NSString*)docdir UserId:(NSString*)userId
{
  NSFileManager *fileManager = [NSFileManager defaultManager];
  NSInteger index = 0;
  while (index < searchPaths.count) {
    NSString* path = [NSString stringWithFormat:@"%@/%@/%@",userId,[searchPaths objectAtIndex:index],key];
    NSString* fileFullPath = [NSString stringWithFormat:@"%@/%@",docdir,path];
    if([fileManager fileExistsAtPath:fileFullPath]){
      return true;
    }
    index++;
  }
  return false;
}

-(instancetype)initWidthUserId:(NSString *)userId ObjectKey:(NSString *)key expectWidth:(NSInteger)width
{
  self = [super init];
  if(self){
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    if(width == 0){ //原图
      if([self checkFile:key ExistsinSearchPath:@[DIR_UDLOAD_IMAGE,DIR_IMAGE] DocumentsDirectory:documentsDirectory UserId:userId]){
        return nil;
      }
      self.dir = [NSString stringWithFormat:@"%@/%@/%@",documentsDirectory,userId,DIR_IMAGE];
    }else{
      if([self checkFile:key ExistsinSearchPath:@[DIR_UDLOAD_IMAGE,DIR_IMAGE,DIR_THUMBNAIL_IMAGE] DocumentsDirectory:documentsDirectory UserId:userId]){
        return nil;
      }
      self.dir = [NSString stringWithFormat:@"%@/%@/%@",documentsDirectory,userId,DIR_THUMBNAIL_IMAGE];
    }
    
    
    self.objectKey = key;
    self.fullPath = [NSString stringWithFormat:@"%@/%@",self.dir,self.objectKey];
    self.expectWidth = width;
  }
  return self;
  
}

-(BOOL)isEqual:(id)object
{
  if([object isKindOfClass:[DownloadImageTask class]]){
    DownloadImageTask* o = object;
    return [o.fullPath isEqualToString:self.fullPath];
  }
  return NO;
}

-(void)run
{
  NSFileManager* fileManager = [NSFileManager defaultManager];
  if([fileManager fileExistsAtPath:self.fullPath]){
    if(self.delegate)[self.delegate taskComplete:self error:nil];
    if(self.sequenceTask)[self.sequenceTask taskComplete:self error:nil];
    return;
  };
  NSURLSessionConfiguration *configuration = [NSURLSessionConfiguration defaultSessionConfiguration];
  AFURLSessionManager *manager = [[AFURLSessionManager alloc] initWithSessionConfiguration:configuration];
  NSURL *URL = nil;
  if(self.expectWidth != 0){
    URL = [NSURL URLWithString:[NSString stringWithFormat:@"%@/%@@%ldw_1l",DOWNLOAD_ENDPOINT,self.objectKey,(long)self.expectWidth]];
  }else{
    URL = [NSURL URLWithString:[NSString stringWithFormat:@"%@/%@",DOWNLOAD_ENDPOINT,self.objectKey]];
  }
  NSURLRequest *request = [NSURLRequest requestWithURL:URL];
  NSURLSessionDownloadTask *downloadTask = [manager downloadTaskWithRequest:request progress:nil destination:^NSURL *(NSURL *targetPath, NSURLResponse *response) {
    [fileManager checkFileDir:self.fullPath];
    return [[NSURL alloc] initFileURLWithPath:self.fullPath];
  } completionHandler:^(NSURLResponse *response, NSURL *filePath, NSError *error) {
    if(self.delegate)[self.delegate taskComplete:self error:error];
    if(self.sequenceTask)[self.sequenceTask taskComplete:self error:error];
  }];
  [downloadTask resume];
  
}

@end


@implementation UploadImageTask
@synthesize localPath,objectKey;

-(instancetype)initWidthUserId:(NSString *)userId ObjectKey:(NSString *)key
{
  self = [super init];
  if(self){
    self.objectKey = key;
    NSFileManager* fileManager = [NSFileManager defaultManager];
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentDir = [paths objectAtIndex:0];
    NSArray* imageSearchPaths = @[DIR_UDLOAD_IMAGE,DIR_IMAGE,DIR_THUMBNAIL_IMAGE];
    NSInteger index = 0;
    while (index < imageSearchPaths.count) {
      NSString* path = [NSString stringWithFormat:@"%@/%@/%@",userId,[imageSearchPaths objectAtIndex:index],key];
      NSString* fullPath = [NSString stringWithFormat:@"%@/%@",documentDir,path];
      if([fileManager fileExistsAtPath:fullPath]){
        self.localPath = fullPath;
        break;
      }
      
      index++;
    }
    if(!self.localPath)return nil;
  }
  return self;
}


-(BOOL)isEqual:(id)object
{
  if([object isKindOfClass:[UploadImageTask class]]){
    UploadImageTask* o = object;
    return [o.localPath isEqualToString:self.localPath];
  }
  return NO;
}


-(void)run
{
  NSFileManager* fileManager = [NSFileManager defaultManager];
  if(![fileManager fileExistsAtPath:self.localPath] || !self.objectKey){
    if(self.delegate)[self.delegate taskComplete:self error:nil];
    if(self.sequenceTask)[self.sequenceTask taskComplete:self error:nil];
    return;
  };
  id<OSSCredentialProvider> credential = [[OSSPlainTextAKSKPairCredentialProvider alloc] initWithPlainTextAccessKey:OSS_ACCESS_KEY secretKey:OSS_SECRET_KEY];
  OSSClient* client = [[OSSClient alloc] initWithEndpoint:OSS_UPLOAD_ENDPOINT credentialProvider:credential];
  OSSPutObjectRequest * put = [OSSPutObjectRequest new];
  put.contentType = @"image/*";
  put.bucketName =OSS_BUCKET_NAME;
  put.objectKey = self.objectKey;
  put.uploadingFileURL = [NSURL fileURLWithPath:self.localPath];
  put.uploadProgress = ^(int64_t bytesSent, int64_t totalByteSent, int64_t totalBytesExpectedToSend) {
    CGFloat progress = totalByteSent / (CGFloat)totalBytesExpectedToSend;
    [[NSNotificationCenter defaultCenter] postNotificationName:NOTI_UPLOAD_IMAGE_PROGRESS object:@{@"key":self.objectKey,@"progress":@(progress)}];
  };
  OSSTask * putTask = [client putObject:put];
  [putTask continueWithBlock:^id(OSSTask *task) {
    if(self.delegate)[self.delegate taskComplete:self error:task.error];
    if(self.sequenceTask)[self.sequenceTask taskComplete:self error:task.error];
    if(!task.error){
      [[NSNotificationCenter defaultCenter] postNotificationName:NOTI_UPLOAD_IMAGE_COMPLETE object:@{@"key":self.objectKey}];
    }
    return nil;
  }];
  
}

@end