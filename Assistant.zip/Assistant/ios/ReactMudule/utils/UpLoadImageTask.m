//
//  UpLoadImageTask.m
//  Practice
//
//  Created by 廖敏 on 16/1/5.
//  Copyright © 2016年 Facebook. All rights reserved.
//

#import "UpLoadImageTask.h"
#import "EDQueue.h"
#import <AliyunOSSiOS/OSSService.h>
#import "AFNetworking.h"
#import "ImageHelper.h"
#import "SequenceTask.h"
#import "Reachability.h"

@interface UpLoadImageTask() <EDQueueDelegate>

@end

@implementation UpLoadImageTask

+(void)load
{
  [UpLoadImageTask shareInstance];
}

-(instancetype)init{
  self = [super init];
  [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onNetworkStatusChange:) name:kReachabilityChangedNotification object:nil];
  return self;
}

-(void)onNetworkStatusChange:(NSNotification*)notif{
  Reachability* rea = notif.object;
  if([rea isReachable]){
    [UpLoadImageTask Start];
  }else{
    [UpLoadImageTask Stop];
  }
}

-(void)dealloc
{
  [[NSNotificationCenter defaultCenter] removeObserver:self];
}

+(UpLoadImageTask*)shareInstance
{
  static UpLoadImageTask *sharedInstance;
  static dispatch_once_t onceToken;
  dispatch_once(&onceToken, ^{
    sharedInstance = [[UpLoadImageTask alloc] init];
  });
  return sharedInstance;
}

+(void)Start
{
  [[EDQueue sharedInstance] setDelegate:[UpLoadImageTask shareInstance]];
  [EDQueue sharedInstance].retryLimit = 0x0FFFFFFF;
  [[EDQueue sharedInstance] start];
}

+(void)Stop
{
  [[EDQueue sharedInstance] stop];
}

-(NSNumber*)leftCount
{
  return [NSNumber numberWithInteger:[[EDQueue sharedInstance] size]];
}

- (void)queue:(EDQueue *)queue processJob:(NSDictionary *)job completion:(EDQueueCompletionBlock)block
{
  NSFileManager* fileManager = [NSFileManager defaultManager];
  NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
  NSString *documentDir = [paths objectAtIndex:0];
  NSArray* imageSearchPaths = @[DIR_UDLOAD_IMAGE,DIR_IMAGE,DIR_THUMBNAIL_IMAGE];
  NSString* userId = job[@"data"][@"userId"];
  NSString* key = job[@"data"][@"key"];
  NSInteger index = 0;
  NSString* localPath;
  while (index < imageSearchPaths.count) {
    NSString* path = [NSString stringWithFormat:@"%@/%@/%@",userId,[imageSearchPaths objectAtIndex:index],key];
    NSString* fullPath = [NSString stringWithFormat:@"%@/%@",documentDir,path];
    if([fileManager fileExistsAtPath:fullPath]){
      localPath = fullPath;
      break;
    }
    
    index++;
  }
  if(![fileManager fileExistsAtPath:localPath] || !key){
    block(EDQueueResultCritical);
    //    if(self.delegate)[self.delegate taskComplete:self error:nil];
    //    if(self.sequenceTask)[self.sequenceTask taskComplete:self error:nil];
    return;
  };
  id<OSSCredentialProvider> credential = [[OSSPlainTextAKSKPairCredentialProvider alloc] initWithPlainTextAccessKey:OSS_ACCESS_KEY secretKey:OSS_SECRET_KEY];
  OSSClient* client = [[OSSClient alloc] initWithEndpoint:OSS_UPLOAD_ENDPOINT credentialProvider:credential];
  OSSPutObjectRequest * put = [OSSPutObjectRequest new];
  put.contentType = @"image/*";
  put.bucketName =OSS_BUCKET_NAME;
  put.objectKey = key;
  put.uploadingFileURL = [NSURL fileURLWithPath:localPath];
  put.uploadProgress = ^(int64_t bytesSent, int64_t totalByteSent, int64_t totalBytesExpectedToSend) {
    CGFloat progress = totalByteSent / (CGFloat)totalBytesExpectedToSend;
    [[NSNotificationCenter defaultCenter] postNotificationName:NOTI_UPLOAD_IMAGE_PROGRESS object:@{@"key":key,@"progress":@(progress)}];
  };
  OSSTask * putTask = [client putObject:put];
  [putTask continueWithBlock:^id(OSSTask *task) {
    //    if(self.delegate)[self.delegate taskComplete:self error:task.error];
    //    if(self.sequenceTask)[self.sequenceTask taskComplete:self error:task.error];
    if(!task.error){
      block(EDQueueResultSuccess);
      [[NSNotificationCenter defaultCenter] postNotificationName:NOTI_UPLOAD_IMAGE_COMPLETE object:@{@"key":key}];
    }else {
      block(EDQueueResultFail);
    }
    return nil;
  }];
}

-(void)addUploadTaskUserId:(NSString *)userId ObjectKey:(NSString *)key
{
  NSString *taskName = [NSString stringWithFormat:@"%@_%@",userId,key];
  if(![[EDQueue sharedInstance] jobExistsForTask:taskName]){
    [[EDQueue sharedInstance] enqueueWithData:@{@"userId":userId,@"key":key} forTask:taskName];
  }
}

-(void)removeUploadTaskUserId:(NSString *)userId ObjectKey:(NSString *)key
{
  NSString *taskName = [NSString stringWithFormat:@"%@_%@",userId,key];
  [[EDQueue sharedInstance] removeTask:taskName];
}


@end
