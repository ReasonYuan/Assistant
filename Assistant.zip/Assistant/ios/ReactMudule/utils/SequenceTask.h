//
//  SequenceTask.h
//  Practice
//
//  Created by 廖敏 on 15/11/20.
//  Copyright © 2015年 Facebook. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Task.h"

@class DownloadImageSequenceTask;
@class UploadImageSequenceTask;

@interface SequenceTask : NSObject

+(DownloadImageSequenceTask*)getDownloadImageSequenceTask;

+(UploadImageSequenceTask*)getUploadImageSequenceTask;

//添加一个task
-(void)addTask:(Task*)task;

//-(void)stop;

-(void)resume;

-(void)cleanTask;

-(NSInteger)taskCount;

-(void)taskComplete:(Task *)task error:(NSError *)error;

@end


@interface DownloadImageSequenceTask : SequenceTask

/**
 *  添加一个下载任务
 *
 *  @param userId 用户id
 *  @param key    阿里云上的objectKey
 *  @param width  如果是缩略图则不为0
 */
-(void)addDownloadTaskUserId:(NSString *)userId ObjectKey:(NSString *)key expectWidth:(NSInteger)width;

@end


@interface UploadImageSequenceTask : SequenceTask

/**
 *  添加上传任务
 *
 *  @param userId 用户id
 *  @param key    阿里云上的objectKey
 */
-(void)addUploadTaskUserId:(NSString *)userId ObjectKey:(NSString *)key;

@end