//
//  Task.h
//  Practice
//
//  Created by 廖敏 on 15/11/20.
//  Copyright © 2015年 Facebook. All rights reserved.
//

#import <Foundation/Foundation.h>



#define DIR_UDLOAD_IMAGE                  @"uploadImages"
#define DIR_THUMBNAIL_IMAGE               @"thumbnailImages"
#define DIR_IMAGE                         @"Images"


#define NOTI_UPLOAD_IMAGE_PROGRESS        @"NOTIFICATION_UPLOAD_IMAGE_PROGRESS"  //上传图片进度通知
#define NOTI_UPLOAD_IMAGE_COMPLETE        @"NOTIFICATION_UPLOAD_IMAGE_COMPLETE"  //上传图片完成通知,失败不会发通知
#define NOTI_DOWNLOADLOAD_IMAGE_PROGRESS  @"NOTIFICATION_DOWNLOADLOAD_IMAGE_PROGRESS"  //上传图片进度通知
#define NOTI_DOWNLOAD_IMAGE_COMPLETE      @"NOTIFICATION_DOWNLOAD_IMAGE_PROGRESS"//下传图片进度通知
#define NOTI_UPLOAD_COUNT_CHANGE          @"NOTI_UPLOAD_COUNT_CHANGE"//上传图片数量有变化


@class Task;
@class SequenceTask;

@protocol TaskDelegate <NSObject>

-(void)taskComplete:(Task*)task error:(NSError*) error;

@end

//一个任务
@interface Task : NSObject

@property (nonatomic,weak) id<TaskDelegate> delegate;
@property (nonatomic,weak) SequenceTask* sequenceTask;
@property (nonatomic,assign) NSInteger tag;
-(void)run;

@end

//下载任务
@interface DownloadImageTask : Task

-(instancetype)initWidthUserId:(NSString*)userId ObjectKey:(NSString*)objectKey expectWidth:(NSInteger)width;

@property (nonatomic,strong) NSString* objectKey;
@property (nonatomic,strong) NSString* dir;
@property (nonatomic,strong) NSString* fullPath;
@property (nonatomic,assign) NSInteger expectWidth;

@end



@interface UploadImageTask : Task

-(instancetype)initWidthUserId:(NSString*)userId ObjectKey:(NSString*)objectKey;

@property (nonatomic,strong) NSString* localPath;
@property (nonatomic,strong) NSString* objectKey;

@end
