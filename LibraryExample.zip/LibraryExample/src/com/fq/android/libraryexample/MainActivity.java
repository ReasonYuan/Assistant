package com.fq.android.libraryexample;

import android.content.Intent;
import android.view.View;

public class MainActivity extends BaseActivity{


	@Override
	public int getContentId() {
		return R.layout.activity_main;
	}

	@Override
	public void init() {
		setLeftBtnShow(false);
		setTitleText("方趣");
	}
	
	/**
	 * Eclipse快捷方式
	 * @param view
	 */
	public void onShortcutClick(View view){
		startActivity(new Intent(this, EclipseShortcutActivity.class));
	}
	
	/**
	 * 公司代码规范
	 * @param view
	 */
	public void onCodeSpecificationClick(View view){
		startActivity(new Intent(this, CodeSpecificationActivity.class));
	}
	
	/**
	 * 快速开发工具类
	 * @param view
	 */
	public void onFastUtilsClick(View view){
		startActivity(new Intent(this, FastUtilsActivity.class));
	}
}
