package com.fq.android.libraryexample;

import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.widget.ListView;

import com.fq.android.dao.FastUtilsDao;
import com.fq.android.utils.AssetsUtil;
import com.fq.library.adapter.CommonAdapter;
import com.fq.library.adapter.ViewHolder;


public class FastUtilsActivity extends BaseActivity{

	private ListView mLvFastUtils;
	private CommonAdapter<FastUtilsDao> mAdapter;
	private ArrayList<FastUtilsDao> mDatas;
	
	@Override
	public int getContentId() {
		return R.layout.activity_fast_utils;
	}

	@Override
	public void init() {
		setTitleText("工具类");
		initWidgets();
		initDatas();
	}

	private void initWidgets() {
		mLvFastUtils = getView(R.id.lv_fast_utils_list);
		mLvFastUtils.setAdapter(mAdapter = new CommonAdapter<FastUtilsDao>(this,R.layout.item_eclipse_shortcut) {
			
			@Override
			public void convert(int position, ViewHolder helper, FastUtilsDao dao) {
				helper.setText(R.id.item_tv_shortcut_key, dao.getClassName());
				helper.setText(R.id.item_tv_shortcut_value, dao.getExplain());
			}
		}); 
	}

	private void initDatas() {
		String shortcuts = AssetsUtil.getFromAssets(this, "fastutils");
		mDatas = new ArrayList<FastUtilsDao>();
		try {
			JSONArray jsonArr= new JSONArray(shortcuts);
			for (int i = 0; i < jsonArr.length(); i++) {
				JSONObject jsonObj = jsonArr.optJSONObject(i);
				FastUtilsDao dao = new FastUtilsDao();
				dao.setClassName(jsonObj.optString("className"));
				dao.setExplain(jsonObj.optString("explain"));
				mDatas.add(dao);
			}
		} catch (JSONException e) {
			e.printStackTrace();
		}
		mAdapter.addDatas(mDatas);
	}

}
