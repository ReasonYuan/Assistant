package com.fq.android.libraryexample;

import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.widget.ListView;

import com.fq.android.dao.EclipseShortcutDao;
import com.fq.android.utils.AssetsUtil;
import com.fq.library.adapter.CommonAdapter;
import com.fq.library.adapter.ViewHolder;
/**
 * Eclipse快捷方式
 * @author niko
 */
public class EclipseShortcutActivity extends BaseActivity{

	private ListView mShortcutListView;
	private CommonAdapter<EclipseShortcutDao> mAdapter;
	private ArrayList<EclipseShortcutDao> mShortcutList;
	
	@Override
	public int getContentId() {
		return R.layout.activity_eclipse_shortcut;
	}

	@Override
	public void init() {
		initWidgets();
		initDatas();
	}
	
	private void initWidgets() {
		setTitleText("Eclipse快捷方式");
		mShortcutListView = (ListView) findViewById(R.id.lv_eclipse_shortcut_list);
		mShortcutListView.setAdapter(mAdapter = new CommonAdapter<EclipseShortcutDao>(this,R.layout.item_eclipse_shortcut) {
			
			@Override
			public void convert(int position, ViewHolder helper,EclipseShortcutDao shortcut) {
				helper.setText(R.id.item_tv_shortcut_key, shortcut.getShortcutKey());
				helper.setText(R.id.item_tv_shortcut_value, shortcut.getShortcutValue());
			}
		});
	}

	public void initDatas(){
		String shortcuts = AssetsUtil.getFromAssets(this, "eclipseshortcuts");
		mShortcutList = new ArrayList<EclipseShortcutDao>();
		try {
			JSONArray jsonArr= new JSONArray(shortcuts);
			for (int i = 0; i < jsonArr.length(); i++) {
				JSONObject jsonObj = jsonArr.optJSONObject(i);
				EclipseShortcutDao dao = new EclipseShortcutDao();
				dao.setShortcutKey(jsonObj.optString("shortcut_key"));
				dao.setShortcutValue(jsonObj.optString("shortcut_value"));
				mShortcutList.add(dao);
			}
		} catch (JSONException e) {
			e.printStackTrace();
		}
		mAdapter.addDatas(mShortcutList);
	}

}
