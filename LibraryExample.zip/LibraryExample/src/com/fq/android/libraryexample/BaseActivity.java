package com.fq.android.libraryexample;

import android.graphics.Color;

import com.fq.library.baseactivity.FQBaseActivity;

public abstract class BaseActivity extends FQBaseActivity{
	
	@Override
	public void setActivityStyle() {
		mTopbar.setBackgroundColor(0xDEDEDE);
		setTitleTextColor(Color.BLACK);
		setLeftBtnTextColor(Color.BLACK);
		setRightBtnTextColor(Color.BLACK);
		setBackground(getResources().getDrawable(R.drawable.home_main_bg));
	}
	
	@Override
	public abstract int getContentId();

	@Override
	public abstract void init();
}
