package com.fq.android.libraryexample;

import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.widget.ListView;

import com.fq.android.dao.CodeSpecificationDao;
import com.fq.android.utils.AssetsUtil;
import com.fq.library.adapter.CommonAdapter;
import com.fq.library.adapter.ViewHolder;

/**
 * 代码规范
 * @author niko
 *
 */
public class CodeSpecificationActivity extends BaseActivity{

	private ListView mLvSpecification;
	private CommonAdapter<CodeSpecificationDao> mAdapter;
	private ArrayList<CodeSpecificationDao> mDatas;
	
	@Override
	public int getContentId() {
		return R.layout.activity_code_specification;
	}

	@Override
	public void init() {
		initWidgets();
		initDatas();
	}

	private void initWidgets() {
		setTitleText("公司代码规范");
		mLvSpecification = getView(R.id.lv_code_specification_list);
		mLvSpecification.setAdapter(mAdapter = new CommonAdapter<CodeSpecificationDao>(this, R.layout.item_eclipse_shortcut) {
			
			@Override
			public void convert(int position, ViewHolder helper, CodeSpecificationDao dao) {
				helper.setText(R.id.item_tv_shortcut_key, dao.getTitle());
				helper.setText(R.id.item_tv_shortcut_value, dao.getSpecification());
			}
		});
	}

	private void initDatas() {
		String shortcuts = AssetsUtil.getFromAssets(this, "codespecification");
		mDatas = new ArrayList<CodeSpecificationDao>();
		try {
			JSONArray jsonArr= new JSONArray(shortcuts);
			for (int i = 0; i < jsonArr.length(); i++) {
				JSONObject jsonObj = jsonArr.optJSONObject(i);
				CodeSpecificationDao dao = new CodeSpecificationDao();
				dao.setTitle(jsonObj.optString("title"));
				dao.setSpecification(jsonObj.optString("specification"));
				mDatas.add(dao);
			}
		} catch (JSONException e) {
			e.printStackTrace();
		}
		mAdapter.addDatas(mDatas);
	}
}
