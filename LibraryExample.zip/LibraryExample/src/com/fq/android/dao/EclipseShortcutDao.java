package com.fq.android.dao;

public class EclipseShortcutDao {

	String shortcutKey;
	String shortcutValue;
	public String getShortcutKey() {
		return shortcutKey;
	}
	public void setShortcutKey(String shortcutKey) {
		this.shortcutKey = shortcutKey;
	}
	public String getShortcutValue() {
		return shortcutValue;
	}
	public void setShortcutValue(String shortcutValue) {
		this.shortcutValue = shortcutValue;
	}
}
