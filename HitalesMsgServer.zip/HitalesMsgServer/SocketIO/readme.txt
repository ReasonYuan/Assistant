1. 更新redisson到2.1.1后接口发生变化（1.7.7对应的Redisson是1.1.5）：
   In RedissonPubSubStore.java
//            @Override
//            public void onMessage(T msg) {
//                if (!nodeId.equals(msg.getNodeId())) {
//                    listener.onMessage(msg);
//                }
//            }

			@Override
			public void onMessage(String channel, T msg) {
              if (!nodeId.equals(msg.getNodeId())) {
	              listener.onMessage(msg);
	          }
			}
2. 为了支持集群群发消息的正确性，增加了函数SocketIOServer#getRoomClients
3. 在NamespaceClient.java里添加了OnFilterPacketListener，用于过滤服务器内部消息
4. 增加了构造函数
	public RedissonStoreFactory(Redisson redisClient, Redisson redisPub, Redisson redisSub, Class<RedissonPubSubStore> clazz)
