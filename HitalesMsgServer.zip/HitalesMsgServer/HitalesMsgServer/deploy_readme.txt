1. 把redis_6380.conf and redis_6379.conf放到/usr/local/etc/目录下
2. 分别运行：redis-server /usr/local/etc/redis_6380.conf 和 redis-server /usr/local/etc/redis_6379.conf
2. 运行服务器：
   java -jar {your path}/MsgServer.jar
   