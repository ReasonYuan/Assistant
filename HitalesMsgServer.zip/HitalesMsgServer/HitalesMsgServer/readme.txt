TODO list:				Server	SDK
1. 登陆验证		4		Ongoing	Ongoing
2. 用户管理		2 		DONE	DONE
3. 离线消息管理	1
	-- 单聊				DONE	DONE
	-- 群聊		
		-- 群组管理		DONE	DONE
		-- 群组消息		DONE	DONE	
4. 客户端SDK		3		DONE	DONE
5. 部署文档		5		
6. 用户基本信息	0		DONE	DONE		
7. 内存，数据管理	1.5		DONE	DONE
8. Hitales接口	1.6		DONE	N/A

==
1. 登陆信息
   这四个信息用于登陆消息服务器验证: Authorization, userid, Expires, uuid
   

Redis配置
1. 多实例配置(离线消息和即时消息用不同的Redis服务器集群): http://www.open-open.com/lib/view/open1404568322655.html
   本机配置见文件：redis-server /usr/local/etc/redis_6380.conf


客户端SDK
1. 初始化：另行实现
2. 登陆注销：实现hitales的统一验证
3. 实现IM文本消息通讯：基本参考IMSDK的接口规范
4. 用户信息：存放imageid和name
5. 自定义消息文本：按我们自己的要求实现
6. 最近联系人：按我们的要求实现
7. 个人聊天记录：参照IMSDK接口，用SDK的缓存，新的实现也保存失败（SDK作为二期功能）
8. 用户关系：
   a. 好友关系: 目前是从我们自己的服务器
   b. 群组关系：目前是从IM
9. 头像：保存imageID在IMSDK
10. 昵称：保存在IMSDK
11. 本地通知消息：未使用
12. 实现APNs远程推送: 目前用的我们自己的
13. 密码修改：不需要
14. 登陆历史：不需要
15. 群组功能：
	a. 群的创建、删除
	b. 添加成员、删除成员
	c. 修改群信息
	d. 群消息
	
==实际内存中所有id都加namespace
数据：
1. 用户信息：userid, head image id, username
2. 好友列表：[用户信息，.....]
3. 群信息：群名称，...
4. 群列表: [群信息，...]
5. 消息体: FROM, TO, BODY, Date...
6. 消息列表: [消息体...]
7. 离线消息: [{fromuserid,destuserid, ...}, ], 这里离线消息和历史消息分开保存，主要是为了效率，离线消息有数量和日期限制
8. 历史消息: [{fromuserid, destid(groupid/userid),g/s(单个或群), ...}]

SDK数据存储: (优先级低)
1. 用sqlite:https://github.com/stephencelis/SQLite.swift
2. 数据：
	a. 最近聊天记录列表
	b. 每条记录里的详细聊天内容
	   每条记录新建一张表

服务器内存数据
1. 用户信息：session id
2. 群信息：群id，由Hitales服务器生成
3. 消息id: 由消息服务器生成，规则：fromuserid_s/g(单个或群)_destid(userid/groupid)_timestamp(serverside)

==
jstatd的文件配置在java home bin 目录下，参考：
./jstatd -J-Djava.security.policy=jstatd.all.policy -J-Djava.rmi.server.hostname=218.244.150.28

	