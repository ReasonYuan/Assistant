package com.yiyihealth.msgserver.db;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.redisson.Redisson;

import com.corundumstudio.socketio.store.RedissonPubSubStore;
import com.corundumstudio.socketio.store.pubsub.PubSubListener;
import com.corundumstudio.socketio.store.pubsub.PubSubMessage;
import com.corundumstudio.socketio.store.pubsub.PubSubStore;
import com.yiyihealth.msgserver.Constants;

/**
 * 由于netty事件中调用redis造成不小的时间开销，影响了netty的快速响应，故而redis的操作准备放到非netty线程里去做<br/>
 * 为了衔接方便，做一个PubSubStore的代理
 * @author xiongchao
 * 
 */
public class RedissonPubSubStoreProxy implements PubSubStore {
	
	/**
	 * 核心消息的redis服务线程，6379端口
	 */
	private ExecutorService coreMsgRedisExcuteService = Executors.newFixedThreadPool(Constants.configure.getIntProperty("redis.threads.pubsub"));
	
	/**
	 * 实际被代理者
	 */
	private RedissonPubSubStore redissonPubSubStore;
	
	/**
	 * 即便构造函数，也和被代理者做成一样
	 * @param redissonPub
	 * @param redissonSub
	 * @param nodeId
	 */
	public RedissonPubSubStoreProxy(Redisson redissonPub, Redisson redissonSub, Long nodeId){
		redissonPubSubStore = new RedissonPubSubStore(redissonPub, redissonSub, nodeId);
	}

	@Override
	public void publish(final String name, final PubSubMessage msg) {
		coreMsgRedisExcuteService.execute(new Runnable() {
			public void run() {
				redissonPubSubStore.publish(name, msg);
			}
		});
	}

	@Override
	public <T extends PubSubMessage> void subscribe(final String name, final PubSubListener<T> listener, final Class<T> clazz) {
		coreMsgRedisExcuteService.execute(new Runnable() {
			public void run() {
				redissonPubSubStore.subscribe(name, listener, clazz);
			}
		});
	}

	@Override
	public void unsubscribe(final String name) {
		coreMsgRedisExcuteService.execute(new Runnable() {
			public void run() {
				redissonPubSubStore.unsubscribe(name);
			}
		});
	}

	@Override
	public void shutdown() {
		coreMsgRedisExcuteService.execute(new Runnable() {
			public void run() {
				redissonPubSubStore.shutdown();
			}
		});
	}

}
