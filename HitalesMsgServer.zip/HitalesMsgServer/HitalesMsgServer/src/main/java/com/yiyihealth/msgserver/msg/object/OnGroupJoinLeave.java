package com.yiyihealth.msgserver.msg.object;

import com.alibaba.fastjson.JSON;

/**
 * 仅用了GroupChat的部分属性
 * @author xiongchao
 *
 */
public class OnGroupJoinLeave extends GroupChatObject {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8146298007392084436L;

	private boolean isJoin;

	public boolean isJoin() {
		return isJoin;
	}

	public void setJoin(boolean isJoin) {
		this.isJoin = isJoin;
	}

	@Override
	public String toString() {
		return JSON.toJSONString(this);
	}
}
