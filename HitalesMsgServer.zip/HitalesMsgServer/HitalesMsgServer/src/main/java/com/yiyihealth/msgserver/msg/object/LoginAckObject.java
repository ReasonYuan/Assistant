package com.yiyihealth.msgserver.msg.object;

import java.io.Serializable;

public class LoginAckObject implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4160523450087226402L;
	
	private boolean success = false;
	
	private String userid = "";

	private String headIconImgId = "";
	
	private String errorMessage = "";
	
	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public boolean isSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getHeadIconImgId() {
		return headIconImgId;
	}

	public void setHeadIconImgId(String headIconImgId) {
		this.headIconImgId = headIconImgId;
	}


}
