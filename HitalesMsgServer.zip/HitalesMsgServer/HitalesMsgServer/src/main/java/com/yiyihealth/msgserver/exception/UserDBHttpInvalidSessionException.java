package com.yiyihealth.msgserver.exception;

public class UserDBHttpInvalidSessionException extends UserDBHttpException {

	public UserDBHttpInvalidSessionException(int errorCode, String detailMsg) {
		super(errorCode, detailMsg);
	}

	public UserDBHttpInvalidSessionException(String detailMsg) {
		super(detailMsg);
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 614560166781878688L;

}
