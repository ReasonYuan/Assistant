package com.yiyihealth.msgserver;

public class Constants {
	
	public static Configure configure = new Configure("config/himserver.properties");
	
	public static final String GROUP_MSG_INTER = "_g_";
	public static final String OFFLINE_REDIS_SERVER = Constants.configure.getStringProperty("redis.server.offlinemsg");
	
	public static final String SESSION_INFO_KEY = "sessionInfo";
	
	public static final String ENV_DEVELOPMENT = "development";
	public static final String ENV_TEST = "test";
	public static final String ENV_PRERELEASE = "prerelease";
	public static final String ENV_RELEASE = "release";
	public static final String ENV_APPSTORE = "appstore";
	
	public static final String[] ENVIRMENTS = {ENV_APPSTORE, ENV_DEVELOPMENT, ENV_TEST, ENV_PRERELEASE, ENV_RELEASE, };
	
	public static final String[] prefixs = {
			configure.getStringProperty("serverUrlAppstore"), //开发
			configure.getStringProperty("serverUrlDev"), //开发
			configure.getStringProperty("serverUrlTest"), //测试
			configure.getStringProperty("serverUrlPrerelease"), //预生产
			configure.getStringProperty("serverUrlRelease") //生产
	};
	public static final boolean[] requiredSession = {
			configure.getBooleanProperty("requiredSessionAppstore"),// false,//开发
			configure.getBooleanProperty("requiredSessionDev"),// false,//开发
			configure.getBooleanProperty("requiredSessionTest"),//false, //测试
			configure.getBooleanProperty("requiredSessionPrerelease"),//false, //预生产
			configure.getBooleanProperty("requiredSessionRelease"),//true //生产
	};
}
