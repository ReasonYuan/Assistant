package com.yiyihealth.msgserver.db;

import java.util.ArrayList;
import java.util.List;

import org.redisson.Config;
import org.redisson.Redisson;
import org.redisson.core.RMap;
import org.redisson.core.RSet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.yiyihealth.msgserver.Constants;
import com.yiyihealth.msgserver.exception.UserRDBException;
import com.yiyihealth.msgserver.helper.GroupHelper;
import com.yiyihealth.msgserver.msg.object.LoginObject;

import io.netty.util.internal.ConcurrentSet;

/**
 * 用户关系的redis cache，避免频繁访问底层服务器
 * @author xiongchao
 *
 */
public class RedisUserRelCacheDB implements UserRelationshipDB {
	
	private static final Logger log = LoggerFactory.getLogger(RedisUserRelCacheDB.class);
	
	private static final String RDB_PREFIX_GROUPS = "RDB_GROUPS_";
	private static final String RDB_PREFIX_MYGROUP_KEYS = "RDB_MYGROUPS_";
	
	private static RedisUserRelCacheDB _instance = new RedisUserRelCacheDB();
	
	public static RedisUserRelCacheDB getInstance() {
		return _instance;
	}
	
	private final Redisson redisson;
	
	private RedisUserRelCacheDB() {
		Config config = new org.redisson.Config();
		config.useSingleServer().setAddress(Constants.configure.getStringProperty("redis.server.coremsg")).setConnectionPoolSize(1024).setSubscriptionConnectionPoolSize(512);
		redisson = Redisson.create(config);
	}
	
	@Override
	public void createGroup(LoginObject session, String envirment, String userid, String groupName, String cgroupId, String... memberIds) throws UserRDBException {
		//new RuntimeException("create group...").printStackTrace();
		if (redisson.getMap(RDB_PREFIX_GROUPS + cgroupId).size() > 0) {
			//Group g = (Group) redisson.getMap(RDB_PREFIX_GROUPS + cgroupId).get("group");
			//log.error("the group exists is: " + JSON.toJSONString(g));
			//throw new UserRDBException(ErrorCodes.MSG_GROUP_EXISTS, ErrorCodes.getAckError(ErrorCodes.MSG_GROUP_EXISTS).getErrorMessage());
			//TODO 检查这个潜在的问题，可能是bug，可能存在流程上的重复创建group
			return;
		}
		Group g = new Group(userid, groupName, cgroupId, System.currentTimeMillis());
		ConcurrentSet<Member> members = new ConcurrentSet<Member>();
		//要添加的其他人
		for (String mid : memberIds) {
			Member m = new Member(mid);
			members.add(m);
		}
		//默认添加自己
		Member mSelf = new Member(userid);
		members.add(mSelf);
		GroupHelper.fillUserInfos(session, members, envirment, userid);
		g.setMembers(members);
		redisson.getMap(RDB_PREFIX_GROUPS + cgroupId).put("group", g);
		for (Member m : members) {
			redisson.getSet(RDB_PREFIX_MYGROUP_KEYS + m.getUserid()).add(RDB_PREFIX_GROUPS + cgroupId);
		}
	}

	@Override
	public void deleteGroup(LoginObject session, String envirment, String userid, String cgroupId) throws UserRDBException {
		Group g = (Group) redisson.getMap(RDB_PREFIX_GROUPS + cgroupId).get("group");
		redisson.getKeys().delete(RDB_PREFIX_GROUPS + cgroupId);
		if (g != null && g.getMembers() != null) {
			for (Member m : g.getMembers()) {
				//distributed set
				RSet<String> set = redisson.getSet(RDB_PREFIX_MYGROUP_KEYS + m.getUserid());
				set.remove(RDB_PREFIX_GROUPS + cgroupId);
			}
		}
	}

	@Override
	public void addMember(LoginObject session, String envirment, String userid, String cgroupId, String... memberIds) throws UserRDBException {
		if (memberIds.length <= 0) {
			throw new RuntimeException("memeberIds.lenth must > 0!");
		}
		Group g = (Group) redisson.getMap(RDB_PREFIX_GROUPS + cgroupId).get("group");
		if (g != null && g.getMembers() != null) {
			ConcurrentSet<Member> members = new ConcurrentSet<Member>();
			for (String mid : memberIds) {
				Member m = new Member(mid);
				members.add(m);
			}
			GroupHelper.fillUserInfos(session, members, envirment, userid);
			g.getMembers().addAll(members);
			for (Member m : g.getMembers()) {
				//distributed set
				RSet<String> set = redisson.getSet(RDB_PREFIX_MYGROUP_KEYS + m.getUserid());
				set.add(RDB_PREFIX_GROUPS + cgroupId);
			}
			g.setUpdateTime(System.currentTimeMillis());
			redisson.getMap(RDB_PREFIX_GROUPS + cgroupId).put("group", g);
		} else {
			throw new UserRDBException("群不存在!");
		}
	}

	@Override
	public void removeMember(LoginObject session, String envirment, String userid, String cgroupId, String... memberIds) throws UserRDBException {
		if (memberIds.length <= 0) {
			throw new RuntimeException("memeberIds.lenth must > 0!");
		}
		Group g = (Group) redisson.getMap(RDB_PREFIX_GROUPS + cgroupId).get("group");
		if (g != null && g.getMembers() != null) {
			for (String mid : memberIds) {
				g.getMembers().remove(new Member(mid));
				redisson.getSet(RDB_PREFIX_MYGROUP_KEYS + mid).remove(RDB_PREFIX_GROUPS + cgroupId);
			}
			g.setUpdateTime(System.currentTimeMillis());
			redisson.getMap(RDB_PREFIX_GROUPS + cgroupId).put("group", g);
		} else {
			throw new UserRDBException("群不存在!");
		}
	}

	@Override
	public List<Member> listMembers(LoginObject session, String envirment, String userid, String cgroupdId) throws UserRDBException {
		Group g = (Group) redisson.getMap(RDB_PREFIX_GROUPS + cgroupdId).get("group");
		if (g != null && g.getMembers() != null) {
			return new ArrayList<Member>(g.getMembers());
		} else {
			throw new UserRDBException("群不存在!");
		}
	}
	
	@Override
	public List<Group> listGroups(LoginObject session, String envirment, String userid) throws UserRDBException {
		RSet<String> keysSet = redisson.getSet(RDB_PREFIX_MYGROUP_KEYS + userid);
		ArrayList<Group> gs = new ArrayList<Group>();
		for(String key : keysSet){
			Group g = (Group) redisson.getMap(key).get("group");
			if(g == null){
				//老数据有一定错误，再测
				redisson.getKeys().delete(key);
			} else {
				gs.add(g);
			}
		}
		return gs;
	}

	@Override
	public void quitGroup(LoginObject session, String envirment, String userid, String useridToQuit, String cgroupId) throws UserRDBException {
		removeMember(session, envirment, userid, cgroupId, useridToQuit);	
	}

	@Override
	public Group findGroup(LoginObject session, String envirment, String userid, String cgroupId) throws UserRDBException {
		Group g = (Group) redisson.getMap(RDB_PREFIX_GROUPS + cgroupId).get("group");
		if (g == null) {
			throw new UserRDBException("群" + cgroupId + "不存在!");
		}
		return g;
	}

	@Override
	public void modifyGroupName(LoginObject session, String envirment, String userid, String cgroupId, String groupName)
			throws UserRDBException {
		RMap<Object, Object> rmp = redisson.getMap(RDB_PREFIX_GROUPS + cgroupId);
		Group g = (Group) rmp.get("group");
		if (g == null) {
			throw new UserRDBException("群" + cgroupId + "不存在!");
		}
		g.setGroupName(groupName);
		rmp.put("group", g);
	}

}
