package com.yiyihealth.msgserver.exception;

public class UserDBHttpException extends UserRDBException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 226419454470085618L;

	public UserDBHttpException(String detailMsg) {
		super(detailMsg);
	}
	
	public UserDBHttpException(int errorCode, String detailMsg) {
		super(errorCode, detailMsg);
	}
	
}
