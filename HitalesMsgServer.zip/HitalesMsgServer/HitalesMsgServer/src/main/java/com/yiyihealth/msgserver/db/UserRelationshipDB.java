package com.yiyihealth.msgserver.db;

import java.util.List;

import com.yiyihealth.msgserver.exception.UserRDBException;
import com.yiyihealth.msgserver.msg.object.LoginObject;

public interface UserRelationshipDB {

	/**
	 * 
	 * @param userid
	 * @param groupName
	 * @param cgroupId
	 * 		- optional, IMSDK参数，适配需要
	 */
	public void createGroup(LoginObject session, String envirment, String userid, String groupName, String cgroupId, String... memberIds) throws UserRDBException;
	
	/**
	 * 解散群组
	 * @param userid
	 * @param cgroupId
	 */
	public void deleteGroup(LoginObject session, String envirment, String userid, String cgroupId) throws UserRDBException;
	
	/**
	 * 退出群
	 * @param userid
	 * @param cgroupdId
	 * @throws UserRDBException
	 */
	public void quitGroup(LoginObject session, String envirment, String userid, String useridToQuit, String cgroupdId) throws UserRDBException;
	
	/**
	 * 添加成员到群
	 * @param userid
	 * 		- 添加动作发起人
	 * @param cgroupId
	 * @param useridToAdd
	 * 		- 被添加的人
	 * @return
	 * 		- success / failed
	 */
	public void addMember(LoginObject session, String envirment, String userid, String cgroupId, String... memberIds) throws UserRDBException;
	
	/**
	 * 移除群成员
	 * @param userid
	 * 		- 移除动作发起人
	 * @param cgroupId
	 * @param useridToAdd
	 * 		- 被移除的人
	 * @return
	 * 		- success / failed
	 */
	public void removeMember(LoginObject session, String envirment, String userid, String cgroupId, String... memberIds) throws UserRDBException;
	
	/**
	 * 查询某群下的所有成员
	 * @param userid
	 * @param cgroupId
	 * @return
	 */
	public List<Member> listMembers(LoginObject session, String envirment, String userid, String cgroupId) throws UserRDBException;
	
	/**
	 * 查询用户的所有群
	 * @param userid
	 * @return
	 */
	public List<Group> listGroups(LoginObject session, String envirment, String userid) throws UserRDBException;
	
	/**
	 * 查询指定的群
	 * @param userid
	 * @param cgroupId
	 * @return
	 */
	public Group findGroup(LoginObject session, String envirment, String userid, String cgroupId) throws UserRDBException;
	
	/**
	 * 查询指定的群
	 * @param userid
	 * @param cgroupId
	 * @param groupName
	 * @return
	 */
	public void modifyGroupName(LoginObject session, String envirment, String userid, String cgroupId, String groupName) throws UserRDBException;
	
}
