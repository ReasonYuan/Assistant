package com.yiyihealth.msgserver.helper;

import java.security.MessageDigest;

public class AeSimpleSHA1 {
	
	private static String convertToHex(byte[] data) {
		StringBuilder buf = new StringBuilder();
		for (byte b : data) {
			int halfbyte = (b >>> 4) & 0x0F;
			int two_halfs = 0;
			do {
				buf.append((0 <= halfbyte) && (halfbyte <= 9) ? (char) ('0' + halfbyte) : (char) ('a' + (halfbyte - 10)));
				halfbyte = b & 0x0F;
			} while (two_halfs++ < 1);
		}
		return buf.toString();
	}
	
	public static String SHA1(String text) {
		try {
			MessageDigest md = MessageDigest.getInstance("SHA-1");
			md.update(text.getBytes("iso-8859-1"), 0, text.length());
			byte[] sha1hash = md.digest();
			return convertToHex(sha1hash);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "";
	}
	
	public static String repeat20Times(String text){
		String str = "";
		for (int i = 0; i < 20; i++) {
			str = str + text;
		}
		return str;
	}
	
	/**
	 * 把明文重复20次再取sha1摘要
	 * @param text
	 * @return
	 */
	public static String repeat20TimesAndSHA1(String text){
		return SHA1(repeat20Times(text));
	}
}