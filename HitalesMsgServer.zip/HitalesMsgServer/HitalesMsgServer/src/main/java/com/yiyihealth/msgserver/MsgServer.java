package com.yiyihealth.msgserver;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

import org.apache.log4j.PropertyConfigurator;
import org.redisson.Config;
import org.redisson.Redisson;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.corundumstudio.socketio.AckRequest;
import com.corundumstudio.socketio.Configuration;
import com.corundumstudio.socketio.SocketConfig;
import com.corundumstudio.socketio.SocketIOClient;
import com.corundumstudio.socketio.SocketIOServer;
import com.corundumstudio.socketio.listener.ConnectListener;
import com.corundumstudio.socketio.listener.DataListener;
import com.corundumstudio.socketio.listener.DisconnectListener;
import com.corundumstudio.socketio.store.RedissonStoreFactory;
import com.yiyihealth.msgserver.db.Group;
import com.yiyihealth.msgserver.db.HitalesRedissonStoreFactory;
import com.yiyihealth.msgserver.db.HitalesUserRelationshipDB;
import com.yiyihealth.msgserver.db.Member;
import com.yiyihealth.msgserver.db.RedissonPubSubStoreProxy;
import com.yiyihealth.msgserver.db.UserRelationshipDB;
import com.yiyihealth.msgserver.exception.UserRDBException;
import com.yiyihealth.msgserver.msg.RedisBroadcastOperations;
import com.yiyihealth.msgserver.msg.error.ErrorCodes;
import com.yiyihealth.msgserver.msg.object.AddToGroupObject;
import com.yiyihealth.msgserver.msg.object.ChatObject;
import com.yiyihealth.msgserver.msg.object.CreateGroupObject;
import com.yiyihealth.msgserver.msg.object.DeleteGroupObject;
import com.yiyihealth.msgserver.msg.object.EventAckObject;
import com.yiyihealth.msgserver.msg.object.GroupBaseObject;
import com.yiyihealth.msgserver.msg.object.GroupChatObject;
import com.yiyihealth.msgserver.msg.object.LoginAckObject;
import com.yiyihealth.msgserver.msg.object.LoginObject;
import com.yiyihealth.msgserver.msg.object.ModifyGroupInfoObject;
import com.yiyihealth.msgserver.msg.object.OnGroupJoinLeave;
import com.yiyihealth.msgserver.msg.object.RemoveFromGroupObject;
import com.yiyihealth.msgserver.msg.object.RequestUpdateGroupInfo;
import com.yiyihealth.msgserver.msg.object.RequestUpdateGroupInfo.UpdateGroupItem;
import com.yiyihealth.msgserver.msg.object.SingleChatObject;
import com.yiyihealth.msgserver.msg.object.UpdateClientGroup;
import com.yiyihealth.msgserver.msg.object.UpdateClientGroup.UpdateCmd;
import com.yiyihealth.msgserver.offline.RedisOfflineMessageManager;
import com.yiyihealth.msgserver.offline.RedisOfflineMessageManager.OfflinePullCallbck;
import com.yiyihealth.msgserver.session.ReconnectSessionManager;
import com.yiyihealth.msgserver.user.OnlineDevicesManager;
import com.yiyihealth.msgserver.user.OnlineDevicesManager.OnCheckUserOnlineStatus;

import io.netty.util.internal.ConcurrentSet;

public class MsgServer {
	
	static {
		PropertyConfigurator.configure("config/log4j.properties");
	}
	
	private static final Logger log = LoggerFactory.getLogger(MsgServer.class);
	
	//所有的网络事件
	private static final String EVENT_MSG = "smsg";
	private static final String EVENT_GROUP_MSG = "gmsg";
	private static final String EVENT_LOGIN = "login";
	private static final String EVENT_CREATE_GROUP = "create_group";
	private static final String EVENT_DELETE_GROUP = "delete_group";
	private static final String EVENT_MODIFY_GROUP_NAME = "modify_group_name";
	private static final String EVENT_ADD_MEMBER_GROUP = "add_member_group";
	private static final String EVENT_REM_MEMBER_GROUP = "rem_member_group";
	public static final String EVENT_ON_JOIN_GROUP = "on_join_group";
	public static final String EVENT_ON_LEAVE_GROUP = "on_leave_group";
	public static final String EVENT_UPDATE_GROUP_INFO_REQUEST = "update_group_info";
	
	private static ConcurrentSet<UUID> allConnections = new ConcurrentSet<UUID>();
	
	public static void main(String[] args) throws InterruptedException {
		
        log.info("Starting hitales msg server...");
        
        Configuration config = new Configuration();
        config.setHostname(Constants.configure.getStringProperty("host")); //218.244.150.28 //TODO 这个需要提取成配置文件
        config.setPort(Constants.configure.getIntProperty("port"));
        config.setBossThreads(Constants.configure.getIntProperty("bossThreads"));
        config.setWorkerThreads(Constants.configure.getIntProperty("workerThreads"));
        SocketConfig socketConfig = new SocketConfig();
        socketConfig.setReuseAddress(Constants.configure.getBooleanProperty("so.reuseAddress"));
        socketConfig.setAcceptBackLog(Constants.configure.getIntProperty("so.backlog"));
        config.setSocketConfig(socketConfig);
        config.setUseLinuxNativeEpoll(Constants.configure.getBooleanProperty("useLinuxNativeEpoll"));
        final int maxConnections = Constants.configure.getIntProperty("maxconnections");
        
        //历史消息或者叫离线消息
        final RedisOfflineMessageManager offlineManager = RedisOfflineMessageManager.getInstance();
        
        Config redisConfig = new Config();
        redisConfig.useSingleServer().setAddress(Constants.configure.getStringProperty("redis.server.onlineregister")).setConnectionPoolSize(1024).setSubscriptionConnectionPoolSize(512);
        Redisson redisson = Redisson.create(redisConfig);
        final RedissonStoreFactory redissonStoreFactory = new HitalesRedissonStoreFactory(redisson, redisson, redisson, RedissonPubSubStoreProxy.class);
        config.setStoreFactory(redissonStoreFactory);
        
        final SocketIOServer server = new SocketIOServer(config);
        
        final UserRelationshipDB userRDB = HitalesUserRelationshipDB.getInstance();
        
        //final ExecutorService fixedThreadPool = Executors.newFixedThreadPool(128);
        
        server.addConnectListener(new ConnectListener(){

			@Override
			public void onConnect(SocketIOClient client) {
				//client.sendEvent("chatevent", new ChatObject("no name", "welcome... please login first!"));
				//client.joinRoom("room1");
				log.info("on connect..." + client.getSessionId());
			}
        	
        });
        
        server.addDisconnectListener(new DisconnectListener() {
			
			@Override
			public void onDisconnect(SocketIOClient client) {
				log.info("on disconnect..."+ client.getSessionId());
				LoginObject sessionInfo = client.get(Constants.SESSION_INFO_KEY);
            	if (sessionInfo != null) {
            		allConnections.remove(client.getSessionId());
            		OnlineDevicesManager.getInstance().leaveOnDeviceLogout(sessionInfo);
            	}
			}
		});
        
        server.addEventListener(EVENT_LOGIN, LoginObject.class, new DataListener<LoginObject>() {
            @Override
            public void onData(final SocketIOClient client, final LoginObject data, AckRequest ackRequest) {
                // broadcast messages to all clients
                //server.getBroadcastOperations().sendEvent("chatevent", data);
            	
            	log.info("on login..."+ data.getUserid() + ", " + data.getUuid());
            	
            	if (allConnections.size() >= maxConnections) {
            		//超过最大连接数
            		log.info("maxConnections reachs! max is " + maxConnections);
            		//发回响应数据, 失败信息
                    LoginAckObject loginAck = new LoginAckObject();
                    loginAck.setSuccess(false);
                    loginAck.setUserid(data.getUserid());
                    loginAck.setErrorMessage("超过服务器最大连接限制!");
                    ackRequest.sendAckData(loginAck);
					return;
				}

            	ReconnectSessionManager recManager = ReconnectSessionManager.getInstance();
                boolean isUserInfoLegal = false;
                if(recManager.isLogin(data)){
                	//已经登陆的用户，不用再验证合法性
                	isUserInfoLegal = true;
                } else {
                	//TODO 访问登陆服务器，如果成功登陆，保存登陆信息
                	isUserInfoLegal = true;
                	if (isUserInfoLegal) {
                		ReconnectSessionManager.getInstance().saveReconnectSession(data);
					}
                }
                
                if(isUserInfoLegal){
                	allConnections.add(client.getSessionId());
                	//保存会话
                	data.setLoginTime(System.currentTimeMillis());
                	client.set(Constants.SESSION_INFO_KEY, data);
                	//分布式信息保存，可单一用户多设备同时登陆
                	OnlineDevicesManager.getInstance().saveOnDeviceLogin(data);
                	
                	//TODO envirment, namespace
                	log.info("join room: " + data.getSessionKey());
                	client.joinRoom(data.getSessionKey());
                	
//                  fixedThreadPool.execute(new Runnable() {
//						@Override
//						public void run() {
//						}
//					});
                    
                    try {
                		//发回响应数据, 注意，取得群信息后再反馈说登陆成功
                		//如果把这一句话放到“注册我所有的群”之前，则SDK不能主动请求群信息，需由服务器推送
                        LoginAckObject loginAck = new LoginAckObject();
                        loginAck.setSuccess(true);
                        loginAck.setUserid(data.getUserid());
                        ackRequest.sendAckData(loginAck);

                        //注册我所有的群
                		List<Group> groups = userRDB.listGroups(data,data.getEnvirment(), data.getUserid());
                		for(Group g : groups){
                			client.joinRoom(GroupChatObject.getToChannelName(data.getEnvirment(), g.getCgroupId()));
                		}
                        
                        //检查是否有离线消息，有则立即发送给客户端
                        //1. 单聊
                        offlineManager.pullOfflineMessage(data.getUserid(), data.getSessionKey(), new OfflinePullCallbck() {
							@Override
							public void onOfflineMsgPullFinish(List<ChatObject> offMsgs) {
								if(offMsgs.size() > 0){
		                        	RedisBroadcastOperations redisBroadcast = null;
		                        	for(ChatObject co : offMsgs){
		                        		if(redisBroadcast == null){
		                        			redisBroadcast = new RedisBroadcastOperations(co.getToChannelName(), server.getRoomClients(co.getToChannelName()), redissonStoreFactory, null);
		                        		}
		                        		redisBroadcast.sendEvent(EVENT_MSG, co);
		                            }
		                        }
							}
						});
                        //2. 群聊
                        for(Group g : groups){
                        	offlineManager.pullOfflineMessage(data.getUserid(), GroupChatObject.getToChannelName(data.getEnvirment(), g.getCgroupId()), new OfflinePullCallbck() {
								@Override
								public void onOfflineMsgPullFinish(List<ChatObject> offMsgs) {
									if(offMsgs.size() > 0){
		                            	RedisBroadcastOperations redisBroadcast = null;
		                            	for(ChatObject co : offMsgs){
		                            		if(redisBroadcast == null){
		                            			//sessionKey和channelname一样
		                            			redisBroadcast = new RedisBroadcastOperations(data.getSessionKey(), server.getRoomClients(data.getSessionKey()), redissonStoreFactory, null);
		                            		}
		                            		redisBroadcast.sendEvent(EVENT_GROUP_MSG, co);
		                                }
		                            }
								}
							});
                		}
					} catch (Exception e) {
						log.error("处理登陆数据失败: " + data.toString(), e);
//						//发回响应数据
//                        LoginAckObject loginAck = new LoginAckObject();
//                        loginAck.setSuccess(false);
//                        loginAck.setUserid(data.getUserid());
//                        loginAck.setErrorMessage("处理登陆后的用户数据失败!");
//                        ackRequest.sendAckData(loginAck);
					}
                    
                } else {
                	//发回响应数据, 失败信息
                    LoginAckObject loginAck = new LoginAckObject();
                    loginAck.setSuccess(false);
                    loginAck.setUserid(data.getUserid());
                    //TODO with error code
                    loginAck.setErrorMessage("非法登陆，用户信息验证失败!");
                    ackRequest.sendAckData(loginAck);
                }
            }
        });
        
        //单聊
        server.addEventListener(EVENT_MSG, SingleChatObject.class, new DataListener<SingleChatObject>() {
            @Override
            public void onData(SocketIOClient client, SingleChatObject data, AckRequest ackRequest) {
            	log.info("on smsg..."+ data.getMessage() + ", " + data.getUserid() + ", toUserId: " + data.getToUser());
            	LoginObject sessionInfo = client.get(Constants.SESSION_INFO_KEY);
            	if (sessionInfo != null && sessionInfo.getUserid().equals(data.getUserid())) {
            		data.setEnvirment(sessionInfo.getEnvirment());
                	
                	//发送成功，反馈
                	EventAckObject mao = new EventAckObject();
        			mao.setSentTime((int)(System.currentTimeMillis()/1000));
        			mao.setSuccess(true);
        			ackRequest.sendAckData(mao);
        			//保存成离线消息
        			offlineManager.addMessage(data);
        			
        			if (data.getToUser() != null) {
            			Iterable<SocketIOClient> clients = server.getRoomClients(data.getToChannelName());
                		RedisBroadcastOperations redisBroadcast = new RedisBroadcastOperations(data.getToChannelName(), clients, redissonStoreFactory, null);
                		redisBroadcast.sendEvent(EVENT_MSG, data);
                		
                		boolean isToUserOnThisServer = false;
                		//这里设置下最后发送消息时间，本服务器内部在这里处理，跨服务器的分布式消息通知在HitalesRedissonStoreFactory的subscribe(PubSubStore.DISPATCH...处理
                		//上面EVENT_MSG也要处理
                		for (SocketIOClient c : clients) {
                			isToUserOnThisServer = true;
                    		LoginObject loginObject = c.get(Constants.SESSION_INFO_KEY);
                    		offlineManager.saveLastSentTime(loginObject.getUserid(), data.getToChannelName(), data.getCreateTime());
						}
                		if (!isToUserOnThisServer) {
							//如果在这台服务器上能够找到，则必定在线，否则查询redis目标用户是否在线
                			OnlineDevicesManager.getInstance().isAnyOneClientLogined(sessionInfo.getEnvirment(), data.getToUser(), new OnCheckUserOnlineStatus() {
								@Override
								public void onCheckUserOnlineStatusFinish(boolean isOnline) {
									if (!isOnline) {
										//不在这台机子上，需要查阅redis，如果也不再其他节点则需要发送推送通知
										
									}
								}
							});
						}
        			}
        			
        		} else {
        			//Not login yet....
        			//TODO handle error
        			
        			EventAckObject mao = new EventAckObject();
        			mao.setSentTime((int)(System.currentTimeMillis()/1000));
        			mao.setSuccess(false);
        			mao.setError(ErrorCodes.getAckError(ErrorCodes.MSG_NO_VALID_SESSION));
        			ackRequest.sendAckData(mao);
        		}
            }
        });
        
        //群聊
        server.addEventListener(EVENT_GROUP_MSG, GroupChatObject.class, new DataListener<GroupChatObject>() {
            @Override
            public void onData(SocketIOClient client, GroupChatObject data, AckRequest ackRequest) {
            	log.info("on gmsg..."+ data.getMessage() + ", " + data.getUserid() + ", toGroupId: " + data.getToGroupId());
            	LoginObject sessionInfo = client.get(Constants.SESSION_INFO_KEY);
            	if (sessionInfo != null && sessionInfo.getUserid().equals(data.getUserid())) {
            		data.setEnvirment(sessionInfo.getEnvirment());
                	
                	//发送成功，反馈
                	EventAckObject mao = new EventAckObject();
        			mao.setSentTime((int)(System.currentTimeMillis()/1000));
        			mao.setSuccess(true);
        			ackRequest.sendAckData(mao);
        			//保存成离线消息
        			offlineManager.addMessage(data);
        			
        			if (data.getToGroupId() != null) {
            			Iterable<SocketIOClient> clients = server.getRoomClients(data.getToChannelName());
                		RedisBroadcastOperations redisBroadcast = new RedisBroadcastOperations(data.getToChannelName(), clients, redissonStoreFactory, client);
                		redisBroadcast.sendEvent(EVENT_GROUP_MSG, data);
                		
                		HashMap<String, Boolean> membersOnThisServer = new HashMap<String, Boolean>();
                		HashSet<String> mOnThisServer = new HashSet<String>();
                		//这里设置下最后发送消息时间，本服务器内部在这里处理，跨服务器的分布式消息通知在HitalesRedissonStoreFactory的subscribe(PubSubStore.DISPATCH...处理
                		//上面EVENT_MSG也要处理
                		for (SocketIOClient c : clients) {
                    		LoginObject loginObject = c.get(Constants.SESSION_INFO_KEY);
                    		offlineManager.saveLastSentTime(loginObject.getUserid(), data.getToChannelName(), data.getCreateTime());
                    		mOnThisServer.add(loginObject.getUserid());
						}
                		
                		//检查哪些需要推送
                		try {
							Group g = userRDB.findGroup(sessionInfo, sessionInfo.getEnvirment(), sessionInfo.getUserid(), data.getToGroupId());
							for (Member m : g.getMembers()) {
								if (!membersOnThisServer.containsKey(m.getUserid())) {
									//不在这台机子上，需要查阅redis，如果也不再其他节点则需要发送推送通知
									
								}
							}
						} catch (UserRDBException e) {
							log.error("", e);
						}
        			}
        			
        		} else {
        			//Not login yet....
        			//TODO handle error
        			
        			EventAckObject mao = new EventAckObject();
        			mao.setSentTime((int)(System.currentTimeMillis()/1000));
        			mao.setSuccess(false);
        			mao.setError(ErrorCodes.getAckError(ErrorCodes.MSG_NO_VALID_SESSION));
        			ackRequest.sendAckData(mao);
        		}
            }
        });
        
        server.addEventListener(EVENT_CREATE_GROUP, CreateGroupObject.class, new DataListener<CreateGroupObject>() {
            @Override
            public void onData(SocketIOClient client, CreateGroupObject data, AckRequest ackRequest) {
            	LoginObject sessionInfo = client.get(Constants.SESSION_INFO_KEY);
            	if (sessionInfo != null && sessionInfo.getUserid().equals(data.getUserid())) {
            		try {
            			//cgroupId的组合形式，代替以前IMSDK的groupid
            			String cgroupId = sessionInfo.getEnvirment() + data.getUserid() + "_" + UUID.randomUUID().toString().replace("-", "");
            			//默认把自己添加到群里
            			userRDB.createGroup(sessionInfo, sessionInfo.getEnvirment(), data.getUserid(), data.getName(), cgroupId, data.getMembersId());
            			//创建成功
            			EventAckObject ack = new EventAckObject();
						ack.setSentTime((int)(System.currentTimeMillis()/1000));
						ack.setSuccess(true);
						ack.setResult(cgroupId);
						ackRequest.sendAckData(ack);
						
						//注册监听group消息，TODO 也许应该在添加成员时注册
						client.joinRoom(cgroupId);
						//如果创建是没有加入自己，则需要加入自己
						boolean isSelfInList = false;
						String[] oldMids = data.getMembersId();
						for (int i = 0; i < oldMids.length; i++) {
							if (oldMids[i].equals(data.getUserid())) {
								isSelfInList = true;
								break;
							}
						}
						if (!isSelfInList) {
							String[] allIds = new String[oldMids.length + 1];
							System.arraycopy(oldMids, 0, allIds, 0, oldMids.length);
							allIds[allIds.length - 1] = data.getUserid();
							data.setMembersId(allIds);
						}
						//加入自己完成
						notifyMembersRegister(server, redissonStoreFactory, data, cgroupId, sessionInfo);
						
						//通知所有相关人，在客户端sdk上创建这个组信息
						Group groupInfo = userRDB.findGroup(sessionInfo, sessionInfo.getEnvirment(), sessionInfo.getUserid(), cgroupId);
						notifyMembersUpdateGroupInfo(server, redissonStoreFactory, groupInfo, sessionInfo, UpdateClientGroup.UpdateCmd.ADD_GROUP);
						
					} catch (UserRDBException e) {
						log.error("failed to create group: " + data.toString(), e);
						//创建失败
						EventAckObject ack = new EventAckObject();
						ack.setSentTime((int)(System.currentTimeMillis()/1000));
						ack.setSuccess(false);
						ack.setError(ErrorCodes.getAckError(ErrorCodes.MSG_GROUP_HITALES_DB_ERROR).cloneAndAppendError(e.getMessage()));
						ackRequest.sendAckData(ack);
					}
				} else {
					//Not login yet....or userid is different from login userid
					//TODO 细化error信息
					//TODO handle error
					sendNoSessionAck(ackRequest);
				}
            }
        });
        
        server.addEventListener(EVENT_DELETE_GROUP, DeleteGroupObject.class, new DataListener<DeleteGroupObject>() {
            @Override
            public void onData(SocketIOClient client, DeleteGroupObject data, AckRequest ackRequest) {
            	LoginObject sessionInfo = client.get(Constants.SESSION_INFO_KEY);
            	if (sessionInfo != null && sessionInfo.getUserid().equals(data.getUserid())) {
            		try {
            			String cgroupId = data.getGroupID();
            			Group group = userRDB.findGroup(sessionInfo, sessionInfo.getEnvirment(), data.getUserid(), cgroupId);	
            			List<Member> members = new ArrayList<Member>(group.getMembers());
            			userRDB.deleteGroup(sessionInfo, sessionInfo.getEnvirment(), data.getUserid(), cgroupId);
            			
            			//反注册所有群成员
            			notifyMembersUnregister(server, redissonStoreFactory, members, data, cgroupId, sessionInfo);
            			
            			//删除成功
            			EventAckObject ack = new EventAckObject();
						ack.setSentTime((int)(System.currentTimeMillis()/1000));
						ack.setSuccess(true);
						ackRequest.sendAckData(ack);
						
						//通知所有相关人，在客户端sdk上删除这个组信息
						notifyMembersUpdateGroupInfo(server, redissonStoreFactory, group, sessionInfo, UpdateClientGroup.UpdateCmd.DELETE_GROUP);
						
					} catch (UserRDBException e) {
						log.error("failed to del group: " + data.toString(), e);
						//删除失败
						EventAckObject ack = new EventAckObject();
						ack.setSentTime((int)(System.currentTimeMillis()/1000));
						ack.setSuccess(false);
						ack.setError(ErrorCodes.getAckError(ErrorCodes.MSG_GROUP_HITALES_DB_ERROR).cloneAndAppendError(e.getMessage()));
						ackRequest.sendAckData(ack);
					}
				} else {
					//Not login yet....or userid is different from login userid
					//TODO 细化error信息
					//TODO handle error
					sendNoSessionAck(ackRequest);
				}
            }
        });
        
        server.addEventListener(EVENT_ADD_MEMBER_GROUP, AddToGroupObject.class, new DataListener<AddToGroupObject>() {
            @Override
            public void onData(SocketIOClient client, AddToGroupObject data, AckRequest ackRequest) {
            	LoginObject sessionInfo = client.get(Constants.SESSION_INFO_KEY);
            	if (sessionInfo != null && sessionInfo.getUserid().equals(data.getUserid())) {
            		try {
            			String cgroupId = data.getGroupID();
            			userRDB.addMember(sessionInfo, sessionInfo.getEnvirment(), data.getUserid(), cgroupId, data.getMembersId());
            			//添加成功
            			EventAckObject ack = new EventAckObject();
						ack.setSentTime((int)(System.currentTimeMillis()/1000));
						ack.setSuccess(true);
						ackRequest.sendAckData(ack);
						//通知相关组员的client注册监听
						notifyMembersRegister(server, redissonStoreFactory, data, cgroupId, sessionInfo);
						
						//通知所有相关人，在客户端sdk上创建这个组信息
						Group groupInfo = userRDB.findGroup(sessionInfo, sessionInfo.getEnvirment(), sessionInfo.getUserid(), cgroupId);
						notifyMembersUpdateGroupInfo(server, redissonStoreFactory, groupInfo, sessionInfo, UpdateClientGroup.UpdateCmd.UPDATE_GROUP);
						
					} catch (UserRDBException e) {
						log.error("failed to add members: " + data.toString(), e);
						//添加失败
						EventAckObject ack = new EventAckObject();
						ack.setSentTime((int)(System.currentTimeMillis()/1000));
						ack.setSuccess(false);
						ack.setError(ErrorCodes.getAckError(ErrorCodes.MSG_GROUP_HITALES_DB_ERROR).cloneAndAppendError(e.getMessage()));
						ackRequest.sendAckData(ack);
						e.printStackTrace();
					}
				} else {
					//Not login yet....or userid is different from login userid
					//TODO 细化error信息
					//TODO handle error
					sendNoSessionAck(ackRequest);
				}
            }
        });
        
        server.addEventListener(EVENT_REM_MEMBER_GROUP, RemoveFromGroupObject.class, new DataListener<RemoveFromGroupObject>() {
            @Override
            public void onData(SocketIOClient client, RemoveFromGroupObject data, AckRequest ackRequest) {
            	LoginObject sessionInfo = client.get(Constants.SESSION_INFO_KEY);
            	if (sessionInfo != null && sessionInfo.getUserid().equals(data.getUserid())) {
            		try {
            			String cgroupId = data.getGroupID();
            			userRDB.removeMember(sessionInfo, sessionInfo.getEnvirment(), data.getUserid(), cgroupId, data.getMembersId());
            			
            			//反注册要移除群的id
            			List<Member> members = new ArrayList<Member>();
            			String[] mIds = data.getMembersId();
            			for (int i = 0; i < mIds.length; i++) {
							Member m = new Member(mIds[i]);
							members.add(m);
						}
            			notifyMembersUnregister(server, redissonStoreFactory, members, data, cgroupId, sessionInfo);
            			//TODO 如果群里没有人了，删除该群
            			//上面TODO功能暂不实现，先靠用户自己删除
            			
            			//移除成功
            			EventAckObject ack = new EventAckObject();
						ack.setSentTime((int)(System.currentTimeMillis()/1000));
						ack.setSuccess(true);
						ackRequest.sendAckData(ack);
						
						//通知所有群里现存的相关人，在客户端sdk上修改这个组信息
						Group groupInfo = userRDB.findGroup(sessionInfo, sessionInfo.getEnvirment(), sessionInfo.getUserid(), cgroupId);
						notifyMembersUpdateGroupInfo(server, redissonStoreFactory, groupInfo, sessionInfo, UpdateClientGroup.UpdateCmd.UPDATE_GROUP);
						
						//通知被移除的人在其客户端删除这个群
						Group delGroup = new Group("", "", groupInfo.getCgroupId(), 0);
						ConcurrentSet<Member> msToRemove = new ConcurrentSet<Member>();
						msToRemove.addAll(members);
						delGroup.setMembers(msToRemove);
						notifyMembersUpdateGroupInfo(server, redissonStoreFactory, delGroup, sessionInfo, UpdateClientGroup.UpdateCmd.DELETE_GROUP);
						
					} catch (UserRDBException e) {
						log.error("failed to remove members: " + data.toString(), e);
						//移除失败
						EventAckObject ack = new EventAckObject();
						ack.setSentTime((int)(System.currentTimeMillis()/1000));
						ack.setSuccess(false);
						ack.setError(ErrorCodes.getAckError(ErrorCodes.MSG_GROUP_HITALES_DB_ERROR).cloneAndAppendError(e.getMessage()));
						ackRequest.sendAckData(ack);
						//new RuntimeException("ee").printStackTrace();
					}
				} else {
					//Not login yet....or userid is different from login userid
					//TODO 细化error信息
					//TODO handle error
					sendNoSessionAck(ackRequest);
				}
            }
        });
        
        server.addEventListener(EVENT_MODIFY_GROUP_NAME, ModifyGroupInfoObject.class, new DataListener<ModifyGroupInfoObject>() {
            @Override
            public void onData(SocketIOClient client, ModifyGroupInfoObject data, AckRequest ackRequest) {
            	LoginObject sessionInfo = client.get(Constants.SESSION_INFO_KEY);
            	if (sessionInfo != null && sessionInfo.getUserid().equals(data.getUserid())) {
            		try {
            			String cgroupId = data.getGroupId();
            			userRDB.modifyGroupName(sessionInfo, sessionInfo.getEnvirment(), sessionInfo.getUserid(), cgroupId, data.getGroupName());
            			
            			//修改成功
            			EventAckObject ack = new EventAckObject();
						ack.setSentTime((int)(System.currentTimeMillis()/1000));
						ack.setSuccess(true);
						ackRequest.sendAckData(ack);
						
						//通知所有相关人，在客户端sdk上修改这个组信息
						Group groupInfo = userRDB.findGroup(sessionInfo, sessionInfo.getEnvirment(), sessionInfo.getUserid(), cgroupId);
						notifyMembersUpdateGroupInfo(server, redissonStoreFactory, groupInfo, sessionInfo, UpdateClientGroup.UpdateCmd.UPDATE_GROUP);
						
					} catch (Exception e) {
						log.error("failed to modify group: " + data.toString(), e);
						//移除失败
						EventAckObject ack = new EventAckObject();
						ack.setSentTime((int)(System.currentTimeMillis()/1000));
						ack.setSuccess(false);
						ack.setError(ErrorCodes.getAckError(ErrorCodes.MSG_GROUP_HITALES_DB_ERROR).cloneAndAppendError(e.getMessage()));
						ackRequest.sendAckData(ack);
						//new RuntimeException("ee").printStackTrace();
					}
				} else {
					//Not login yet....or userid is different from login userid
					//TODO 细化error信息
					//TODO handle error
					sendNoSessionAck(ackRequest);
				}
            }
        });

        server.addEventListener(EVENT_UPDATE_GROUP_INFO_REQUEST, RequestUpdateGroupInfo.class, new DataListener<RequestUpdateGroupInfo>() {
            @Override
            public void onData(SocketIOClient client, RequestUpdateGroupInfo data, AckRequest ackRequest) {
            	LoginObject sessionInfo = client.get(Constants.SESSION_INFO_KEY);
            	if (sessionInfo != null && sessionInfo.getUserid().equals(data.getUserid())) {
            		try {
            			//请求成功
            			EventAckObject ack = new EventAckObject();
						ack.setSentTime((int)(System.currentTimeMillis()/1000));
						ack.setSuccess(true);
						ackRequest.sendAckData(ack);
            			
						//开始查询数据并逐条返回
            			HashMap<String, RequestUpdateGroupInfo.UpdateGroupItem> requestItems = new HashMap<String, RequestUpdateGroupInfo.UpdateGroupItem>();
            			for (int i = 0; i < data.getGroupItems().length; i++) {
            				requestItems.put(data.getGroupItems()[i].getCgroupId(), data.getGroupItems()[i]);
						}
            			List<Group> groups = userRDB.listGroups(sessionInfo, sessionInfo.getEnvirment(), data.getUserid());
            			HashMap<String, Group> hgs = new HashMap<String, Group>();
            			for (Group gr : groups) {
            				hgs.put(gr.getCgroupId(), gr);
            				RequestUpdateGroupInfo.UpdateGroupItem item = requestItems.remove(gr.getCgroupId());
            				boolean updateAllMembers = false;
							if (item == null) {
								//没有找到，证明客户端没有这个组，需要完整发送这个组
								updateAllMembers = true;
							} else if(Long.parseLong(item.getUpdateTime()) < gr.getUpdateTime()){
								//如果服务器上的组的更新时间更新，需要更新客户端组信息
								updateAllMembers = true;
							} else {
								//else, do nothing
							}
							if (updateAllMembers) {
								//上面整组和单个更新何为一个，都用整组更新，TODO 以后对单个更新进行迭代优化
								UpdateClientGroup ucp = new UpdateClientGroup();
								ucp.setUpdateCmd(item == null ? UpdateCmd.ADD_GROUP : UpdateCmd.UPDATE_GROUP);
								ucp.setGroupInfo(gr);
								client.sendEvent(EVENT_UPDATE_GROUP_INFO_REQUEST, ucp);
							}
						}
            			if (requestItems.size() > 0) {
							//通过上面的遍历，如果发现还有客户端的组没有被处理，说服务器上已经不存在这个组了，需要删除客户端的组
            				for(UpdateGroupItem it : requestItems.values()) {
            					UpdateClientGroup ucp = new UpdateClientGroup();
                				ucp.setUpdateCmd(UpdateCmd.DELETE_GROUP);
                				ucp.setGroupInfo(it);
                				client.sendEvent(EVENT_UPDATE_GROUP_INFO_REQUEST, ucp);
            				}
						}
            			
            			//最后通知客户端，所有数据都发送完毕
            			UpdateClientGroup ucp = new UpdateClientGroup();
            			ucp.setUpdateCmd(UpdateCmd.UPDATE_ALL_FINISH);
            			client.sendEvent(EVENT_UPDATE_GROUP_INFO_REQUEST, ucp);
            			
					} catch (Exception e) {
						log.error("failed to request group info: " + data.toString(), e);
						//请求失败
						EventAckObject ack = new EventAckObject();
						ack.setSentTime((int)(System.currentTimeMillis()/1000));
						ack.setSuccess(false);
						ack.setError(ErrorCodes.getAckError(ErrorCodes.MSG_GROUP_HITALES_DB_ERROR).cloneAndAppendError(e.getMessage()));
						ackRequest.sendAckData(ack);
						//new RuntimeException("ee").printStackTrace();
					}
				} else {
					//Not login yet....or userid is different from login userid
					//TODO 细化error信息
					//TODO handle error
					sendNoSessionAck(ackRequest);
				}
            }
        });
        
        server.start();

        Thread.sleep(Integer.MAX_VALUE);

        server.stop();
    }
	
	/**
	 * 通知所有组员，更新sdk上的本地组数据
	 * @param server
	 * @param redissonStoreFactory
	 * @param data
	 * @param groupInfo
	 * 		- Group(for modify) or UpdateGroupItem(for delete)
	 * @param sessionInfo
	 */
	private static void notifyMembersUpdateGroupInfo(SocketIOServer server, RedissonStoreFactory redissonStoreFactory,
			Group group, LoginObject sessionInfo, UpdateClientGroup.UpdateCmd cmd) {
		// 通知相关组员
		String[] memberIds = group.toMemberIds();
		for (String uid : memberIds) {
			// 构建通知数据
			UpdateClientGroup ucg = new UpdateClientGroup();
			ucg.setUpdateCmd(cmd);
			if (cmd == UpdateCmd.DELETE_GROUP) {
				ucg.setGroupInfo(new Group("", "", group.getCgroupId(), 0));
			} else {
				ucg.setGroupInfo(group);
			}
			
			// 被通知的人
			String toChannel = LoginObject.getSessionKey(sessionInfo.getEnvirment(), uid);
			RedisBroadcastOperations redisBroadcast = new RedisBroadcastOperations(toChannel,
					server.getRoomClients(toChannel), redissonStoreFactory, null);
			redisBroadcast.sendEvent(EVENT_UPDATE_GROUP_INFO_REQUEST, ucg);
		}
	}
	
	/**
	 * 注册监听群消息
	 * @param server
	 * @param redissonStoreFactory
	 * @param data
	 * @param cgroupId
	 * @param sessionInfo
	 */
	private static void notifyMembersRegister(SocketIOServer server, RedissonStoreFactory redissonStoreFactory, GroupBaseObject data, String cgroupId, LoginObject sessionInfo) {
		//通知新增人员去监听这个群消息
		for (String uid : data.getMembersId()) {
			//通知被邀请方，如果对方不在线，下次对方登陆时会自动注册这个群监听，所以不需要离线通知
			OnGroupJoinLeave onJoinGroup = new OnGroupJoinLeave();
			onJoinGroup.setUserid(data.getUserid());
			onJoinGroup.setEnvirment(sessionInfo.getEnvirment());
			onJoinGroup.setToGroupId(cgroupId);
			//被通知的人
			String toChannel = LoginObject.getSessionKey(sessionInfo.getEnvirment(), uid);
			RedisBroadcastOperations redisBroadcast = new RedisBroadcastOperations(toChannel,
					server.getRoomClients(toChannel), redissonStoreFactory, null);
    		redisBroadcast.sendJoinLeaveGroupNotify(EVENT_ON_JOIN_GROUP, onJoinGroup);
		}
	}
	
	/**
	 * 反注册监听
	 * @param server
	 * @param redissonStoreFactory
	 * @param data
	 * @param cgroupId
	 * @param sessionInfo
	 */
	private static void notifyMembersUnregister(SocketIOServer server, RedissonStoreFactory redissonStoreFactory, List<Member> members, GroupBaseObject data, String cgroupId, LoginObject sessionInfo) {
		for (Member member : members) {
			String uid = member.getUserid();
			//通知被邀请方，如果对方不在线，下次对方登陆时会自动注册这个群监听，所以不需要离线通知
			OnGroupJoinLeave onLeaveGroup = new OnGroupJoinLeave();
			onLeaveGroup.setUserid(data.getUserid());
			onLeaveGroup.setEnvirment(sessionInfo.getEnvirment());
			onLeaveGroup.setToGroupId(cgroupId);
			//被通知的人
			String toChannel = LoginObject.getSessionKey(sessionInfo.getEnvirment(), uid);
			RedisBroadcastOperations redisBroadcast = new RedisBroadcastOperations(toChannel,
					server.getRoomClients(toChannel), redissonStoreFactory, null);
    		redisBroadcast.sendJoinLeaveGroupNotify(EVENT_ON_LEAVE_GROUP, onLeaveGroup);
		}
	}
	
	/**
	 * 未登录而非法调用方法, TODO 需logo记录请求来源，预防攻击
	 * @param ackRequest
	 */
	private static void sendNoSessionAck(AckRequest ackRequest) {
		EventAckObject mao = new EventAckObject();
		mao.setSentTime((int)(System.currentTimeMillis()/1000));
		mao.setSuccess(false);
		mao.setError(ErrorCodes.getAckError(ErrorCodes.MSG_NO_VALID_SESSION));
		ackRequest.sendAckData(mao);
	}

}

//发送欢迎消息
//ChatObject co = new ChatObject();
//co.setUserName(data.getUserName());
//co.setMessage(data.getUserName() + " No....you are so cool! you said: " + data.getMessage() + " at " + System.currentTimeMillis());
//client.sendEvent("chatevent", co);

//发送到目的地
//co = new ChatObject();
//co.setUserName(data.getUserName());
//co.setMessage("room1 send message: " + data.getMessage() + " at " + System.currentTimeMillis());
//TODO 优化发送

//redisBroadcast.sendEvent(EVENT_MSG, data);
