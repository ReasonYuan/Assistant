package com.yiyihealth.msgserver.msg.object;

import java.io.Serializable;
import java.util.ArrayList;

import org.apache.http.message.BasicHeader;

import com.alibaba.fastjson.JSON;
import com.yiyihealth.msgserver.Constants;
import com.yiyihealth.msgserver.helper.FQSecuritySession;

public class LoginObject implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4822082340237787045L;
	
	private String uuid;
	private String userid;
	private String envirment;
	private String accessToken;
	private String clientType;
	private String clientVersion;
	private long loginTime;
	
	transient private Boolean isRequiredSession;
	
	public Boolean getIsRequiredSession() {
		if (isRequiredSession == null) {
			isRequiredSession = false;
			for (int i = 0; i < Constants.ENVIRMENTS.length; i++) {
				if(Constants.ENVIRMENTS[i].equals(getEnvirment())){
					isRequiredSession = Constants.requiredSession[i];
					break;
				}
			}
		}
		return isRequiredSession;
	}
	public void setIsRequiredSession(Boolean isRequiredSession) {
		this.isRequiredSession = isRequiredSession;
	}
	public long getLoginTime() {
		return loginTime;
	}
	public void setLoginTime(long loginTime) {
		this.loginTime = loginTime;
	}

	public String getUuid() {
		return uuid;
	}
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getEnvirment() {
		return envirment;
	}
	
	public void setEnvirment(String envirment) {
		this.envirment = envirment;
	}
	
	public String getClientType() {
		return clientType;
	}
	
	public void setClientType(String clientType) {
		this.clientType = clientType;
	}
	
	public String getClientVersion() {
		return clientVersion;
	}
	
	public void setClientVersion(String clientVersion) {
		this.clientVersion = clientVersion;
	}
	
	public String getReconnectSessionKey(){
		return envirment + "_" + userid + "_" + uuid;
	}
	
	public String getSessionKey(){
		return getSessionKey(envirment, userid);
	}
	
	public static String getSessionKey(String envirment, String userid){
		return envirment + "_" + userid;
	}
	
	@Override
	public boolean equals(Object obj) {
		LoginObject lo = (LoginObject) obj;
		try {
			return lo.uuid.equals(uuid) && lo.accessToken.equals(accessToken) && lo.envirment.equals(envirment)
					 && lo.userid.equals(userid);
		} catch (Exception e) {
			return false;
		}
	}
	
	public BasicHeader[] toSessionHeaders(String uri) {
		boolean requiredSession = getIsRequiredSession();
		if (requiredSession) {
			FQSecuritySession securitySession = new FQSecuritySession();
			securitySession.setAccessToken(getAccessToken());
			ArrayList<BasicHeader> hs =  securitySession.getSessionHeaders(getUserid(), uri, "POST");
			hs.add(new BasicHeader("uuid", uuid));
			BasicHeader[] results = new BasicHeader[hs.size()];
			for (int i = 0; i < results.length; i++) {
				results[i] = hs.get(i);
			}
			return results;
		} else {
			return new BasicHeader[0];
		}
	}
	public String getAccessToken() {
		if (accessToken == null) {
			return "";
		}
		return accessToken;
	}
	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}
	
	@Override
	public String toString() {
		return JSON.toJSONString(this);
	}
}
