package com.yiyihealth.msgserver.msg.object;

public class CreateGroupObject extends GroupBaseObject {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -6376577684820331165L;
	
	private String name;
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
