package com.yiyihealth.msgserver.msg.object;

import java.io.Serializable;

import com.alibaba.fastjson.JSON;

public class ModifyGroupInfoObject implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1662711270954377498L;

	private String groupId;
	
	private String groupName;
	
	private String userid;

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getGroupId() {
		return groupId;
	}

	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	
	@Override
	public String toString() {
		return JSON.toJSONString(this);
	}
	
}
