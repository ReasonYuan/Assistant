package com.yiyihealth.msgserver.msg.object;

import com.yiyihealth.msgserver.Constants;

public class GroupChatObject extends ChatObject {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6110502053833345601L;

	private String toGroupId;

	public String getToGroupId() {
		return toGroupId;
	}

	public void setToGroupId(String toGroupId) {
		this.toGroupId = toGroupId;
	}
	
	@Override
	public String getToChannelName() {
		return getToChannelName(getEnvirment(), toGroupId);
	}
	
	public static String getToChannelName(String envirment, String toGroupId){
		return envirment + Constants.GROUP_MSG_INTER + toGroupId;
	}

	@Override
	public boolean isSingleChat() {
		return false;
	}
	
}
