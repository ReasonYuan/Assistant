package com.yiyihealth.msgserver.session;

import org.redisson.Config;
import org.redisson.Redisson;
import org.redisson.core.RMap;

import com.yiyihealth.msgserver.Constants;
import com.yiyihealth.msgserver.msg.object.LoginObject;

/**
 * 
 * 避免频繁重连时访问登陆服务器，内部保存重连信息
 * @author xiongchao
 *
 */
public class ReconnectSessionManager {
	
	private static ReconnectSessionManager _instance = new ReconnectSessionManager();
	
	private final Redisson redisson;
	
	/**
	 * 成功登陆的登陆记录
	 */
	private RMap<String, LoginObject> sessionMap;
	
	private ReconnectSessionManager(){
		Config conifig = new Config();
		conifig.useSingleServer().setAddress(Constants.configure.getStringProperty("redis.server.coremsg"));
		redisson = Redisson.create(conifig);
		sessionMap = redisson.getMap("hitales_im_login_session");
		//TODO 这不能清空
		sessionMap.clear();
	}
	
	public static ReconnectSessionManager getInstance(){
		return _instance;
	}
	
	/**
	 * 是否需要重新登陆
	 * @param loginObject
	 * @return
	 */
	public boolean isLogin(LoginObject loginObject){
		LoginObject login = sessionMap.get(loginObject.getReconnectSessionKey());
		if (login != null) {
			return login.equals(loginObject);
		}
		return false;
	}
	
	public void saveReconnectSession(LoginObject successLoginObject){
		sessionMap.putAsync(successLoginObject.getReconnectSessionKey(), successLoginObject);
	}
	
	public LoginObject logout(String sessionKey){
		return sessionMap.remove(sessionKey);
	}
	
}
