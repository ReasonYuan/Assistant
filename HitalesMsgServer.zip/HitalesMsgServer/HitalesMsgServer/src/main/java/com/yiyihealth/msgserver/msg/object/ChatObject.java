package com.yiyihealth.msgserver.msg.object;

import com.alibaba.fastjson.JSON;
import com.corundumstudio.socketio.store.pubsub.PubSubMessage;

public abstract class ChatObject extends PubSubMessage {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8631189392700188827L;
	
	private String userid;
    private String message;
    private String payload;
	private String envirment;
	private long createTime = System.currentTimeMillis();
	
	public long getCreateTime() {
		return createTime;
	}

	public void setCreateTime(long createTime) {
		this.createTime = createTime;
	}

	public String getPayload() {
		return payload == null ? "" : payload;
	}

	public void setPayload(String payload) {
		this.payload = payload;
	}

	public String getEnvirment() {
		return envirment;
	}

	public void setEnvirment(String envirment) {
		this.envirment = envirment;
	}

	public ChatObject() {
    }

    public ChatObject(String userid, String message) {
        super();
        this.userid = userid;
        this.message = message;
    }


    public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getMessage() {
        return message;
    }
    public void setMessage(String message) {
        this.message = message;
    }
    
    /**
     * 是否是单聊
     * @return
     */
    public abstract boolean isSingleChat();
    
    public abstract String getToChannelName();
    
	@Override
	public String toString() {
		return JSON.toJSONString(this);
	}
}
