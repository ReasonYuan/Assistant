package com.yiyihealth.msgserver.db;

import java.io.Serializable;

import io.netty.util.internal.ConcurrentSet;

public class Group implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8285104142828213885L;
	
	/**
	 * createrId, 创建者id
	 */
	private String userid;
	
	private String groupName;
	
	private String cgroupId;
	
	private ConcurrentSet<Member> members;
	
	/**
	 * 设置更新时间，以便客户端和服务器比较，避免重复传输
	 */
	private long updateTime = System.currentTimeMillis();
	
	public Group(){
	}
	
	/**
	 * 
	 * @param userid
	 * 		- 创建在的id
	 * @param groupName
	 * @param cgroupId
	 */
	public Group(String userid, String groupName, String cgroupId, long updateTime){
		this.userid = userid;
		this.groupName = groupName;
		this.cgroupId = cgroupId;
		this.updateTime = updateTime;
	}

	public ConcurrentSet<Member> getMembers() {
		if (members == null) {
			members = new ConcurrentSet<Member>();
		}
		return members;
	}
	
	/**
	 * 转换成String[]的memberids
	 * @return
	 */
	public String[] toMemberIds(){
		ConcurrentSet<Member> ms = getMembers();
		String[] result = new String[ms.size()];
		int offset = 0;
		for(Member m : ms) {
			result[offset++] = m.getUserid();
		}
		return result;
	}

	public void setMembers(ConcurrentSet<Member> members) {
		this.members = members;
	}

	public long getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(long updateTime) {
		this.updateTime = updateTime;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getGroupName() {
		return groupName == null ? "" : groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public String getCgroupId() {
		return cgroupId;
	}

	public void setCgroupId(String cgroupdId) {
		this.cgroupId = cgroupdId;
	}
	
	@Override
	public boolean equals(Object obj) {
		Group g = (Group) obj;
		return userid.equals(g.userid) && cgroupId.equals(g.cgroupId) && groupName.equals(g.groupName);
	}
}
