package com.yiyihealth.msgserver.db;

import java.io.Serializable;

public class Member implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8285104142828213885L;
	
	private String userid;
	
	private String username;
	
	private String imageId;
	
	public Member(){
	}
	
	public Member(String userid){
		this.userid = userid;
	}
	
	public String getUsername() {
		return username == null ? "" : username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getImageId() {
		return imageId == null ? "0" : imageId;
	}

	public void setImageId(String imageId) {
		this.imageId = imageId;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	@Override
	public int hashCode() {
		return userid.hashCode();
	}
	
	@Override
	public String toString() {
		return "mid:"+userid;
	}
	
	@Override
	public boolean equals(Object obj) {
		Member m = (Member) obj;
		return userid.equals(m.userid);
	}
}
