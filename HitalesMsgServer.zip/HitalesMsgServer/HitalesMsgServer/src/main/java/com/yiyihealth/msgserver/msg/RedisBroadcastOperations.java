package com.yiyihealth.msgserver.msg;

import java.util.Arrays;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.corundumstudio.socketio.ClientOperations;
import com.corundumstudio.socketio.SocketIOClient;
import com.corundumstudio.socketio.protocol.Packet;
import com.corundumstudio.socketio.protocol.PacketType;
import com.corundumstudio.socketio.store.StoreFactory;
import com.corundumstudio.socketio.store.pubsub.DispatchMessage;
import com.corundumstudio.socketio.store.pubsub.PubSubStore;
import com.yiyihealth.msgserver.MsgServer;
import com.yiyihealth.msgserver.helper.GroupHelper;
import com.yiyihealth.msgserver.msg.object.OnGroupJoinLeave;

public class RedisBroadcastOperations implements ClientOperations {
	
	private String channel;
	private StoreFactory storeFactory;
	private Iterable<SocketIOClient> localClients;
	private SocketIOClient clientSelf;//自己，一般情况自己发发送的消息不发给自己
	
	/**
	 * both channel and localClients are optional 
	 * @param channel
	 * 		- broadcast the message to the client on other server
	 * @param localClients
	 * 		- all clients in the room on this server instance, or null
	 * @param storeFactory
	 * @param clietSelf - 自己，一般情况自己发发送的消息不发给自己，如果 null， 则要发给自己
	 */
    public RedisBroadcastOperations(String channel, Iterable<SocketIOClient> localClients, StoreFactory storeFactory, SocketIOClient clienttSelf) {
        super();
        this.channel = channel;
        this.storeFactory = storeFactory;
        this.localClients = localClients;
        this.clientSelf = clienttSelf;
    }

    @Override
    public void send(Packet packet) {
    	if(localClients != null){
    		for (SocketIOClient client : localClients) {
    			if (clientSelf != client) {
    				client.send(packet);
				}
            }
    	}
        dispatch(channel, packet, "");
    }
    
    /**
     * 加入群的监听
     * @param name
     * @param data
     */
    public void sendJoinLeaveGroupNotify(String name, OnGroupJoinLeave data) {
    	if(localClients != null) {
    		if(name.equals(MsgServer.EVENT_ON_JOIN_GROUP)){
    			GroupHelper.notifyMembersRegister(localClients, "", channel, data.getToChannelName());
    		} else if(name.equals(MsgServer.EVENT_ON_LEAVE_GROUP)){
    			GroupHelper.notifyMembersUnregister(localClients, "", channel, data.getToChannelName());
    		}
    	}
    	//由于支持分布式，这消息也要发送到其他服务器
    	Packet packet = new Packet(PacketType.MESSAGE);
        packet.setSubType(PacketType.EVENT);
        packet.setName(name);
        packet.setData(Arrays.asList(data));
        dispatch(channel, packet, "");
    }

    @Override
    public void disconnect() {
    	if(localClients != null){
    		for (SocketIOClient client : localClients) {
                client.disconnect();
            }
    	}
    }

    @Override
    public void sendEvent(String name, Object... data) {
        Packet packet = new Packet(PacketType.MESSAGE);
        packet.setSubType(PacketType.EVENT);
        packet.setName(name);
        packet.setData(Arrays.asList(data));
        send(packet);
    }

    private void dispatch(final String room, final Packet packet, final String namespace) {
//        for (Entry<String, List<String>> entry : namespaceRooms.entrySet()) {
//            for (String room : entry.getValue()) {
//                storeFactory.pubSubStore().publish(PubSubStore.DISPATCH, new DispatchMessage(room, packet, entry.getKey()));
//            }
//        }
    	storeFactory.pubSubStore().publish(PubSubStore.DISPATCH, new DispatchMessage(room, packet, namespace));
    }
}
