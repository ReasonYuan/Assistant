package com.yiyihealth.msgserver.msg.object;

public class AddToGroupObject extends GroupBaseObject {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6376577684820331165L;
	
}
