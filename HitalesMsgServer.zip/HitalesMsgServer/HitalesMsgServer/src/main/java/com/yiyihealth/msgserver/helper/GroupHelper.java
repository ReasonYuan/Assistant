package com.yiyihealth.msgserver.helper;

import java.util.HashMap;
import java.util.Iterator;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.corundumstudio.socketio.SocketIOClient;
import com.sun.org.apache.xalan.internal.xsltc.runtime.Hashtable;
import com.yiyihealth.msgserver.db.Member;
import com.yiyihealth.msgserver.exception.UserRDBException;
import com.yiyihealth.msgserver.http.UserDBHttpAPI;
import com.yiyihealth.msgserver.msg.object.LoginObject;

import io.netty.util.internal.ConcurrentSet;

public class GroupHelper {
	
	/**
	 * 监听群消息
	 * @param clients
	 * @param namespace
	 * @param room
	 * @param groupNameToRegister
	 */
	public static void notifyMembersRegister(Iterable<SocketIOClient> clients, String namespace, String room, String groupNameToRegister){
		//通知这个room下的所有用户注册监听新建群的消息
    	for (SocketIOClient socketIOClient : clients) {
            socketIOClient.joinRoom(groupNameToRegister);
        }
	}
	
	/**
	 * 取消监听群消息
	 * @param clients
	 * @param namespace
	 * @param room
	 * @param groupNameToRegister
	 */
	public static void notifyMembersUnregister(Iterable<SocketIOClient> clients, String namespace, String room, String groupNameToRegister){
		//通知这个room下的所有用户取消监听群的消息
    	for (SocketIOClient socketIOClient : clients) {
            socketIOClient.leaveRoom(groupNameToRegister);
        }
	}
	
//	public static void fillUserInfo(LoginObject session, Member m, String envirment, String userid) throws UserRDBException {
//		try {
//			UserDBHttpAPI api = UserDBHttpAPI.getHttpAPI(envirment);
//			String uri = "/users/search_by_userid.do";
//			String searchUserInfo = "{\"user_id\":"+m.getUserid()+", \"my_user_id\":"+userid+"}";
//			JSONObject result = api.post(uri, searchUserInfo, session.toSessionHeaders(uri));
//			m.setImageId("" + result.getJSONObject("results").getInteger("image_id"));
//			m.setUsername(result.getJSONObject("results").getString("name"));
//		} catch (Exception e) {
//			//TODO handle exception
//		}
//	}
	
	/**
	 * 用5.8接口一次性的填充所有用户信息
	 * @param session
	 * @param members
	 * @param envirment
	 * @param userid
	 * @throws UserRDBException
	 */
	public static void fillUserInfos(LoginObject session, ConcurrentSet<Member> members, String envirment, String userid) throws UserRDBException {
		try {
			HashMap<String, Object> mids = new HashMap<String, Object>();
			int[] ids = new int[members.size()];
			Member[] ms = new Member[members.size()];
			int idx = 0;
			for(Member m : members){
				ms[idx] = m;
				ids[idx++] = Integer.parseInt(m.getUserid());
			}
			mids.put("user_ids", ids);
			String reqeustBody = JSON.toJSONString(mids);
			UserDBHttpAPI api = UserDBHttpAPI.getHttpAPI(envirment);
			String uri = "/users/select_name_image.do";
			JSONObject result = api.post(uri, reqeustBody, session.toSessionHeaders(uri));
			JSONArray uinfos = result.getJSONArray("results");
			for (int i = 0; i < uinfos.size(); i++) {
				JSONObject jsonM = uinfos.getJSONObject(i);
				ms[i].setImageId("" + (jsonM.containsKey("image_id") ? jsonM.getInteger("image_id") : 0));
				ms[i].setUsername(jsonM.containsKey("name") ? jsonM.getString("name") : "");
			}
		} catch (Exception e) {
			//TODO handle exception
			throw new UserRDBException(e);
		}
	}
}
