package com.yiyihealth.msgserver.exception;

public class UserRDBException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5345861853369310366L;
	
	private int errorCode = 1000001;
	
	public UserRDBException(){
	}
	
	public UserRDBException(String detailMsg) {
		super(detailMsg);
	}
	
	public UserRDBException(Exception e) {
		super(e);
	}
	
	public UserRDBException(int errorCode, String detailMsg) {
		super(detailMsg);
		this.errorCode = errorCode;
	}

	public int getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}
	
}
