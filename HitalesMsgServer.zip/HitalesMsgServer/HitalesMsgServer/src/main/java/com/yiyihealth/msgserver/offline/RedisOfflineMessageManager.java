package com.yiyihealth.msgserver.offline;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.redisson.Config;
import org.redisson.Redisson;
import org.redisson.core.RList;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.yiyihealth.msgserver.Constants;
import com.yiyihealth.msgserver.msg.object.ChatObject;

public class RedisOfflineMessageManager {
	
	public static interface OfflinePullCallbck {
		
		/**
		 * 得到离线数据
		 * @param msgs
		 */
		void onOfflineMsgPullFinish(List<ChatObject> msgs);
		
	}
	
	private static final Logger log = LoggerFactory.getLogger(RedisOfflineMessageManager.class);
	
	/**
	 * 上次成功发送消息的时间
	 */
	public static final String LAST_SENT_TIME_FREFIX = "hi_";

	private static RedisOfflineMessageManager _instance = null;
	
	/**
	 * 为避免过多同步请求涌向离线服务器，用2个单线程了执行, 具体多少线程合适依赖于服务器配置,2为mac pro开发机测试结果, TODO 提成配置文件
	 */
	private static ExecutorService redisOfflineService = Executors.newFixedThreadPool(Constants.configure.getIntProperty("redis.threads.storeoffline"));
	
	/**
	 * 单独用线程来发送离线消息
	 */
	private static ExecutorService sendOfflineMsgService = Executors.newCachedThreadPool();
	
	/**
	 * TODO 加到配置文件里
	 */
	private static final int MAX_OFFLINE_MESSAGE = Constants.configure.getIntProperty("maxofflinemsgs");
	
	private Redisson offlineRedisson;

	private RedisOfflineMessageManager(Redisson redisson) {
		this.offlineRedisson = redisson;
	}
	
	public static RedisOfflineMessageManager getInstance() {
		if (_instance == null) {
			Config config = new Config();
			config.useSingleServer().setAddress(com.yiyihealth.msgserver.Constants.OFFLINE_REDIS_SERVER).setConnectionPoolSize(1024).setSubscriptionConnectionPoolSize(512);;
			Redisson redisson = Redisson.create(config);
			_instance = new RedisOfflineMessageManager(redisson);
		}
		return _instance;
	}
	
	public Redisson getRedisson() {
		return offlineRedisson;
	}
	
	/**
	 * 当用户离线时，保存为离线消息
	 * @param message
	 * @return
	 */
	public void addMessage(final ChatObject message){
		redisOfflineService.execute(new Runnable() {
			public void run() {
				if(message.getUserid() == null){
					throw new NullPointerException("Destination user id must be set!");
				}
				List<ChatObject> list = offlineRedisson.getList(message.getToChannelName());
				while (list.size() > MAX_OFFLINE_MESSAGE) {
					list.remove(0);
				}
				list.add(message);
			}
		});
	}
	
	/**
	 * 保存上次成功发送消息的时间
	 */
	public void saveLastSentTime(String userid, String toChannelName, final long time){
		final String TIME_KEY = LAST_SENT_TIME_FREFIX + userid + toChannelName;
		redisOfflineService.execute(new Runnable() {
			public void run() {
				offlineRedisson.getAtomicLong(TIME_KEY).set(time);
			}
		});
	}
	
	/**
	 * 一个人的离线消息限制为 #{@link MAX_OFFLINE_MESSAGE}
	 * @param toChannelName
	 * 		- 接受者的频道, 群消息会被多次拷贝，这里利用空间换取算法简单，TODO 增加群索引来降低内存消耗
	 * @return
	 */
	public void pullOfflineMessage(final String userid, final String toChannelName, final OfflinePullCallbck callback){
		redisOfflineService.execute(new Runnable() {
			public void run() {
				final String TIME_KEY = LAST_SENT_TIME_FREFIX + userid + toChannelName;
				//纪录最后一次发送的消息的创建时间
				long lastSentTime = offlineRedisson.getAtomicLong(TIME_KEY).get();
				RList<ChatObject> list = offlineRedisson.getList(toChannelName);
				//TODO 优化历史消息查询性能
				//真正需要重发的
				final ArrayList<ChatObject> offlineList = new ArrayList<ChatObject>();
				int startFrom = 0;
				if (lastSentTime > 0) {
					startFrom = list.size();
					for (int i = list.size() - 1; i >= 0; i--) {
						if (list.get(i).getCreateTime() > lastSentTime) {
							startFrom = i;
						} else {
							break;
						}
					}
				}
				for (int i = startFrom; i < list.size(); i++) {
					offlineList.add(list.get(i));
				}
				if (offlineList.size() > 0) {
					//重置，表示离线消息已经被提取, 如果同一账号多客户端链接，这里只有第一个链接的才能拿到离线消息
					offlineRedisson.getAtomicLong(TIME_KEY).set(offlineList.get(offlineList.size()-1).getCreateTime());
					//DEBUG
					log.info("userid: " + userid + ", toChannelName: "  + toChannelName + " got offline message count " + offlineList.size() + ", lastTime is: " + offlineList.get(offlineList.size()-1).getCreateTime() + ", preLastSentTime is " + lastSentTime + ", listSize: " + list.size());
				}
				sendOfflineMsgService.execute(new Runnable() {
					public void run() {
						callback.onOfflineMsgPullFinish(offlineList);
					}
				});
			}
		});
	}
	
	/**
	 * 清空离线消息<br/>
	 * 不要通过 {@link #pullOfflineMessage(String)} 得到的list来清空，因为以后扩展算法时反回的list可能不能被清空
	 * @param toChannelName
	 */
	public void clearOfflineMessage(final String userid, final String toChannelName){
		redisOfflineService.execute(new Runnable() {
			public void run() {
				offlineRedisson.getList(LAST_SENT_TIME_FREFIX + userid + toChannelName).clear();
			}
		});
	}
	
}
