package com.yiyihealth.msgserver.msg.object;

import java.io.Serializable;

import com.alibaba.fastjson.JSON;

public class RequestUpdateGroupInfo implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7434274245059501688L;

	private String userid;
	
	private UpdateGroupItem[] groupItems;

	public UpdateGroupItem[] getGroupItems() {
		if (groupItems == null) {
			return new UpdateGroupItem[0];
		}
		return groupItems;
	}

	public void setGroupItems(UpdateGroupItem[] groupItems) {
		this.groupItems = groupItems;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}
	
	public static class UpdateGroupItem implements Serializable {
		
		/**
		 * 
		 */
		private static final long serialVersionUID = 6252111481336378633L;

		private String cgroupId;
		
		private String updateTime;

		public String getCgroupId() {
			return cgroupId;
		}

		public void setCgroupId(String cgroupId) {
			this.cgroupId = cgroupId;
		}

		public String getUpdateTime() {
			return updateTime;
		}

		public void setUpdateTime(String updateTime) {
			this.updateTime = updateTime;
		}
		
	}
	
	@Override
	public String toString() {
		return JSON.toJSONString(this);
	}
}


