package com.yiyihealth.msgserver.msg.object;

import java.io.Serializable;

/**
 * 事件执行反馈
 * @author xiongchao
 *
 */
public class EventAckObject implements Serializable {

	public int getSentTime() {
		return sentTime;
	}

	public void setSentTime(int sentTime) {
		this.sentTime = sentTime;
	}

	public boolean isSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}

	public AckError getError() {
		return error;
	}

	public void setError(AckError error) {
		this.error = error;
	}

	public Serializable getResult() {
		return result;
	}

	public void setResult(Serializable result) {
		this.result = result;
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 8441233588402472677L;
	
	/**
	 * in seconds，发送时间
	 */
	private int sentTime;
	
	/**
	 * 是否发送成功
	 */
	private boolean success;
	
	/**
	 * 错误信息
	 */
	private AckError error;
	
	/**
	 * 事件执行结果
	 */
	private Serializable result;
	
}
