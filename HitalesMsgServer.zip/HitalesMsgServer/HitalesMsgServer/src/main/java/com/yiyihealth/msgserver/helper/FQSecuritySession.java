package com.yiyihealth.msgserver.helper;

import java.net.URLEncoder;
import java.util.ArrayList;

import org.apache.http.message.BasicHeader;

public class FQSecuritySession {
	
	private String mAccessToken = null;
	
	private byte[] mSecuriy3DesKey = null;
	
	public FQSecuritySession(){
	}

	public void setAccessToken(String accessToken) {
		mAccessToken = accessToken;
		if(accessToken == null){
			mSecuriy3DesKey = null;
		} else {
			byte[] data = accessToken.getBytes();
			mSecuriy3DesKey = new byte[24];
			System.arraycopy(data, 0, mSecuriy3DesKey, 0, mSecuriy3DesKey.length);
		}
	}

	public ArrayList<BasicHeader> getSessionHeaders(String userid, String resource, String method) {
		if(mAccessToken == null || userid.length() == 0){
			return new ArrayList<BasicHeader>();
		}
		long timestamp = System.currentTimeMillis();
		String signature = HMACSHA1Helper.getSessionSignature(mAccessToken, "" + userid, method, timestamp, resource);
		ArrayList<BasicHeader> headers = new ArrayList<BasicHeader>();
		headers.add(new BasicHeader("Expires", "" + timestamp));
		headers.add(new BasicHeader("userid", "" + userid));
		//signature需要做url encode
		try {
			headers.add(new BasicHeader("Authorization", URLEncoder.encode(signature, "utf-8")));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return headers;
	}

	public byte[] get3DesKeyBytes() {
		return mSecuriy3DesKey;
	}

}