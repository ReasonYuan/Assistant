package com.yiyihealth.msgserver.db;

import org.redisson.Redisson;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.corundumstudio.socketio.SocketIOClient;
import com.corundumstudio.socketio.handler.AuthorizeHandler;
import com.corundumstudio.socketio.namespace.NamespacesHub;
import com.corundumstudio.socketio.protocol.JsonSupport;
import com.corundumstudio.socketio.protocol.Packet;
import com.corundumstudio.socketio.store.RedissonPubSubStore;
import com.corundumstudio.socketio.store.RedissonStoreFactory;
import com.corundumstudio.socketio.store.pubsub.ConnectMessage;
import com.corundumstudio.socketio.store.pubsub.DisconnectMessage;
import com.corundumstudio.socketio.store.pubsub.DispatchMessage;
import com.corundumstudio.socketio.store.pubsub.JoinLeaveMessage;
import com.corundumstudio.socketio.store.pubsub.PubSubListener;
import com.corundumstudio.socketio.store.pubsub.PubSubStore;
import com.yiyihealth.msgserver.Constants;
import com.yiyihealth.msgserver.MsgServer;
import com.yiyihealth.msgserver.helper.GroupHelper;
import com.yiyihealth.msgserver.msg.object.ChatObject;
import com.yiyihealth.msgserver.msg.object.LoginObject;
import com.yiyihealth.msgserver.msg.object.OnGroupJoinLeave;
import com.yiyihealth.msgserver.offline.RedisOfflineMessageManager;

public class HitalesRedissonStoreFactory extends RedissonStoreFactory {
	
    private final Logger log = LoggerFactory.getLogger(getClass());
    
    final static RedisOfflineMessageManager offlineManager = RedisOfflineMessageManager.getInstance();
    
    public HitalesRedissonStoreFactory(Redisson redisson) {
    	super(redisson);
    }
    
    public HitalesRedissonStoreFactory(Redisson redisClient, Redisson redisPub, Redisson redisSub, Class<? extends PubSubStore> clazz) {
    	super(redisClient, redisPub, redisSub, clazz);
	}

	@Override
	public void init(final NamespacesHub namespacesHub, final AuthorizeHandler authorizeHandler, JsonSupport jsonSupport) {
	       pubSubStore().subscribe(PubSubStore.DISCONNECT, new PubSubListener<DisconnectMessage>() {
	            @Override
	            public void onMessage(DisconnectMessage msg) {
	                log.debug("{} sessionId: {}", PubSubStore.DISCONNECT, msg.getSessionId());
	            }
	        }, DisconnectMessage.class);

	        pubSubStore().subscribe(PubSubStore.CONNECT, new PubSubListener<ConnectMessage>() {
	            @Override
	            public void onMessage(ConnectMessage msg) {
	                authorizeHandler.connect(msg.getSessionId());
	                log.debug("{} sessionId: {}", PubSubStore.CONNECT, msg.getSessionId());
	            }
	        }, ConnectMessage.class);

	        pubSubStore().subscribe(PubSubStore.DISPATCH, new PubSubListener<DispatchMessage>() {
	            @Override
	            public void onMessage(DispatchMessage msg) {
	                String name = msg.getRoom();
	                Packet packet = msg.getPacket();
	                //检查该消息是否是服务器内部消息，否则发送到客户端
	                if(MsgServer.EVENT_ON_JOIN_GROUP.equals(packet.getName())){
	                	//通知这个room下的所有用户注册监听新建群的消息
	                	OnGroupJoinLeave onJoinGroup = packet.getData();
	                	GroupHelper.notifyMembersRegister(namespacesHub.getRoomClients(name), msg.getNamespace(), name, onJoinGroup.getToChannelName());
	                } else if(MsgServer.EVENT_ON_LEAVE_GROUP.equals(packet.getName())) { 
	                	//通知这个room下的所有用户反注册监听群的消息
	                	OnGroupJoinLeave onJoinGroup = packet.getData();
	                	GroupHelper.notifyMembersUnregister(namespacesHub.getRoomClients(name), msg.getNamespace(), name, onJoinGroup.getToChannelName());
	                } else {
	                	namespacesHub.get(msg.getNamespace()).dispatch(name, packet);
	                	//记录上次发送消息的时间，用于查询离线消息
	                	Iterable<SocketIOClient> clients = namespacesHub.get(msg.getNamespace()).getRoomClients(name);
	                    for (SocketIOClient socketIOClient : clients) {
	                    	try {
	                    		//这里设置下最后发送消息时间，这里是跨服务器消息，另外还需要在本服务器内部消息发送里记录一下，见MsgServer里EVENT_GROUP_MSG和EVENT_MSG的处理
	                    		ChatObject co = packet.getData();
	                    		LoginObject loginObject = socketIOClient.get(Constants.SESSION_INFO_KEY);
	                    		offlineManager.saveLastSentTime(loginObject.getUserid(), loginObject.getSessionKey(), co.getCreateTime());
							} catch (Exception e) {
								//TODO handle error, 通常在增加了EVENT_ON_JOIN_GROUP，EVENT_ON_LEAVE_GROUP以外的系统消息才会出现这个异常，否则都会是chatobject
								e.printStackTrace();
							}
	                    }
	                }
	                log.debug("{} packet: {}", PubSubStore.DISPATCH, msg.getPacket());
	            }
	        }, DispatchMessage.class);

	        pubSubStore().subscribe(PubSubStore.JOIN, new PubSubListener<JoinLeaveMessage>() {
	            @Override
	            public void onMessage(JoinLeaveMessage msg) {
	                String name = msg.getRoom();

	                namespacesHub.get(msg.getNamespace()).join(name, msg.getSessionId());
	                log.debug("{} sessionId: {}", PubSubStore.JOIN, msg.getSessionId());
	            }
	        }, JoinLeaveMessage.class);

	        pubSubStore().subscribe(PubSubStore.LEAVE, new PubSubListener<JoinLeaveMessage>() {
	            @Override
	            public void onMessage(JoinLeaveMessage msg) {
	                String name = msg.getRoom();

	                namespacesHub.get(msg.getNamespace()).leave(name, msg.getSessionId());
	                log.debug("{} sessionId: {}", PubSubStore.LEAVE, msg.getSessionId());
	            }
	        }, JoinLeaveMessage.class);
	}
	
}
