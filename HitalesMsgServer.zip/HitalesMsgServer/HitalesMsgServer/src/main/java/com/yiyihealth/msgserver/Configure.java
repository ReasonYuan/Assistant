package com.yiyihealth.msgserver;

import java.io.FileInputStream;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Configure {
	
	private static final Logger log = LoggerFactory.getLogger(MsgServer.class);
	
	private Properties properties;

	public Configure (String filename) {
		properties = new Properties();
		try {
			try {
				properties.load(new FileInputStream(filename));
			} catch (Exception e) {
				properties.load(this.getClass().getResourceAsStream(filename));
			}
		} catch (Exception e) {
			log.error("", e);
			throw new RuntimeException(e);
		}
	}
	
	public String getStringProperty(String key){
		return properties.getProperty(key);
	}
	
	public int getIntProperty(String key){
		try {
			return Integer.parseInt(properties.getProperty(key));
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
	
	public boolean getBooleanProperty(String key){
		try {
			return Boolean.parseBoolean(properties.getProperty(key));
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
}
