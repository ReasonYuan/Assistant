package com.yiyihealth.msgserver.msg.object;

public class SingleChatObject extends ChatObject {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4147749514623261798L;

	private String toUser;
	
	public SingleChatObject(String userId, String message) {
		super(userId, message);
	}
	
	public SingleChatObject(){}
	
    public String getToUser() {
		return toUser;
	}

	public void setToUser(String toUser) {
		this.toUser = toUser;
	}
	
	@Override
	public String getToChannelName() {
		return getEnvirment() + "_" + toUser;
	}

	@Override
	public boolean isSingleChat() {
		return true;
	}
}
