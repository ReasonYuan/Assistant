package com.yiyihealth.msgserver.user;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.redisson.Config;
import org.redisson.Redisson;

import com.yiyihealth.msgserver.Constants;
import com.yiyihealth.msgserver.msg.object.LoginObject;

/**
 * 维护多用户登陆的登陆状态
 * @author xiongchao
 *
 */
public class OnlineDevicesManager {
	
	public static interface OnCheckUserOnlineStatus {
		
		void onCheckUserOnlineStatusFinish(boolean isOnline);
		
	}
	
	private final static String DEVICES_PREFIX = "DEVICES_";
	
	private static OnlineDevicesManager _instance = new OnlineDevicesManager();
	
	/**
	 * 为避免过多redis请求，用固定线程数来处理，2为mac pro开发机测试结果, TODO 提成配置文件
	 */
	private static ExecutorService redisOnlineDeviceService = Executors.newFixedThreadPool(Constants.configure.getIntProperty("redis.threads.onlineregister"));

	private final Redisson redisson;

	private OnlineDevicesManager() {
		Config config = new Config();
		config.useSingleServer().setAddress(Constants.configure.getStringProperty("redis.server.coremsg")).setConnectionPoolSize(1024).setSubscriptionConnectionPoolSize(512);
		redisson = Redisson.create(config);
	}

	public static OnlineDevicesManager getInstance() {
		return _instance;
	}
	
	/**
	 * 是否有至少一个客户端登陆该环境下的账号，只要有一个都不发送推送信息，不录入离线消息队列
	 * @param envirment
	 * @param userid
	 * @return
	 */
	public void isAnyOneClientLogined(final String envirment, final String userid, final OnCheckUserOnlineStatus onCheckUserOnlineStatus){
		redisOnlineDeviceService.execute(new Runnable() {
			@Override
			public void run() {
				onCheckUserOnlineStatus.onCheckUserOnlineStatusFinish(redisson.getSet(DEVICES_PREFIX + envirment + "_" + userid).size() > 0);
			}
		});
	}
	
	public void saveOnDeviceLogin(final LoginObject loginObject){
		redisOnlineDeviceService.execute(new Runnable() {
			@Override
			public void run() {
				redisson.getSet(DEVICES_PREFIX + loginObject.getSessionKey()).add(loginObject);
			}
		});
	}
	
	public void leaveOnDeviceLogout(final LoginObject loginObject){
		redisOnlineDeviceService.execute(new Runnable() {
			@Override
			public void run() {
				redisson.getSet(DEVICES_PREFIX + loginObject.getSessionKey()).remove(loginObject);
			}
		});
	}
}
