package com.yiyihealth.msgserver.msg.object;

public class DeleteGroupObject extends GroupBaseObject {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6376577684820331165L;
	
	@Override
	public String[] getMembersId() {
		throw new RuntimeException("Unimplemented!");
	}
	
	@Override
	public void setMembersId(String[] membersId) {
		throw new RuntimeException("Unimplemented!");
	}
	
}
