package com.yiyihealth.msgserver.msg.object;

import java.io.Serializable;

public class AckError implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6349701945072531766L;
	
	private String errorMessage;
	
	private int errorCode;
	
	public AckError(int code, String message){
		errorCode = code;
		errorMessage = message;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public int getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(int errorCode) {
		this.errorCode = errorCode;
	}
	
	@Override
	protected Object clone() {
		return new AckError(this.errorCode, this.errorMessage);
	}
	
	public AckError cloneAndAppendError(String extraError){
		AckError e = (AckError) this.clone();
		e.errorMessage = e.errorMessage + ", " + extraError;
		return e;
	}
	
}
