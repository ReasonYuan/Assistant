package com.yiyihealth.msgserver.offline;

public class RHistoryMessage {
	
	/**
	 * 谁发送的
	 */
	private String fromUserId;
	
	/**
	 * 是否是群消息
	 */
	private boolean isGroup;
	
	/**
	 * 群组id
	 */
	private String groupId;
	
	/**
	 * 目标者的id, 目标：个人或群
	 */
	private String toUserId;
	
	
	public boolean isGroup() {
		return isGroup;
	}

	public void setGroup(boolean isGroup) {
		this.isGroup = isGroup;
	}

	public String getToUserId() {
		return toUserId;
	}

	public void setToUserId(String destId) {
		this.toUserId = destId;
	}

	public String getFromUserId() {
		return fromUserId;
	}
	
	/**
	 * 由fromUserId + ("_g_" / "_s_") + destId组成
	 * @return
	 */
	public String getMessageId(){
		return fromUserId + (isGroup ? "_g_" : "_s_") + toUserId;
	}

	public String getFromeUserId() {
		return fromUserId;
	}

	public void setFromUserId(String destUserId) {
		this.fromUserId = destUserId;
	}
	
	public String getGroupId() {
		return groupId;
	}

	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
	
}
