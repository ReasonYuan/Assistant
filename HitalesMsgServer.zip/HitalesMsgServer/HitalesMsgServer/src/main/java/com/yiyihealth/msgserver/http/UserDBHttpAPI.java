package com.yiyihealth.msgserver.http;

import java.io.IOException;
import java.nio.charset.Charset;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicHeader;
import org.apache.http.util.EntityUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.yiyihealth.msgserver.Constants;
import com.yiyihealth.msgserver.exception.UserDBHttpException;
import com.yiyihealth.msgserver.msg.error.ErrorCodes;

/**
 * 访问用户关系服务器的http接口
 * @author xiongchao
 *
 */
public class UserDBHttpAPI {
	
	private Log logger = LogFactory.getLog(this.getClass());
	
	//private HttpClient httpClient = null;
	
	private ConcurrentLinkedQueue<HttpClient> clientsIdle = new ConcurrentLinkedQueue<HttpClient>();
	
	private static ConcurrentHashMap<String, UserDBHttpAPI> apis = new ConcurrentHashMap<String, UserDBHttpAPI>();
	
	private String serverPrefix;
	
	/**
	 * release 和 prerelease 需要验证用户安全
	 */
	private boolean isRequiredSession = false;
	
	static {
		for (int i = 0; i < Constants.ENVIRMENTS.length; i++) {
			//create api instance
			UserDBHttpAPI api = new UserDBHttpAPI();
			apis.put(Constants.ENVIRMENTS[i], api);
			//set url prefix
			api.serverPrefix = Constants.prefixs[i];
			api.isRequiredSession = Constants.requiredSession[i];
		}
	}
	
	@SuppressWarnings("deprecation")
	private UserDBHttpAPI(){
	}
	
	private HttpClient createOneClient(){
		HttpClient httpClient = new DefaultHttpClient(); //HttpClientBuilder.create().build();
        SSLSocketFactory sslSocketFactory = MySSLSocketFactory.getFixedSocketFactory();
		httpClient.getConnectionManager().getSchemeRegistry().register(new Scheme("https", sslSocketFactory, 443));
		return httpClient;
	}
	
	private HttpClient getOneIdleHttpClient() {
		HttpClient c = clientsIdle.poll();
		if (c == null) {
			return createOneClient();
		} else {
			return c;
		}
	}
	
	/**
	 * 由于服务器支持不同的环境，所以必须提供环境来访问用户关系数据：development, test, prerelease, release
	 * @param envirment
	 * @return
	 */
	public static UserDBHttpAPI getHttpAPI(String envirment){
		return apis.get(envirment);
	}
	
	/**
	 * 发送post数据，有任何错误或返回值不合法，均抛出异常
	 * @param uri
	 * @param parameters
	 * @param headers
	 * @return
	 * @throws Exception
	 */
	public JSONObject post(String uri, String parameters, BasicHeader... headers) throws UserDBHttpException {
		HttpPost method = new HttpPost(serverPrefix + uri);
		if (method != null & parameters != null && !"".equals(parameters.trim())) {
			HttpClient httpClient = null;
			try {
				// 建立一个NameValuePair数组，用于存储欲传送的参数
				method.addHeader("Content-type", "application/json; charset=utf-8");
				method.setHeader("Accept", "application/json");
				
				method.setEntity(new StringEntity(parameters, Charset.forName("UTF-8")));
				if (headers != null && headers.length > 0) {
					for (int i = 0; i < headers.length; i++) {
						method.addHeader(headers[i]);
					}
				}
				long startTime = System.currentTimeMillis();

				httpClient = getOneIdleHttpClient();
				HttpResponse response = httpClient.execute(method);
				
				long endTime = System.currentTimeMillis();
				int statusCode = response.getStatusLine().getStatusCode();

				logger.info("statusCode:" + statusCode);
				logger.info("调用API " + uri + " 花费时间(单位：毫秒)：" + (endTime - startTime));
				if (statusCode != HttpStatus.SC_OK) {
					logger.error("Method failed:" + response.getStatusLine());
				} else if (statusCode == HttpStatus.SC_INTERNAL_SERVER_ERROR) {
					//do nothing, maybe later have to handle error
				}

				// Read the response body
				String body = EntityUtils.toString(response.getEntity(), "utf-8");
				
				JSONObject json = JSON.parseObject(body);
				
				if (json.getIntValue("response_code") != 0) {
					throw new UserDBHttpException("访问userdb server出错: " + json.getString("msg"));
				} else {
					if(uri.indexOf("/users/login.do") >= 0){
						String accessToken = response.getFirstHeader("accessToken").getValue();
						logger.info("accessToken: " + accessToken);
						json.put("accessToken", accessToken);
					}
				}
				
				return json;
			} catch (IOException e) {
				logger.error("http error", e);
				// 网络错误
				//status = 3;
				throw new UserDBHttpException(ErrorCodes.MSG_USERDB_HTTP_ERROR, "Unknown exception, http call not excuted!");
			} catch (Exception e) {
				logger.error("http error", e);
				// 网络错误
				//status = 3;
				throw new UserDBHttpException(ErrorCodes.MSG_USERDB_HTTP_ERROR, e.toString());
			} finally {
				//logger.info("调用接口状态：" + status);
				if (httpClient != null) {
					clientsIdle.add(httpClient);
				}
			}

		}
		throw new UserDBHttpException("Unknown exception, http call not excuted!");
	}

	public boolean isRequiredSession() {
		return isRequiredSession;
	}
	
	
}

//备查
//method.addHeader("Content-type", "application/json; charset=utf-8");
//method.addHeader("uuid", "43A082F2-DB5C-4A11-BBBA-7BEDB14FFA31");
//method.addHeader("userid", "40");
//long timestamp = 1442212193853L; //System.currentTimeMillis() + 24*60*60*1000;
//accessToken = "2507afe17c33b983e3a3b906a428af54";
//method.addHeader("Expires", "" + timestamp);
//String sessionAuth = "YIYI40%3Adr9EKvJfpEbJ2Ch6LwwcYPlQYiA%3D%0A"; //URLEncoder.encode(new HMACSHA1_Android().getSessionSignature(accessToken, "40", "POST", timestamp, uri));
//method.addHeader("Authorization", sessionAuth);
