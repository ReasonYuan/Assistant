package com.yiyihealth.msgserver.db;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.yiyihealth.msgserver.exception.UserRDBException;
import com.yiyihealth.msgserver.helper.GroupHelper;
import com.yiyihealth.msgserver.http.UserDBHttpAPI;
import com.yiyihealth.msgserver.msg.object.LoginObject;

import io.netty.util.internal.ConcurrentSet;
import sun.util.logging.resources.logging;

/**
 * 利用redis缓存用户关系，仅第一次访问群信息时才读取远程服务器, 写操作
 * @author xiongchao
 *
 */
public class HitalesUserRelationshipDB implements UserRelationshipDB {
	
	private static final String URI_EDIT_CREATE_GROUP = "/group/add_members.do";
	private static final String URI_DISMISS_GROUP = "/group/dimiss_group.do";
	private static final String URI_LIST_GROUP_MEMBERS = "/group/select_group.do";
	
	private int[] strArr2IntArr(String[] strArr){
		int[] res = new int[strArr.length];
		for (int i = 0; i < res.length; i++) {
			res[i] = Integer.parseInt(strArr[i]);
		}
		return res;
	}
	
	private static HitalesUserRelationshipDB _instance = null;
	
	public static HitalesUserRelationshipDB getInstance() {
		if (_instance == null) {
			_instance = new HitalesUserRelationshipDB();
		}
		return _instance;
	}

	@Override
	public void createGroup(LoginObject session, String envirment, String userid, String groupName, String cgroupId, String... memberIds)
			throws UserRDBException {
		UserDBHttpAPI api = UserDBHttpAPI.getHttpAPI(envirment);
		//创建群
		HashMap<String, Object> jsonJava = new HashMap<String, Object>();
		jsonJava.put("creater_id", Integer.parseInt(userid));
		jsonJava.put("cgroup_id", cgroupId);
		jsonJava.put("add_user_ids", strArr2IntArr(memberIds));
		jsonJava.put("group_name", groupName);
		api.post(URI_EDIT_CREATE_GROUP, JSON.toJSONString(jsonJava), session.toSessionHeaders(URI_EDIT_CREATE_GROUP));
		//缓存, 如果上面步骤出错，一定抛出异常
		RedisUserRelCacheDB urdb = RedisUserRelCacheDB.getInstance();
		urdb.createGroup(session, envirment, userid, groupName, cgroupId, memberIds);
	}

	@Override
	public void deleteGroup(LoginObject session, String envirment, String userid, String cgroupId) throws UserRDBException {
		UserDBHttpAPI api = UserDBHttpAPI.getHttpAPI(envirment);
		//删除群
		HashMap<String, Object> jsonJava = new HashMap<String, Object>();
		jsonJava.put("creater_id", Integer.parseInt(userid));
		jsonJava.put("cgroup_id", cgroupId);
		api.post(URI_DISMISS_GROUP, JSON.toJSONString(jsonJava), session.toSessionHeaders(URI_DISMISS_GROUP));
		//删除缓存
		RedisUserRelCacheDB urdb = RedisUserRelCacheDB.getInstance();
		urdb.deleteGroup(session, envirment, userid, cgroupId);
	}

	@Override
	public void quitGroup(LoginObject session, String envirment, String userid, String useridToQuit, String cgroupdId)
			throws UserRDBException {
		UserDBHttpAPI api = UserDBHttpAPI.getHttpAPI(envirment);
		//退出群
		HashMap<String, Object> jsonJava = new HashMap<String, Object>();
		jsonJava.put("user_id", Integer.parseInt(userid));
		jsonJava.put("cgroup_id", cgroupdId);
		jsonJava.put("remove_user_ids", new int[]{Integer.parseInt(useridToQuit)});
		api.post(URI_EDIT_CREATE_GROUP, JSON.toJSONString(jsonJava), session.toSessionHeaders(URI_EDIT_CREATE_GROUP));
		//退出缓存
		RedisUserRelCacheDB urdb = RedisUserRelCacheDB.getInstance();
		urdb.quitGroup(session, envirment, userid, useridToQuit, cgroupdId);
	}

	@Override
	public void addMember(LoginObject session, String envirment, String userid, String cgroupId, String... memberIds)
			throws UserRDBException {
		UserDBHttpAPI api = UserDBHttpAPI.getHttpAPI(envirment);
		//添加成员
		HashMap<String, Object> jsonJava = new HashMap<String, Object>();
		jsonJava.put("user_id", Integer.parseInt(userid));
		jsonJava.put("cgroup_id", cgroupId);
		jsonJava.put("add_user_ids", strArr2IntArr(memberIds));
		api.post(URI_EDIT_CREATE_GROUP, JSON.toJSONString(jsonJava), session.toSessionHeaders(URI_EDIT_CREATE_GROUP));
		//添加缓存
		RedisUserRelCacheDB urdb = RedisUserRelCacheDB.getInstance();
		urdb.addMember(session, envirment, userid, cgroupId, memberIds);
	}

	@Override
	public void removeMember(LoginObject session, String envirment, String userid, String cgroupId, String... memberIds)
			throws UserRDBException {
		UserDBHttpAPI api = UserDBHttpAPI.getHttpAPI(envirment);
		//删除群成员
		HashMap<String, Object> jsonJava = new HashMap<String, Object>();
		jsonJava.put("creater_id", Integer.parseInt(userid));
		jsonJava.put("cgroup_id", cgroupId);
		jsonJava.put("remove_user_ids", strArr2IntArr(memberIds));
		api.post(URI_EDIT_CREATE_GROUP, JSON.toJSONString(jsonJava), session.toSessionHeaders(URI_EDIT_CREATE_GROUP));
		//删除缓存
		RedisUserRelCacheDB urdb = RedisUserRelCacheDB.getInstance();
		urdb.removeMember(session, envirment, userid, cgroupId, memberIds);
	}

	@Override
	public List<Member> listMembers(LoginObject session, String envirment, String userid, String cgroupId) throws UserRDBException {
		RedisUserRelCacheDB urdb = RedisUserRelCacheDB.getInstance();
		List<Member> members = null;
		try {
			members = urdb.listMembers(session, envirment, userid, cgroupId);
			if (members.size() > 0) {
				//TODO 这里不能靠groups.size()判断是否已经缓存
				return members;
			}
		} catch (Exception e) {
			//这里不做任何处理，因为第一次一定抛出异常
			members = new ArrayList<Member>();
		}
		//请求远程
		UserDBHttpAPI api = UserDBHttpAPI.getHttpAPI(envirment);
		HashMap<String, Object> jsonJava = new HashMap<String, Object>();
		jsonJava.put("cgroup_id", cgroupId);
		JSONObject result = api.post(URI_LIST_GROUP_MEMBERS, JSON.toJSONString(jsonJava), session.toSessionHeaders(URI_LIST_GROUP_MEMBERS));
		JSONArray gsJson = result.getJSONArray("results");
		List<Group> groups = convertGroupJsonAndDoCache(session, envirment, userid, gsJson);
		if (groups.size() != 1) {
			throw new UserRDBException("用groupid：" + cgroupId + "查出的群个数不对，应该是唯一一个，实际是：" + groups.size());
		}
		return new ArrayList<Member>(groups.get(0).getMembers());
	}

	@Override
	public List<Group> listGroups(LoginObject session, String envirment, String userid) throws UserRDBException {
		RedisUserRelCacheDB urdb = RedisUserRelCacheDB.getInstance();
		List<Group> groups = urdb.listGroups(session, envirment, userid);
		if (groups.size() > 0) {
			//TODO 这里不能靠groups.size()判断是否已经缓存
			return groups;
		}
		UserDBHttpAPI api = UserDBHttpAPI.getHttpAPI(envirment);
		HashMap<String, Object> jsonJava = new HashMap<String, Object>();
		jsonJava.put("user_id", Integer.parseInt(userid));
		JSONObject result = api.post(URI_LIST_GROUP_MEMBERS, JSON.toJSONString(jsonJava), session.toSessionHeaders(URI_LIST_GROUP_MEMBERS));
		JSONArray gsJson = result.getJSONArray("results");
		return convertGroupJsonAndDoCache(session, envirment, userid, gsJson);
	}
	
	private List<Group> convertGroupJsonAndDoCache(LoginObject session, String envirment, String userid, JSONArray gsJson) throws UserRDBException {
		List<Group> groups = new ArrayList<Group>();
		for (int i = 0; i < gsJson.size(); i++) {
			JSONObject js = gsJson.getJSONObject(i);
			//TODO 这个updateTime时间可以由底层服务器提供
			Group g = new Group(js.getString("user_id"), js.getString("group_name"), js.getString("cgroup_id"), System.currentTimeMillis());
			JSONArray usersJson = js.getJSONArray("group_users");
			if (usersJson != null) {
				for (int j = 0; j < usersJson.size(); j++) {
					String uid = Integer.toString(usersJson.getJSONObject(j).getIntValue("user_id"));
					Member m = new Member();
					m.setUserid(uid);
					g.getMembers().add(m);
				}
				if (usersJson.size() > 0) {
					GroupHelper.fillUserInfos(session, g.getMembers(), envirment, userid);
				}
			}
			groups.add(g);
			//缓存起来
			RedisUserRelCacheDB urdb = RedisUserRelCacheDB.getInstance();
			urdb.createGroup(session, envirment, userid, g.getGroupName(), g.getCgroupId(), g.toMemberIds());
		}
		return groups;
	}

	@Override
	public Group findGroup(LoginObject session, String envirment, String userid, String cgroupId) throws UserRDBException {
		try {
			return RedisUserRelCacheDB.getInstance().findGroup(session, envirment, userid, cgroupId);
		} catch (Exception e) {
			//缓存里找不到，没有关系，下面去远程服务器
		}
		//请求远程
		UserDBHttpAPI api = UserDBHttpAPI.getHttpAPI(envirment);
		HashMap<String, Object> jsonJava = new HashMap<String, Object>();
		jsonJava.put("cgroup_id", cgroupId);
		JSONObject result = api.post(URI_LIST_GROUP_MEMBERS, JSON.toJSONString(jsonJava), session.toSessionHeaders(URI_LIST_GROUP_MEMBERS));
		JSONArray gsJson = result.getJSONArray("results");
		List<Group> groups = convertGroupJsonAndDoCache(session, envirment, userid, gsJson);
		if (groups.size() != 1) {
			throw new UserRDBException("用groupid：" + cgroupId + "查出的群个数不对，应该是唯一一个，实际是：" + groups.size());
		}
		List<Member> members = new ArrayList<Member>(groups.get(0).getMembers());
		Group group = new Group();
		ConcurrentSet<Member> ms = new ConcurrentSet<Member>();
		ms.addAll(members);
		group.setMembers(ms);
		
		//缓存起来
		RedisUserRelCacheDB.getInstance().createGroup(session, envirment, userid, group.getGroupName(), cgroupId, group.toMemberIds());
		
		return group;
	}

	@Override
	public void modifyGroupName(LoginObject session, String envirment, String userid, String cgroupId, String groupName)
			throws UserRDBException {
		// 创建群
		UserDBHttpAPI api = UserDBHttpAPI.getHttpAPI(envirment);
		HashMap<String, Object> jsonJava = new HashMap<String, Object>();
		jsonJava.put("user_id", Integer.parseInt(userid));
		jsonJava.put("cgroup_id", cgroupId);
		jsonJava.put("group_name", groupName);
		api.post(URI_EDIT_CREATE_GROUP, JSON.toJSONString(jsonJava), session.toSessionHeaders(URI_EDIT_CREATE_GROUP));
		
		//修改缓存
		try {
			RedisUserRelCacheDB.getInstance().modifyGroupName(session, envirment, userid, cgroupId, groupName);
		} catch (Exception e) {
			//可能还没有缓存，所以忽略异常
		}
	}

}
