package com.yiyihealth.msgserver.msg.object;

import java.io.Serializable;

import com.alibaba.fastjson.JSON;

public class UpdateClientGroup implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public static enum UpdateCmd {
		ADD_GROUP,
		DELETE_GROUP,
		UPDATE_GROUP,
		UPDATE_ALL_FINISH
	}
	
	private UpdateCmd updateCmd;
	
	private Serializable groupInfo;

	public UpdateCmd getUpdateCmd() {
		return updateCmd;
	}

	public void setUpdateCmd(UpdateCmd updateCmd) {
		this.updateCmd = updateCmd;
	}

	public Serializable getGroupInfo() {
		return groupInfo;
	}

	public void setGroupInfo(Serializable group) {
		this.groupInfo = group;
	}
	
	@Override
	public String toString() {
		return JSON.toJSONString(this);
	}
	
}
