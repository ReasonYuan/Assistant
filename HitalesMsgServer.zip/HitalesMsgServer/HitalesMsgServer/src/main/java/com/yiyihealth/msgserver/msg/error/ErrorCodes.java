package com.yiyihealth.msgserver.msg.error;

import com.yiyihealth.msgserver.msg.object.AckError;

public class ErrorCodes {
	
	//每一个模块分配100个长度，共计不能超过20个模块
	private static final AckError[] ackErrors = new AckError[2000];
	public static AckError getAckError(int code){
		return ackErrors[code];
	}
	//模块1：全局
	public static final int MSG_NO_VALID_SESSION = 001;
	public static final int MSG_USERDB_HTTP_ERROR = 002;
	static {
		ackErrors[MSG_NO_VALID_SESSION] = new AckError(MSG_NO_VALID_SESSION, "用户未登录或非法访问!");
		ackErrors[MSG_USERDB_HTTP_ERROR] = new AckError(MSG_USERDB_HTTP_ERROR, "访问用户数据服务器出错!");
	}

	//模块2：群组
	public static final int MSG_GROUP_EXISTS = 101;
	public static final int MSG_GROUP_HITALES_DB_ERROR = 102;
	static {
		ackErrors[MSG_GROUP_EXISTS] = new AckError(MSG_GROUP_EXISTS, "群组已经存在，创建失败!");
		ackErrors[MSG_GROUP_HITALES_DB_ERROR] = new AckError(MSG_GROUP_HITALES_DB_ERROR, "调用Hitales用户关系接口创建群组错误!");
	}
}
