package com.yiyihealth.msgserver.msg.object;

import java.io.Serializable;

import com.alibaba.fastjson.JSON;

public class GroupBaseObject implements Serializable {
	
	private static String[] EMPTY = {};

	/**
	 * 
	 */
	private static final long serialVersionUID = -2772424399102989861L;

	private String userid;

	private String[] membersId;
	
	private String groupID;

	public String getGroupID() {
		return groupID;
	}

	public void setGroupID(String groupID) {
		this.groupID = groupID;
	}
	
	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String[] getMembersId() {
		if(membersId == null){
			return EMPTY;
		}
		return membersId;
	}

	public void setMembersId(String[] membersId) {
		this.membersId = membersId;
	}
	
	@Override
	public String toString() {
		return JSON.toJSONString(this);
	}
}
