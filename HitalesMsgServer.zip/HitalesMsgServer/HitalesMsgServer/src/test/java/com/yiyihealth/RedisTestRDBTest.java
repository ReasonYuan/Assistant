package com.yiyihealth;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.List;
import java.util.function.Consumer;

import org.junit.Test;

import com.yiyihealth.msgserver.db.Group;
import com.yiyihealth.msgserver.db.Member;
import com.yiyihealth.msgserver.db.RedisUserRelCacheDB;
import com.yiyihealth.msgserver.msg.object.LoginObject;

public class RedisTestRDBTest {
	
	private LoginObject session;

	@Test
	public void testCreateGroup() {
		RedisUserRelCacheDB rrdb = RedisUserRelCacheDB.getInstance();
		try {
			rrdb.deleteGroup(session, "test", "123", "c12322");
			rrdb.createGroup(session, "test", "123", "gname123", "c12322", new String[]{"m2"});
			assertTrue(rrdb.listGroups(session, "test", "123").size() > 0);
		} catch (Exception e) {
			fail(e.getMessage());
		}
	}

	@Test
	public void testDeleteGroup() {
		try {
			String myUserId = "111123";
			String cgGroupId = "c123";
			RedisUserRelCacheDB rrdb = RedisUserRelCacheDB.getInstance();
			rrdb.deleteGroup(session, "test", myUserId, cgGroupId);
			int gsize1 = rrdb.listGroups(session, "test", myUserId).size();
			rrdb.createGroup(session, "test", myUserId, "gname123", cgGroupId, new String[]{"m1", "ppp"});
			assertTrue(rrdb.listMembers(session, "test", myUserId, cgGroupId).size() == 3);
			int gsize2 = rrdb.listGroups(session, "test", myUserId).size();
			assertTrue(gsize2 - gsize1 == 1);
			rrdb.deleteGroup(session, "test", myUserId, cgGroupId);
			int gsize3 = rrdb.listGroups(session, "test", cgGroupId).size();
			assertTrue(gsize3 - gsize2 == -1);
		} catch (Exception e) {
			fail(e.getMessage());
		}
	}

	@Test
	public void testAddMember() {
		try {
			final String myUserId = "111140";
			final String groupId = "c1112";
			RedisUserRelCacheDB rrdb = RedisUserRelCacheDB.getInstance();
			rrdb.deleteGroup(session, "test", myUserId, groupId);
			rrdb.createGroup(session, "test", myUserId, "gname111", groupId, new String[]{"m3","m4"});
			String midToAdd = "memberid1";
			rrdb.addMember(session, "test", myUserId, groupId, midToAdd);
			List<Member> ms = rrdb.listMembers(session, "test", myUserId, groupId);
			boolean found = false;
			for (int i = 0; i < ms.size(); i++) {
				if (ms.get(i).getUserid().equals(midToAdd)) {
					found = true;
					break;
				}
			}
			assertTrue(found);
		} catch (Exception e) {
			e.printStackTrace();
			fail(e.getMessage());
		}
	}

	@Test
	public void testRemoveMember() {
		try {
			final String myUserId = "111112";
			final String groupId = "c1112";
			RedisUserRelCacheDB rrdb = RedisUserRelCacheDB.getInstance();
			rrdb.deleteGroup(session, "test", myUserId, groupId);
			rrdb.createGroup(session, "test", myUserId, "gname111", groupId, new String[]{"m3","m4"});
			rrdb.addMember(session, myUserId, myUserId, groupId, "m1");
			rrdb.addMember(session, myUserId, myUserId, groupId, "m222");
			rrdb.removeMember(session, "test", myUserId, groupId, new String[]{"m222"});
			final boolean[] foundGroup = {false, false};
			rrdb.listGroups(session, "test", myUserId).forEach(new Consumer<Group>() {
				@Override
				public void accept(Group t) {
					if(t.getUserid().equals(myUserId) && t.getGroupName().equals("gname111") && t.getCgroupId().equals(groupId)){
						foundGroup[0] = true;
						Member mb = new Member("m1");
						for(Member m : t.getMembers()){
							if (m.equals(mb)) {
								foundGroup[1] = true;
							}
						}
					}
				}
			});
			assertTrue(foundGroup[0]);
			assertTrue(foundGroup[1]);
			rrdb.deleteGroup(session, "test", myUserId, groupId);
		} catch (Exception e) {
			e.printStackTrace();
			fail(e.getMessage());
		}
	}

	@Test
	public void testListMembers() {
	}

	@Test
	public void testListGroups() {
	}
	
	@Test
	public void testQuitGroup() {
		
	}

}
