package com.yiyihealth;

import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.Test;

import com.yiyihealth.msgserver.msg.object.ChatObject;
import com.yiyihealth.msgserver.msg.object.SingleChatObject;
import com.yiyihealth.msgserver.offline.RedisOfflineMessageManager;
import com.yiyihealth.msgserver.offline.RedisOfflineMessageManager.OfflinePullCallbck;

public class RedisOfflineMessageManagerTest {

	@Test
	public void testAddMessage() {
		RedisOfflineMessageManager messageManager = RedisOfflineMessageManager.getInstance();
		messageManager.getRedisson().delete("hitales_123");
		
		SingleChatObject msg = new SingleChatObject();
		//必须设置id,否则redis会报错
		msg.setUserid("hitales_123");
		msg.setToUser("to_123_id");
		msg.setEnvirment("test");
		messageManager.addMessage(msg);
	}

	@Test
	public void testPullOfflineMessage() {
		testAddMessage();
		SingleChatObject msg = new SingleChatObject();
		//必须设置id,否则redis会报错
		msg.setUserid("hitales_123");
		msg.setToUser("to_123_id");
		msg.setEnvirment("test");
		RedisOfflineMessageManager messageManager = RedisOfflineMessageManager.getInstance();
		messageManager.pullOfflineMessage(msg.getUserid(), msg.getToChannelName(), new OfflinePullCallbck() {
			@Override
			public void onOfflineMsgPullFinish(List<ChatObject> msgs) {
				Object obj = msgs.get(0);
				assertTrue(obj != null);
			}
		});
		
	}

}
