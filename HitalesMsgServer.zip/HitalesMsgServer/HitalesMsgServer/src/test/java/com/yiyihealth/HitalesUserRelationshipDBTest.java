package com.yiyihealth;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.List;

import org.apache.http.message.BasicHeader;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.alibaba.fastjson.JSONObject;
import com.yiyihealth.msgserver.db.Group;
import com.yiyihealth.msgserver.db.HitalesUserRelationshipDB;
import com.yiyihealth.msgserver.db.Member;
import com.yiyihealth.msgserver.helper.AeSimpleSHA1;
import com.yiyihealth.msgserver.helper.FQSecuritySession;
import com.yiyihealth.msgserver.http.UserDBHttpAPI;
import com.yiyihealth.msgserver.msg.object.LoginObject;

public class HitalesUserRelationshipDBTest {
	
	private static final String user_id = "40";
	private static final String ENVIRMENT = "test";
	private HitalesUserRelationshipDB db;
	private String groupId = "test_" + System.currentTimeMillis();
	
	private String uuid = "any_uuid" + System.currentTimeMillis();
	
	private LoginObject session = new LoginObject();

	@Before
	public void setUp() throws Exception {
		db = new HitalesUserRelationshipDB();
		String pw = AeSimpleSHA1.repeat20TimesAndSHA1("123qwe");
		String searchUserInfo = "{\"username\":\"18008056392\",\"pass_word\":\""+pw+"\",\"role_type\":1}";
		try {
			BasicHeader[] headers = {
					new BasicHeader("uuid", uuid),
					new BasicHeader("client_type", "2"),
					new BasicHeader("client_version", "1.3.0")
			};
			UserDBHttpAPI api = UserDBHttpAPI.getHttpAPI(ENVIRMENT);
			JSONObject result = api.post("/users/login.do", searchUserInfo, headers);
			FQSecuritySession securitySession = new FQSecuritySession();
			securitySession.setAccessToken(result.getString("accessToken"));
			session.setUserid("" + result.getJSONObject("results").getInteger("user_id"));
			session.setUuid(uuid);
		} catch (Exception e) {
			e.printStackTrace();
			fail(e.toString());
		}
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testCreateGroup() {
		try {
			db.createGroup(session, ENVIRMENT, user_id, "test group name", groupId, new String[]{"3", "23", "12", "24"});
		} catch (Exception e) {
			e.printStackTrace();
			fail("testCreateGroup failed!");
		}
	}

	@Test
	public void testDeleteGroup() {
		try {
			testCreateGroup();
			db.deleteGroup(session, ENVIRMENT, user_id, groupId);
		} catch (Exception e) {
			e.printStackTrace();
			fail("testDeleteGroup failed!");
		}
	}

	@Test
	public void testQuitGroup() {
		try {
			groupId = "test_g_" + System.currentTimeMillis();
			testCreateGroup();
			db.quitGroup(session, ENVIRMENT, user_id, "3", groupId);
		} catch (Exception e) {
			e.printStackTrace();
			fail("testQuitGroup failed!");
		}
	}

	@Test
	public void testAddMember() {
		try {
			groupId = "test_g_" + System.currentTimeMillis();
			testCreateGroup();
			db.addMember(session, ENVIRMENT, user_id, groupId, new String[]{"234", "344"});
		} catch (Exception e) {
			e.printStackTrace();
			fail("testAddMember failed!");
		}
	}

	@Test
	public void testRemoveMember() {
		try {
			groupId = "test_g_" + System.currentTimeMillis();
			testCreateGroup();
			db.removeMember(session, ENVIRMENT, user_id, groupId, new String[]{"40", "24"});
		} catch (Exception e) {
			e.printStackTrace();
			fail("testRemoveMember failed!");
		}
	}

	@Test
	public void testListMembers() {
		try {
			testCreateGroup();
			List<Member> members = db.listMembers(session, ENVIRMENT, user_id, groupId);
			assertTrue(members.size() > 0);
		} catch (Exception e) {
			e.printStackTrace();
			fail("testListMembers failed!");
		}
	}

	@Test
	public void testListGroups() {
		try {
			testCreateGroup();
			List<Group> groups = db.listGroups(session, ENVIRMENT, user_id);
			assertTrue(groups.size() > 0);
		} catch (Exception e) {
			e.printStackTrace();
			fail("testListMembers failed!");
		}
	}

}
