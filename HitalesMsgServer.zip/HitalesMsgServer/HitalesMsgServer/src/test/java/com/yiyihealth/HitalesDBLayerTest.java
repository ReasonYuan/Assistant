package com.yiyihealth;

import java.util.ArrayList;

import org.apache.http.message.BasicHeader;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.alibaba.fastjson.JSONObject;
import com.yiyihealth.msgserver.Constants;
import com.yiyihealth.msgserver.helper.AeSimpleSHA1;
import com.yiyihealth.msgserver.helper.FQSecuritySession;
import com.yiyihealth.msgserver.http.UserDBHttpAPI;

import junit.framework.TestCase;

public class HitalesDBLayerTest extends TestCase {
	
	private UserDBHttpAPI api;
	private String testUserid = "40";
	//服务器不支持删除的群id重新创建
	private String testGroupId;
	
	private JSONObject loginJson;
	
	private String uuid;
	
	private boolean needSession = false;

	@Before
	protected void setUp() throws Exception {
		super.setUp();
		
		//不同的环境参数修改以下2行
		needSession = true;
		api = UserDBHttpAPI.getHttpAPI(Constants.ENV_RELEASE);
		
		uuid = "uuid_40";// + System.currentTimeMillis();
		testGroupId = "testgroupid_1234_" + System.currentTimeMillis() ;
		testLogin();
	}

	@After
	protected void tearDown() throws Exception {
		super.tearDown();
	}

	@Test
	public void testCreateGroup() {
		String createGroup = "{\"creater_id\":"+testUserid+",\"cgroup_id\":\""+testGroupId+"\",\"add_user_ids\":[2,3,4],\"group_name\":\"di yige group2\"}";
		try {
			final String uri = "/group/add_members.do";
			JSONObject result = api.post(uri, createGroup, getSessionHeaders(uri));
			assertEquals(0, result.getIntValue("response_code"));
		} catch (Exception e) {
			e.printStackTrace();
			fail(e.toString());
		}
	}

	@Test
	public void testDeleteGroup() {
		testCreateGroup();
		String deleteGroup = "{\"creater_id\":"+testUserid+",\"cgroup_id\":\""+testGroupId+"\"}";
		try {
			String uri = "/group/dimiss_group.do";
			JSONObject result = api.post(uri, deleteGroup, getSessionHeaders(uri));
			assertEquals(0, result.getIntValue("response_code"));
		} catch (Exception e) {
			e.printStackTrace();
			fail(e.toString());
		}
	}

	@Test
	public void testQuitGroup() {
		testCreateGroup();
		String quitGroup = "{\"creater_id\":"+testUserid+",\"cgroup_id\":\""+testGroupId+"\",\"remove_user_ids\":[2,3]}";
		try {
			String uri = "/group/add_members.do";
			JSONObject result = api.post(uri, quitGroup, getSessionHeaders(uri));
			assertEquals(0, result.getIntValue("response_code"));
		} catch (Exception e) {
			e.printStackTrace();
			fail(e.toString());
		}
	}

	@Test
	public void testAddMember() {
		testDeleteGroup();
		testCreateGroup();
		String addMembers = "{\"cgroup_id\":\""+testGroupId+"\",\"add_user_ids\":[10,34]}";
		try {
			String uri = "/group/add_members.do";
			JSONObject result = api.post(uri, addMembers, getSessionHeaders(uri));
			assertEquals(0, result.getIntValue("response_code"));
		} catch (Exception e) {
			e.printStackTrace();
			fail(e.toString());
		}
		testDeleteGroup();
		addMembers = "{\"cgroup_id\":\""+testGroupId+"\",\"add_user_ids\":[10,34]}";
		try {
			String uri = "/group/add_members.do";
			JSONObject result = api.post(uri, addMembers, getSessionHeaders(uri));
			//TODO 这里服务器应该返回错误码，但Gary返回了正确码
			assertEquals(0, result.getIntValue("response_code"));
		} catch (Exception e) {
			e.printStackTrace();
			fail(e.toString());
		}
	}

	@Test
	public void testRemoveMember() {
		testDeleteGroup();
		testCreateGroup();
		String addMembers = "{\"cgroup_id\":\""+testGroupId+"\",\"remove_user_ids\":[2,3]}";
		try {
			String uri = "/group/add_members.do";
			JSONObject result = api.post(uri, addMembers, getSessionHeaders(uri));
			assertEquals(0, result.getIntValue("response_code"));
		} catch (Exception e) {
			e.printStackTrace();
			fail(e.toString());
		}
	}

	@Test
	public void testListMembers() {
		testDeleteGroup();
		//服务器不支持删除的群id重新创建
		testGroupId += System.currentTimeMillis();
		testCreateGroup();
		String addMembers = "{\"cgroup_id\":\""+testGroupId+"\"}";
		try {
			String uri = "/group/select_group.do";
			JSONObject result = api.post(uri, addMembers, getSessionHeaders(uri));
			assertEquals(0, result.getIntValue("response_code"));
			assertTrue(result.getJSONArray("results").size() > 0);
		} catch (Exception e) {
			e.printStackTrace();
			fail(e.toString());
		}
	}
	
	@Test
	public void testFillUserInfo(){
		testCreateGroup();
		String searchUserInfo = "{\"user_id\":"+40+", \"my_user_id\":1}";
		try {
			String uri = "/users/search_by_userid.do";
			JSONObject result = api.post(uri, searchUserInfo, getSessionHeaders(uri));
			assertEquals(0, result.getIntValue("response_code"));
			assertTrue(result.getJSONObject("results").getInteger("image_id") >= 0);
			assertTrue(result.getJSONObject("results").getString("name").length() >= 0);
		} catch (Exception e) {
			e.printStackTrace();
			fail(e.toString());
		}
	}

	@Test 
	public void testLogin(){
		///users/login.do
		String pw = AeSimpleSHA1.repeat20TimesAndSHA1("123qwe");
		String searchUserInfo = "{\"username\":\"18008056392\",\"pass_word\":\""+pw+"\",\"role_type\":1}";
		try {
			String uri = "/users/login.do";
			BasicHeader[] headers = {
					new BasicHeader("uuid", uuid),
					new BasicHeader("client_type", "2"),
					new BasicHeader("client_version", "1.3.0")
			};
			JSONObject result = api.post(uri, searchUserInfo, headers);
			assertEquals(0, result.getIntValue("response_code"));
			loginJson = result;
		} catch (Exception e) {
			e.printStackTrace();
			fail(e.toString());
		}
	}
	
	private BasicHeader[] getSessionHeaders(String uri){
		if (!needSession || loginJson == null) {
			return new BasicHeader[0];
		}
		FQSecuritySession securitySession = new FQSecuritySession();
		securitySession.setAccessToken(loginJson.getString("accessToken"));
		ArrayList<BasicHeader> headers = null;
		if (api.isRequiredSession()) {
			headers = securitySession.getSessionHeaders("40", uri, "POST");
		} else {
			headers = new ArrayList<BasicHeader>();
		}
		headers.add(new BasicHeader("uuid", uuid));
		BasicHeader[] hs = new BasicHeader[headers.size()];
		for (int i = 0; i < hs.length; i++) {
			hs[i] = headers.get(i);
		}
		return hs;
	}
	
	@Test
	public void testHomeAPI() {
		///home/get_patient_record_count.do
		String homeInfo = "{\"user_id\":40}";
		try {
			String uri = "/home/get_patient_record_count.do";
			
			JSONObject result = api.post(uri, homeInfo, getSessionHeaders(uri));
			assertEquals(0, result.getIntValue("response_code"));
			
		} catch (Exception e) {
			e.printStackTrace();
			fail(e.toString());
		}
	}
	
	@Test 
	public void testQueryUserInfos(){
		String searchUserInfo = "{\"user_ids\":[1,2,3]}";
		try {
			String uri = "/users/select_name_image.do";
			JSONObject result = api.post(uri, searchUserInfo, getSessionHeaders(uri));
			assertEquals(0, result.getIntValue("response_code"));
		} catch (Exception e) {
			e.printStackTrace();
			fail(e.toString());
		}
	}
}
