/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 */
'use strict';

var React = require('react-native');
var {
  AppRegistry,
  StyleSheet,
  Text,
  View,
  Navigator,
  Platform,
} = React;
var MainPage = require('./jssrc/pages/MainPage')

// var Screen = require('Dimensions').get('window');
// let TARGET_WIDTH = Screen.width;

var ReactNativeWebExample = React.createClass({
  render: function() {
    return ( <Navigator
    initialRoute={{}}
    renderScene={(route, navigator) => {
      if(route.component){
        return  route.component;
      }else{
        return (<MainPage navigator = {navigator}/>);
      }
    }
    }
    configureScene = {(route, routeStack) =>
      {
        return Navigator.SceneConfigs.HorizontalSwipeJump;
      }
    }

  />);

  }
});

var styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5FCFF',
  },
  welcome: {
    fontSize: 20,
    textAlign: 'center',
    margin: 10,
  },
  instructions: {
    textAlign: 'center',
    color: '#333333',
    marginBottom: 5,
  },
});

AppRegistry.registerComponent('ReactNativeWebExample', () => ReactNativeWebExample);


if(Platform.OS == 'web'){
  var app = document.createElement('div');
  document.body.appendChild(app);

  AppRegistry.runApplication('ReactNativeWebExample', {
    rootTag: app
  })
}
