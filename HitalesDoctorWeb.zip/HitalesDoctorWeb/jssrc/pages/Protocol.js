'use strict';

var React = require('react-native')
var BaseComponent = require('./BaseComponent');
var ProtocolPage1 = require('./ProtocolPage1');
var{w,h,screenWidth,screenHeight,fixWidth,fixHeight} = require('../utils/Porting');
var {
  StyleSheet,
  Text,
  TextInput,
  View,
  Navigator,
  TouchableHighlight,
  Alert,
  ScrollView,
  WebView,
} = React;


class Protocol extends BaseComponent {
  constructor(props) {
    super(props);
    this.state = {
      showNaBar:true,
      showLeftBtn:true,
      showRightBtn:true,
      showTitleUnderLine:false,
      tittle:'上海翼依信息技术有限公司',
    }
  }

    _render(){
        return (
        <View style={styles.content}>
          <View >
            <Text style ={styles.text}>"hitales大数据医学服务"</Text>
          </View>
            <View >
          <Text style ={styles.text}>合作协议</Text>
            </View>
        </View>
      );
    }

    leftClick(){
        this.props.navigator.pop();
    }

    rightClick(){
      this.props.navigator.push({component:<ProtocolPage1 navigator={this.props.navigator}/>});
    }
}

var styles = StyleSheet.create({
  text:{
    fontSize:fixWidth(16),
  },
  content:{
    flex:1,
    backgroundColor:'white',
    justifyContent:'center',
    alignItems:'center',
  }
});
module.exports = Protocol;
