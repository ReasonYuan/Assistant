'use strict';
var servername = "";

class Config {
   static serverPath(NODE_ENV){
     var server_yiyi = "";
     switch(NODE_ENV){
      case "production"://生产
          server_yiyi = "121.196.227.133:3000/";
         break;
      case "development"://开发
         server_yiyi = "121.41.43.230:3000/";
        break;
      case "test"://测试
         server_yiyi = "120.27.199.222:3000/";
        break;
      case "pre_production"://预生产
         server_yiyi = "114.55.35.31:3000/";
        break;
      default:
         server_yiyi = "121.41.43.230:3000/";
        break;
      }
      servername = server_yiyi;
      console.log("NODE_ENV:"+NODE_ENV);
      console.log("serverName:"+servername);
      return  server_yiyi;
  }
}

module.exports = Config;
