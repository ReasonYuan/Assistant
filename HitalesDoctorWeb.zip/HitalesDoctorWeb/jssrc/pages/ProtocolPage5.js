	'use strict';

var React = require('react-native')
var BaseComponent = require('./BaseComponent');

// var testHtml =  require('./test')
var {
  StyleSheet,
  Text,
  TextInput,
  View,
  Navigator,
  TouchableHighlight,
  Alert,
  ScrollView,
  WebView,
} = React;


class Protocol extends BaseComponent {
  constructor(props) {
    super(props);
    this.state = {
      showNaBar:true,
      showLeftBtn:true,
      showRightBtn:false,
			showTitleUnderLine:true,
      tittle:'返回首页',
    }
  }

    _render(){
        return (
					<ScrollView style={styles.contentView}>

		        <Text style={[styles.content2,{marginTop:20}]}>会计师或其他顾问的雇员）外，不向其他任何人披露，且上述人员须签署书面保密协议，其中保密义务的严格程度不得低于本条的规定。</Text>

		        <Text style={styles.content1}>4、上述条款对以下信息不适用：</Text>

		        <Text style={styles.content2}>（1）受方有在披露方向其披露前存在的书面记录证明其已经掌握；</Text>

		        <Text style={styles.content2}>（2）并非由于受方违反本协议而已经或者在将来进入公共领域；</Text>

		        <Text style={styles.content2}>（3）受方从对该信息无保密义务的第三方获得。</Text>

		        <Text style={styles.content1}>5、本附录与主文具备同等法律效力。</Text>

						<Text style={styles.content1}>（以下无正文）<Text style={{color:'transparent'}}>____________________</Text></Text>

						<Text style={styles.title}>双方签字：<Text style={{color:'transparent'}}>______________________</Text></Text>

						<Text style={styles.content3}>甲<Text style={{backgroundColor:"transparent",color:"transparent"}}>字数</Text>方：上海翼依信息技术有限公司 </Text>

            <Text style={styles.content3}>代表签字：<Text style={{color:'#999999'}}>__________________________</Text></Text>

            <Text style={styles.content3}>公司盖章：<Text style={{color:'#999999'}}>__________________________</Text></Text>

            <Text style={styles.content3}>日<Text style={{backgroundColor:"transparent",color:"transparent"}}>字数</Text>期：<Text style={{color:'#999999'}}>__________________________</Text></Text>

						<Text style={[styles.content3,{marginTop:20}]}>乙<Text style={{backgroundColor:"transparent",color:"transparent"}}>字数</Text>方：<Text style={{color:'#999999'}}>______________________</Text>医生</Text>

						<Text style={styles.content3}>签<Text style={{backgroundColor:"transparent",color:"transparent"}}>字数</Text>字：<Text style={{color:'#999999'}}>__________________________</Text></Text>

						<Text style={styles.content3}>日<Text style={{backgroundColor:"transparent",color:"transparent"}}>字数</Text>期：<Text style={{color:'#999999'}}>__________________________</Text></Text>

		      </ScrollView>
      );
    }

		leftClick(){
        this.props.navigator.pop();
    }




}

var styles = StyleSheet.create({
	contentView: {
    flex: 1,
    // marginTop: 65,
    backgroundColor: 'white'
  },
  content:{
    flexDirection:'row',
  },
  title:{
    marginTop:40,
    marginLeft:20,
    fontSize:14,

  },
  content1:{
    marginTop:20,
    marginRight:20,
    marginLeft:20,
    color:"#666666",
    fontSize:14,
  },

  content2:{
		marginTop:5,
    marginRight:20,
    marginLeft:30,
    color:"#666666",
    fontSize:14,
  },
	content3:{
		marginTop:10,
    marginRight:20,
    marginLeft:20,
    color:"#666666",
    fontSize:14,
  },
});
module.exports = Protocol;
