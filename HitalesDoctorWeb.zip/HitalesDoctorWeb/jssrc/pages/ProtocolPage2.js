'use strict';

var React = require('react-native')
var BaseComponent = require('./BaseComponent');
var ProtocolPage4 = require('./ProtocolPage4');
// var testHtml =  require('./test')
var {
  StyleSheet,
  Text,
  TextInput,
  View,
  Navigator,
  TouchableHighlight,
  Alert,
  ScrollView,
  WebView,
} = React;


class Protocol extends BaseComponent {
  constructor(props) {
    super(props);
    this.state = {
      showNaBar:true,
      showLeftBtn:true,
      showRightBtn:true,
      showTitleUnderLine:true,
      tittle:'返回首页',
    }
  }

    _render(){
        return (
          <ScrollView style={styles.contentView}>

            <Text style={styles.content1}>5、项目费用：项目费用按照项目涉及的病例数量计算，每一个病例收费10元人民币。本项目服务费用为______元。</Text>

            <Text style={styles.content1}>6、结算方式：</Text>

            <Text style={[styles.content1,{marginLeft:40,marginTop:0}]}>项目完成后由乙方验收，验收标准为乙方向甲方提供，验收完成后三天内由甲方支付项目费用。支付账号：账户名称：上海翼依信息技术有限公司，开户行：招商银行股份有限公司上海创智天地支行，账号：121913524110101。</Text>

            <Text style={styles.content1}>7、本协议一式两份，甲乙双方各保留一份。</Text>

            <Text style={styles.content1}>8、合作过程中，如有争议，双方本着真诚友好的态度进行协商，未协商一致，则可按照国家法律法规进行协商解决。</Text>

            <Text style={styles.content1}>（以下无正文）<Text style={{color:'transparent'}}>____________________</Text></Text>

            <Text style={styles.title}>双方签字：<Text style={{color:'transparent'}}>_______________________</Text></Text>

            <Text style={styles.content1}>甲<Text style={{backgroundColor:"transparent",color:"transparent"}}>字数</Text>方：上海翼依信息技术有限公司 </Text>

            <Text style={styles.content3}>代表签字：<Text style={{color:'#999999'}}>__________________________</Text></Text>

            <Text style={styles.content3}>公司盖章：<Text style={{color:'#999999'}}>__________________________</Text></Text>

            <Text style={styles.content3}>日<Text style={{backgroundColor:"transparent",color:"transparent"}}>字数</Text>期：<Text style={{color:'#999999'}}>__________________________</Text></Text>

            <Text style={[styles.content3,{marginTop:20}]}>乙<Text style={{backgroundColor:"transparent",color:"transparent"}}>字数</Text>方：<Text style={{color:'#999999'}}>______________________</Text>医生</Text>

    				<Text style={styles.content3}>签<Text style={{backgroundColor:"transparent",color:"transparent"}}>字数</Text>字：<Text style={{color:'#999999'}}>__________________________</Text></Text>

    				<Text style={styles.content3}>日<Text style={{backgroundColor:"transparent",color:"transparent"}}>字数</Text>期：<Text style={{color:'#999999'}}>__________________________</Text></Text>

          </ScrollView>
      );
    }

    leftClick(){
        this.props.navigator.pop();
    }

    rightClick(){
      this.props.navigator.push({component:<ProtocolPage4 navigator={this.props.navigator}/>});
    }


}

var styles = StyleSheet.create({
  contentView: {
    flex: 1,
    // marginTop: 65,
    backgroundColor: 'white'
  },
  content:{
    flexDirection:'row',
  },
  title:{
    marginTop:40,
    marginLeft:20,
    marginRight:20,
    fontSize:14,

  },
  content1:{
    marginTop:20,
    marginRight:20,
    marginLeft:20,
    color:"#666666",
    fontSize:14,
  },

  content2:{
    marginTop:10,
    marginRight:20,
    marginLeft:30,
    color:"#666666",
    fontSize:14,
  },

  content3:{
    marginTop:10,
    marginRight:20,
    marginLeft:20,
    color:"#666666",
    fontSize:14,
  },
});
module.exports = Protocol;
