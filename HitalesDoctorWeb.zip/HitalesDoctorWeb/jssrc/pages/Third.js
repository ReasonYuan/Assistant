'use strict';

var React = require('react-native')
var BaseComponent = require('./BaseComponent');
var {
  StyleSheet,
  Text,
  View,
  TextInput,
  Navigator,
  Alert,
  TouchableHighlight,
  Component
} = React;

class Third extends BaseComponent {

  constructor(props) {
    super(props);
    this.state = {
      showNaBar:true,
      leftName:'返回',
      rightName:'下一个',
      tittle:'标题',

    };
  }
  loginPress(){
    console.log("login被点击了");
    this.props.navigator.pop();
  }

  leftClick(){
    this.props.navigator.pop();
  }

  _render() {
    return (
      <View style={styles.viewContent}>
        <View style={styles.topContent}>
          <Text style={styles.bigTittle}>海苔健康</Text>
          <Text style={styles.smallTittle}>医生版1.0</Text>
        </View>
        <View style={styles.bottomContent}>
          <TextInput style={styles.phoneNumber} placeholder="请输入用户名" placeholderTextColor='white'></TextInput>
          <TextInput style={styles.passWord} placeholder="请输入密码" placeholderTextColor='white' secureTextEntry={true}></TextInput>
          <TouchableHighlight style={styles.login} underlayColor="rgba(82,182,166,125)" onPress={()=>this.loginPress()}>
            <Text style={styles.loginText}>登录</Text>
          </TouchableHighlight>
          <View style={styles.lastView}>
            <Text style={styles.register} onPress={()=>this.register()} underlayColor='gray'>注册</Text>
            <Text style={styles.forget} onPress={()=>this.forget()} underlayColor='gray'>忘记密码</Text>
          </View>
        </View>
      </View>
    )
  }

  // _handleBackButtonPress(){
  //   Tools.showDialog('sure被点击了', 'sure被点击了',()=>this.sureClick(),()=>this.cancel());
  // }
  //
  // _handleNextButtonPress(){
  //   Tools.showDialog('sure被点击了', 'sure被点击了',()=>this.sureClick(),()=>this.cancel());
  // }

sureClick(){
  // Tools.showDialog('sure被点击了', 'sure被点击了',()=>this.sureClick(),()=>this.cancel());
  this.props.navigator.pop();
}

cancel(){

}

register(){
  Alert.alert('register被点击了', 'register被点击了', [
    {
      text: 'ok',onPress:()=>this.sureClick(),
    }, {
      text: 'cancel'
    }
  ]);
}

forget(){
  Alert.alert('forget被点击了', 'forget被点击了', [
    {
      text: 'ok',onPress:()=>this.sureClick(),
    }, {
      text: 'cancel'
    }
  ]);
}
  // onThirdPress(){
  //   console.log("third被点击了");
  //   this.props.navigator.pop()
  // }
}

var styles = StyleSheet.create({
  viewContent: {
    // marginTop: 65,
    backgroundColor: "rgba(63,138,127,255)",
    flex: 1
  },
  bottomContent: {
    flex: 1,
    // backgroundColor: 'green'
  },
  topContent: {
    flex: 1,
    justifyContent: 'flex-end',
    // backgroundColor: 'red'
  },
  tv: {
    backgroundColor: '#123456'
  },
  bigTittle: {
    fontSize: 30,
    color: "white",
    marginBottom: 20,
    textAlign: 'center'
  },
  smallTittle: {
    fontSize: 20,
    color: "white",
    marginBottom: 50,
    textAlign: 'center'
  },
  phoneNumber: {
    backgroundColor: "rgba(131,181,175,255)",
    marginTop: 30,
    height: 40,
    marginRight: 20,
    marginLeft: 20,
    textAlign: 'center',
    borderRadius: 20,
    color:'white',
    fontSize:15,
  },
  passWord: {
    backgroundColor: "rgba(131,181,175,255)",
    marginTop: 10,
    height: 40,
    marginRight: 20,
    marginLeft: 20,
    textAlign: 'center',
    borderRadius: 20,
    color:'white',
    fontSize:15,
  },
  login: {
    backgroundColor: "rgba(82,182,166,255)",
    marginTop: 20,
    height: 40,
    marginRight: 20,
    marginLeft: 20,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 8,

  },
  register: {
    // backgroundColor: "rgba(82,182,166,255)",
    height: 15,
    width: 40,
    color:'white',
  },
  forget: {
    // backgroundColor: "rgba(82,182,166,255)",
    height: 15,
    width: 80,
    textAlign:'right',
    color:'white',
  },
  lastView: {
    flexDirection: 'row',
    marginLeft: 20,
    marginRight:20,
    marginTop:10,
    justifyContent:'space-between',
  },
  loginText:{
    color:'white',
    fontSize:15,
  }

})

module.exports = Third
