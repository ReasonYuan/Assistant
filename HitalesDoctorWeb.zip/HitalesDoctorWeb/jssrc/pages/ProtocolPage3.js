	'use strict';

var React = require('react-native')
var BaseComponent = require('./BaseComponent');
var ProtocolPage4 = require('./ProtocolPage4');
// var testHtml =  require('./test')
var {
  StyleSheet,
  Text,
  TextInput,
  View,
  Navigator,
  TouchableHighlight,
  Alert,
  ScrollView,
  WebView,
} = React;


class Protocol extends BaseComponent {
  constructor(props) {
    super(props);
    this.state = {
      showNaBar:true,
      showLeftBtn:true,
      showRightBtn:true,
			showTitleUnderLine:true,
      tittle:'返回首页',
    }
  }

    _render(){
        return (
					<ScrollView style={styles.contentView}>

					<Text style={styles.content1}>乙<Text style={{backgroundColor:"transparent",color:"transparent"}}>字数</Text>方：<Text style={{color:'#999999'}}>________________________</Text>医生</Text>

					<Text style={styles.content1}>签<Text style={{backgroundColor:"transparent",color:"transparent"}}>字数</Text>字：<Text style={{color:'#999999'}}>____________________________</Text></Text>

					<Text style={styles.content1}>日<Text style={{backgroundColor:"transparent",color:"transparent"}}>字数</Text>期：<Text style={{color:'#999999'}}>____________________________</Text></Text>

		      </ScrollView>
      );
    }

		leftClick(){
        this.props.navigator.pop();
    }

    rightClick(){
      this.props.navigator.push({component:<ProtocolPage4 navigator={this.props.navigator}/>});
    }


}

var styles = StyleSheet.create({
	contentView: {
    flex: 1,
    // marginTop: 65,
    backgroundColor: 'white'
  },
  content1:{
    marginTop:10,
    marginRight:20,
    marginLeft:20,
    color:"#666666",
    fontSize:14,
  },

});
module.exports = Protocol;
