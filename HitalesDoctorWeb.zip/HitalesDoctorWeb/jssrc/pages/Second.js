'use strict';

var React = require('react-native')
var Third = require('./Third')
var BaseComponent = require('./BaseComponent');
var {
  StyleSheet,
  Text,
  TextInput,
  View,
  Navigator,
  TouchableHighlight,
  Alert,
  Animated,
} = React;

class Second extends BaseComponent {
  constructor(props) {
    super(props);
    this.state = {
      showNaBar:false,
      leftName:'返回',
      rightName:'下一个',
      tittle:'标题',

    };
  }

  onclick() {
    if (this.state.inputString != "") {
      this.props.navigator.push({
          component:<Third navigator={this.props.navigator}/>
      });
    } else {
      Alert.alert('tittle', '没输入字', [
        {
          text: 'ok'
        }, {
          text: 'cancel'
        }
      ]);
    }
  }

  _render() {
    return (
      <View style={styles.contentView}>
        <View style={styles.inputView}>
          <View style={styles.textinput}>
            <TextInput style={styles.textinput} placeholder={"输入东西吧。。。"} onChangeText={this.textChange.bind(this)}/>
          </View>
          <TouchableHighlight style={styles.touch} onPress={this.onclick.bind(this)} underlayColor={"#789778"}>
            <Text style={styles.btn}>调到第三个界面</Text>
          </TouchableHighlight>
        </View>

      </View>
    );
  }

  textChange(event) {
    console.log(event);
    this.state.inputString = event
  }
}

var styles = StyleSheet.create({
  contentView: {
    flex: 1,
    // marginTop: 65,
    backgroundColor: '#555666'
  },
  touch: {
    height: 40,
    flex: 1,
    justifyContent: 'center',
    // backgroundColor: '#FF0000'
    backgroundColor: "rgba(82,182,166,255)",
  },
  inputView: {
    height: 80,
    flexDirection: 'row',
    backgroundColor:"rgba(63,138,127,255)",
    alignItems: 'center',
  },
  btn: {
    // backgroundColor: 'gray',
    textAlign: 'center'
  },
  textinput: {
    backgroundColor: '#FFFFFF',
    height: 40,
    flex: 4,
  },
  testView:{
    width:100,
    height:50,
    backgroundColor:'red',
    justifyContent:'center',
    alignItems:'center',
  }
});

module.exports = Second;
