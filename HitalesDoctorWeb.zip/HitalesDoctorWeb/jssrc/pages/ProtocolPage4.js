'use strict';

var React = require('react-native')
var BaseComponent = require('./BaseComponent');
var ProtocolPage5 = require('./ProtocolPage5');
// var testHtml =  require('./test')
var {
  StyleSheet,
  Text,
  TextInput,
  View,
  Navigator,
  TouchableHighlight,
  Alert,
  ScrollView,
  WebView,
} = React;


class Protocol extends BaseComponent {
  constructor(props) {
    super(props);
    this.state = {
      showNaBar:true,
      showLeftBtn:true,
      showRightBtn:true,
      showTitleUnderLine:true,
      tittle:'返回首页',
    }
  }

    _render(){
        return (
          <ScrollView style={styles.contentView}>
            <Text style={styles.title}>附录一：隐私保护及保密协议</Text>

            <Text style={styles.content1}>1、乙方在项目履行过程中需配合向甲方提供相应数据，乙方对其提供的病例数据享有处分权，乙方享有对经甲方数据处理后的数字化数据使用的权利。甲方承诺不得将原始数据以任何形式用作于任何侵害乙方权益或侵害病例所有人权益的商事活动中，不得在未经数字化去身份化处理前调用数据，并将保护隐私权作为甲方展开研究、分析行为的首要准则。</Text>

            <Text style={styles.content1}>2、甲方承诺对于经甲方数据处理后的数字化初始数据仅供自身科研使用，不向任何第三方商业机构提交初始数据的全部或任意部分。</Text>

            <Text style={styles.content1}>3、本协议订立前以及在本协议期限内，一方（下称“披露方”）曾经或者可能不时向对方（下称“受方”）披露该方的保密资料。在本协议期限内以及随后[ 2 ]年间，受方必须：</Text>

            <Text style={styles.content2}>（1）对保密资料进行保密；</Text>

            <Text style={styles.content2}>（2）不为除协议明确规定的目的之外的其他目的使用保密资料；</Text>

            <Text style={styles.content2}>（3）除为履行其职责而确有必要知悉保密资料的该方雇员（或其关联机构、该方律师、</Text>

          </ScrollView>
      );
    }

    leftClick(){
        this.props.navigator.pop();
    }

    rightClick(){
      this.props.navigator.push({component:<ProtocolPage5 navigator={this.props.navigator}/>});
    }


}

var styles = StyleSheet.create({
  contentView: {
    flex: 1,
    // marginTop: 65,
    backgroundColor: 'white'
  },
  content:{
    flexDirection:'row',
  },
  title:{
    marginTop:40,
    marginLeft:20,
    marginRight:20,
    fontSize:20,

  },
  content1:{
    marginTop:20,
    marginRight:20,
    marginLeft:20,
    color:"#666666",
    fontSize:14,
  },

  content2:{
    marginTop:10,
    marginRight:20,
    marginLeft:30,
    color:"#666666",
    fontSize:14,
  },
});
module.exports = Protocol;
