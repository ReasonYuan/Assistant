'use strict';

var React = require('react-native')
var BaseComponent = require('./BaseComponent');
var ProtocolPage2 = require('./ProtocolPage2');
// var testHtml =  require('./test')
var {
  StyleSheet,
  Text,
  TextInput,
  View,
  Navigator,
  TouchableHighlight,
  Alert,
  ScrollView,
  WebView,
} = React;


class Protocol extends BaseComponent {
  constructor(props) {
    super(props);
    this.state = {
      showNaBar:true,
      showLeftBtn:true,
      showRightBtn:true,
      showTitleUnderLine:true,
      tittle:'返回首页',
    }
  }

    _render(){
        return (
          <ScrollView style={styles.contentView}>
            <Text style={styles.title}>甲方：上海翼依信息技术有限公司</Text>

            <Text style={[styles.title,{marginTop:20}]}>乙方：_____________________医生</Text>

            <Text style={[styles.content1,{marginTop:40}]}>上海翼依信息技术有限公司（以下简称甲方）是一家帮助医生提高科研与临床效率的技术公司，Hitales是上海翼依信息技术有限公司的服务品牌。Hitales的愿景是以数据驱动健康，以科技和服务提高医生的工作效率、提升个人品牌。</Text>

            <Text style={styles.content1}>双方就相关合作达成以下约定：</Text>

            <Text style={styles.content1}>1、自双方签订本约定之日起， 甲方为乙方提供“Hitales大数据医学服务”。</Text>

            <Text style={styles.content1}>2、项目名称为：“________________________”。</Text>

            <Text style={styles.content1}>3、项目计划：本项目涉及病例数量为______例，计划于_____年___月___日完成。</Text>

            <Text style={styles.content1}>4、“Hitales大数据医学服务”包含：</Text>

            <Text style={styles.content2}>a)Hitales APP医生版（iOS/Android版本）</Text>

            <Text style={styles.content2}>b)病例智能采集<Text style={{color:'transparent'}}>___________________</Text></Text>

            <Text style={styles.content2}>c)建立个人云病历库<Text style={{color:'transparent'}}>_________________</Text></Text>

            <Text style={styles.content2}>d)病例数据结构化<Text style={{color:'transparent'}}>___________________</Text></Text>

            <Text style={styles.content2}>e)分析与统计服务<Text style={{color:'transparent'}}>___________________</Text></Text>

            <Text style={styles.content2}>f)协助进行多中心科研项目<Text style={{color:'transparent'}}>_________________</Text></Text>

          </ScrollView>
      );
    }

    leftClick(){
        this.props.navigator.pop();
    }

    rightClick(){
      this.props.navigator.push({component:<ProtocolPage2 navigator={this.props.navigator}/>});
    }


}

var styles = StyleSheet.create({
  contentView: {
    flex: 1,
    // marginTop: 65,
    backgroundColor: 'white'
  },
  content:{
    flexDirection:'row',
  },
  title:{
    marginTop:20,
    marginLeft:20,
    marginRight:20,
    fontSize:18,
    textDecorationStyle:'double'

  },
  content1:{
    marginTop:20,
    marginRight:20,
    marginLeft:20,
    color:"#666666",
    fontSize:14,
  },

  content2:{
    marginTop:2,
    marginRight:20,
    marginLeft:30,
    color:"#666666",
    fontSize:14,
  },
});
module.exports = Protocol;
