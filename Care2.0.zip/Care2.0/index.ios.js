/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 */
'use strict';

var React = require('react-native');
var {
  AppRegistry,
  StyleSheet,
  Text,
  View,
} = React;

var Navigator = require("./Navigator")
var Login = require("./Login");
var {Styles} = require('./Styles');
var Home = require('./core/Home2');

// __DEV__ = true;
console.disableYellowBox = true;

//TODO==JP==以后版本稳定后可以不加这个remotelog
//DEV模式下允许
if(__DEV__){
  var setRemoteErrorHandler = require("./utils/RemoteErrorUtils").setUpErrorHandler
  setRemoteErrorHandler()
}

var {ScrollView,View,Dimensions} = React;

var deviceWidth = Dimensions.get('window').width;
var deviceHeight = Dimensions.get('window').height;
class TableView extends React.Component {
  constructor(prop) {
    super(prop)
  }
  render(){
    return(
      <View style={{flex:1}}>
        <ScrollView
          horizontal
          pagingEnabled
          style={{flex:1}}
          contentContainerStyle={{flex:1}}
          automaticallyAdjustContentInsets={false}
        >
          <View style={{flex:1,width:deviceWidth,backgroundColor:'blue'}}>

          </View>
          <View style={{flex:1,width:deviceWidth,backgroundColor:'yellow'}}>

          </View>
          <View style={{flex:1,width:deviceWidth,backgroundColor:'blue'}}>

          </View>
        </ScrollView>
        <View style={{height:60,backgroundColor:"red"}} />
      </View>
    )
  }
}

class Care extends React.Component {
  render() {
    return (
      <Navigator
        style={Styles.content}
        initialRoute={{
          component:Login
        }}
      />
    );
  }
}

AppRegistry.registerComponent('Care', () => Care);
