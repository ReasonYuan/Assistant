'use strict';
var React = require('react-native');
var {User} = require("../Models");
var { NativeAppEventEmitter } = React;


Array.prototype.contains = function(obj) {
    var i = this.length;
    while (i--) {
        if (this[i] === obj) {
            return true;
        }
    }
    return false;
}

class ImageSync {
  filtterView:DatabaseView;
  db:Couchbase;
  callbacks:Object;
  constructor(db) {
    this.db = db;
    this.callbacks = {};
  }
  update(){
    this.filtterView.update();
  }
  stopInterval(){
    if(this.interval){
      clearInterval(this.interval);
      delete this.interval;
    }
  }
  startInterval(){
    this.stopInterval();
    this.interval = setInterval(()=>{
      this.update();
    }, 5000);
  }
}

class UploadImageSync extends ImageSync{
  constructor(db) {
    super(db);
    var {DatabaseView,DatabaseManager} = require("../couchbase/Couchbase");
    var self = this;
    this.filtterView = new DatabaseView(db,null,"UploadImageSyncView","function(doc){if(doc.type === \"Message\" && doc.messageType == 1 && doc.message && doc.message.status == 0){emit(doc._id,{'type':doc.type,'objectKey':doc.message.objectKey});}else if(doc.type === \"Record\" && doc.status == 0){emit(doc._id,{'type':doc.type,'images':doc.images});}else if(doc.type === \"User\" && doc._id == '"+User.currentUser.documentID+"' && doc.headIcon && doc.headIcon.status == 0){emit(doc._id,{'type':doc.type,'image':doc.headIcon.objectKey});}}",()=>{
      self.filtterView.setOnDataChangeCallback((data)=>self.onDataChanged(data));
    });
    var Emitter = React.Platform.OS === "ios"?React.NativeAppEventEmitter:React.DeviceEventEmitter;
    Emitter.addListener(React.NativeModules.ImageHelper.NOTI_UPLOAD_IMAGE_COMPLETE,
      (key) => {
        self.onImageUpdated(key);
      }
    );
  }
  onDataChanged(data){

    if(data.length>0){
      this.startInterval();
      for (var i = 0; i < data.length; i++) {
        if(data[i].value.type == "Message"){  //上传消息图片
          var objectKey = data[i].value.objectKey;
          if(!this.callbacks[objectKey])this.callbacks[objectKey] = [];
          if(!this.callbacks[objectKey].contains(data[i].key)){
            this.callbacks[objectKey].push(data[i].key);
            React.NativeModules.ImageHelper.uploadImage(User.currentUser.documentID,objectKey);
          }
        }else if (data[i].value.type == "User") { //上传头像
          var objectKey = data[i].value.image;
          if(!this.callbacks[objectKey])this.callbacks[objectKey] = [];
          if(!this.callbacks[objectKey].contains(data[i].key)){
            this.callbacks[objectKey].push(data[i].key);
            React.NativeModules.ImageHelper.uploadImage(User.currentUser.documentID,objectKey);
          }
        }else if (data[i].value.type == "Record") { //上传记录
          var images = data[i].value.images;
          var haveUploadFile = false;
          for (var j = 0; j < images.length; j++) {
            var objectKey = images[j].key;
            if(images[j].status == 0){
              haveUploadFile = true;
              if(!this.callbacks[objectKey])this.callbacks[objectKey] = [];
              if(!this.callbacks[objectKey].contains(data[i].key)){
                this.callbacks[objectKey].push(data[i].key)
              }
              React.NativeModules.ImageHelper.uploadImage(User.currentUser.documentID,objectKey);
            }
          }
          if(!haveUploadFile){ //全部上传完成
            this.db.getModel(data[i].key,(m)=>{
              if(m.status == 0){
                m.status = 1;
                m.save();
              }
            });
          }
        }
      }
    }else {
      this.stopInterval();
    }
  }
  onImageUpdated(objectKey){
    console.log("--->1 ",objectKey);
    var ids = this.callbacks[objectKey];
    if(ids && ids instanceof Array){
      for (var i = 0; i < ids.length; i++) {
        var id =  ids[i];
        this.db.getModel(id,(m)=>{
          this.onModelImageUploaded(m,objectKey);
        });
      }
    }
    delete this.callbacks[objectKey];
  }
  onModelImageUploaded(model,objectKey){
    console.log("---->2 ",objectKey,model);
    if(model.type == "Message"){
      model.message.status = 1;
      model.save();
    }else if (model.type == "User" && model.headIcon) {
      model.headIcon.status = 1;
      model.save();
    }else if(model.type == "Record"){
      var images = model.images;
      var haveUploadFile = false;
      for (var i = 0; i < images.length; i++) {
        var key = images[i].key;
        if(key == objectKey){
          images[i].status = 1;
        }
        if(images[i].status == 0) haveUploadFile = true;
      }
      if(!haveUploadFile){
        model.status = 1;
      }
      model.save();
    }

  }
}

module.exports = {
  "UploadImageSync":UploadImageSync,
}
