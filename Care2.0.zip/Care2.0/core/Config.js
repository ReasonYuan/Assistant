'use strict';
var React = require('react-native');
var {View,Text} = React;
let CouchbaseHelper = React.NativeModules.CouchbaseHelper;
let env = CouchbaseHelper.ENV;
let local_port = CouchbaseHelper.LOCAL_PORT;

let boundleVersion = "1.0.6";

var getCurrnetUploadImageCount = function(cb){
  React.NativeModules.ImageHelper.getLeftUploadImageCount(cb);
}

let onImageUploadCountListeners = [];

var addImageUploadCountListener = function(cb){
  onImageUploadCountListeners.push(cb)
}

var removeImageUploadCountListener = function(cb){
  onImageUploadCountListeners.remove(cb)
}

var Emitter = React.Platform.OS === "ios"?React.NativeAppEventEmitter:React.DeviceEventEmitter;
var changeListener = Emitter.addListener("NOTI_UPLOAD_COUNT_CHANGE",
  (data) => {
    for (var i = 0; i < onImageUploadCountListeners.length; i++) {
      onImageUploadCountListeners[i](data);
    }
  }
);

class UpLoadImageCount extends React.Component{
  constructor(props) {
    super(props);
    this.state = {count:0};
  }
  componentWillMount(){
    var {DatabaseManager,DatabaseView} = require('./couchbase/Couchbase');
    var {User} = require("./Models");
    var db = DatabaseManager.instance.currentDatabase;
    this.recordImageCountView = new DatabaseView(db,"Record","RecordImageCountView","function(doc){if(doc.type === 'Record' && doc.status == 0){emit(doc._id,{'type':doc.type,'images':doc.images})}}",()=>{
      this.recordImageCountView.setOnDataChangeCallback((data)=>this.onDataChanged(data));
    });
  }
  onDataChanged(data){
    var count = 0;
    for (var i = 0; i < data.length; i++) {
      var item = data[i].value.images;
      for (var j= 0; j < item.length; j++) {
        if(item[j].status != 2) count++;
      }
    }
    this.setState({count:count})
  }
  componentWillUnmount(){
    if(this.recordImageCountView)this.recordImageCountView.stop();
  }
  render(){
    if(this.state.count > 0){
      return(
        <View {...this.props} style={[this.props.style,{width:18,height:18,borderRadius:9,backgroundColor:'red',justifyContent:'center',alignItems:'center'}]}>
          <Text style={{color:'white',fontSize:11}}>{this.state.count}</Text>
        </View>
      )
    }else{
      return(
        <View/>
      )
    }
  }
}

let ROLE_TYPE = 1;

var server_name = "开发环境"
var server_syncgateway = "121.41.43.230:4984/";
var server_assistant = "121.41.43.230:3100/";
var server_baoshi = "121.41.43.230:5000/";
var server_yiyi = "121.41.43.230:3000/";
var server_dongtai = "121.41.43.230:3001/";
var server_bucket = "test";
var PAY_DEBUG = true;
if(env == 1){
  //测试服务器
  server_name = "测试环境"
  server_syncgateway = "121.196.244.95:4984/";
  server_assistant = "120.55.189.100:3100/";
  server_baoshi = "120.27.199.93:5000/";
  server_yiyi = "120.27.199.222:3000/";
  server_dongtai = "120.27.199.165:3001/";
  server_bucket = "test";
  PAY_DEBUG = true;
}else if (env == 2) {
  //bug重现环境
  server_name = "bug重现环境"
  server_syncgateway = "121.196.232.71:4984/";
  server_assistant = "121.196.232.71:3100/";
  server_baoshi = "121.196.232.71:5000/";
  server_yiyi = "121.196.232.71:3000/";
  server_dongtai = "121.196.232.71:3001/";
  server_bucket = "test";
  PAY_DEBUG = true;
}else if (env == 3) {
  // 预生产环境
  server_name = "生产环境" //预生产环境
  server_syncgateway = "114.55.35.31:4984/";
  server_assistant = "114.55.35.31:3100/";
  server_baoshi = "114.55.35.31:5000/";
  server_yiyi = "114.55.35.31:3000/";
  server_dongtai = "114.55.35.31:3001/";
  server_bucket = "production";
  PAY_DEBUG = false;
}else if (env == 4) {
  // 生产环境
  server_name = "生产环境"
  server_syncgateway = "120.55.240.23:4984/";
  server_assistant = "121.196.244.147:3100/";
  server_baoshi = "121.196.244.146:5000/";
  server_yiyi = "121.196.227.133:3000/";
  server_dongtai = "120.55.188.146:3001/";
  server_bucket = "production";
  PAY_DEBUG = false;
}else if (env == 0) {
  //开发环境
  server_name = "开发环境"
  server_syncgateway = "121.41.43.230:4984/";
  server_assistant = "121.41.43.230:3100/";
  server_baoshi = "121.41.43.230:5000/";
  server_yiyi = "121.41.43.230:3000/";
  server_dongtai = "121.41.43.230:3001/";
  server_bucket = "test";
  PAY_DEBUG = true;
}

// DEMO环境
// let server_name = "demo环境"
// let server_syncgateway = "121.199.16.216:4984/";
// let server_assistant = "121.199.16.216:3100/";
// let server_baoshi = "121.199.16.216:5000/";
// let server_yiyi = "121.199.16.216:3000/";
// let server_dongtai = "121.199.16.216:5001/";
// let server_bucket = "demo";
// let PAY_DEBUG = true;


var rest_api_server = server_yiyi;
switch (ROLE_TYPE) {
  case 1:
    rest_api_server = server_baoshi;
    break;
  case 2:
    rest_api_server = server_assistant;
    break;
  default:
}


module.exports = {
  env:env,
  boundleVersion:boundleVersion,
  serverType:server_name,
  UpLoadImageCount:UpLoadImageCount,
  localURL:"http://127.0.0.1:"+local_port+"/",
  // serverURL:"http://"+"192.168.2.211"+":4984/",
  serverURL:"http://"+server_syncgateway,
  serverBucket:server_bucket,
  // LoginPath:"getSession",
  LoginPath:"users/register",
  webServerURL:"http://"+rest_api_server,
  webShowForwardServerURL:"http://"+server_yiyi,
  role_type:ROLE_TYPE,
  message_time_line_interval:60*5*1000, //消息里面显示时间显的最小时间，5分钟
  // IMAGE_URL:"http://hitalestest.yiyihealth.com/" , //阿里云图片下载地址
  IMAGE_URL:CouchbaseHelper.DOWNLOAD_ENDPOINT,
  PAY_DEBUG:PAY_DEBUG, //测试付费
}
