/**
 *
 * 客户对服务评价，支付的页面
 * @author  reason 2015-12-08
 *
 */

'use strict';

var React = require('react-native');

var {
  StyleSheet,
  View,
  Text,
  Image,
  TextInput,
  TouchableHighlight,
} = React;

var Dimensions = require('Dimensions');
var DatabaseManager = require("../couchbase/Couchbase").DatabaseManager;
var {User,Order} = require("../Models");
var {PayLoadingDialog} = require('../../Dialog');

var screenHeight = function(){
  return Dimensions.get('window').height;
}
var screenWidth = function(){
  return Dimensions.get('window').width;
}
var {BaseComponent,Tools,Color,Config} = require('../../Styles');
var w = Tools.fixWidth;
var fs = function(s){
  return s/2+2;
};

var Pay = require('../setting/Pay');


var stars = [require('../../images/icon_judge_star_n.png'),
             require('../../images/icon_judge_star_y.png')]


class Start extends React.Component{
  constructor(props){
    super(props)
  }

  render(){
    return(
      <TouchableHighlight
        underlayColor='transprent'
        onPress={()=>{this.props.onClick(this.props.index)}}>

        <Image style={istyles.star}
          source={stars[this.props.selected]}/>
      </TouchableHighlight>
    )
  }
}

class ServiceJudge extends BaseComponent {

  constructor(props){
    super(props)
    this.state={showPayLoading:false,editable:true,selectedIndex:0,navigatorBarConfig:{title:"服务",showBackIcon:true},provider:this.props.message.provider,price:this.props.message.price,judgment:""};
    this.onServiceSet(this.props.service);
    this.canPay = true;
  }
  lastRender(){
    return (
      <PayLoadingDialog show={this.state.showPayLoading}/>
    )
  }
  pay(){
    do{
      if(!this.canPay){this.showWarning("未找到服务记录");break;}
      if(this.checkStringIsNull(this.judgment,"评价不能为空"))break;
      if(this.state.selectedIndex == 0){this.showWarning("尚未评分");break;}
      this.setState({showPayLoading:true});
      Pay.payMoney(Config.PAY_DEBUG?1:this.state.price*100,this.service.name,Pay.ORDER_CATEGORY_SERVICE,this.serviceId,User.currentUser.documentID,(data)=>{
        if(this.service && data && data.success){
          // this.service.orderId = data.result.out_trade_no;
          // this.service.save();
        }else{
          this.setState({showPayLoading:false});
          this.showWarning("网络异常");
        }
      },(ok)=>{
        this.setState({showPayLoading:false});
        if(ok == "success" && this.service){
          this.pop();
        }
      },{service_judgment:this.judgment,service_rating:this.state.selectedIndex},this.props.navigator,(success)=>{
        this.setState({showPayLoading:false});
        if(success){
          var routes = this.props.navigator.getCurrentRoutes();
          var route = routes[routes.length-3];
          this.props.navigator.popToRoute(route);
        }else{
          this.props.navigator.pop();
        }
      });
    }while (false);
  }


  componentWillReceiveProps(nextProps){
    this.setState({provider:nextProps.message.provider,price:nextProps.message.price});
    this.onServiceSet(nextProps.service);
  }

  onServiceSet(serviceId){
    if(this.serviceId != serviceId){
      var self = this;
      this.serviceId = serviceId;
      DatabaseManager.instance.currentDatabase.getModel(serviceId,(service)=>{
        self.service = service;
        if (this.service){
          self.canPay=true;
        }else{
          self.canPay=false;
        }
        var e = service.payStatus!=3;
        this.judgment = service.judgment;
        this.setState({editable:e,price:service.price,judgment:service.judgment,selectedIndex:service.rating})
      })
    }
  }

  onLeftPress(){
    this.pop();
  }

  onStarClick(index){
    this.setState({selectedIndex:index})
  }


  getStars(){
    var views = []
    for(var i = 1; i < 6; i++){
      var selected = i > this.state.selectedIndex?0:1;
      views.push(<Start index={i} selected={selected}
        onClick={(index)=>{this.state.editable&&this.onStarClick(index)}}/>)
    }
    return views
  }

  renderStar(){
    return(
      <View style={istyles.starContainer}>
        { this.getStars() }
      </View>
    )
  }

  _render(){
    return(
      <View>
        <Image style={istyles.full} source={require('../../images/bg_pay.jpg')}/>

        <View style={istyles.container}>
          <Image style={istyles.logo} source={require('../../images/icon_logo.png')}/>
          <Text style={istyles.title}>海苔全家健康服务</Text>
          <Text style={istyles.des}>{"¥ "+parseFloat(this.state.price).toFixed(2)}</Text>
          <Text style={istyles.des}>{"提供者："+this.state.provider}</Text>
          <View style={istyles.inputBg}>
            <TextInput
              multiline={React.Platform.OS !== 'ios'}
              textAlignVertical='top'
              numberOfLines={5}
              style={istyles.input}
              editable={this.state.editable}
              placeholderTextColor="#c1c1c1"
              onChangeText={(text)=>this.judgment = text}
              defaultValue={this.state.judgment}
              placeholder={"请输入对本次服务的评价..."}/>
          </View>


          <View style={istyles.startView}>{this.renderStar()}</View>
          {
            (()=>{
              if(this.state.editable){
                return(
                  <TouchableHighlight style={istyles.btnPay} underlayColor="#ccc" onPress={this.pay.bind(this)}>
                    <Text style={istyles.btnTitle}>支付</Text>
                  </TouchableHighlight>
                )
              }
            })()
          }
        </View>

      </View>
    )
  }
}

var istyles = StyleSheet.create({
  full:{
    flex:1,
  },
  container:{
    position:'absolute',
    left:(screenWidth()-w(250))/2,
    top:0,
    width:w(250),
    height:screenHeight()-64,
    alignItems:'center',
    backgroundColor:'transprent',
  },
  logo:{
    width:w(250),
    height:w(94),
    marginTop:w(40),
    resizeMode:'contain',
  },
  title:{
    marginTop:w(30),
    marginBottom:w(30),
    fontSize:fs('36'),
    color:'#61c4b2'
  },
  des:{
    fontSize:fs('26'),
    marginBottom:w(10),
    color:Color.des,
  },
  inputBg:{
    flex:1,
    width:w(250),
    borderWidth:1,
    borderColor:'#b6dbd4',
    backgroundColor:'#fff',
  },
  input:{
    flex:1,
    padding:w(9),
    backgroundColor:'#fff',
    color:'#c1c1c1',
    fontSize:fs('24')
  },
  startView:{
    alignSelf:'flex-end',
    marginBottom:w(23),
    marginTop:w(20),
  },
  starContainer:{
    height:w(20),
    flexDirection:'row',
    alignItems:'flex-end',
  },
  btnPay:{
    width:w(250),
    height:w(35),
    backgroundColor:'#67bfb5',
    alignItems:'center',
    justifyContent:'center',
    borderRadius:w(5),
    marginBottom:w(35)
  },
  btnTitle:{
    fontSize:fs('28'),
    color:'#f5eff1'
  },
  star:{
    width:w(20),
    height:w(24),
    marginLeft:w(6),
    resizeMode:'contain'
  }
});


module.exports = ServiceJudge
