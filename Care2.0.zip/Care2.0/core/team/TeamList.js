'use strict';

var React = require('react-native');
var {
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableHighlight,
  Navigator,
  ScrollView,
  Image,
  ListView,
  LayoutAnimation,
  InteractionManager,
} = React;

var {Styles,ImageView,Button,BaseComponent,Config,Color,Tools,UserIcon,FQListView} = require('../../Styles');
var {Record,Patient,User,FriendShip} = require("../Models");
var FriendsCicleItem = require('./FriendsCicleItem');
var LocalCache = require('../sync/LocalCache');
var UserZone = require('./UserZone');
var SimpleChatView = require('../chat/SimpleChatView');
var {DatabaseManager,DatabaseView} = require('../couchbase/Couchbase');

let DEFAULT_HEAD_ICON = "http://www.kq36.cn/KqFile/alluploadfile/2013/7/20/doctor/201372015314742685.jpg"
let DEFAULT_ASSISTANC_ID = "assistant_15828584450";
let ASSISTANT_ITEM_HEIGHT = Tools.fixWidth(60);

class AssistantItem extends React.Component {
  constructor(props) {
    super(props)
    var assistant = User.currentUser.assistant || DEFAULT_ASSISTANC_ID;
    this.state={userId:assistant,imageUrl:DEFAULT_HEAD_ICON,renderPlaceholderOnly: false};
    DatabaseManager.instance.currentDatabase.getModel(assistant,(assistantData)=>{
      if(assistantData){
        this.setState({name:assistantData.name});
      }
    })
  }
  componentWillMount(){
    DatabaseManager.instance.currentDatabase.addChangeCallback("User",this,(body)=>{
      for (var i = 0; i < body.length; i++) {
        var item = body[i];
        if(item.type == "User" && item._id == User.currentUser.assistant){
          this.setState({name:item.name});
        }
      }
    })
  }
  componentDidMount(){
    InteractionManager.runAfterInteractions(() => {
          this.setState({renderPlaceholderOnly: false});
    });
  }
  componentWillUnmount(){
    DatabaseManager.instance.currentDatabase.removeChangeCallback("User",this);
  }
  render(){

    if (this.state.renderPlaceholderOnly) {
      return  (
        <View style={[Styles.center,{flex:1}]}>
          <Text>Loading...</Text>
        </View>
      );
    }

    return(
      <View {...this.props} style={{backgroundColor:'white'}}>
        <View style={[styles.rowContent,{marginTop:Tools.fixWidth(8)}]}>
          <View style={[{flexDirection:'row'}]}>
            <View style={Styles.center}>
              <UserIcon style={[styles.headImage]} user={User.currentUser.assistant} source={require('../../images/head_assistant.png')}/>
            </View>
            <View style={{flex:1}}>
              <View style={{height:Tools.fixWidth(40),marginLeft:Tools.fixWidth(12),justifyContent:'center'}}>
                  <Text style={{fontSize:Tools.fixWidth(12)}}>{this.state.name||""}</Text>
                  <Text style={[styles.infoHospital,{color:"#f39800"}]}>{"私人健康助理"}</Text>
              </View>
            </View>
            <TouchableHighlight style={[Styles.center,{width:Tools.fixWidth(40),height:Tools.fixWidth(40)}]} underlayColor="transparent" onPress={()=>{
              var friendShip = new FriendShip(User.currentUser.documentID,this.state.userId);
               this.props.navigator.push({
                 component:<SimpleChatView navigator={this.props.navigator} friendShip={friendShip}/>
               })
            }}>
              <Image style={{width:Tools.fixWidth(18),height:Tools.fixWidth(16)}} source={require('../../images/icon_chat.png')} />
            </TouchableHighlight>
          </View>
          <View style={styles.line}/>
        </View>
      </View>
    )
  }
}

class DoctorInfo extends React.Component {
  constructor(props) {
    super(props);
    this.setProps(this.props);
  }
  componentWillReceiveProps(nextProps){
    this.setProps(nextProps);
  }
  setProps(nextProps){
    var imageUrl = DEFAULT_HEAD_ICON;
    if(nextProps.info.userInfo.headIcon && nextProps.info.userInfo.headIcon.objectKey){
      imageUrl = Config.IMAGE_URL+nextProps.info.userInfo.headIcon.objectKey+"@200w_1l";
    }
    this.state = {imageUrl:imageUrl}
  }
  _renderInfo(){
    return (
      <View style={{height:Tools.fixWidth(40),marginLeft:Tools.fixWidth(12),flexDirection:'row',alignItems:'center'}}>
        <Text style={{fontSize:Tools.fixWidth(12)}}>{this.props.info.userInfo.name || ""}</Text>
        <Text style={[{marginLeft:Tools.fixWidth(10)},styles.infoDepartment]}>{this.props.info.userInfo.department || ""}</Text>
        <Text style={styles.infoHospital}>{this.props.info.userInfo.hospital || ""}</Text>
      </View>
    )
  }
  render(){
    return (
      <TouchableHighlight underlayColor="transparent" onPress={()=>{
        this.props.navigator.push({
          component:<UserZone
            navigator={this.props.navigator}
            name = {this.props.info.userInfo.name || "" }
            defautIcon={DEFAULT_HEAD_ICON}
            userInfo = {this.props.info.userInfo}
            uri={this.state.imageUrl}
            objectKey={this.props.info.userInfo.headIcon?this.props.info.userInfo.headIcon.objectKey:null}
            userId = {this.props.info.userInfo.id}
            introduction={this.props.info.userInfo.introduction}
            showMessageButton={false}
            />
        })
      }}>
        <View style={[styles.rowContent]}>
          <View style={[styles.info,{flexDirection:'row'}]}>
            <View style={Styles.center}>
              <ImageView  style={[styles.headImage]} width={200} imageKey={this.props.info.userInfo.headIcon?this.props.info.userInfo.headIcon.objectKey:null} source={{uri:DEFAULT_HEAD_ICON}}/>
            </View>
            <View style={{flex:1}}>
                {
                  this._renderInfo()
                }
            </View>
          </View>
          <FriendsCicleItem
            style={[styles.doctorShare]}
            date={this.props.info.newestShare?new Date(this.props.info.newestShare.createAt).format('yyyy-MM-dd'):null}
            imageUrl={this.props.info.newestShare?this.props.info.newestShare.imageUrl:null}
            title={this.props.info.newestShare?this.props.info.newestShare.title:null}
            titleMaxLength={10}
           />
          <View style={styles.line} />
        </View>
      </TouchableHighlight>
    )
  }
}

DoctorInfo.propTypes = {
  info:React.PropTypes.object,//服务器 users/get_doctors 返回的一个item
}

DoctorInfo.defaultProps = {
  info:{userInfo:{},newestShare:{}},
}

class TeamList extends BaseComponent {
  allData:Object;
  lastOffsetY:Number;
  constructor(props){
    super(props);
    var config = {title:"健康团队"}
    var ds = new ListView.DataSource({rowHasChanged: (r1, r2) => r1 !== r2});
    this.allData = {};
    this.state = {navigatorBarConfig:config,dataSource:ds,isShowAsstent:true};
    this.page = 1;
    this.isLoading = false;
    this.lastOffsetY = 0;
    this.getDoctorShareMessage(this.page);
  }
  refreshAll(){
    var pageSize = Object.keys(this.allData).length;
    if(pageSize){
      this.post("users/get_doctors",{page:0,pageSize:5*pageSize},(data)=>{
        if(data.success && data.doctors && data.doctors.length > 0){
          var allData = {};
          var tmp = [];
          var index = 0;
          while(data.doctors.length > 0){
            tmp.push(data.doctors.splice(0,1)[0]);
            if(tmp.length == 5){
              var key = this.getCacheKey(index);
              LocalCache.save(key,data);
              allData[index] = tmp;
              index++;
              tmp=[];
            }
          }
          if(tmp.length!=0){
            var key = this.getCacheKey(index);
            LocalCache.save(key,data);
            allData[index] = tmp;
          }
          this.allData = allData;
          var keys = Object.keys(this.allData).sort();
          var doctors = [];
          keys.forEach((key)=>{
            doctors =  doctors.concat(this.allData[key])
          })
          this.doctors = doctors;
          this.setState({dataSource:this.state.dataSource.cloneWithRows([null].concat(doctors))});
        }
      });
    }
  }
  getDoctorShareMessage(page,cb){
    var key = this.getCacheKey(page);
    LocalCache.get(key,(data)=>{
      this.onReceiveData(data,page);
    })
    this.post("users/get_doctors",{page:page,pageSize:5},(data)=>{
      if(data.success && data.doctors && data.doctors.length > 0){
        this.onReceiveData(data,page);
        LocalCache.save(key,data);
      }
      if(cb)cb();
    });
  }
  getCacheKey(page){
    return User.currentUser.documentID+"_doctorsInfos_"+page
  }
  onReceiveData(data,page){
    if(data.doctors.length == 0) {
      return;
    };
    this.allData[page] = data.doctors;
    var keys = Object.keys(this.allData).sort();
    var doctors = [];
    keys.forEach((key)=>{
      doctors =  doctors.concat(this.allData[key])
    })
    var tmp = [];
    var reDoctors = [];
    for (var i = 0; i < doctors.length; i++) {
      try {
        if(!tmp.contains(doctors[i].userInfo.id)){
          tmp.push(doctors[i].userInfo.id);
          reDoctors.push(doctors[i]);
        }
      } catch (e) {

      }
    }
    this.doctors = reDoctors;
    this.setState({dataSource:this.state.dataSource.cloneWithRows([null].concat(this.doctors))});
  }
  loadNextPage(){
    if(!this.isLoading){
      this.isLoading = true;
      this.getDoctorShareMessage(++this.page,()=>{
        this.isLoading = false;
      });
    }
  }
  renderRow(rowData,sectionId,rowId){
    if(rowData){
      return (
        <DoctorInfo key={rowData} navigator={this.props.navigator} info={rowData}/>
      )
    }
    return (
      <View key={rowId} style={{height:ASSISTANT_ITEM_HEIGHT}}/>
    )
  }
  hideAssistant(){
    if(this.state.isShowAsstent){
      LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
      this.setState({isShowAsstent:false})
    }
  }
  showAssistant(){
    if(!this.state.isShowAsstent){
      LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
      this.setState({isShowAsstent:true})
    }
  }

  onScroll(){
    var offsetY = this.refs.teamlist.scrollProperties.offset;
    let offset = this.refs.teamlist.scrollProperties.contentLength - this.refs.teamlist.scrollProperties.offset + this.refs.teamlist.scrollProperties.visibleLength ;
    if(offset > 50){
      this.refs.teamlist.props.onEndReached();
    }
    if(offset > 0) return;
    var direction = offsetY - this.lastOffsetY;
    if(direction > 0 && this.state.isShowAsstent && offsetY >= ASSISTANT_ITEM_HEIGHT ){ //向上滚动，隐藏助手
      this.hideAssistant();
    }else if (direction < 0 && !this.state.isShowAsstent) { //向下，显示助手
      this.showAssistant();
    }
    this.lastOffsetY = offsetY;
  }

  _render() {
    //tabbar 高度49
    var self = this;
    var assistant_height = 0;
    if(this.state.isShowAsstent)assistant_height = ASSISTANT_ITEM_HEIGHT;
    return (
      <View style={[Styles.content]}>
       <FQListView
           automaticallyAdjustContentInsets={false}
           pageSize={10}
           ref="teamlist"
           onScroll={this.onScroll.bind(this)}
           dataSource={this.state.dataSource}
           renderRow={this.renderRow.bind(this)}
           onEndReached={this.loadNextPage.bind(this)}
       />
       <View style={{position:'absolute',top:0,left:0,right:0,height:assistant_height,overflow:'hidden'}}>
         <AssistantItem navigator={this.props.navigator}/>
       </View>
      </View>
    );
  }
}

var styles = StyleSheet.create({
  rowContent : {
    paddingLeft:Tools.fixWidth(12),
    paddingRight:Tools.fixWidth(12),
    backgroundColor:'white',
  },
  info:{
    marginTop:Tools.fixWidth(8),
  },
  headImage:{
    width:Tools.fixWidth(40),
    height:Tools.fixWidth(40),
    resizeMode:'cover',
    borderRadius:Tools.fixWidth(5),
  },
  infoHospital:
  {
    position:'absolute',
    left:0,
    bottom:0,
    color:"#999999",
    fontSize:Tools.fixWidth(10),
  },
  infoDepartment:{
    color:"#999999",
    fontSize:Tools.fixWidth(10),
    flex:1,
  },
  doctorShare:{
    marginLeft:Tools.fixWidth(8),
    marginRight:Tools.fixWidth(8),
    marginTop:Tools.fixWidth(15),
  },
  line:{
    backgroundColor:Color.white_border_color,
    height:1,
    marginTop:Tools.fixWidth(10),
  },
});

module.exports = TeamList;
