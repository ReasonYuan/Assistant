
'use strict';

var React = require('react-native');
var {
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableHighlight,
  Navigator,
  ScrollView,
  Image,
} = React;

var {Styles,Button,BaseComponent,Color,Tools} = require('../../Styles');
var {Record,Patient,User} = require("../Models");
var WebView = require('../WebView');

class FriendsCicleItem extends React.Component {
  constructor(props){
    super(props)
    this._setProp(this.props);
  }
  componentWillReceiveProps(nextProps){
    this._setProp(nextProps);
  }
  _setProp(props){
    var date = props.date || new Date().format("yyyy-MM-dd");
    var imageUrl = props.imageUrl;
    var title = props.title || "";
    // var titleMaxLength = props.titleMaxLength || 0;
    // if (titleMaxLength > title.length) {
    //   titleMaxLength = title.length;
    // }
    // if(titleMaxLength){
    //   title = title.substring(0,titleMaxLength) + "...";
    // }
    var url = props.url || "";
    this.state = {date:date,imageUrl:imageUrl,title:title,url:url}
  }
  _renderImage(){
    if(this.state.imageUrl){
      return(
        <Image style={styles.image} source={{uri:this.state.imageUrl}}/>
      )
    }
  }
  _renderTitle(isRendImage){
    if(isRendImage){
      return (
        <View style={{height:Tools.fixWidth(55),justifyContent:'center'}}>
          <Text style={styles.titleText} numberOfLines={2}>
          {
            this.state.title
          }
          </Text>
        </View>
      )
    }
    return(
      <View style={{flex:1,justifyContent:'center'}}>
        <Text style={styles.titleText} numberOfLines={2}>
        {
          this.state.title
        }
        </Text>
      </View>
    )
  }
  render() {
    return (
      <View {...this.props} >
        <View>
          <Text style={styles.dateText}>
          {
            (()=>{
              if(this.state.title){
                return this.state.date
              }else{
                return "医生没有分享..."
              }
            })()

          }
          </Text>
          <View style={{marginTop:Tools.fixWidth(7)}}>
          {
            (()=>{
              if(this.state.imageUrl){
                return (
                  <View style={{flexDirection:'row'}}>
                    <View style={Styles.center}>
                    {
                      this._renderImage()
                    }
                    </View>
                    <View style={{flex:1}}>
                    {
                      this._renderTitle(true)
                    }
                    </View>
                  </View>
                )
              }else{
                return this._renderTitle(false)
              }
            })()
          }
          </View>
        </View>
      </View>
    );
  }
}

var styles = StyleSheet.create({
  dateText : {
    fontSize:Tools.fixWidth(11),
    color:"#333333"
  },
  titleText:{
    fontSize:Tools.fixWidth(11),
    color:"#999999",
  },
  image:{
    width:Tools.fixWidth(45),
    height:Tools.fixWidth(45),
    resizeMode:'contain',
    margin:Tools.fixWidth(5),
    marginLeft:0,
  }
});

module.exports = FriendsCicleItem;
