
'use strict';

var React = require('react-native');
var {
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableHighlight,
  Navigator,
  ScrollView,
  Image,
  ListView,
  InteractionManager,
} = React;
var WebView = require('../WebView');
var {Styles,Button,BaseComponent,ImageView,Config,Color,Tools} = require('../../Styles');
var {Record,Patient,User,FriendShip} = require("../Models");
var FriendsCicleItem = require('./FriendsCicleItem');
var LocalCache = require('../sync/LocalCache');
var SimpleChatView = require('../chat/SimpleChatView');

class UserZone extends BaseComponent {
  allData:Object;
  constructor(props){
    super(props)
    // if(!this.props.userId)throw new Error("no user id");
    var config = {title:this.props.name+"的分享",showBackIcon:true};
    if(this.props.patient){
      config.rightButtonTitle="停止授权",
      config.rightTextColor="rgba(255,0,0,0.5)"
    }
    var ds = new ListView.DataSource({rowHasChanged: (r1, r2) => r1 !== r2});
    this.state = {navigatorBarConfig:config,dataSource:ds,renderPlaceholderOnly:true};
    this.page = 0;
    this.allData = {};
    this.getShareMessage(this.page);
    this.isLoading = false;
  }
  onRightPress(){
    if(this.props.onRightPress)this.props.onRightPress();
  }
  getShareMessage(page,cb){
    var key = this.getCacheKey(page);
    LocalCache.get(key,(data)=>{
      this.onReceiveData(data,page);
    })
    this.post("sharemessage/get_user_shares",{userId:this.props.userId,page:page,pageSize:5},(data)=>{
      if(data && data.success && data.shareMessages && data.shareMessages.length > 0){
        this.onReceiveData(data,page);
        LocalCache.save(key,data);
      }
      if(cb)cb();
    });

  }
  getCacheKey(page){
    return this.props.userId+"_zone_"+page
  }
  onReceiveData(data,page){
    if(data.shareMessages.length == 0) {
      return;
    };
    this.allData[page] = data.shareMessages;
    var keys = Object.keys(this.allData).sort();
    var shareMessages = [];
    keys.forEach((key)=>{
      shareMessages =  shareMessages.concat(this.allData[key])
    })
    var tmp = [];
    var reShareMessages = [];
    for (var i = 0; i < shareMessages.length; i++) {
      if(!tmp.contains(shareMessages[i].id)){
        tmp.push(shareMessages[i].id);
        reShareMessages.push(shareMessages[i]);
      }
    }
    this.shareMessages = reShareMessages;
    this.setState({dataSource:this.state.dataSource.cloneWithRows(this.shareMessages)});
  }
  onLeftPress(){
    this.pop();
  }
  loadNextPage(){
    if(!this.isLoading){
      this.isLoading = true;
      this.getShareMessage(++this.page,()=>{
        this.isLoading = false;
      });
    }
  }
  componentDidMount(){
    InteractionManager.runAfterInteractions(() => {
          this.setState({renderPlaceholderOnly: false});
    });
  }
  renderRow(rowData,sectionId,rowId){
    return (
      <TouchableHighlight underlayColor="rgba(221, 221, 221, 0.5)" onPress={()=>{
        if(rowData.url){
          this.props.navigator.push({
            component:<WebView title={"分享详情"} navigator={this.props.navigator} url={rowData.url} />
          })
        }
      }}>
        <View>
          <FriendsCicleItem
            style={{marginTop:Tools.fixWidth(10)}}
            navigator={this.props.navigator}
            imageUrl={rowData.imageUrl}
            title={rowData.title}
            url={rowData.url}
            date={new Date(rowData.createAt).format('yyyy-MM-dd')}
           />
           {
             this._renderLine()
           }
         </View>
      </TouchableHighlight>
    )
  }
  _renderInfo(){
    return (
      <View style={{height:Tools.fixWidth(40),marginLeft:Tools.fixWidth(12),flexDirection:'row',alignItems:'center'}}>
          <Text style={{fontSize:Tools.fixWidth(12)}}>{this.props.name || ""}</Text>
          <Text style={[{marginLeft:Tools.fixWidth(10)},styles.infoDepartment]}>{this.props.userInfo.department || ""}</Text>
          <Text style={styles.infoHospital}>{this.props.userInfo.hospital || ""}</Text>
      </View>
    )
  }
  _renderTitle(){
    return(
      <View style={[styles.info,{flexDirection:'row'}]}>
        <View style={Styles.center}>
          <ImageView  style={[styles.headImage]}  imageKey={this.props.objectKey} defautIcon={{uri:this.props.defautIcon}} source={{uri:this.props.defautIcon}}/>
        </View>
        <View style={{flex:1}}>
            {
              this._renderInfo()
            }
        </View>
      </View>
    )
    return(
      <View style={[styles.rowContent]}>
        <View style={[{flexDirection:'row'}]}>
          <View style={Styles.center}>
            <Image style={[styles.headImage]} source={{uri:this.props.headIcon}}/>
          </View>
          <View style={{flex:1}}>
            <View style={[{justifyContent:'flex-end',marginTop:10}]}>
              <View>
                <Text style={{fontSize:14}}> { this.props.name } </Text>
              </View>
            </View>
          </View>
          <View style={Styles.center}>
          {
            (()=>{
              if(this.props.showMessageButton){
                return <Button style={{width:40,height:30,marginRight:15,marginTop:10}} title={"消息"} onTouch={()=>{
                  var friendShip = new FriendShip(User.currentUser.documentID,this.props.userId);
                  this.props.navigator.push({
                    component:<SimpleChatView navigator={this.props.navigator} friendShip={friendShip}/>
                  })
                }}/>
              }
            })()
          }
          </View>
        </View>
      </View>
    )
  }
  _renderLine(){
    return(
      <View style={styles.line} />
    )
  }
  // <Text style={[styles.text_title,styles.text_introduction]}>简介：</Text>
  // <Text style={styles.introduction} numberOfLines={5}>{this.props.introduction || "该医生没有简介..." }</Text>
  _render() {
    if (this.state.renderPlaceholderOnly) {
      return  (
        <View style={[Styles.center,{flex:1}]}>
          <Text>Loading...</Text>
        </View>
      );
    }

    return (
      <View style={[styles.content]}>
       {
         this._renderTitle()
       }

       <Text style={[styles.text_title,styles.text_share]}>分享：</Text>
       <View style={[{marginTop:Tools.fixWidth(10)},styles.line]} />
        <ListView
           automaticallyAdjustContentInsets={false}
           onLayout={(evnt)=>{
             this.listViewHeight = evnt.nativeEvent.layout.height;
           }}
           onScroll={(e)=>{
             var offsetY = e.nativeEvent.contentOffset.y;
             let offset = offsetY + e.nativeEvent.layoutMeasurement.height - e.nativeEvent.contentSize.height;
             if(offset > 50){
               this.loadNextPage();
             }
           }}
           dataSource={this.state.dataSource}
           renderRow={this.renderRow.bind(this)}
       />
      </View>
    );
  }
}


var styles = StyleSheet.create({
  content:{
    flex:1,
    paddingLeft:Tools.fixWidth(12),
    paddingRight:Tools.fixWidth(12),
    backgroundColor:'white',
  },
  text_introduction:{
    marginTop:Tools.fixWidth(10),
  },
  introduction:{
    fontSize:Tools.fixWidth(10),
    color:"#666666",
  },
  text_share:{
    marginTop:Tools.fixWidth(28),
  },
  text_title:{
    fontSize:Tools.fixWidth(12),
    color:"#333333"
  },
  rowContent : {
    marginLeft:10,
    marginRight:10,
  },
  info:{
    marginTop:Tools.fixWidth(8),
  },
  headImage:{
    width:Tools.fixWidth(40),
    height:Tools.fixWidth(40),
    resizeMode:'cover',
    borderRadius:Tools.fixWidth(5),
  },
  infoHospital:
  {
    position:'absolute',
    left:0,
    bottom:0,
    color:"#999999",
    fontSize:Tools.fixWidth(10),
  },
  infoDepartment:{
    color:"#999999",
    fontSize:Tools.fixWidth(10),
    flex:1,
  },
  doctorShare:{
    marginLeft:Tools.fixWidth(8),
    marginRight:Tools.fixWidth(8),
    marginTop:Tools.fixWidth(15),
  },
  line:{
    backgroundColor:Color.white_border_color,
    height:1,
    marginTop:Tools.fixWidth(10),
  },
});

module.exports = UserZone;
