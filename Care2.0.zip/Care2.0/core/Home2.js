/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 */
'use strict';

var React = require('react-native');
var {
  StyleSheet,
  Text,
  View,
  Image,
  TouchableHighlight,
  InteractionManager,
} = React;

var MessageList = require('./message/MessageList');
var TeamList = require('./team/TeamList');
var PlanList = require('./plan/PlanList');
var MySetting = require('./setting/MySetting');
var MessageCount = require('./message/MessageCount');

var{screenWidth} = require('../utils/Porting')

class TabbarItem extends React.Component {
  constructor(props) {
    super(props);
    this.state={selected:this.props.selected || false,showRedIcon:this.props.showRedIcon};
  }
  componentWillReceiveProps(nextProps){
    if(this.props.selected != nextProps.selected){
        this.setState({selected:nextProps.selected,showRedIcon:nextProps.showRedIcon});
    }else{
      this.setState({showRedIcon:nextProps.showRedIcon});
    }
  }
  onTableSelect(){
    this.setState({selected:true});
    if(this.props.onPress)this.props.onPress(this.props.index);
  }
  render(){
    var tintColor = {};
    if(this.props.tintColor){
      if(this.state.selected){
        tintColor.tintColor = this.props.tintColor;
      }else {
        tintColor.tintColor = "gray";
      }
    }
    return (
      <TouchableHighlight style={styles.tabbar_item} underlayColor="transparent" onPress={this.onTableSelect.bind(this)}>
        <View >
          <Image style={[styles.tabbar_item_icon,tintColor]} source={this.state.selected?(this.props.selectedIcon ? this.props.selectedIcon : this.props.icon):this.props.icon}>
          </Image>
          {
            (()=>{
              if(this.state.showRedIcon){
                return <View style={{position:'absolute',backgroundColor:'red',top:0,right:0,width:8,height:8,borderRadius:4,overflow:'visible'}}/>
              }
            })()
          }
        </View>
      </TouchableHighlight>
    )
  }
}

class Home extends React.Component {
  constructor(props) {
    super(props);
    this.state={index:1,currentIndex:1};
    MessageCount.changeListener = (count)=>{
      this.setState({noReadMessageCount:count});
    }
    this.views = this.getViews();
  }
  componentDidMount(){

  }
  getViews(){
    var views=[];
    views.push(this.wrapComponent(0,<PlanList navigator={this.props.navigator}/>));
    views.push(this.wrapComponent(1,<MessageList navigator={this.props.navigator}/>));
    views.push(this.wrapComponent(2,<TeamList ref={(c)=>this.teamlist=c} navigator={this.props.navigator}/>));
    views.push(this.wrapComponent(3,<MySetting ref={(c)=>this.mySetting=c} navigator={this.props.navigator}/>));
    return views;
  }
  wrapComponent(index,component){
    return (
      <View key={index} style={{width:screenWidth()}}>
      {
        component
      }
      </View>
    )
  }
  onSelectView(index){
    // if(index != this.state.index){
    //   var allIndex = this.state.allIndex;
    //   if(!allIndex.contains(index))allIndex.push(index);
    //   this.setState({index:index,allIndex:allIndex});
    //   if(index == 2 && this.teamlist){
    //     this.teamlist.refreshAll();
    //   }
    // }
    if(index != this.state.index){
      this.setState({index:index,currentIndex:index});
      if(index == 2 && this.teamlist){
          this.teamlist.refreshAll();
      }
      if(index == 3){
        this.mySetting.refresh();

      }
    }
  }



  render() {

    return (
      <View {...this.props} style={[this.props.style,styles.tabGroup]}>
        <View style={styles.tabGroup}>
         <Tabar currentIndex={this.state.currentIndex} style={{flex:1}}>
         {
            this.views
         }
         </Tabar>
        </View>
        <View style={styles.line}/>
        <View style={styles.bottom_content}>
          <TabbarItem onPress={(index)=>this.onSelectView(index)} index={0} selected={this.state.index == 0} icon={require("../images/tab_item_record.png")} selectedIcon={require("../images/tab_item_record_pressed.png")}/>
          <TabbarItem onPress={(index)=>this.onSelectView(index)} index={1} selected={this.state.index == 1} icon={require("../images/tab_item_message.png")} selectedIcon={require("../images/tab_item_message_pressed.png")} showRedIcon={this.state.noReadMessageCount}/>
          <TabbarItem onPress={(index)=>this.onSelectView(index)} index={2} selected={this.state.index == 2} icon={require("../images/tab_item_team.png")} selectedIcon={require("../images/tab_item_team_pressed.png")}/>
          <TabbarItem onPress={(index)=>this.onSelectView(index)} index={3} selected={this.state.index == 3} icon={require("../images/tab_item_me.png")} selectedIcon={require("../images/tab_item_me_pressed.png")}/>
        </View>
      </View>
    );
  }
}

class Tabar extends React.Component {
  render(){
    // var allIndex = this.props.allIndex || [0];
    // var children = [];
    // for (var i = 0; i < allIndex.length; i++) {
    //   children.push(this.props.children[allIndex[i]]);
    // }
    return (
      <View style={{flex:1,flexDirection:'row',width:screenWidth()*this.props.children.count,left:-this.props.currentIndex*screenWidth()}}>
      {
        this.props.children
      }
      </View>
    )
  }
}

var styles = StyleSheet.create({
  tabGroup: {
    flex: 1,
  },
  gone:{
    height:0,
    overflow:'hidden',
  },
  line:{
    backgroundColor:"#C1C1C1",
    height:1
  },
  bottom_content:{
    height:49,
    flexDirection:'row',
    backgroundColor:'#ffffff',
  },
  tabbar_item:{
    flex:1,
    justifyContent:'center',
    alignItems:'center',
  },
  tabbar_item_icon:{
    width:24,
    height:24,
    resizeMode:'contain',
    backgroundColor:'transparent',
    marginTop:8,
    marginRight:8,

  }
});


module.exports = Home
