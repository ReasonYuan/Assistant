'use strict';
var React = require('react-native');
var {
  StyleSheet,
  Text,
  View,
  Image,
  TouchableHighlight,
} = React;
var Dimensions = require('Dimensions');
var {User,Patient,FriendShip,Message} = require("../Models");
var {Config,Color,Tools,ImageView} = require('../../Styles');
var TimerMixin = require('react-timer-mixin');
var ChatRow = require('./ChatRow');
var MessageImageView = require('../message/MessageManager').MessageImageView;

class ImageRow extends ChatRow{
  getInitState(){
    let imageWidth = this.props.message.message.width;
    let imageHeight = this.props.message.message.height;
    var maxlayout = this.maxWidth;
    if(imageWidth < imageHeight){
      maxlayout = maxlayout / 2;
    }else{
      maxlayout = maxlayout * 2 / 3;
    }
    this.maxlayout = maxlayout;
    var state = super.getInitState();
    state.width = 0;
    return state;
  }

  onReceiveProps(props,state){
    state.message = props.message;
    let imageWidth = props.message.message.width;
    let imageHeight = props.message.message.height;
    var maxlayout = this.maxWidth;
    if(imageWidth < imageHeight){
      maxlayout = maxlayout / 2;
    }else{
      maxlayout = maxlayout * 2 / 3;
    }
    this.maxlayout = maxlayout;
  }

  onItemClick(){
    var usrId = User.currentUser.documentID;
    var index = 0;
    var count = 0;
    var imgs = [];
    var view = this.props.view;
    var msgs = view.messages;
    for(var i = msgs.length - 1; i > -1; i--){
      var msg = msgs[i]
      if(msg.messageType == 1){
        var img = {userId:usrId}
        img.key = msg.message.objectKey
        imgs.push(img)

        if(msg == this.state.message){//当前图片所在的序号
          index = count
        }
        count++
      }
    }

    var BrowseImages = require('../record/BrowerImages')
    view.pushWidthComponent({
      component:<BrowseImages navigator={view.props.navigator} source={imgs} index={index} hiddenRightTitle={true} title={'图片'}/>
    });
  }

  renderContent(fromMe){
    let imageWidth = this.state.message.message.width;
    let imageHeight = this.state.message.message.height;
    var layoutWith = 0;
    var layoutHeight = 0;
    var maxlayout = this.maxlayout;
    if(imageWidth >= maxlayout){
      layoutWith = maxlayout;
      layoutHeight = imageHeight * (maxlayout / imageWidth);
    }else{
      layoutWith = imageWidth;
      layoutHeight = imageHeight;
    }
    return(
      <MessageImageView
         message={this.state.message}
         resizeMode='cover'
         style={[styles.image,{width:layoutWith,height:layoutHeight}]}
         imageKey = {this.state.message.message.objectKey}
       />
    )
  }
}


var styles = StyleSheet.create({
  image:{
    borderRadius: 10,
    marginBottom:10,
    borderWidth:1,
    borderColor:'#CCC'
  },
});


module.exports = ImageRow;
