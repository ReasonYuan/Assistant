'use strict';
var React = require('react-native');
var {
  StyleSheet,
  TabBarIOS,
  Text,
  View,
  Image,
  ListView,
  TouchableHighlight,
  TextInput,
  ScrollView,
  Animated,
  ActionSheetIOS,
  PanResponder,
  InteractionManager,
} = React;

var Dimensions = require('Dimensions');
var {Styles,Button,BaseComponent,Config,Tools,Color,FQListView} = require('../../Styles');
var UIImagePickerManager = require('NativeModules').UIImagePickerManager;
var Models = require("../Models");
var {User,Patient,FriendShip,Message,Service} = Models;
var {DatabaseView,DatabaseManager} = require("../couchbase/Couchbase");

var Config = require('../Config');
var { NativeAppEventEmitter } = React;
var SelectPatientView = require('./SelectPatientView');

var InvertibleScrollView = require('react-native-invertible-scroll-view');
var ChatFeatures = require('./ChatFeatures');
var SystemInfo = require('./SystemInfo');
var NormalRow = require('./NormalRow');
var ImageRow = require('./ImageRow');
var ServerRow = require('./ServerRow');
var CardRow = require('./CardRow');
var ResourceRow = require('./ResourceRow');

class GroupChatView extends BaseComponent{
  firstMessageKey:String;
  isLoading:Boolean;
  contentOffset:Number;
  isKeyboardIsShow:Boolean;
  isFeatureShow:Boolean;
  onLeftPress(){
    this.pop()
  }
  constructor(props) {
    super(props)
    if(!this.props.group) throw new Error("no group");
    this.firstMessageKey= null;
    this.isLoading = false;
    this.contentOffset = 0;
    this.isKeyboardIsShow = false;
    this.isFeatureShow = false;
    var config = {title:this.props.group.name,showBackIcon:true};
    this.state = {
      dataSource: new ListView.DataSource({rowHasChanged: (r1, r2) => {if(r1.documentID && r2.documentID)return r1.documentID != r2.documentID; return r1 !== r2}}),
      friendName:"",
      inputText:"",
      moveAnim: new Animated.ValueXY(),
      moveAnim2:new Animated.ValueXY(),
      chatHistory:[],
      messages:[],
      navigatorBarConfig:config,
      renderPlaceholderOnly: true,
    };
    var self = this;
    var group = this.props.group;
    var db = DatabaseManager.instance.currentDatabase;
    var channelMessageView =  new DatabaseView(db,"Message","MessageView_"+group.documentID,"function(doc) { if (doc.type == 'Message') && ( doc.group == '"+group.documentID+"')) { emit(doc.date,doc);} }",()=>{
      channelMessageView.setOnDataChangeCallback((data)=>this.onDataChanged(data));
    });
    channelMessageView.beforeUpdate = ()=>{
      if(!self.firstMessageKey){
        channelMessageView.limit = 10;
        channelMessageView.descending = true;
      }else{
        channelMessageView.startKey = self.firstMessageKey;
        channelMessageView.limit = null;
        channelMessageView.descending = null;
      }
    }
    this.channelMessageView = channelMessageView;
  }
  KeyboardWillShow(e){
    this.hideFeatures();
    this.isKeyboardIsShow = true;
  }
  KeyboardWillHide(e){
    this.isKeyboardIsShow = false;
  }
  getHeadIcon(id,cb){
    DatabaseManager.instance.currentDatabase.getModel(id,(from)=>{
       from.getAttachment("head",(data)=>{
         if(data){
           cb(data);
         }
       })
    });
  }
  componentWillUnmount(){
    super.componentWillUnmount();
    if(this.channelMessageView)this.channelMessageView.stop();
  }
  componentDidMount(){
    InteractionManager.runAfterInteractions(() => {
          this.setState({renderPlaceholderOnly: false});
    });
  }
  onDataChanged(data){
    if(!this.firstMessageKey){
      this.firstMessageKey = data[data.length - 1].key || new Date().getTime().toString();
      this.channelMessageView.limit = null;
      this.channelMessageView.descending = null;
      this.channelMessageView.startKey = this.firstMessageKey;
      var sortFunc = function(a,b){
        return new Date(new Number(a.key)).getTime() - new Date(new Number(b.key)).getTime()
      }
      data.sort(sortFunc);
    }
    var messages = [];
    for (var i = 0; i < data.length; i++) {
      var message = new Message();
      message.setProperty(data[i].value);
      messages.push(message);
    }
    if(messages.length > 0){
      User.currentUser.getProfile((profile)=>{
        if(profile.setting[this.props.group.documentID] !== messages[messages.length - 1].date.getTime().toString()){
          profile.setting[this.props.group.documentID] = messages[messages.length - 1].date.getTime().toString();
          profile.save();
        }
      });
    }
    messages.sort(function(a,b){
      return b.date.getTime() - a.date.getTime();
    })
    var lastMessage = messages[0];
    for (var i = 0; i < messages.length; i++) {
      var tmp = messages[i];
      if( lastMessage.date.getTime() - tmp.date.getTime() > Config.message_time_line_interval){
        messages.splice(i,0,{type:"Message_Time",date:lastMessage.date})
      }
      lastMessage = tmp;
    }
    this.messages = messages;
    this.setState({
      messages:messages,
      dataSource:this.state.dataSource.cloneWithRows(messages)
    });
  }
  sendText(){
    var text = this.state.inputText;
    this.setState({inputText:""});
    if(text && text != ""){
      var message = new Message(this.channel);
      message.messageType = 0;
      message.group = this.props.group.documentID;
      message.message = text;
      message.from = User.currentUser.documentID;
      this.appenMessage(message);
      message.save();
    }
  }
  appenMessage(message){
    if(this.messages && Array.isArray(this.messages)){
      var messages = [];
      for (var i = 0; i < this.messages.length; i++) {
        messages.push(this.messages[i])
      }
      messages.push(message);
      messages.sort(function(a,b){
        return b.date.getTime() - a.date.getTime();
      })
      this.setState({inputText:"",dataSource:this.state.dataSource.cloneWithRows(messages)});
    }
  }
  create(friendShip){
    var name = this.props.group.name;
    var self = this;
    DatabaseManager.instance.currentDatabase.getModel(friendShip.getFriendId(),(from)=>{
      name += "、" + from.name;
      self.props.group.name = name;
      self.props.group.members.push(friendShip.getFriendId());
      self.props.group.save();
    });
  }
  renderRow(rowData, sectionID: number, rowID: number){
    if(rowData.type === 'Message'){
      if(rowData.messageType == 0){ //普通消息
        return (
          <NormalRow
            key = {rowData.messageType}
            message = {rowData}
            relationship = {this.props.group}
          />
        )
      }else if (rowData.messageType == 1) { //图片
        return (
          <ImageRow
            key = {rowData.messageType}
            message = {rowData}
            view={this}
            relationship = {this.props.group}
          />
        )
      }else if (rowData.messageType == 2) { //share
        return (
          <SystemInfo color={Color.default_color} key={rowData.messageType}  message={rowData} info={""} showBorder={false}/>
        )
      }else if (rowData.messageType == 3) { //资源
          return (
            <ResourceRow
              key = {rowData.messageType}
              message = {rowData}
              relationship = {this.props.group}
              navigator = {this.props.navigator}
            />
          )
      }else if (rowData.messageType == 5) { //名片ResourceRow
          return (
            <CardRow
              key = {rowData.messageType}
              message = {rowData}
              relationship = {this.props.group}
              navigator = {this.props.navigator}
            />
          )
      }else if (rowData.messageType == 4) { //服务
        return (
          <ServerRow
            key = {rowData.messageType}
            message = {rowData}
            relationship = {this.props.group}
            navigator = {this.props.navigator}
          />
        )
    }
    }else if (rowData.type === "Message_Time") {
      var info = rowData.date.format("yyyy-MM-dd");
      if(info === new Date().format("yyyy-MM-dd")){
        info = rowData.date.format("hh:mm");
      }else{
        info = rowData.date.format("yyyy-MM-dd hh:mm");
      }
      return <SystemInfo color={"#333333"}  key={9999} info={info} showBorder={false}/>
    }
    return (
      <View />
    )
  }
  componentDidUpdate() {
    try {
      var self = this;
      if(self.isLoading) return;
      let listView = self.refs.chat_list;
      let scrollView = listView.refs.listviewscroll;
      if(scrollView)scrollView.scrollTo(0);
    } catch (e) {
      console.log(e);
    }
  }

  loadHistory(){
    if(!this.isLoading){
      this.isLoading = true;
      var self = this;
      var url = this.channelMessageView.getUrl();
      url += "?startkey=\""+this.firstMessageKey+"\"&limit=10&descending=true";
      fetch(url).then((response) => response.json())
      .then((data)=>{
        var rows = data.rows;
        if(rows && rows.length > 1){
          rows.splice(0,1);
          if(rows.length > 0){
            this.firstMessageKey = rows[rows.length - 1].key;
            var messages = [];
            for (var i = 0; i < rows.length; i++) {
              var message = new Message();
              message.setProperty(rows[i].value);
              messages.push(message);
            }
            var allMessages = messages.concat(self.state.messages);
            allMessages.sort(function(a,b){
              return b.date.getTime() - a.date.getTime();
            })

            for (var i = 0; i < allMessages.length; i++) {
              if(allMessages[i].type == "Message_Time"){
                allMessages.splice(i,1)
              }
            }
            var lastMessage = allMessages[0];
            for (var i = 0; i < allMessages.length; i++) {
              var tmp = allMessages[i];
              if( lastMessage.date.getTime() - tmp.date.getTime() > Config.message_time_line_interval){
                allMessages.splice(i,0,{type:"Message_Time",date:lastMessage.date})
              }
              lastMessage = tmp;
            }
            this.messages = allMessages;
            self.setState({
              messages:allMessages,
              dataSource:self.state.dataSource.cloneWithRows(allMessages),
            });
            setTimeout(function () {
              self.isLoading = false;
            }, 500);
          }
        }
      });
    }
  }

  onScroll(){
    if (this.refs.chat_list.scrollProperties.offset + this.refs.chat_list.scrollProperties.visibleLength >= this.refs.chat_list.scrollProperties.contentLength){
       this.first = true
       this.refs.chat_list.props.onEndReached();
   }
  }
  //聊天框
  renderInputView(){
    //multiline={true}  default
    //onFocus={this.inputFocus.bind(this)}
    //this.setState({inputText:text})
    return(
      <View style={{height:Tools.fixWidth(46),flexDirection:'row',justifyContent:'center'}}>
        <View style={styles.inputBg}>
          <TextInput
            style={styles.input}
            placeholder={"输入聊天文字"}
            returnKeyType={"send"}
            onSubmitEditing={this.sendText.bind(this)}
            value={this.state.inputText}
            fontSize={Tools.fixWidth(12)}
            paddingLeft={5}
            onChangeText={(text) => this.setState({inputText:text})}
            />
        </View>
        <TouchableHighlight onPress={this.showActionSheet.bind(this)}
          underlayColor="gary"
          style={{width:Tools.fixWidth(30),
            height:Tools.fixWidth(30),
            marginLeft:Tools.fixWidth(9),
            marginRight:Tools.fixWidth(12),
            marginTop:Tools.fixWidth(8),
            justifyContent:"center",
            alignItems:"center"}}>
            <View>
            <Image style={{width:Tools.fixWidth(30),height:Tools.fixWidth(30)}} resizeMode='stretch' source={require('../../images/icon_msg_more.png')}/>
            </View>
          </TouchableHighlight>
      </View>
    )
  }



  _render(){
    var doctorId = null;
    for (var i = 0; i < this.props.group.members.length; i++) {
      if(this.props.group.members[i] && this.props.group.members[i].indexOf("doctor") === 0){
        doctorId = this.props.group.members[i];
        break;
      }
    }

    if (this.state.renderPlaceholderOnly) {
      return  (
        <View style={[Styles.center,{flex:1}]}>
          <Text>Loading...</Text>
        </View>
      );
    }

    return (
      <View  style={[styles.tabContent, {backgroundColor: '#FFFFFF'}]}>
        <Animated.View  style={[this.state.moveAnim.getLayout(),{flex:1}]}>
          <View style={{flex:1}} {...this._panResponder.panHandlers}>
            <FQListView
              removeClippedSubviews={true}
              pageSize={15}
              renderScrollComponent={props => <InvertibleScrollView {...props} inverted />}
              style={{marginBottom:Tools.fixWidth(5)}}
              ref="chat_list"
              onScroll={this.onScroll.bind(this)}
              onKeyboardWillShow={this.KeyboardWillShow.bind(this)}
              onKeyboardWillHide={this.KeyboardWillHide.bind(this)}
              dataSource={this.state.dataSource}
              renderRow={this.renderRow.bind(this)}
              onEndReached={this.loadHistory.bind(this)}
            />
          </View>
          <View style={Styles.line}/>
          </Animated.View>
          <Animated.View style={[{marginBottom:-ChatFeatures.Height},this.state.moveAnim2.getLayout()]}>
            {
              this.renderInputView()
            }
              <ChatFeatures onPress={this.onChatFeaturesPress.bind(this)} disableSendRecord={doctorId == null}/>
          </Animated.View>
      </View>
    )
  }
  componentWillMount() {
    this._panResponder = PanResponder.create({
      onStartShouldSetPanResponder: (evt, gestureState) => { this.hideFeatures(); return false;},
      onStartShouldSetPanResponderCapture: (evt, gestureState) => {this.hideFeatures(); return false;},
    });
  }
  showFeatures(){
    if(this.isKeyboardIsShow || this.isFeatureShow) return;
    this.isFeatureShow = true;
    Animated.timing(
      this.state.moveAnim2,
      {toValue: {x: 0, y: -ChatFeatures.Height},duration: 200}
    ).start();
    Animated.timing(
      this.state.moveAnim,
      {toValue: {x: 0, y: -ChatFeatures.Height},duration: 200}
    ).start();
  }
  hideFeatures(){
    if(this.isKeyboardIsShow) return;
    this.isFeatureShow = false;
    Animated.timing(
      this.state.moveAnim2,
      {toValue: {x: 0, y: 0},duration: 200}
    ).start();
    Animated.timing(
      this.state.moveAnim,
      {toValue: {x: 0, y: 0},duration: 200}
    ).start();
  }
  onChatFeaturesPress(index){
    var self = this;
    var options = {
      title:"发送图片",
      cancelButtonTitle: '取消',
      takePhotoButtonTitle: '拍照', // specify null or empty string to remove this button
      chooseFromLibraryButtonTitle: '选择图片', // specify null or empty string to remove this button
      maxWidth: 600,
      maxHeight: 600,
      quality: 0.7,
      allowsEditing: false, // Built in iOS functionality to resize/reposition the image
      noData: false, // Disables the base64 `data` field from being generated (greatly improves performance on large photos)
      storageOptions: { // if this key is provided, the image will get saved in the documents directory (rather than a temporary directory)
        skipBackup: true, // image will NOT be backed up to icloud
        path: User.currentUser.documentID+'/uploadImages' // will save image at /Documents/images rather than the root
      }
    };
    if(index === 0){
        if(React.Platform.OS === 'ios'){
          UIImagePickerManager.showImagePicker(options, (didCancel, response) => {
            if (didCancel) return;
            var message = new Message(this.channel);
            message.messageType = 1;
            message.message = {width:response.width,height:response.height,objectKey:response.fileName,status:0}; //本地图片名
            message.from = User.currentUser.documentID;
            message.group = this.props.group.documentID;
            message.save(()=>{
              DatabaseManager.instance.currentDatabase.checkUploadFile();
            });
          });
        }else if (React.Platform.OS === 'android') {
            React.NativeModules.ActionSheet.showActionSheet(["拍照","选择图片"],"取消",(index)=>{
              React.NativeModules.AndroidSelectPhoto.selectPhoto(index,options,(response)=>{
                var message = new Message(this.channel);
                message.messageType = 1;
                message.message = {width:response.width,height:response.height,objectKey:response.fileName,status:0}; //本地图片名
                message.from = User.currentUser.documentID;
                message.group = this.props.group.documentID;
                this.appenMessage(message);
                message.save(()=>{
                  DatabaseManager.instance.currentDatabase.checkUploadFile();
                });
              })
            })
        }



    }else if (index === 1) {
      self.props.navigator.push({
        component:<SelectPatientView navigator={self.props.navigator} onPress={(d)=>{
          var doctorId = null;
          var patientId = d.patient.documentID;
          for (var i = 0; i < self.props.group.members.length; i++) {
            if(self.props.group.members[i].indexOf("doctor") === 0){
              doctorId = self.props.group.members[i];
              break;
            }
          }
          if(patientId && doctorId){
            self.post("patient/authorize_user",{doctor_id:doctorId,patient_id:patientId},(data)=>{
               var message = new Message(self.channel);
               message.messageType = 2;
               message.message = {doctor_id:doctorId,patient_id:patientId};
               message.group = self.props.group.documentID;
               message.from = User.currentUser.documentID;
               this.appenMessage(message);
               message.save();
            })
          }
        }}/>
      })
    }else if (index === 2) {

    }
    console.log("---->",index);
  }
  showActionSheet(){
    this.showFeatures()
    return;
  }
}

var styles = StyleSheet.create({
  tabContent: {
    flex: 1,
    alignItems: 'stretch',
  },
  tabText: {
    color: 'white',
    margin: 50,
  },

  inputBg:{
    borderWidth:1,
    height: Tools.fixWidth(35),
    borderColor:'#CCC',
    borderRadius:Tools.fixWidth(5),
    marginTop:Tools.fixWidth(5),
    marginLeft:Tools.fixWidth(12),
    flex:1,
  },
  input:{
    height:Tools.fixWidth(35),
    backgroundColor:'transprent',
  },
  addFeatures:{
    width:Tools.fixWidth(30),
    height:Tools.fixWidth(30),
    marginLeft:Tools.fixWidth(9),
    marginRight:Tools.fixWidth(12),
    marginTop:Tools.fixWidth(8),
    justifyContent:"center",
    alignItems:"center"
  },

});


module.exports = GroupChatView;
