'use strict';
var React = require('react-native');
var {
  StyleSheet,
  Text,
  View,
  Image,
  TouchableHighlight,
} = React;
var Dimensions = require('Dimensions');
var {User,Patient,FriendShip,Message} = require("../Models");
var {Config,Color,Tools,ImageView} = require('../../Styles');
var WebView = require('../WebView');
let resWidth =  Dimensions.get('window').width - Tools.fixWidth(120)
var ChatRow = require('./ChatRow');

class ServerRow extends ChatRow{

  onItemClick(){
    var Judge = require('../service/ServiceJudge')
    this.props.navigator.push({
      component: <Judge navigator={this.props.navigator} service={this.state.message.message.serviceId} message={this.state.message.message}/>
    })
    // var url = Config.webServerURL+"payment/pay_service?";
    // url += "serviceId="+this.state.message.message.serviceId;
    // this.props.navigator.push({
    //   component: <WebView navigator={this.props.navigator} url={url}/>
    // })
  }

  renderContent(fromMe){
    var msg = this.state.message.message
    return(
      <View style={istyles.cell}>
        <View style={istyles.content}>
          <Image style={istyles.icon} source={{uri: msg.icon}}/>
          <View style={istyles.full}>
              <Text numberOfLines={1} style={istyles.desLabel}>¥{msg.price}</Text>
              <Text numberOfLines={2} style={istyles.desLabel}>提供者:{msg.provider}</Text>
              <Text numberOfLines={3} style={istyles.desLabel}>{msg.title}</Text>
          </View>
        </View>
      </View>
    )
  }

}


var istyles = StyleSheet.create({
  full:{
    flex:1,
  },
  cell:{
    width:resWidth,
    height:Tools.fixWidth(75),
    padding:Tools.fixWidth(6),

    borderWidth: Tools.fixWidth(1),
    borderRadius: Tools.fixWidth(4),
    borderColor: Color.chatBorder,
  },
  content:{
    flexDirection:'row',
  },
  icon:{
    width:Tools.fixWidth(40),
    height:Tools.fixWidth(40),
  },
  desContainer:{
    flex:1,
    marginLeft:Tools.fixWidth(5),
  },
  desLabel:{
    flex:1,
    marginBottom:Tools.fixWidth(2),
    marginLeft:Tools.fixWidth(5),
    fontSize:Tools.fixWidth(10),
    color:'#666'
  }
});



module.exports = ServerRow;
