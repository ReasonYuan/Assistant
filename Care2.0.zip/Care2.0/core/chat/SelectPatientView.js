'use strict';

var React = require('react-native');
var {
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableHighlight,
  Navigator,
  ScrollView,
  ListView,
} = React;

var {Styles,Button,BaseComponent,FQListView} = require('../../Styles');
var {User,Patient,Record} = require("../Models")
var {DatabaseManager,DatabaseView} = require('../couchbase/Couchbase');
var MK = require('react-native-material-kit');
const {
  MKRadioButton,
} = MK;



class SelectPatientView extends BaseComponent {
  selectPatient:Patient;
  constructor(props){
    super(props)
    var config = {title:"选择健康档案",leftButtonTitle:"取消",rightButtonTitle:"确定"};
      var ds = new ListView.DataSource({rowHasChanged: (r1, r2) => true});
    this.state = {navigatorBarConfig:config,dataSource: ds}
    var db = DatabaseManager.instance.currentDatabase;
    var patientView =  new DatabaseView(db,"Patient","PatientView","function(doc) { if(doc.type == 'Patient') emit(doc.date,doc)}",()=>{
        patientView.setOnDataChangeCallback((data)=>this.onPatientChanged(data));
    });
    this.patientView = patientView;
    this.selectPatient = null;
  }
  componentWillUnmount(){
    super.componentWillUnmount()
    if(this.patientView)this.patientView.stop();
  }
  onPatientChanged(data){
    var patients = [];
    for (var i = 0; i < data.length; i++) {
        var patient = new Patient();
        patient.setProperty(data[i].value);
        patients.push(patient);
    }
    this.selectPatient = patients[0];
    this.patients = patients;
    this.setState({selectPatient:this.selectPatient,dataSource:this.state.dataSource.cloneWithRows(patients)});
  }
  onLeftPress(){
    this.props.navigator.pop();
  }
  onRightPress(){
    this.send();
  }
  send(){
      if(this.props.onPress && this.selectPatient){
        var db = DatabaseManager.instance.currentDatabase;
        var userRecordsView =  new DatabaseView(db,"Record","RecordsView","function(doc) { if(doc.type == 'Record') emit(doc.patient,doc)}",()=>{
          userRecordsView.key = this.selectPatient.documentID;
          userRecordsView.setOnDataChangeCallback((data)=>{
            userRecordsView.stop();
            var info = {patient:this.selectPatient};
            var recordIds = [];
            for (var i = 0; i < data.length; i++) {
              var record = new Record();
              record.setProperty(data[i].value);
              recordIds.push({id:record.documentID,revision:record.rev});
            }
            info.records = recordIds;
            this.props.onPress(info);
            this.props.navigator.pop();
          });
        });
      }
  }
  onSelectPatient(patient){
    this.selectPatient = patient;
    this.setState({dataSource:this.state.dataSource.cloneWithRows(this.patients)});
  }
  renderRow(rowData,s,i){
    return (
      <View style={[Styles.content]} key={rowData.documentID}>
        <TouchableHighlight style={styles.row} underlayColor={'transparent'} onPress={()=>this.onSelectPatient(rowData)}>
        <View style={{flexDirection:'row'}}>
        <View style={{justifyContent:'center',alignItems:'center'}}>
        <MKRadioButton
          checked={rowData == this.selectPatient}
          onCheckedChange={(changed)=>{
            if(changed.checked){
              this.onSelectPatient(rowData)
            }
          }}/>
        </View>
        <View style={{flex:1,justifyContent:'center',alignItems:'center'}}>
          <Text> {rowData.relationship} </Text>
       </View>
       </View>
        </TouchableHighlight>
      </View>
    )
  }
  _render() {
    return (
      <View style={[Styles.content]}>
        <FQListView
            contentContainerStyle={styles.list}
            automaticallyAdjustContentInsets={false}
            dataSource={this.state.dataSource}
            renderRow={this.renderRow.bind(this)}
        />
      </View>
    );
  }
}


var styles = StyleSheet.create({
  list: {
    justifyContent: 'flex-start',
    flexWrap: 'wrap'
  },
  row: {
    backgroundColor: '#F6F6F6',
    height:44,
    borderWidth: 1,
    borderColor: '#CCC',
    flexDirection:'row'
  }
});


module.exports = SelectPatientView;
