'use strict';

var React = require('react-native');
var {
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableHighlight,
  Navigator,
  ScrollView,
  Image,
} = React;

var {Styles,Button,BaseComponent,Color,Tools} = require('../../Styles');
var {User,Record,Patient} = require("../Models")

class ImageButton extends React.Component {
  constructor(props) {
    super(props)
  }
  render(){
    return(
      <TouchableHighlight {...this.props} onPress={()=>{
        if(!this.props.disable && this.props.onPress){
           this.props.onPress();
        }
      }} underlayColor={this.props.disable?"transform":"gray"}>
       <Image style={[styles.imageSize,{tintColor:this.props.disable?"gray":"red"}]} source={this.props.source} />
      </TouchableHighlight>
    )
  }
}


class ChatFeatures extends React.Component {
  constructor(props){
    super(props)
  }
  render() {
    return (
      <View style={styles.content}>
        <View style={[Styles.vCenter]}>
         <View style={{flex:1,flexDirection:'row'}}>
          <ImageButton source={require('../../images/button_send_picture.png')} style={[styles.button,styles.imageSize]} disable={false} onPress={()=>{
            if(this.props.onPress)this.props.onPress(0);
          }}/>
          <ImageButton source={require('../../images/button_send_patient.png')} style={[styles.button,styles.imageSize,{marginLeft:Tools.fixWidth(45)}]} disable={this.props.disableSendRecord?this.props.disableSendRecord:false} onPress={()=>{
            if(this.props.onPress)this.props.onPress(1);
          }}/>
         </View>
        </View>
      </View>
    );
  }
}


ChatFeatures.Height = Tools.fixWidth(70);
var styles = StyleSheet.create({
  button : {
    marginLeft:Tools.fixWidth(12),
    marginTop:Tools.fixWidth(35/2),
  },
  imageSize:{
    height: Tools.fixWidth(40),
    width: Tools.fixWidth(40),
    borderRadius: Tools.fixWidth(2),
  },
  content:{
    height:ChatFeatures.Height,
    backgroundColor:'#EEEEEE'
  }
})



module.exports = ChatFeatures;
