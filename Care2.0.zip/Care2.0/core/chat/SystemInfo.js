'use strict';

var React = require('react-native');
var {
  StyleSheet,
  Text,
  View,
  Image,
  TouchableHighlight,
} = React;

var {User,Patient,FriendShip,Message} = require("../Models");
var WebView = require('../WebView');
var {Config,Color,Tools} = require('../../Styles');
var {DatabaseManager} = require("../couchbase/Couchbase");

class SystemInfo extends React.Component{
  constructor(props) {
    super(props)
    this.state = {};
    this.onSetProp(this.props);
  }
  componentWillReceiveProps(nextProps){
    this.onSetProp(nextProps);
  }
  onSetProp(props){
    if(props.message){
      var message = props.message;
      if( !this.message || this.message.documentID != message.documentID){
        this.message = message;
        var patientId = message.message.patient_id;
        var doctorId = message.message.doctor_id;
        var check = ()=>{
          if(this.patientName && this.doctorName){
            this.setState({info:"你授权"+this.doctorName+"查看"+this.patientName+"的健康档案"})
          }
        }
        DatabaseManager.instance.currentDatabase.getModel(patientId,(patient)=>{
          this.patientName = patient.relationship;
          check()
        });
        DatabaseManager.instance.currentDatabase.getModel(doctorId,(doctor)=>{
          this.doctorName = doctor.name;
          check();
        });
      }
    }
  }
  render(){
    var style = [styles.context,styles.lable,{color:this.props.color|| Color.white_border_color}];
    if(this.props.showBorder){
      style.push(styles.border);
    }
    return (
      <View style ={[{alignItems:'center'}]}>
        <View>
          <Text style={style}>{this.state.info || this.props.info}</Text>
        </View>
      </View>
    )
  }
}

SystemInfo.propTypes={
  info:React.PropTypes.string,
  showBorder:React.PropTypes.bool
}

SystemInfo.defaultProps = {
  info:"",
  showBorder:true
}

var styles = StyleSheet.create({
  context: {
    justifyContent:'center',
    borderColor: '#CCC'
  },
  border:{
    borderWidth: 1,
    borderRadius: 10,
    backgroundColor:'#F6F6F6',
  },
  lable: {
    marginTop:Tools.fixWidth(12),
    marginBottom:Tools.fixWidth(12),
    fontSize: Tools.fixWidth(10),
  },
});


module.exports = SystemInfo;
