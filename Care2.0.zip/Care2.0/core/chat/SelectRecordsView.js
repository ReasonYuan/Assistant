'use strict';
var React = require('react-native');
var {
  StyleSheet,
  TabBarIOS,
  Text,
  View,
  Image,
  ListView,
  TouchableHighlight,
  ScrollView
} = React;


var SelectRecordsView = React.createClass({
  getInitialState: function() {

    return {

    };
  },
  render:function(){
    return (
      <View style={[styles.tabContent, {backgroundColor: '#FFFFFF'}]}>
      
      </View>
    )
  }
})


var styles = StyleSheet.create({
  tabContent: {
    flex: 1,
    alignItems: 'stretch',
  },
  tagList: {
    justifyContent: 'flex-start',
    flexDirection: 'row',
    flexWrap: 'wrap'
  },
  tagrow: {
    justifyContent: 'center',
    width: 80,
    height: 50,
    backgroundColor: '#F6F6F6',
    alignItems: 'center',
    borderWidth: 1,
    borderRadius: 5,
    margin:10,
    borderColor: '#CCC'
  },
});


module.exports = SelectRecordsView;
