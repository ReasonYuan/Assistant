'use strict';
var React = require('react-native');
var {
  StyleSheet,
  Text,
  View,
  Image,
  TouchableHighlight,
} = React;
var Dimensions = require('Dimensions');
var {User,Patient,FriendShip,Message} = require("../Models");
var {Config,Color,Tools,ImageView} = require('../../Styles');
var Dimensions = require('Dimensions');
let w = Tools.fixWidth;
let carWidth = Dimensions.get('window').width - w(120)
var ChatRow = require('./ChatRow');
var UserZone = require('../team/UserZone');

class CardRow extends ChatRow{

  onItemClick(){
    // var ProfileView = require("../profile/DoctorProfile")
    // this.props.navigator.push({
    //   component:<UserZone navigator={this.props.navigator.props.navigator} user={this.state.message.message} hiddenMsg={true}/>
    // });
    this.props.navigator.push({
      component:<UserZone
        navigator={this.props.navigator}
        name = {this.state.message.message.name || "" }
        userInfo = {this.state.message.message}
        uri={this.state.imageUrl}
        objectKey={this.state.message.message.headIcon?this.state.message.message.headIcon.objectKey:null}
        userId = {this.state.message.message.documentID}
        showMessageButton={false}
        />
    });

  }

  renderContent(fromMe){
    var doctor = this.state.message.message;
    return(
        <View style={istyles.full}>
          <View style={istyles.iconContainer}>
            <ImageView style={istyles.icon} imageKey={doctor.headIcon.objectKey} />
            <Image style={istyles.logo} source={require('../../images/icon_card_logo.png')}/>
          </View>

          <View style={istyles.contentContainer}>
            <Text style={istyles.nameLabel} numberOfLines={1}>{doctor.name}</Text>
            <Text style={istyles.dspLabel} numberOfLines={1}>{doctor.department}</Text>
            <Text style={istyles.dspLabel} numberOfLines={1}>{doctor.hospital}</Text>
          </View>
        </View>
      )
  }
}


var istyles = StyleSheet.create({
  full:{
    flexDirection:'row',
    width:carWidth,
    height:w(72),
    padding:w(6),

    borderWidth: w(1),
    borderRadius: w(4),
    borderColor: Color.chatBorder,
  },
  iconContainer:{
    width:w(35),
    height:w(60),
    paddingRight:w(5),
    justifyContent:'center',
    alignItems:'center',
    borderRightWidth:w(1),
    borderColor:'#ecedee'
  },
  icon:{
    width:w(30),
    height:w(30),
    borderRadius:w(5),
    backgroundColor:'#777'
  },
  logo:{
    width:w(28),
    height:w(28),
    marginTop:w(2),
  },
  contentContainer:{
    flex:1,
    marginLeft:w(5),
    marginVertical:w(6),
  },
  nameLabel:{
    fontSize:w(11),
    marginBottom:w(7),
    color:'#333'
  },
  dspLabel:{
    fontSize:w(10),
    marginTop:w(2),
    color:"#999"
  },
});


module.exports = CardRow;
