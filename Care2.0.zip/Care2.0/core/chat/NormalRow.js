'use strict';
var React = require('react-native');
var {
  StyleSheet,
  Text,
  View,
  Image,
  TouchableHighlight,
} = React;
var Dimensions = require('Dimensions');
var {User,Patient,FriendShip,Message} = require("../Models");
var {Config,Color,Tools} = require('../../Styles');

var ChatRow = require('./ChatRow');

class NormalRow extends ChatRow{

  renderContent(fromMe){
    var borderWidth = {
      borderWidth:fromMe?0:1,
      borderColor:fromMe?'transparent':'#CCC',
    };
    return(
      <View style={[styles.lableRadius,borderWidth,{backgroundColor:fromMe?"#52B5A6":'transparent'}]}>
        <Text style={[styles.lable,styles.lableRadius,styles.lableStyle,{maxWidth:this.maxWidth},{color:fromMe?"white":"#666666"}]}
          >
        {this.state.message.message}</Text>
      </View>
    )
  }
}


var styles = StyleSheet.create({
  lable: {
    fontWeight: '600',
    fontSize: Tools.fixWidth(11),
    padding:Tools.fixWidth(10),
  },
  lableRadius:{
    borderRadius: Tools.fixWidth(5),
  },
  lableStyle:{
    overflow:'hidden',
    justifyContent:'center',
  },
});


module.exports = NormalRow;
