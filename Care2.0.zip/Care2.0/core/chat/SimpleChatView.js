'use strict';
var React = require('react-native');
var {
  StyleSheet,
  TabBarIOS,
  Text,
  View,
  Image,
  ListView,
  TouchableHighlight,
  TextInput,
  ScrollView,
  Animated,
  ActionSheetIOS,
  PanResponder,
  InteractionManager,
} = React;

var Dimensions = require('Dimensions');
var {Styles,Button,BaseComponent,Config,Color,Tools,FQListView} = require('../../Styles');
var UIImagePickerManager = require('NativeModules').UIImagePickerManager;
var Models = require("../Models");
var {User,Patient,FriendShip,Message,Service} = Models;
var {DatabaseView,DatabaseManager} = require("../couchbase/Couchbase");
var SelectPatientView = require('./SelectPatientView');
var { NativeAppEventEmitter } = React;
var InvertibleScrollView = require('react-native-invertible-scroll-view');
var ChatFeatures = require('./ChatFeatures');
var SystemInfo = require('./SystemInfo');
var NormalRow = require('./NormalRow');
var ImageRow = require('./ImageRow');
var ServerRow = require('./ServerRow');
var CardRow = require('./CardRow');
var ResourceRow = require('./ResourceRow');

var {Fetch} = require('../../JSLibrary/Logic')

class SimpleChatView extends BaseComponent {
  channel:String;
  firstMessageKey:String;
  isLoading:Boolean;
  contentOffset:Number;
  isKeyboardIsShow:Boolean;
  isFeatureShow:Boolean;
  constructor(props) {
    super(props)
    this.firstMessageKey = null,
    this.isLoading = false;
    this.contentOffset = 0;
    this.isKeyboardIsShow = false;
    var config = {title:"健康管家",showBackIcon:true};
    this.isFeatureShow = false;
    this.state = {
      dataSource: new ListView.DataSource({rowHasChanged: (r1, r2) => r1 !== r2}),
      friendName:"",
      inputText:"",
      moveAnim: new Animated.ValueXY(),
      moveAnim2:new Animated.ValueXY(),
      chatHistory:[],
      messages:[],
      navigatorBarConfig:config,
      renderPlaceholderOnly: true,
    };
    if(!this.props.friendShip)console.error("no friendShip");
    var self = this;
    this.channel = Models.getChannle(this.props.friendShip.from,this.props.friendShip.to);
    var friendShip = this.props.friendShip;
    var db = DatabaseManager.instance.currentDatabase;
    var channelMessageView =  new DatabaseView(db,"Message","MessageView_"+this.channel,"function(doc) { if(doc.type == 'Message') && ( doc.channel == '"+this.channel+"')) { emit(doc.date,doc);} }",()=>{
      channelMessageView.setOnDataChangeCallback((data)=>this.onDataChanged(data));
    });
    channelMessageView.beforeUpdate = ()=>{
      if(!self.firstMessageKey){
        channelMessageView.limit = 10;
        channelMessageView.descending = true;
      }else{
        channelMessageView.startKey = self.firstMessageKey;
        channelMessageView.limit = null;
        channelMessageView.descending = null;
      }
    }
    this.channelMessageView = channelMessageView;
    // var myID = User.currentUser.documentID;
    // var friendName = User.currentUser.documentID;
    // if( User.currentUser.documentID == this.props.friendShip.from){
    //   friendName = this.props.friendShip.to;
    // }
    // if( User.currentUser.documentID == this.props.friendShip.to){
    //   friendName = this.props.friendShip.from;
    // }
    // DatabaseManager.instance.currentDatabase.getModel(friendName,(from)=>{
    //    self.setState({
    //      friendName:from.name
    //    })
    // });
  }
  onLeftPress(){
    this.pop()
  }
  KeyboardWillShow(e){
    this.hideFeatures();
    this.isKeyboardIsShow = true;
  }
  KeyboardWillHide(e){
    this.isKeyboardIsShow = false;
  }
  getHeadIcon(id,cb){
    DatabaseManager.instance.currentDatabase.getModel(id,(from)=>{
       from.getAttachment("head",(data)=>{
         if(data){
           cb(data);
         }
       })
    });
  }
  componentWillUnmount(){
    super.componentWillUnmount()
    if(this.channelMessageView)this.channelMessageView.stop();
  }
  componentDidMount(){
    var self = this;
    var myID = User.currentUser.documentID;
    var friendName = User.currentUser.documentID;
    if( User.currentUser.documentID == this.props.friendShip.from){
      friendName = this.props.friendShip.to;
    }
    if( User.currentUser.documentID == this.props.friendShip.to){
      friendName = this.props.friendShip.from;
    }
    DatabaseManager.instance.currentDatabase.getModel(friendName,(from)=>{
       self.setState({
         friendName:from.name
       })
    });
    InteractionManager.runAfterInteractions(() => {
          this.setState({renderPlaceholderOnly: false});
    });
  }
  onDataChanged(data){
    if(data.length <= 0) return;
    var newDate =  [];
    for (var i = 0; i < data.length; i++) {
      if(data[i].key)newDate.push(data[i]);
    }
    data = newDate; //TODO 删除判断
    if(!this.firstMessageKey){
      this.firstMessageKey = data[data.length - 1].key;
      this.channelMessageView.limit = null;
      this.channelMessageView.descending = null;
      this.channelMessageView.startKey = this.firstMessageKey;
      var sortFunc = function(a,b){
        return new Date(new Number(a.key)).getTime() - new Date(new Number(b.key)).getTime()
      }
      data.sort(sortFunc);
    }
    var messages = [];
    for (var i = 0; i < data.length; i++) {
      var message = new Message();
      message.setProperty(data[i].value);
      messages.push(message);
    }
    messages.sort(function(a,b){
      return a.date.getTime() - b.date.getTime();
    })
    if(messages.length > 0){
      User.currentUser.getProfile((profile)=>{
        if(profile.setting[this.channel] !== messages[messages.length - 1].date.getTime().toString()){
          profile.setting[this.channel] = messages[messages.length - 1].date.getTime().toString();
          profile.save();
        }
      });
    }
    messages.sort(function(a,b){
      return b.date.getTime() - a.date.getTime();
    })
    var lastMessage = messages[0];
    for (var i = 0; i < messages.length; i++) {
      var tmp = messages[i];
      if( lastMessage.date.getTime() - tmp.date.getTime() > Config.message_time_line_interval){
        messages.splice(i,0,{type:"Message_Time",date:lastMessage.date})
      }
      lastMessage = tmp;
    }
    this.messages = messages;
    this.setState({
      messages:messages,
      dataSource:this.state.dataSource.cloneWithRows(messages)
    });
  }
  sendText(){
    var text = this.state.inputText;
    // this.setState({inputText:""});
    if(text && text != ""){
      var message = new Message(this.channel);
      message.messageType = 0;
      message.message = text;
      message.from = User.currentUser.documentID;
      message.to = this.props.friendShip.getFriendId();
      this.appenMessage(message);
      message.save();
    }
  }
  appenMessage(message){
    if(this.messages && Array.isArray(this.messages)){
      var messages = [];
      for (var i = 0; i < this.messages.length; i++) {
        messages.push(this.messages[i])
      }
      messages.push(message);
      messages.sort(function(a,b){
        return b.date.getTime() - a.date.getTime();
      })
      this.setState({inputText:"",dataSource:this.state.dataSource.cloneWithRows(messages)});
    }
  }
  onRightPress(){
    if(this.props.onRightPress) this.props.onRightPress();
  }
  renderRow(rowData, sectionID: number, rowID: number){
    if(rowData.type === 'Message'){
      if(rowData.messageType == 0){ //普通消息
        return (
          <NormalRow
            key = {rowData.messageType}
            message = {rowData}
            relationship = {this.props.friendShip}
          />
        )
      }else if (rowData.messageType == 1) {
        return (
          <ImageRow
            key = {rowData.messageType}
            message = {rowData}
            view={this}
            relationship = {this.props.friendShip}
          />
        )
      }else if (rowData.messageType == 2) { //share
        return (
          <SystemInfo color={Color.default_color} key={rowData.documentID}  message={rowData} info={""} showBorder={false}/>
        )
      }else if (rowData.messageType == 3) { //资源
          return (
            <ResourceRow
              key = {rowData.documentID}
              message = {rowData}
              relationship = {this.props.group}
              navigator = {this.props.navigator}
            />
          )
      }else if (rowData.messageType == 5) { //名片ResourceRow
          return (
            <CardRow
              key = {rowData.documentID}
              message = {rowData}
              relationship = {this.props.group}
              navigator = {this.props.navigator}
            />
          )
      }else if (rowData.messageType == 4) { //服务
        return (
          <ServerRow
            key = {rowData}
            message = {rowData}
            relationship = {this.props.group}
            navigator = {this.props.navigator}
          />
        )
    }
    }else if (rowData.type === "Message_Time") {
      var info = rowData.date.format("yyyy-MM-dd");
      if(info === new Date().format("yyyy-MM-dd")){
        info = rowData.date.formatAMPM();
      }else{
        info = rowData.date.format("yyyy-MM-dd hh:mm");
      }
      return <SystemInfo color={"#333333"}  info={info} showBorder={false}/>
    }
    return (
      <View/>
    )
  }
  componentDidUpdate() {
    try {
      var self = this;
      if(self.isLoading) return;
      let listView = self.refs.chat_list;
      let scrollView = listView.refs.listviewscroll;
      if(scrollView)scrollView.scrollTo(0);
    } catch (e) {
      console.log(e);
    }

  }

  onScroll(){
    if (this.refs.chat_list.scrollProperties.offset + this.refs.chat_list.scrollProperties.visibleLength >= this.refs.chat_list.scrollProperties.contentLength){
       this.first = true
       this.refs.chat_list.props.onEndReached();
   }
  }

  loadHistory(){
    if(!this.isLoading){
      this.isLoading = true;
      var self = this;
      var url = this.channelMessageView.getUrl();
      url += "?startkey=\""+this.firstMessageKey+"\"&limit=10&descending=true";
      fetch(url).then((response) => response.json())
      .then((data)=>{
        var rows = data.rows;
        if(rows && rows.length > 1){
          rows.splice(0,1);
          if(rows.length <= 0) return;
          var newRows =  [];
          for (var i = 0; i < rows.length; i++) {
            if(rows[i].key)newRows.push(rows[i]);
          }
          rows = data.rows;
          rows = newRows; //TODO 删除判断
          if(rows.length > 0){
            this.firstMessageKey = rows[rows.length - 1].key;
            var messages = [];
            for (var i = 0; i < rows.length; i++) {
              var message = new Message();
              message.setProperty(rows[i].value);
              messages.push(message);
            }
            var allMessages = messages.concat(self.state.messages);
            for (var i = 0; i < allMessages.length; i++) {
              if(allMessages[i].type == "Message_Time"){
                allMessages.splice(i,1)
              }
            }
            allMessages.sort(function(a,b){
              return b.date.getTime() - a.date.getTime();
            })
            var lastMessage = allMessages[0];
            for (var i = 0; i < allMessages.length; i++) {
              var tmp = allMessages[i];
              if( lastMessage.date.getTime() - tmp.date.getTime() > Config.message_time_line_interval){
                allMessages.splice(i,0,{type:"Message_Time",date:lastMessage.date})
              }
              lastMessage = tmp;
            }
            this.messages = allMessages;
            self.setState({
              messages:allMessages,
              dataSource:self.state.dataSource.cloneWithRows(allMessages),
            });
            this.setTimeout(function () {
              self.isLoading = false;
            }, 500);
            return;
          }
        }
      });
    }
  }
  _render(){
    if (this.state.renderPlaceholderOnly) {
      return  (
        <View style={[Styles.center,{flex:1}]}>
          <Text>Loading...</Text>
        </View>
      );
    }
    return (
      <View style={[styles.tabContent, {backgroundColor: '#FFFFFF'}]}>
          <Animated.View  style={[this.state.moveAnim.getLayout(),{flex:1}]}>
            <View style={{flex:1}} {...this._panResponder.panHandlers}>
              <FQListView
                pageSize={15}
                automaticallyAdjustContentInsets={false}
                renderScrollComponent={props => <InvertibleScrollView {...props} inverted />}
                style={{marginBottom:Tools.fixWidth(5)}}
                ref="chat_list"
                onScroll={this.onScroll.bind(this)}
                onKeyboardWillShow={this.KeyboardWillShow.bind(this)}
                onKeyboardWillHide={this.KeyboardWillHide.bind(this)}
                dataSource={this.state.dataSource}
                renderRow={this.renderRow.bind(this)}
                onEndReached={this.loadHistory.bind(this)}
              />
            </View>
            <View style={Styles.line}/>

          </Animated.View>
          <Animated.View style={[{marginBottom:-ChatFeatures.Height},this.state.moveAnim2.getLayout()]}>
            <View style={{height:Tools.fixWidth(46),flexDirection:'row',justifyContent:'center'}}>
              <View style={styles.inputBg}>
                <TextInput
                  style={styles.input}
                  placeholder={"输入聊天文字"}
                  returnKeyType={"send"}
                  onSubmitEditing={this.sendText.bind(this)}
                  value={this.state.inputText}
                  fontSize={Tools.fixWidth(12)}
                  paddingLeft={5}
                  onChangeText={(text) => this.setState({inputText:text})}
                  />
              </View>
              <TouchableHighlight onPress={this.showActionSheet.bind(this)}
                underlayColor="gary"
                style={{width:Tools.fixWidth(30),
                  height:Tools.fixWidth(30),
                  marginLeft:Tools.fixWidth(9),
                  marginRight:Tools.fixWidth(12),
                  marginTop:Tools.fixWidth(8),
                  justifyContent:"center",
                  alignItems:"center"}}>
                  <View>
                  <Image style={{width:Tools.fixWidth(30),height:Tools.fixWidth(30)}} resizeMode='stretch' source={require('../../images/icon_msg_more.png')}/>
                  </View>
                </TouchableHighlight>
            </View>
              <ChatFeatures onPress={this.onChatFeaturesPress.bind(this)} disableSendRecord={true}/>
          </Animated.View>
      </View>
    )
  }
  componentWillMount() {
    this._panResponder = PanResponder.create({
      onStartShouldSetPanResponder: (evt, gestureState) => { this.hideFeatures(); return false;},
      onStartShouldSetPanResponderCapture: (evt, gestureState) => {this.hideFeatures(); return false;},
    });
  }
  showFeatures(){
    if(this.isKeyboardIsShow || this.isFeatureShow) return;
    this.isFeatureShow = true;
    Animated.timing(
      this.state.moveAnim2,
      {toValue: {x: 0, y: -ChatFeatures.Height},duration: 200}
    ).start();
    Animated.timing(
      this.state.moveAnim,
      {toValue: {x: 0, y: -ChatFeatures.Height},duration: 200}
    ).start();
  }
  hideFeatures(){
    if(this.isKeyboardIsShow) return;
    this.isFeatureShow = false;
    Animated.timing(
      this.state.moveAnim2,
      {toValue: {x: 0, y: 0},duration: 200}
    ).start();
    Animated.timing(
      this.state.moveAnim,
      {toValue: {x: 0, y: 0},duration: 200}
    ).start();
  }
  onChatFeaturesPress(index){
    var self = this;
    var options = {
      title:"发送图片",
      cancelButtonTitle: '取消',
      takePhotoButtonTitle: '拍照', // specify null or empty string to remove this button
      chooseFromLibraryButtonTitle: '选择图片', // specify null or empty string to remove this button
      maxWidth: 600,
      maxHeight: 600,
      quality: 0.7,
      allowsEditing: false, // Built in iOS functionality to resize/reposition the image
      noData: false, // Disables the base64 `data` field from being generated (greatly improves performance on large photos)
      storageOptions: { // if this key is provided, the image will get saved in the documents directory (rather than a temporary directory)
        skipBackup: true, // image will NOT be backed up to icloud
        path: User.currentUser.documentID+'/uploadImages' // will save image at /Documents/images rather than the root
      }
    };
    if(index === 0){
        if(React.Platform.OS === 'ios'){
          UIImagePickerManager.showImagePicker(options, (didCancel, response) => {
            if (didCancel) return;
            var message = new Message(this.channel);
            message.messageType = 1;
            message.message = {width:response.width,height:response.height,objectKey:response.fileName,status:0}; //本地图片名
            message.from = User.currentUser.documentID;
            message.to = self.props.friendShip.getFriendId();
            this.appenMessage(message);
            message.save(()=>{
              DatabaseManager.instance.currentDatabase.checkUploadFile();
            });
          });
        }else if (React.Platform.OS === 'android') {
            React.NativeModules.ActionSheet.showActionSheet(["拍照","选择图片"],"取消",(index)=>{
              React.NativeModules.AndroidSelectPhoto.selectPhoto(index,options,(response)=>{
                var message = new Message(this.channel);
                message.messageType = 1;
                message.message = {width:response.width,height:response.height,objectKey:response.fileName,status:0}; //本地图片名
                message.from = User.currentUser.documentID;
                message.to = self.props.friendShip.getFriendId();
                this.appenMessage(message);
                message.save(()=>{
                  DatabaseManager.instance.currentDatabase.checkUploadFile();
                });
              })
            })
        }

    }else if (index === 1) {
      UIImagePickerManager.launchCamera(options, (didCancel, response) => {
        if (didCancel) return;
        var message = new Message(this.channel);
        message.messageType = 1;
        message.message = {width:response.width,height:response.height,objectKey:response.fileName,status:0}; //本地图片名
        message.from = User.currentUser.documentID;
        message.to = self.props.friendShip.getFriendId();
        this.appenMessage(message);
        message.save(()=>{
          DatabaseManager.instance.currentDatabase.checkUploadFile();
        });
      });
    }else if (index === 2) {

    }
  }
  showActionSheet(){
    this.showFeatures()
    return;
    var options = {
      title:"选择发送项",
      cancelButtonTitle: '取消',
      takePhotoButtonTitle: '拍照', // specify null or empty string to remove this button
      chooseFromLibraryButtonTitle: '选择图片', // specify null or empty string to remove this button
      customButtons: {
        '分享病历': 'sharePatient',
        '发送病历': 'sendRecords',
      },
      maxWidth: 600,
      maxHeight: 600,
      quality: 0.7,
      allowsEditing: false, // Built in iOS functionality to resize/reposition the image
      noData: false, // Disables the base64 `data` field from being generated (greatly improves performance on large photos)
      storageOptions: { // if this key is provided, the image will get saved in the documents directory (rather than a temporary directory)
        skipBackup: true, // image will NOT be backed up to icloud
        path: User.currentUser.documentID+'/uploadImages' // will save image at /Documents/images rather than the root
      }
    };
    if(this.props.sendRecords == false){
      delete options.customButtons
    }
    UIImagePickerManager.showImagePicker(options, (didCancel, response) => {
      // console.log('Response = ', response);
      var self = this;
      if (didCancel) {
        // console.log('User cancelled image picker');
      }
      else {
        if(response.customButton == "sharePatient"){
          var that = this;
          this.props.navigator.push({
            component: <SelectPatientView navigator={this.props.navigator} onlyPatient={true} onSelect={(patient)=>{
              if(patient){
                var par = {"from":that.props.friendShip.from,"to":that.props.friendShip.getFriendId(),"share_patient":patient.documentID};
                var url = Config.webServerURL+"records/share_patients";
                Fetch.post("",par,(data) => {
                    React.NativeModules.CouchbaseHelper.showToast(JSON.stringify(data));
                  },url);
                // fetch(url, {
                //     method: "POST",
                //     headers: {
                //       'Content-Type': 'application/json'
                //     },
                //     body: JSON.stringify(par)
                //   })
                //   .then((response) => response.json())
                //   .then((data) => {
                //     React.NativeModules.CouchbaseHelper.showToast(JSON.stringify(data));
                //   }).catch((err)=>{
                //     React.NativeModules.CouchbaseHelper.showToast(JSON.stringify(err));
                //     console.dblog(err);
                //   });
              }
            }}/>
          })
        }else if (response.customButton == "sendRecords") {
          this.props.navigator.push({
            component: <SelectPatientView navigator={this.props.navigator}  onSelect={(d)=>{
              if(d.records.length > 0){
                var message = new Message(self.channel);
                message.messageType = 2;
                message.message = d;
                message.from = User.currentUser.documentID;
                message.to = self.props.friendShip.getFriendId();
                message.save();
              }
            }}/>,

          })
        } else if (response.customButton == "shareRecords") {
          var that = this;
          this.props.navigator.push({
            component: <SelectPatientView navigator={this.props.navigator}  onSelect={(d)=>{
              if(d.records.length > 0){
                var records = [];
                for (var i = 0; i < d.records.length; i++) {
                  records.push(d.records[i]["id"]);
                }
                var par = {"from":that.props.friendShip.from,"to":that.props.friendShip.getFriendId(),"share_records":records};
                var url = Config.webServerURL+"records/share_records";
                Fetch.post("",par,(data) => {
                    React.NativeModules.CouchbaseHelper.showToast(JSON.stringify(data));
                  },url);
                // fetch(url, {
                //     method: "POST",
                //     headers: {
                //       'Content-Type': 'application/json'
                //     },
                //     body: JSON.stringify(par)
                //   })
                //   .then((response) => response.json())
                //   .then((data) => {
                //     React.NativeModules.CouchbaseHelper.showToast(JSON.stringify(data));
                //   }).catch((err)=>{
                //     React.NativeModules.CouchbaseHelper.showToast(JSON.stringify(err));
                //     console.dblog(err);
                //   });
              }
            }}/>
          })
        }  else {
          var message = new Message(this.channel);
          message.messageType = 1;
          message.message = {width:response.width,height:response.height,objectKey:response.fileName,status:0}; //本地图片名
          message.from = User.currentUser.documentID;
          message.to = self.props.friendShip.getFriendId();
          message.save(()=>{
            DatabaseManager.instance.currentDatabase.checkUploadFile();
          });
        }
      }
    });
  }
}

var styles = StyleSheet.create({
  tabContent: {
    flex: 1,
    alignItems: 'stretch',
  },
  tabText: {
    color: 'white',
    margin: 50,
  },
  inputBg:{
    borderWidth:1,
    height: Tools.fixWidth(35),
    borderColor:'#CCC',
    borderRadius:Tools.fixWidth(5),
    marginTop:Tools.fixWidth(5),
    marginLeft:Tools.fixWidth(12),
    flex:1,
  },
  input:{
    height:Tools.fixWidth(35),
    backgroundColor:'transprent',
  },
});


module.exports = SimpleChatView;
