'use strict';
var React = require('react-native');
var {
  StyleSheet,
  Text,
  View,
  Image,
  TouchableHighlight,
} = React;
var Dimensions = require('Dimensions');
var {User,Patient,FriendShip,Message} = require("../Models");
var {Config,Color,Tools,UserIcon} = require('../../Styles');

class ChatRow extends React.Component{
  maxWidth:Number;
  constructor(props){
    super(props);
    if(!this.props.message)console.error("no message");
    this.maxWidth = Dimensions.get('window').width - Tools.fixWidth(74)
    this.state = this.getInitState() || {};
    this.message = this.props.message;
    this.relationship = this.props.relationship;
  }

  componentWillReceiveProps(nextProps){
    if(this.state.message == nextProps.message && this.state.relationship == nextProps.relationship)return;
    var state = {};
    this.onReceiveProps(nextProps,state);
    if(Object.keys(state).length > 0){
      this.setState(state);
    }
  }

  getInitState(){
    return {message:this.props.message,relationship:this.props.relationship}
  }

  onReceiveProps(props,state){
    state.message = props.message;
    state.relationship = props.relationship;
    state.head = null;
  }

  renderHead(){
    var style = [styles.header];
    if(this.state.message.from == User.currentUser.documentID){//发送方是我
      style.push(styles.rightMargin)
    }else{
      style.push(styles.leftMargin)
    }
    if(this.state.head){
      return (
        <UserIcon
         style={style}
         user={this.state.message.from}
         thumbnailWidth={40}
         source={require('../../images/head_assistant.png')}
         />
      )
    }else {
      return (
        <UserIcon
         style={style}
         thumbnailWidth={40}
         user={this.state.message.from}
         source={require('../../images/head_assistant.png')}
         />
      )
    }
  }
  onHeadClick(){

  }
  onItemClick(){

  }
  renderContent(fromMe){

  }
  render(){
    if(this.state.message.from !== User.currentUser.documentID){
      return (
        <View key={this.props.key} style ={[styles.content,styles.topMargin,{alignItems:'flex-start',flexDirection:'row'}]}>
          <TouchableHighlight  underlayColor="transparent" onPress={this.onHeadClick.bind(this)}>
          {
            this.renderHead(false)
          }
          </TouchableHighlight>

          <TouchableHighlight  underlayColor="transparent" onPress={this.onItemClick.bind(this)}>
            <View style={{flex:1}}>
            {
              this.renderContent()
            }
            </View>
          </TouchableHighlight>

        </View>
      )
    }
    return (
      <View key={this.props.key}  style ={[styles.content,styles.topMargin,{justifyContent:'flex-end',flexDirection:'row'}]}>
        <TouchableHighlight  underlayColor="transparent" onPress={this.onItemClick.bind(this)}>
          <View>
            {
              this.renderContent(true)
            }
          </View>
        </TouchableHighlight>
        <TouchableHighlight underlayColor="transparent" onPress={this.onHeadClick.bind(this)}>
        {
          this.renderHead()
        }
        </TouchableHighlight>
      </View>
    )

  }
}


var styles = StyleSheet.create({
  topMargin:{
    marginTop:Tools.fixWidth(18),
  },
  context: {
    flex: 1,
    justifyContent:'center',
    borderWidth: 1,
    borderRadius: Tools.fixWidth(5),
    borderColor: '#CCC'
  },
  header:{
    width:Tools.fixWidth(40),
    height:Tools.fixWidth(40),
    borderRadius:Tools.fixWidth(5),
  },
  leftMargin:{
    marginLeft:Tools.fixWidth(12),
    marginRight:Tools.fixWidth(5),
  },
  rightMargin:{
    marginLeft:Tools.fixWidth(5),
    marginRight:Tools.fixWidth(12),
  },
});


module.exports = ChatRow;
