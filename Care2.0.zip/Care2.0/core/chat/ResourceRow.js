'use strict';
var React = require('react-native');
var {
  StyleSheet,
  Text,
  View,
  Image,
  TouchableHighlight,
} = React;
var Dimensions = require('Dimensions');
var {User,Patient,FriendShip,Message} = require("../Models");
var {Config,Color,Tools,ImageView} = require('../../Styles');
var Dimensions = require('Dimensions');
let w = Tools.fixWidth;
var {f} = require('../../utils/Porting');
let resWidth = Dimensions.get('window').width - w(120)
var ChatRow = require('./ChatRow');
var WebView = require('../WebView');

class ResourceRow extends ChatRow{

  onItemClick(){
    var url = this.state.message.message.url;
    this.props.navigator.push({
      component: <WebView title="分享详情" navigator={this.props.navigator} url={url}/>
    })
  }

  //渲染资讯icon，当没有时用默认图片
  renderIcon(url){
    if(url && url != ""){
      return <Image style={istyles.icon} source={{uri: url}}/>
    }else{
      return <Image style={istyles.icon} source={require('../../images/icon_def.png')}/>
    }
  }


  renderContent(fromMe){
    var msg = this.state.message.message
    return(
      <View style={istyles.cell}>
        <View style={istyles.content}>
          {this.renderIcon(msg.icon)}
          <Text numberOfLines={6} style={istyles.desContainer}>
            <Text numberOfLines={6} style={istyles.desLabel}>{msg.title}</Text>
          </Text>
        </View>
      </View>
    )
  }
}


var istyles = StyleSheet.create({
  cell:{
    width:resWidth,
    height:w(75),
    padding:w(6),

    borderWidth: w(1),
    borderRadius: w(4),
    borderColor: Color.chatBorder,
  },
  content:{
    flexDirection:'row',
  },
  icon:{
    width:w(40),
    height:w(40),
  },
  desContainer:{
    flex:1,
    marginLeft:w(5),
  },
  desLabel:{
    fontSize:f(10),
    color:'#666'
  }
});



module.exports = ResourceRow;
