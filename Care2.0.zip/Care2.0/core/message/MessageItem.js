'use strict';
var React = require('react-native');
var {
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableHighlight,
  Navigator,
  ScrollView,
  ListView,
  Image,
} = React;


var {Styles,Button,BaseComponent} = require('../../Styles');
var {User,Record,Patient} = require("../Models");
var {DatabaseManager,DatabaseView} = require('../couchbase/Couchbase');


class MessageItem extends React.Component {
  constructor(props){
    super(props)
    this.state = {}
  }
  render() {
    return (
      <View style={[]}>
        <TouchableHighlight style={{borderWidth:1}} onPress={this.props.onPress}>
          <View sytle={{flexDirection:'row'}}>
            <Image
               style={{width:54,height:54,borderRadius: 27,margin:6}}
               source={{uri: 'http://facebook.github.io/react/img/logo_og.png'}}
             />

            <Text sytle={{fontSize:20}}> {this.props.name} </Text>
          </View>
        </TouchableHighlight>
      </View>
    );
  }
}

module.exports = MessageItem;
