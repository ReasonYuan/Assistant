'use strict';

var React = require('react-native');
var {
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableHighlight,
  Navigator,
  ScrollView,
  ListView,
  InteractionManager,
} = React;


var {Styles,Button,BaseComponent,Config,Tools,Color,FQListView} = require('../../Styles');
var {User,Record,Patient,Group,FriendShip} = require("../Models");
var {DatabaseManager,DatabaseView} = require('../couchbase/Couchbase');
var MessageItem = require('./MessageItem');
var SimpleChatView = require('../chat/SimpleChatView');
var GroupChatView = require('../chat/GroupChatView');
var FriendShipLastMessageRow = require('./FriendShipLastMessageRow');
var GroupLastMessageRow = require('./GroupLastMessageRow');
var LastMessageView = require('./LastMessageView');


class MessageList extends BaseComponent {
  constructor(props){
    super(props)
    var config = {title:"消息"}
    var friendShip = new FriendShip(User.currentUser.documentID,User.currentUser.assistant);
    var ds = new ListView.DataSource({rowHasChanged: (r1, r2) => r1 !== r2});
    this.state = {navigatorBarConfig:config,dataSource: ds,friendShip:friendShip,renderPlaceholderOnly: true}
  }
  componentWillMount(){
    var db = DatabaseManager.instance.currentDatabase;
    var filtter = "function(doc){if(doc.type == 'Group'){emit(doc.date,doc);}}";
    var groupView =  new DatabaseView(db,["Group"],"GroupView",filtter,()=>{
      groupView.setOnDataChangeCallback((data)=>this.onDataChanged(data));
    });
    this.groupView = groupView;
    db.addChangeCallback(["Message"],this,(body)=>{
      if(body && body.length){
        User.currentUser.getProfile((profile)=>{
          var changed = false;
          for (var i = 0; i < body.length; i++) {
            var item = body[i];
            if(item && item.type == "Message" && item.group){
              changed = true;
              var channel = item.group;
              profile.setting["Group_"+channel] = item.date;
            }
          }
          if(changed){
            profile.save(()=>{
              this.sortGroup();
            })
          }
        });

      }
    })
  }
  sortGroup(){
    if(this.groups){
      User.currentUser.getProfile((profile)=>{
        var tmp = this.groups;
        var allGoups = {};
        var timestamps = [];
        for (var i = 0; i < tmp.length; i++) {
          var group = tmp[i];
          var timestamp = profile.setting["Group_"+group.documentID] || group.date.getTime()+"";
          timestamps.push(timestamp);
          allGoups[timestamp] = group;
        }
        timestamps.sort().reverse();
        var goups = [];
        for (var i = 0; i < timestamps.length; i++) {
          goups.push(allGoups[timestamps[i]])
        }
        this.setState({
          dataSource:this.state.dataSource.cloneWithRows(goups)
        });
      })
    }
  }
  componentWillUnmount(){
    super.componentWillUnmount();
    if(this.groupView){
      this.groupView.stop();
      delete this.groupView;
    }
    var db = DatabaseManager.instance.currentDatabase;
    db.removeChangeCallback("Message",this);
  }
  componentDidMount(){
    InteractionManager.runAfterInteractions(() => {
          this.setState({renderPlaceholderOnly: false});
    });
  }
  onDataChanged(data){
    var groups = [];
    for (var i = 0; i < data.length; i++) {
      var goup = new Group();
      goup.setProperty(data[i].value);
      groups.push(goup);
    }
    this.groups = groups;
    this.sortGroup();
  }
  renderRow(rowData,s,i){
    return (
      <LastMessageView key={rowData.documentID} relationship={rowData} onPress={()=>{
        this.props.navigator.push({
          component:<GroupChatView navigator={this.props.navigator} group={rowData}/>
        })
      }}/>
    )

    // return (
    //   <GroupLastMessageRow key={rowData.documentID} group={rowData} onPress={()=>{
    //     this.props.navigator.push({
    //       component:<GroupChatView navigator={this.props.navigator} group={rowData}/>
    //     })
    //   }}/>
    // )
  }
  renderAssistant(){
    if(this.state.friendShip){
      return (
        <LastMessageView key={this.state.friendShip.documentID} relationship={this.state.friendShip} onPress={()=>{
          this.props.navigator.push({
            component:<SimpleChatView navigator={this.props.navigator} friendShip={this.state.friendShip}/>
          })
        }}/>
      )
      // return (
      //   <FriendShipLastMessageRow friendShip={this.state.friendShip} user={User.currentUser.assistant} onPress={()=>{
      //     this.props.navigator.push({
      //       component:<SimpleChatView navigator={this.props.navigator} friendShip={this.state.friendShip}/>
      //     })
      //   }}/>
      // )
    }
  }


  _render() {

    if (this.state.renderPlaceholderOnly) {
      return  (
        <View style={[Styles.center,{flex:1}]}>
          <Text>Loading...</Text>
        </View>
      );
    }

    return (
      <View style={[Styles.content]}>
      {
        this.renderAssistant()
      }
        <FQListView
            automaticallyAdjustContentInsets={false}
            dataSource={this.state.dataSource}
            renderRow={this.renderRow.bind(this)}
        />
      </View>
    );
  }
}

module.exports = MessageList;
