//MessageManager
'use strict';

var React = require('react-native');
var {
  StyleSheet,
  Text,
  View,
  TouchableHighlight,
} = React;
var Models = require("../Models");
var {User,Patient,FriendShip,Group,Message} = Models;
var {DatabaseView,DatabaseManager} = require("../couchbase/Couchbase");
var {Styles,ImageView,Tools,Color,UserIcon} = require('../../Styles');
var {DatabaseView,DatabaseManager} = require("../couchbase/Couchbase");
var Emitter = React.Platform.OS === "ios"?React.NativeAppEventEmitter:React.DeviceEventEmitter;

class MessageImageView extends React.Component {
  constructor(props) {
    super(props)
    this.state = {message:this.props.message,progress:0};
    this.addListener(this.props.message);
  }
  componentWillReceiveProps(nextProps){
    this.setState({message:nextProps.message,progress:0})
    this.addListener(nextProps.message);
  }
  removeListener(){
    if(this.listener){
      this.listener.remove();
      delete this.listener;
    }
  }
  addListener(message){
    this.removeListener();
    if(message.message.status != 1){
      this.listener = Emitter.addListener("NOTIFICATION_UPLOAD_IMAGE_PROGRESS",(data)=>{
        //data {key:imageKey,progress:0-1 }
        if(data.key == message.message.objectKey){
          this.setState({progress:data.progress});
        }
      });
    }
  }
  renderProgross(){
    if(this.state.message.message.status != 1){
      var flex = parseInt(this.state.progress*100);
      if(flex < 100 && flex >= 0){
        return (
          <View style={Styles.content}>
            <View style={{flex:flex}} />
            <View style={{flex:100-flex,backgroundColor:'rgba(0,0,0,0.4)'}} />
            <View style={styles.overlay}>
             <Text style={styles.progress}>{flex+"%"}</Text>
            </View>
          </View>
        )
      }
    }
  }
  render(){
    return (
      <ImageView {...this.props} imageKey = {this.state.message.message.objectKey}>
      {
        this.renderProgross()
      }
      </ImageView>
    )
  }
}

class LastMessagItem {
  members:[];     //成员Id
  name:String;    //名字
  channel:String; //如果是单聊消息有channel
  group:Group;    //如果是群聊消息有group
  friendship:FriendShip;
  message:String; //最后一条消息内容
  date:String;    //消息时间
  time:String;    //时间毫秒数
  redIcon:Boolean; //是否有未读消息
  constructor(value){
    this.members = [];
    this.name = "";
    this.channel = null;
    this.group = null;
    this.friendship = null;
    this.message = "";
    this.date = "";
    this.time = "";
    this.redIcon = false;
    if(value)this.setProperty(value);
    //找出最后一条消息
    var url = null;
    if(value instanceof FriendShip){
    }else if (value instanceof Group) {
    }
  }
  setProperty(value){
    if(value instanceof FriendShip){
      this.friendship = value;
      var uId = User.currentUser.documentID == value.from ? value.to : value.from;
      DatabaseManager.instance.currentDatabase.getModel(uId,(user)=>{
        var members = [];
        members.push(uId);
        this.members = members;
        this.name = user.name;
        this.channel = value.channel;
        this.group = null;
        if(this.changeListener)this.changeListener(this);
      })
    }else if (value instanceof Group) {
      this.members = value.members;
      this.name = value.name;
      this.channel = null;
      this.group = value;
      this.friendship = null;
      if(this.changeListener)this.changeListener(this);
    }
  }
  setChangeListener(l){
    this.changeListener = l;
  }
  setMessage(message){
    if(message.type == "Message" && message.channel == this.channel || message.group == this.group.documentID){
      var messageValue = "";
      if(message.messageType == 0){
        messageValue = message.message;
      }else if (message.messageType == 1) {
        messageValue = "【图片】"
      }else if (message.messageType == 2) {
        messageValue = "【病案】"
      }else if (message.messageType == 3) {
        messageValue = "【资讯】"
      }else if (message.messageType == 4) {
        messageValue = "【服务】"
      }else if (message.messageType == 5) {
        messageValue = "【名片】"
      }else if (message.messageType == 6) {
        messageValue = "【删除群成员】"
      }else if (message.messageType == 7) {
        messageValue = "【病案】"
      }
      var time = new Date(message.date).format("yyyy-MM-dd");
      if(time === new Date().format("yyyy-MM-dd")){
        time = message.date.formatAMPM();
      }
      this.message = messageValue;
      this.date = time;
      this.time = message.date;
      if(this.changeListener)this.changeListener(this);
      return true;
    }
    return false;
  }
}

//消息数据管理
class MessageManager {

  static instance = null;
  changeListener:Function;

  constructor() {
    this.db = DatabaseManager.instance.currentDatabase;
    if(MessageManager.instance){
      MessageManager.instance.clear();
      MessageManager.instance = null;
    }
    MessageManager.instance = this;
    this.init();
  }

  clear(){
    if(this.messageListView){
      this.messageListView.stop();
      delete this.messageListView;
    }
    this.db.removeChangeCallback("Message",this);
  }

  init(){
    this.clear();
    this.getList();
    this.db.addChangeCallback("Message",this,(body)=>{
      for (var i = 0; i < body.length; i++) {
        var item = body[i];
        if(this.lastMessagItems && item.type == "Message"){
          for (var i = 0; i < this.lastMessagItems.length; i++) {
            if(this.lastMessagItems[i].setMessage(item)) break;
          }
        }
      }
    })
  }


  //获取消息列表，friendship和group
  getList(){
    var messageListView =  new DatabaseView(this.db,["FriendShip","Group"],User.currentUser.documentID+"_FriendShip&GroupView","function(doc) { if(doc.type == 'FriendShip' || doc.type=='Group') {emit(doc.date,doc);}}",()=>{
      messageListView.setOnDataChangeCallback(this.onListChange.bind(this));
    });
    this.messageListView = messageListView;
  }
  setChangeListener(l){
    this.changeListener = l;
    this.notifyDataChange();
  }
  notifyDataChange(){
    if(this.changeListener && this.lastMessagItems){
      var assistant = null;
      var groups = [];
      for (var i = 0; i < this.lastMessagItems.length; i++) {
        var item = this.lastMessagItems[i];
        if(item.friendship) {
          assistant = item;
          continue;
        }
        groups.push(item);
      }
      this.changeListener(assistant,groups);
    }
  }
  onListChange(data){
    if(!this.lastMessagItems)this.lastMessagItems = [];
    var lastMessagItems = this.lastMessagItems;
    if(data && data.length > 0){
      for (var j = 0; j < data.length; j++) {
        var item = data[j].value;
        if(item.type=="FriendShip" && (User.currentUser.assistant == item.from || User.currentUser.assistant == item.to)){
          var value = new FriendShip();
          value.setProperty(item);
          var lItem = null;
          for (var i = 0; i < lastMessagItems.length; i++) {
            var tmp =  lastMessagItems[i];
            if(tmp && tmp.friendship && tmp.friendship.documentID === value.documentID){
              lItem = tmp;
              lItem.setProperty(value);
              break;
            }
          }
          if(!lItem){
            lItem = new LastMessagItem(value);
            lastMessagItems.push(lItem);
          }
        }else if (item.type=="Group") {
          var value = new Group();
          value.setProperty(item);
          var lItem = null;
          for (var i = 0; i < lastMessagItems.length; i++) {
            var tmp =  lastMessagItems[i];
            if(tmp && tmp.group && tmp.group.documentID === value.documentID){
              lItem = tmp;
              lItem.setProperty(value);
              break;
            }
          }
          if(!lItem){
            lItem = new LastMessagItem(value);
            lastMessagItems.push(lItem);
          }
        }
      }
      this.notifyDataChange();
    }
  }

}

var styles = StyleSheet.create({
  overlay: {
    position: 'absolute',
    top: 0,
    bottom: 0,
    left: 0,
    right: 0,
    flex: 1,
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
  },
  progress:{
    fontSize:13,
    color:'white',
  },
});


MessageManager.MessageImageView = MessageImageView;
MessageManager.LastMessagItem = LastMessagItem;
module.exports = MessageManager;
