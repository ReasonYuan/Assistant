/**
 *
 * 群聊时的群聊头像:将最多9个人的头像组成一个头像
 * @author  reason 2015-12-08
 *
 */

'use strict';

var React = require('react-native');

var {
  StyleSheet,
  Text,
  ListView,
  View,
  TouchableHighlight,
} = React;

var {ImageView,Color,len,fs,Tools,UserIcon} = require('../../Styles')
var w = Tools.fixWidth
var h = w

var {DatabaseManager,Database} = require("../couchbase/Couchbase");


class GroupHeadView extends React.Component {
   constructor(props){
     super(props)
     this.ids = props.ids

     this.state = {
       dataSource:new ListView.DataSource({rowHasChanged: (r1, r2) => r1 != r2})//r1 != r2
     }
     this.initData(props)
   }

   initData(props){
     var lineCount = 3
     if(this.props.ids.length < 5){
       var lineCount = 2
     }
     this.lineCount = lineCount
     this.cellWidth = (w(36) - (lineCount-1)*w(2))/lineCount
   }

   componentWillReceiveProps(nextProps){
     if(nextProps == this.props)return
     this.initData(nextProps)
   }

   renderItem(data,index){
     var isb = (index%this.lineCount != 0)

     return(
       <UserIcon
        key={data}
        style={[istyles.item,{width:this.cellWidth,height:this.cellWidth},isb && istyles.left]}
        user={data}
        source={require('../../images/head_assistant.png')}/>
      )
   }
   renderGrid(){
     var views = []
     var ids = this.props.ids
     var count = ids.length
     if(count > 9)count = 9
     for(var i = 0; i < count; i++){
       views.push(this.renderItem(ids[i],i))
     }
     return views
   }

   render(){
     return(
       <View style={istyles.grid}>
          {this.renderGrid()}
       </View>
     )//
    //  return(
    //    <ListView
    //      style={istyles.list}
    //     //  initialListSize={10}
    //     //  pageSize={100}
    //      automaticallyAdjustContentInsets={false}
    //      contentContainerStyle={istyles.content}
    //      dataSource={this.state.dataSource.cloneWithRows(this.props.ids)}
    //      renderRow={this.renderItem.bind(this)}/>
    //  )
   }
}

var istyles = StyleSheet.create({
  list:{
    width:w(40),
    height:w(40),
    padding:w(1),
    borderRadius:w(5),
    backgroundColor:'#ccc'
  },
  content:{
    flexWrap:'wrap',
    flexDirection:'row',
    justifyContent:'space-between'
  },
  item:{
    marginBottom:w(1.5),
  },
  grid:{
    width:w(40),
    height:w(40),
    padding:w(2),
    flexWrap:'wrap',
    flexDirection:'row',
    alignItems:'center',
    justifyContent:'center',
    borderRadius:w(5),
    backgroundColor:'#ccc'
  },
  left:{
    marginLeft:w(2)
  }
})

module.exports = GroupHeadView;
