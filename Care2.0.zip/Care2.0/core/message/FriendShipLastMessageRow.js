var React = require('react-native');
var {
  StyleSheet,
  Text,
  View,
  Image,
  TouchableHighlight,
} = React;

var Models = require("../Models");
var {User,Patient,FriendShip,Message} = Models;
var {DatabaseView,DatabaseManager} = require("../couchbase/Couchbase")
var MessageCount = require('./MessageCount');
var {Styles,ImageView,Tools,Color,UserIcon} = require('../../Styles');

/**
*好友关系的最后通话
*/
class FriendShipLastMessageRow extends React.Component {
  constructor(props) {
    super(props);
    this.state = {name:"",lastMessage:"",date:"",head:null,noReadMessageCount:0,};
  }
  componentWillMount(){
    DatabaseManager.instance.currentDatabase.addChangeCallback("User",this,(body)=>{
      for (var i = 0; i < body.length; i++) {
        var item = body[i];
        if(item.type == "User" && item._id == this.props.user){
          this.setState({name:item.name});
        }
      }
    })
  }
  componentWillUnmount(){
    if(this.channelMessageView)this.channelMessageView.stop();
    if(this.channelMessageCountView)this.channelMessageCountView.stop();
    DatabaseManager.instance.currentDatabase.removeChangeCallback("User",this);
  }
  componentDidMount(){
    if(!this.props.friendShip)console.error("no friendShip");
    var self = this;
    var id = this.props.friendShip.getFriendId();
    DatabaseManager.instance.currentDatabase.getModel(id,(from)=>{
      if(!from)return;
       self.setState({
         name:from.name
       })
       User.getHeadIcon(from.documentID,(data)=>{
         if(data){
           self.setState({
             head:data
           })
         }
       });
    });

    self.getLastChatMessage(self.props.friendShip,(view,message)=>{
      var messageValue = "";
      if(message.type == "Message"){
        if(message.messageType == 0){
          messageValue = message.message;
        }else if (message.messageType == 1) {
          messageValue = "【图片】"
        }else if (message.messageType == 2) {
          messageValue = "【病案】"
        }else if (message.messageType == 3) {
          messageValue = "【资讯】"
        }else if (message.messageType == 4) {
          messageValue = "【服务】"
        }else if (message.messageType == 5) {
          messageValue = "【名片】"
        }else if (message.messageType == 6) {
          messageValue = "【删除群成员】"
        }else if (message.messageType == 7) {
          messageValue = "【病案】"
        }
      }else if (message.type == "Service") {
        messageValue = "【服务】"
      }

      var time = message.date.format("yyyy-MM-dd");
      if(time === new Date().format("yyyy-MM-dd")){
        time = message.date.formatAMPM();
      }
      self.setState({lastMessage:messageValue,date:time});
    });
  }
  getLastChatMessage(friendShip,cb){
    var self = this;
    var channel = Models.getChannle(friendShip.from,friendShip.to);
    var db = DatabaseManager.instance.currentDatabase;
    var channelMessageView =  new DatabaseView(db,"Message","MessageView_"+channel,"function(doc) { if((doc.type == 'Message' || doc.type=='Service') && ( doc.channel == '"+channel+"')) { emit(doc.date,doc);} }",()=>{
      channelMessageView.limit = 1;
      channelMessageView.descending = true;
      channelMessageView.setOnDataChangeCallback((data)=>{
        try {
          var message = new Message();
          message.setProperty(data[0].value);
          if(cb)cb(channelMessageView,message);
          if(self.channelMessageCountView)self.channelMessageCountView.update();
        } catch (e) {

        }
      });
    });
    this.channelMessageView = channelMessageView;
    var channelMessageCountView =  new DatabaseView(db,["Profile","Message"],"MessageView_"+channel,"function(doc) { if((doc.type == 'Message' || doc.type=='Service') && ( doc.channel == '"+channel+"')) { emit(doc.date,doc);} }",()=>{
      channelMessageCountView.setOnDataChangeCallback((data)=>{
        var length = data.length;
        if(length>0&&channelMessageCountView.startKey) length -= 1;
        self.setState({noReadMessageCount:length});
        MessageCount.addCount(self.props.friendShip.documentID,length);
      });
      self.channelMessageCountView = channelMessageCountView;
    });
    channelMessageCountView.beforeUpdate = ()=>{
      User.currentUser.getProfile((profile)=>{
        var lastReadTime = profile.setting[channel];
        if(lastReadTime){
          channelMessageCountView.startKey = lastReadTime;
        }else{
          channelMessageCountView.startKey = null;
        }
      });

    }
  }
  onUserIconClick(){
    if(this.props.onPress)this.props.onPress();
  }
  render(){
    return (
      <TouchableHighlight underlayColor="transparent" onPress={this.onUserIconClick.bind(this)}>
        <View style={{backgroundColor:'#ffffff'}}>
          <View style={styles.context}>
            <TouchableHighlight style={[styles.header_width]}  underlayColor="transparent"  onPress={this.onUserIconClick.bind(this)}>
              <View>
                <UserIcon
                  user={this.props.user}
                  style={styles.header_width}
                  source={require('../../images/head_assistant.png')}
                />

              {
                (()=>{
                  if(this.state.noReadMessageCount > 0){
                    return <View style={styles.redPoint}/>
                  }
                })()
              }
              </View>
            </TouchableHighlight>
            <View style={{height:Tools.fixWidth(40),justifyContent:'center',flex:1}}>
                <Text style={{margin:5}}>{this.state.name}</Text>
                <Text style={[styles.message]} numberOfLines={1}>{this.state.lastMessage}</Text>
            </View>
            <View style={[{height:Tools.fixWidth(40),justifyContent:'center',alignItems:'center'}]}>
              <Text style={styles.text_time}>{this.state.date}</Text>
            </View>
          </View>
          <View style={styles.line} />
        </View>
      </TouchableHighlight>
    )
  }
}




var styles = StyleSheet.create({
  context: {
    flex:1,
    marginLeft:Tools.fixWidth(12),
    marginRight:Tools.fixWidth(12),
    marginTop:Tools.fixWidth(8),
    marginBottom:Tools.fixWidth(8),
    flexDirection:'row',
  },
  text_time:{
    fontSize:Tools.fixWidth(11),
    color:"#333333",
  },
  message:
  {
    position:'absolute',
    left:0,
    right:0,
    bottom:0,
    margin:5,
    color:"#999999",
    fontSize:Tools.fixWidth(10),
  },
  redPoint:{
    position:'absolute',
    top:-Tools.fixWidth(15/8),
    right:-Tools.fixWidth(15/7),
    width:Tools.fixWidth(15/2),
    height:Tools.fixWidth(15/2),
    borderRadius:Tools.fixWidth(15/4),
    backgroundColor:'red'
  },
  lable: {
    fontWeight: '600',
    fontSize: 20,
    margin:15
  },
  line:{
    backgroundColor:Color.white_border_color,
    height:1,
    marginLeft:Tools.fixWidth(12),
    marginRight:Tools.fixWidth(12),
  },
  header_width:{
    width:Tools.fixWidth(40),
    height:Tools.fixWidth(40),
    borderRadius:Tools.fixWidth(5),
  },
});


module.exports = FriendShipLastMessageRow;
