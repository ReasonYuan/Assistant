
var React = require('react-native');
var {
  StyleSheet,
  Text,
  View,
  Image,
  TouchableHighlight,
} = React;

var Models = require("../Models");
var {User,Patient,FriendShip,Message,Group} = Models;
var {DatabaseView,DatabaseManager} = require("../couchbase/Couchbase")
var MessageCount = require('./MessageCount');
var {Styles,ImageView,Tools,Color,UserIcon} = require('../../Styles');
var GroupHeadView = require('./GroupHeadView');

class LastMessageView extends React.Component {
  constructor(props) {
    super(props);
    var state = {name:"",lastMessage:"",date:"",showRedIcon:false};
    this.onPropSet(props,state);
    this.state = state;
  }
  componentWillReceiveProps(props){
    var state = {};
    this.onPropSet(props,state);
    this.setState(state);
  }
  onPropSet(props,state){
    this.relationship = props.relationship;
    if(props.relationship instanceof FriendShip){
      var userId = this.props.relationship.from;
      var self = this;
      if(userId == User.currentUser.documentID)userId = this.props.relationship.to;
      DatabaseManager.instance.currentDatabase.getModel(userId,(user)=>{
        state.name = user.name;
      })
    }else if(props.relationship instanceof Group){
      state.name = props.relationship.name;
    }
    this.getLastMessage(props);
  }

  getLastMessage(props){
    this.addMessageListener();
    var channelMessageView = null;
    var channel = this.getChannle();
    var db = DatabaseManager.instance.currentDatabase;
    if(props.relationship ){
      var filter = "function(doc) { if((doc.type == 'Message') && ( doc.group == '"+channel+"')) { emit(doc.date,doc);} }";
      if(props.relationship instanceof FriendShip){
        filter = "function(doc) { if((doc.type == 'Message') && ( doc.channel == '"+channel+"')) { emit(doc.date,doc);} }";
      }
      channelMessageView =  new DatabaseView(db,["Group"],"MessageView_"+channel,filter,()=>{
        channelMessageView.limit = 1;
        channelMessageView.descending = true;
        channelMessageView.setOnDataChangeCallback((data)=>{
          channelMessageView.stop();
          try {
            var message = new Message();
            message.setProperty(data[0].value);
            this.onMessageReceive(message);
          } catch (e) {
            console.log(e);
          }
        });
      });
    }
  }

  addMessageListener(){
    this.removeMessageListener();
    var db = DatabaseManager.instance.currentDatabase;
    db.addChangeCallback(["Message","Profile"],this,(body)=>{
      if(body && body.length){
        for (var i = 0; i < body.length; i++) {
          var item = body[i];
          if(item && item.type == "Message"){
            if(this.relationship instanceof FriendShip){
              if(item.channel == this.getChannle()){
                this.onMessageReceive(item);
              }
            }else if (this.relationship instanceof Group) {
              if(item.group == this.relationship.documentID){
                this.onMessageReceive(item);
              }
            }
          }else if (item.type == "Profile") {
            this.onProfileReSet(item);
          }
        }
      }
    })
  }

  removeMessageListener(){
    if(this.messageListener){
      var db = DatabaseManager.instance.currentDatabase;
      db.removeChangeCallback("Message",this);
      db.removeChangeCallback("Profile",this);
      delete this.messageListener;
    }
  }

  onProfileReSet(profile){
    try {
      var setting = profile.setting;
      var channel = this.getChannle();
      if(setting[channel] && this.state.date){
        var lastReadTime = new Date(new Number(setting[channel]));
        var showRedIcon = false;
        if(this.state.date.getTime() > lastReadTime.getTime()){
          showRedIcon = true;
        }
        if(this.state.showRedIcon != showRedIcon){
          this.setState({showRedIcon:showRedIcon});
          MessageCount.addCount(this.relationship.documentID,showRedIcon?1:0);
        }
      }else if(!setting[channel] && this.state.date){
        var showRedIcon = true;
        if(this.state.showRedIcon != showRedIcon){
          this.setState({showRedIcon:showRedIcon});
          MessageCount.addCount(this.relationship.documentID,showRedIcon?1:0);
        }
      }
    } catch (e) {
      console.log(e);
    }
  }

  onMessageReceive(message){
    var messageValue = "";
    var date = message.date;
    if(!(date instanceof Date)){
      date = new Date(new Number(date));
    }
    if(message.type == "Message"){
      if(message.messageType == 0){
        messageValue = message.message;
      }else if (message.messageType == 1) {
        messageValue = "【图片】"
      }else if (message.messageType == 2) {
        messageValue = "【病案】"
      }else if (message.messageType == 3) {
        messageValue = "【资讯】"
      }else if (message.messageType == 4) {
        messageValue = "【服务】"
      }else if (message.messageType == 5) {
        messageValue = "【名片】"
      }else if (message.messageType == 6) {
        messageValue = "【删除群成员】"
      }else if (message.messageType == 7) {
        messageValue = "【病案】"
      }
    }
    var time = date.format("yyyy-MM-dd");
    if(time === new Date().format("yyyy-MM-dd")){
      time = date.formatAMPM();
    }
    User.currentUser.getProfile((profile)=>{
      var state = {lastMessage:messageValue,date:date,dateText:time};
      var channel = this.getChannle();
      if(profile.setting &&  profile.setting[channel]){
        var lastReadTime = new Date( new Number(profile.setting[channel]));
        if(date.getTime() > lastReadTime.getTime()){
          state.showRedIcon = true;
        }else{
          state.showRedIcon = false;
        }
      }else{
        state.showRedIcon = true;
      }
      MessageCount.addCount(this.relationship.documentID,state.showRedIcon?1:0);
      this.setState(state);
    });
  }

  getChannle(){
    if(this.relationship instanceof FriendShip){
      return  Models.getChannle(this.relationship.from,this.relationship.to);
    }else if(this.relationship instanceof Group){
      return this.relationship.documentID;
    }
  }

  renderHead(){
    if(this.relationship instanceof FriendShip){
      var userId = this.props.relationship.from;
      if(userId == User.currentUser.documentID)userId = this.props.relationship.to;
      return(
        <View style={{marginRight:Tools.fixWidth(3)}}>
        <TouchableHighlight style={[styles.header_width]}  underlayColor="transparent">
          <View>
            <UserIcon
              user={userId}
              style={styles.header_width}
              source={require('../../images/head_assistant.png')}
            />
          </View>
        </TouchableHighlight>
        {
          (()=>{
            if(this.state.showRedIcon){
              return <View style={styles.redPoint}/>
            }
          })()
        }
        </View>
      )
    }else if (this.relationship instanceof Group) {
      return (
        <View style={{marginRight:Tools.fixWidth(3)}}>
          <GroupHeadView ids={this.relationship.members}/>
          {
            (()=>{
              if(this.state.showRedIcon){
                return <View style={styles.redPoint}/>
              }
            })()
          }
        </View>
      )
    }
  }
  render(){
    return (
      <TouchableHighlight underlayColor="transparent" onPress={this.props.onPress}>
        <View style={{backgroundColor:'white'}}>
          <View style={styles.context}>
            {this.renderHead()}
            <View style={{height:Tools.fixWidth(40),justifyContent:'center',flex:1}}>
                <Text style={{margin:5}} numberOfLines={1}>{this.state.name}</Text>
                <Text style={[styles.message]} numberOfLines={1}>{this.state.lastMessage}</Text>
            </View>
            <View style={[{height:Tools.fixWidth(40),justifyContent:'center',alignItems:'center'}]}>
              <Text style={styles.text_time}>{this.state.dateText}</Text>
            </View>
          </View>
          <View style={styles.line}/>
        </View>
      </TouchableHighlight>
    )
  }
}




var styles = StyleSheet.create({
  context: {
    flex:1,
    marginLeft:Tools.fixWidth(12),
    marginRight:Tools.fixWidth(12),
    marginTop:Tools.fixWidth(8),
    marginBottom:Tools.fixWidth(8),
    flexDirection:'row',
  },
  text_time:{
    fontSize:Tools.fixWidth(11),
    color:"#333333",
  },
  message:
  {
    position:'absolute',
    left:0,
    right:0,
    bottom:0,
    margin:5,
    color:"#999999",
    fontSize:Tools.fixWidth(10),
  },
  redPoint:{
    position:'absolute',
    top:-Tools.fixWidth(15/8),
    right:-Tools.fixWidth(15/7),
    width:Tools.fixWidth(15/2),
    height:Tools.fixWidth(15/2),
    borderRadius:Tools.fixWidth(15/4),
    backgroundColor:'red'
  },
  lable: {
    fontWeight: '600',
    fontSize: 20,
    margin:15
  },
  line:{
    backgroundColor:Color.white_border_color,
    height:1,
    marginLeft:Tools.fixWidth(12),
    marginRight:Tools.fixWidth(12),
  },
  header_width:{
    width:Tools.fixWidth(40),
    height:Tools.fixWidth(40),
    borderRadius:Tools.fixWidth(5),
  },
});


module.exports = LastMessageView;
