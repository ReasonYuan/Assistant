var React = require('react-native');
var {
  StyleSheet,
  Text,
  View,
  Image,
  TouchableHighlight,
} = React;

var Models = require("../Models");
var {User,Patient,FriendShip,Message,Group} = Models;
var {DatabaseView,DatabaseManager} = require("../couchbase/Couchbase")
var MessageCount = require('./MessageCount');
var {Styles,ImageView,Tools,Color} = require('../../Styles');
var GroupHeadView = require('./GroupHeadView');

/**
*好友关系的最后通话
*/
class GroupLastMessageRow extends React.Component {
  group:Group;
  constructor(props) {
    super(props);
    if(!this.props.group) throw new Error("no group");
    this.onGroupSet(this.props.group);

  }
  onGroupSet(group){
    this.stopView();
    if(this.group !== group){
      this.group = group;
      if(this.state){
        this.setState({name:group.name || "",lastMessage:"",date:"",head:null,noReadMessageCount:0})
      }else{
        this.state = {name:group.name || "",lastMessage:"",date:"",head:null,noReadMessageCount:0};
      }
      this.stopView();
      var db = DatabaseManager.instance.currentDatabase;
      var groupChangeView =  new DatabaseView(db,["Group"],"Group_"+group.documentID,"function(doc) { if((doc.type == 'Group') && ( doc.documentID == '"+group.documentID+"')) { emit(doc.date,doc);} }",()=>{
        groupChangeView.setOnDataChangeCallback((data)=>{
          this.setState({name:data[0].value.name || "",})
        });
      });
      this.groupChangeView = groupChangeView;
      var self = this;
      self.getLastChatMessage((view,message)=>{
        var messageValue = "";
        if(message.type == "Message"){
          if(message.messageType == 0){
            messageValue = message.message;
          }else if (message.messageType == 1) {
            messageValue = "【图片】"
          }else if (message.messageType == 2) {
            messageValue = "【病案】"
          }else if (message.messageType == 3) {
            messageValue = "【资讯】"
          }else if (message.messageType == 4) {
            messageValue = "【服务】"
          }else if (message.messageType == 5) {
            messageValue = "【名片】"
          }else if (message.messageType == 6) {
            messageValue = "【删除群成员】"
          }else if (message.messageType == 7) {
            messageValue = "【病案】"
          }
        }else if (message.type == "Service") {
          messageValue = "【服务】"
        }
        var time = message.date.format("yyyy-MM-dd");
        if(time === new Date().format("yyyy-MM-dd")){
          time = message.date.formatAMPM();
        }
        self.setState({lastMessage:messageValue,date:time});
      });
    }
  }
  componentWillUnmount(){
    this.stopView();
  }
  stopView(){
    if(this.channelMessageView){
      this.channelMessageView.stop();
      delete this.channelMessageView;

    }
    if(this.channelMessageCountView){
      this.channelMessageCountView.stop();
      delete this.channelMessageCountView;
    }
    if(this.groupChangeView){
      this.groupChangeView.stop();
      delete this.groupChangeView;
    }
  }
  componentWillReceiveProps(nextProps){
    this.onGroupSet(nextProps.group)
  }
  getLastChatMessage(cb){
    var self = this;
    var channel = this.group.documentID;
    var db = DatabaseManager.instance.currentDatabase;
    var channelMessageView =  new DatabaseView(db,["Message"],"MessageView_"+channel,"function(doc) { if((doc.type == 'Message' || doc.type=='Service') && ( doc.group == '"+channel+"')) { emit(doc.date,doc);} }",()=>{
      channelMessageView.limit = 1;
      channelMessageView.descending = true;
      channelMessageView.setOnDataChangeCallback((data)=>{
        try {
          var message = new Message();
          message.setProperty(data[0].value);
          if(cb)cb(channelMessageView,message);
          if(self.channelMessageCountView)self.channelMessageCountView.update();
        } catch (e) {

        }
      });
    });
    this.channelMessageView = channelMessageView;
    var channelMessageCountView =  new DatabaseView(db,["Profile","Message"],"MessageView_"+channel,"function(doc) { if((doc.type == 'Message' || doc.type=='Service') && ( doc.group == '"+channel+"')) { emit(doc.date,doc);} }",()=>{
      channelMessageCountView.setOnDataChangeCallback((data)=>{
        var length = data.length;
        if(length>0&&channelMessageCountView.startKey) length -= 1;
        self.setState({noReadMessageCount:length});
        MessageCount.addCount(self.props.group.documentID,length);
      });
    });
    this.channelMessageCountView = channelMessageCountView;
    channelMessageCountView.beforeUpdate = ()=>{
      User.currentUser.getProfile((profile)=>{
        var lastReadTime = profile.setting[channel];
        if(lastReadTime){
          channelMessageCountView.startKey = lastReadTime;
        }else{
          channelMessageCountView.startKey = null;
        }
      });
    }
  }
  onUserIconClick(){
    if(this.props.onPress)this.props.onPress();
  }
  render(){
    return (
      <TouchableHighlight underlayColor="transparent" onPress={this.onUserIconClick.bind(this)}>
        <View>
          <View style={styles.context}>
            <TouchableHighlight style={[styles.header_width]}  underlayColor="transparent"  onPress={this.onUserIconClick.bind(this)}>
              <View>
              <GroupHeadView ids={this.group.members}/>
              {
                (()=>{
                  if(this.state.noReadMessageCount > 0){
                    return <View style={styles.redPoint}/>
                  }
                })()
              }
              </View>
            </TouchableHighlight>
            <View style={{height:Tools.fixWidth(40),justifyContent:'center',flex:1}}>
                <Text numberOfLines={1} style={{margin:5}}>{this.state.name}</Text>
                <Text numberOfLines={1} style={[styles.message]} >{this.state.lastMessage}</Text>
            </View>
            <View style={[{height:Tools.fixWidth(40),justifyContent:'center',alignItems:'center'}]}>
              <Text style={styles.text_time}>{this.state.date}</Text>
            </View>
          </View>
          <View style={styles.line} />
        </View>
      </TouchableHighlight>
    )
  }
}




var styles = StyleSheet.create({
  context: {
    flex:1,
    backgroundColor:'white',
    paddingLeft:Tools.fixWidth(12),
    paddingRight:Tools.fixWidth(12),
    paddingTop:Tools.fixWidth(8),
    paddingBottom:Tools.fixWidth(8),
    flexDirection:'row',
  },
  text_time:{
    fontSize:Tools.fixWidth(11),
    color:"#333333",
  },
  message:
  {
    position:'absolute',
    left:0,
    right:0,
    bottom:0,
    margin:5,
    color:"#999999",
    fontSize:Tools.fixWidth(10),
  },
  lable: {
    fontWeight: '600',
    fontSize: 20,
    margin:15
  },
  redPoint:{
    position:'absolute',
    top:-Tools.fixWidth(15/8),
    right:-Tools.fixWidth(15/7),
    width:Tools.fixWidth(15/2),
    height:Tools.fixWidth(15/2),
    borderRadius:Tools.fixWidth(15/4),
    backgroundColor:'red'
  },
  line:{
    backgroundColor:Color.white_border_color,
    height:1,
    marginLeft:Tools.fixWidth(12),
    marginRight:Tools.fixWidth(12),
  },
  header_width:{
    width:Tools.fixWidth(40),
    height:Tools.fixWidth(40),
    borderRadius:Tools.fixWidth(5),
  },
});


module.exports = GroupLastMessageRow;
