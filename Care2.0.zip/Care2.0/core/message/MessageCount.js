var MessageCount = {};

MessageCount.allNoReadMessage = {};
MessageCount.changeListener = null;
MessageCount.addCount = function(id,count){
    MessageCount.allNoReadMessage[id] = count;
    var allCount = 0;
    var keys = Object.keys(MessageCount.allNoReadMessage);
    keys.forEach(function (key) {
        allCount += MessageCount.allNoReadMessage[key];
    })
    if(MessageCount.changeListener)MessageCount.changeListener(allCount);
}


module.exports = MessageCount;
