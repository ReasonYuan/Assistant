'use strict';

var React = require('react-native');
var {
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableHighlight,
  Navigator,
  ScrollView,
  ListView,
  Image,
} = React;

var {Styles,Button,BaseComponent,Tools,Color,Config} = require('../../Styles');
var Models = require("../Models");
var {User,Plan,Record} = Models;

class PlanItem extends React.Component {
  constructor(prop) {
    super(prop)
    if(!this.props.plan) throw new Error("no plan");
  }
  render(){
    return(
      <View style={styles.item_content}>
        <View style={{flex:1}}>
          <Text style={styles.plan_date}>{this.props.plan.date.format("yyyy-MM-dd")}</Text>
          <Text style={styles.plan_title} numberOfLines={30}>{this.props.plan.title}</Text>
        </View>
        <Image style={styles.plan_image} source={require('../../images/icon_plan.png')} />
        <View style={styles.line}/>
      </View>
    )
  }
}

class RecordItem extends React.Component {
  constructor(prop) {
    super(prop)
    if(!this.props.record) throw new Error("no record");
  }
  render(){
    return(
      <TouchableHighlight key={this.props.record} style={styles.item_record_content} underlayColor="transparent" onPress={this.props.onPress}>
        <View>
          <View style={{flex:1}}>
            <Text style={styles.date}>{this.props.record.date.format("yyyy-MM-dd")}</Text>
            <Text style={styles.text_title}>{this.props.record.recordType}</Text>
            <Text numberOfLines={4} style={styles.text_content}>{this.props.record.summary}</Text>
          </View>
          <View style={styles.line}/>
        </View>
      </TouchableHighlight>
    )
  }
}

var styles = StyleSheet.create({
  plan_image:{
    position:'absolute',
    right:0,
    top:0,
    width:Tools.fixWidth(20),
    height:Tools.fixWidth(40),
  },
  item_content: {
    paddingLeft:Tools.fixWidth(12),
    paddingRight:Tools.fixWidth(12),
    backgroundColor:'white'
  },
  item_record_content: {
    paddingLeft:Tools.fixWidth(12),
    paddingRight:Tools.fixWidth(12),
    backgroundColor:'white'
  },
  line:{
    backgroundColor:Color.white_border_color,
    height:1,
    marginTop:Tools.fixWidth(5)
  },
  date:{
    color:"#333333",
    fontSize:Tools.fixWidth(13),
    marginTop:Tools.fixWidth(10),
  },
  plan_date:{
    color:"#333333",
    fontSize:Tools.fixWidth(13),
    marginTop:Tools.fixWidth(18),
  },
  plan_title:{
    color:"#666666",
    fontSize:Tools.fixWidth(11),
    marginTop:Tools.fixWidth(15),
  },
  text_title:{
    color:"#333333",
    fontSize:Tools.fixWidth(10),
    marginTop:Tools.fixWidth(5),
  },
  text_content:{
    color:"#999999",
    fontSize:Tools.fixWidth(10),
    marginTop:Tools.fixWidth(5),
    flex:1,
  }
});

module.exports = {
  "RecordItem":RecordItem,
  "PlanItem":PlanItem
}
