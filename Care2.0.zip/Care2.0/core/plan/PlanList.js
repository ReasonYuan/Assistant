'use strict';

var React = require('react-native');
var {
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableHighlight,
  Navigator,
  ScrollView,
  ListView,
  Image,
  Alert,
  Dimensions,
  InteractionManager,
} = React;

var {Styles,Button,BaseComponent,Tools,Color,Config,FQListView} = require('../../Styles');
var Patients = require('../record/AllRecord');
var {PatientTabList} = require('../BaseComponent')
var Models = require("../Models");
var {User,Plan,Record} = Models;
var {DatabaseManager,DatabaseView} = require('../couchbase/Couchbase');
var PlanInfo = require('./PlanInfo');
var AddRecordView = require('../record/AddRecordView');
var AddMembers = require('../../AddMembers');
var PersonalInfo = require('../../PersonalInfo');
var NoRecognizeList = require('../record/NoRecognizeList');
var WebView = require('../WebView');
var {RecordItem,PlanItem} = require('./PlanItem');
var CamerScanner = require('../record/CameraScanner');
var UpLoadImageCount = Config.UpLoadImageCount;

var ShowContextView = require('../record/ShowContextView');
var RecordExamInfo = require('../record/RecordExamInfo');

class ImageButton extends React.Component {
  constructor(props) {
    super(props)
  }
  render(){
    return(
      <TouchableHighlight {...this.props} underlayColor={"transparent"} onPress={this.props.onPress}>
        <Image style={{width:this.props.width,height:this.props.height}} source ={this.props.source} />
      </TouchableHighlight>
    )
  }
}



class PlanList extends BaseComponent {
  currentPatient:Patient;
  constructor(props){
    super(props)
    var config = {title:"健康记录",rightButtonTitle:'删除'}
    var ds = new ListView.DataSource({rowHasChanged: (r1, r2) => r1 !== r2});
    this.state = {navigatorBarConfig:config,dataSource: ds,renderPlaceholderOnly:true}
  }
  onRightPress(){
    if(this.currentPatient.relationship == '我'){
      Alert.alert(
      '不能删除该病案！',
      null,
        [
          {text: '确定'},
          {text: '取消'},
        ]
      )
      return;
    }
    Alert.alert(
    '确认删除？',
    '确认删除'+this.currentPatient?this.currentPatient.relationship:"",
      [
        {text: '确定', onPress: () => {
          if(this.currentPatient){
            this.post("patient/remove_user_member",{patientId:this.currentPatient.documentID,userId:User.currentUser.documentID},(data)=>{
              if(data.error){
                this.showWarning(data.error);
                return;
              }
              this.currentPatient.delete();
            })
          }
        }},
        {text: '取消'},
      ]
    )
  }
  onPlanTouch(plan){
    if(plan.status == 1){ //完成，查看
      this.pushWidthComponent({component:<PlanInfo plan={plan} navigator={this.props.navigator} />})
    }else{//未完成，更新
      if(this.currentPatient){
        this.pushWidthComponent({component:<AddRecordView navigator={this.props.navigator} patient={this.currentPatient}/>});
      }
    }
  }
  _stopView(){
    if(this.userPlantView)this.userPlantView.stop();
    delete this.userPlantView;
  }
  _onSelectPatient(patient){
    if(patient){
      this.currentPatient = patient;
      this._stopView()
      var name = patient.name;
      var db = DatabaseManager.instance.currentDatabase;
      var userPlantView =  new DatabaseView(db,["Record","Plan","Profile"],patient.documentID+"_Record&PlanView","function(doc) { if((doc.type == 'Plan' || (doc.type=='Record' && doc.status==2)) && doc.patient === '"+patient.documentID+"') emit(doc.date,doc)}",()=>{
          userPlantView.descending = true;
          userPlantView.setOnDataChangeCallback((data)=>this._onPlanChanged(data));
      });
      this.userPlantView = userPlantView;
    }
  }
  _onPlanChanged(data){
    var allData = [];
    for (var i = 0; i < data.length; i++) {
        if(data[i].value.type == "Plan"){
          var plan = new Plan();
          plan.setProperty(data[i].value);
          allData.push(plan);
        }
        if(data[i].value.type == "Record"){
          if(!User.currentUser.isTrash(data[i].value._id)){
            if(data[i].value.status == 2 && Array.isArray(data[i].value.info)){
              if("化验记录" == data[i].value.recordType){
                for (var j = 0; j < data[i].value.info.length; j++) {
                  var info =  data[i].value.info[j];
                  var record = new Record();
                  record.setProperty(data[i].value);
                  record.info = info;
                  allData.push(record);
                }
              }else{
                for (var j = 0; j < data[i].value.info.length; j++) {
                  var info =  data[i].value.info[j];
                  var record = new Record();
                  record.setProperty(data[i].value);
                  record.info = info;
                  allData.push(record);
                  break;
                }
              }
            }else {
              var record = new Record();
              record.setProperty(data[i].value);
              allData.push(record);
            }
          }
        }
    }
    this.setState({dataSource:this.state.dataSource.cloneWithRows(allData)})
  }
  onPersonalInfoClick(){
    this.pushWidthComponent({component:<PersonalInfo navigator={this.props.navigator} patient={this.currentPatient}/>});
  }
  onDelete(record){
    if(record){
        User.currentUser.moveToTrash(record.documentID,()=>{
          this.pop();
        })
      }
  }
  onItemClick(rowData){
      if(rowData.status == 2){
        var RecordDetail = null
        if("化验记录" == rowData.recordType){
          RecordDetail = RecordExamInfo
        }else{
          RecordDetail = ShowContextView
        }
        this.pushWidthComponent({
          component:<RecordDetail onDelete={this.onDelete.bind(this)} navigator={this.props.navigator} record={rowData} title={this.props.title} />
        })
      }else{
        var ShowGalleryImagesView = require('../record/ShowGalleryImagesView');
        var images = []
        var record = rowData;
        for (var i = 0; i < record.images.length; i++) {
          images.push(record.images[i].key)
        }
        this.pushWidthComponent({component:<ShowGalleryImagesView showNoOCR={true} record={rowData} navigator={this.props.navigator} group={images} title={"查看原图"}/>})
      }
  }
  renderRow(rowData,s,i){
    if(rowData.type == "Record"){
      return (
        <RecordItem record={rowData} onPress={()=>this.onItemClick(rowData)}/>
      )
    }
    if(rowData.type == "Plan"){
      return (
        <PlanItem plan={rowData} />
      )
    }
  }
  renderAD(){
    if(!User.currentUser.isVIP){
      return(
        <TouchableHighlight underlayColor="transparent" onPress={()=>{
          var Pay = require('../setting/Pay')
          this.push(Pay);
        }}>
          <View style={[styles.ad,Styles.center]}>
           <Text style={styles.ad_title}>家人健康关爱计划</Text>
           <Text style={styles.ad_join}>加入 >> </Text>
          </View>
        </TouchableHighlight>
      )
    }
  }

  // <ImageButton style={styles.imageButton} width={Image_icon_width} height={Image_icon_width} source={require('../../images/icon_health_test.png')} onPress={()=>{
  //   var url = Config.webServerURL+"selftest/get_by_patient_id?is_self_view=true&patient_id="+this.currentPatient.documentID;
  //   this.pushWidthComponent({component:<WebView title="健康自测" navigator={this.props.navigator} url={url}/>})}
  // }/>

  componentDidMount(){
    InteractionManager.runAfterInteractions(() => {
          this.setState({renderPlaceholderOnly: false});
    });
  }

  _render() {

    if (this.state.renderPlaceholderOnly) {
      return  (
        <View style={[Styles.center,{flex:1}]}>
          <Text>Loading...</Text>
        </View>
      );
    }

    return (
      <View style={[Styles.content]}>
        {
          this.renderAD()
        }
        <PatientTabList showAddButton={true} onAddPress={()=>{
          this.pushWidthComponent({
            component:<AddMembers navigator={this.props.navigator} jumpOver={()=>{
              var routes = this.props.navigator.getCurrentRoutes()
              var lastRoutes = routes[routes.length-2];
              if((lastRoutes.component.name || lastRoutes.component.type.name) !== 'Home'){
                lastRoutes = routes[routes.length-3];
              }
              this.props.navigator.popToRoute(lastRoutes)
            }}/>
          })
        }} onSelected={(index,patient)=>{
          console.log("------->",index,patient);
          this._onSelectPatient(patient);
        }}/>
        <View style={{backgroundColor:'white',height:Tools.fixWidth(75),justifyContent:'flex-end'}}>
          <View style={[{flex:1,alignItems:'center',flexDirection:'row'}]}>
            <View style={[styles.imageButton,{marginLeft:Tools.fixWidth(12)}]}>
              <ImageButton style={styles.imageButton} width={Image_icon_width} height={Image_icon_width} source={require('../../images/icon_add_record.png')} onPress={()=>this.pushWidthComponent({component:<CamerScanner navigator={this.props.navigator} patient={this.currentPatient}/>})} />
              <UpLoadImageCount style={{position:'absolute',top:-8,right:-8}}/>
            </View>

            <ImageButton style={[styles.imageButton,styles.imageMargin]} width={Image_icon_width} height={Image_icon_width} source={require('../../images/icon_recognized.png')} onPress={()=>this.pushWidthComponent({component:<NoRecognizeList navigator={this.props.navigator} patient={this.currentPatient}/>})}/>

            <ImageButton style={[styles.imageButton,styles.imageMargin]} width={Image_icon_width} height={Image_icon_width} source={require('../../images/icon_personal_info.png')} onPress={this.onPersonalInfoClick.bind(this)}/>
          </View>
          <View style={[Styles.line,styles.margin]}></View>
        </View>
          <FQListView
            dataSource={this.state.dataSource}
            renderRow={this.renderRow.bind(this)}/>
        </View>

    );
  }
}

let Image_icon_width = Tools.fixWidth(50);
var Image_icon_margin = (Dimensions.get('window').width - Tools.fixWidth(12)*2 - Image_icon_width*4) / 3

var styles = StyleSheet.create({
  margin:{
    marginLeft:Tools.fixWidth(12),
    marginRight:Tools.fixWidth(12),
  },
  imageButton:{
    width:Image_icon_width,
    height:Image_icon_width,
  },
  imageMargin:{
    marginLeft:Image_icon_margin
  },
  ad:{
    height:Tools.fixWidth(50),
    backgroundColor:'#E15064',
  },
  ad_title:{
    fontSize:Tools.fixWidth(12),
    color:'white',
  },
  ad_join:{
    position:'absolute',
    right:Tools.fixWidth(10),
    bottom:0,
    fontSize:Tools.fixWidth(11),
    color:'white',
  }
});
module.exports = PlanList;
