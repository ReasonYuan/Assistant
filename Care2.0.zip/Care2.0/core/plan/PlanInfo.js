'use strict';

var React = require('react-native');
var {
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableHighlight,
  Navigator,
  ScrollView,
} = React;

var {Styles,Button,BaseComponent} = require('../../Styles');

class PlanInfo extends BaseComponent {
  constructor(props){
    super(props)
    if(!this.props.plan) throw new Error("no plan")
    var config = {title:this.props.plan.title,leftButtonTitle:"返回"}
    this.state = {navigatorBarConfig:config}
  }
  onLeftPress(){
    this.props.navigator.pop();
  }
  _render() {
    return (
      <View style={[Styles.content]}>
        <ScrollView>
          <Text style={{marginLeft:20,marginRight:20,marginTop:10,marginBottom:30,fontSize:20}}>
            {
              this.props.plan.info
            }
          </Text>
        </ScrollView>
      </View>
    );
  }
}

module.exports = PlanInfo;
