'use strict';

var React = require('react-native');
var {
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableHighlight,
  Navigator,
  ListView,
  ScrollView,
} = React;
var {Styles,Button,BaseComponent,Tools,Color} = require('../Styles');
var {User,Patient} = require("./Models")
var {DatabaseManager,DatabaseView} = require('./couchbase/Couchbase');

class PatientTabItem extends Button {
  constructor(props) {
    super(props)
    var group = this.props.group;
    if(group && Array.isArray(group)){
      if(group.indexOf(this) < 0){
        group.push(this);
      }
    }
    this.state = {disable:props.disable,titleColor:this.props.titleColor};
  }
  componentWillReceiveProps(nextProps){
    this.setState( {disable:nextProps.disable,titleColor:nextProps.titleColor} );
  }
  setSelectIndex(index){
    var newState = (index == this.props.index);
    if(this.state.disable != newState){
      setTimeout(()=>{
        this.setState({disable:newState})
      })
    }
  }
  _renderNormal(){
    return (
      <TouchableHighlight
        {...this.props}
        onPress={()=>{this.onPress()}}
        style={[
          Styles.center,
          {width:this.props.width,height:this.props.height},
          {backgroundColor: '#48BBEC',borderColor: '#48BBEC',borderWidth: 1,borderRadius: 4},
          this.props.style
        ]}
        underlayColor={"transprent"}
        >
        <Text style={{color:this.state.titleColor,fontSize:this.props.fontSize}}>{this.props.title}</Text>
      </TouchableHighlight>
    )
  }
  _renderDisable(){
    return (
      <TouchableHighlight
        {...this.props}
        style={[
          Styles.center,
          {width:this.props.width,height:this.props.height},
          {borderColor:this.props.pressColor,borderWidth: 1,borderRadius: 4},
          this.props.style,
          {backgroundColor:this.props.pressColor}
        ]}
        underlayColor={this.props.pressColor}
        >
        <Text style={{color:this.props.pressTitleColor,fontSize:this.props.fontSize}}>{this.props.title}</Text>
      </TouchableHighlight>
    )
  }
  render(){
    if(this.state.disable){
      return this._renderDisable();
    }
    return this._renderNormal();
  }
}

class PatientTabList extends React.Component {
  items:[PatientTabItem];
  selectedID:String;
  constructor(props) {
    super(props)
    var patient = new Patient();
    var db = DatabaseManager.instance.currentDatabase;
    var myPatinet = "patient_"+User.currentUser.documentID;
    db.getModel(myPatinet,(p)=>{
      if(!p){ //我不存在，重新创建
        var patinet = new Patient();
        patient.documentID = "patient_"+User.currentUser.documentID;
        patient.user = User.currentUser.documentID;
        patient.name = User.currentUser.name;
        patient.gender = User.currentUser.gender;
        patient.relationship = "我";
        patient.save(()=>{
          User.currentUser.patient = patient;
          User.currentUser.save()
        })
      }else{
        User.currentUser.patient = patient;
      }
    })

    var ds = new ListView.DataSource({rowHasChanged: (r1, r2) => r1 !== r2});
    this.state = {dataSource: ds.cloneWithRows([])};
    this.items = [];
  }
  componentDidMount(){
    var db = DatabaseManager.instance.currentDatabase;
    var patientView =  new DatabaseView(db,["Patient"],"PatientView","function(doc) { if(doc.type == 'Patient') emit(doc.date,doc)}",()=>{
        patientView.setOnDataChangeCallback((data)=>this.onPatientChanged(data));
    });
    this.patientView = patientView;
  }
  componentWillUnmount(){
    if(this.patientView)this.patientView.stop();
  }
  onPatientChanged(data){
    var patients = [];
    for (var i = 0; i < data.length; i++) {
        // if(!User.currentUser.isTrash(data[i].value._id)){
          var patient = new Patient();
          patient.setProperty(data[i].value);
          patients.push(patient);
        // }
    }
    if(patients.length > 0){
      if(this.props.showAddButton){
        patients.push({relationship:"+"})
      }
      if(!this.selectedID){
        this.selectedID = patients[0].documentID;
        if(this.props.onSelected)this.props.onSelected(0,patients[0]);
      }else {
        var found = false;
        for (var j = 0; j < patients.length; j++) {
          if(patients[j].documentID == this.selectedID){
            found = true;
            if(this.props.onSelected)this.props.onSelected(j,patients[j]);
            break;
          }
        }
        if(!found){
          this.selectedID = patients[0].documentID;
          if(this.props.onSelected)this.props.onSelected(0,patients[0]);
        }
      }
      this.setState({dataSource:this.state.dataSource.cloneWithRows(patients)});
    }
  }
  renderRow(rowData,s,i){
    var disable = ( this.selectedID == rowData.documentID );
    return (
      <PatientTabItem key={rowData.documentID} index={i} pressColor={Color.default_color} fontSize={Tools.fixWidth(14)} titleColor={Color.default_color} pressTitleColor={"white"} ref={(c)=>this.items.push(c)} style={styles.item} title={rowData.relationship} disable={disable} onTouch={()=>{
        if(!this.props.showAddButton || i != this.state.dataSource.getRowCount()-1){
          this.selectedID = rowData.documentID;
          for (var j = 0; j < this.items.length; j++) {
            if(this.items[j])this.items[j].setSelectIndex(i);
          }
          if(this.props.onSelected)this.props.onSelected(i,rowData);
        }
        if(this.props.showAddButton && i == this.state.dataSource.getRowCount()-1){ //点击了添加按钮
          if(this.props.onAddPress)this.props.onAddPress();
        }
      }}/>
    )
  }
  render(){
    return (
      <View>
        <ListView
            style={{backgroundColor:'white'}}
            horizontal={true}
            showsHorizontalScrollIndicator={false}
            automaticallyAdjustContentInsets={false}
            contentContainerStyle={styles.list}
            dataSource={this.state.dataSource}
            renderRow={this.renderRow.bind(this)}
        />
        <View style={[Styles.line,{marginLeft:Tools.fixWidth(12),marginRight:Tools.fixWidth(12)}]} />
      </View>
    )
  }
}

PatientTabList.propTypes = {
  showAddButton:React.PropTypes.bool,//是否显示添加按钮
  onAddPress:React.PropTypes.func,  //添加按钮被点击
  onSelected:React.PropTypes.func,   //patient 被点击 参数（index,patient）
}

PatientTabList.defaultProps = {
  showAddButton:false,
  onAddPress:null,
  onSelected:null,
}



var styles = StyleSheet.create({
  content: {
    flex: 1,
    alignItems: 'stretch',
  },
  list: {
    justifyContent: 'flex-start',
    flexDirection: 'row',
    flexWrap: 'wrap'
  },
  row: {
    justifyContent: 'center',
    width: 60,
    height: 30,
    backgroundColor: '#F6F6F6',
    alignItems: 'center',
    borderWidth: 1,
    borderRadius: 5,
    borderColor: '#CCC'

  },
  rowSelected: {
    justifyContent: 'center',
    width: 60,
    height: 30,
    backgroundColor: '#00FF00',
    alignItems: 'center',
    borderWidth: 1,
    borderRadius: 5,
    borderColor: '#00FF00'
  },
  item:{
    height:Tools.fixWidth(40),
    width:Tools.fixWidth(40),
    margin:Tools.fixWidth(12),
    borderRadius:Tools.fixWidth(20),
    backgroundColor:"transparent",
    borderWidth:1,
    borderColor:"#3F8A7F",
  },
});

module.exports = {
  "PatientTabList":PatientTabList,
}
