/**
 *
 * 医生动态，对Restful接口数据的封装
 * @author johnny 2015-12-19
 *
 */

'use strict';

var Config = require("../Config")
var LocalCache = require("../sync/LocalCache")

var {Fetch} = require("../../JSLibrary/Logic")

class DoctorSpaceDataSource {

  page = 0;
  pageSize = 5;
  userid = "doctor_112233";
  callback = null;
  //第一页缓存
  isFirstLoad = true;

  //参数：医生的用户id
  constructor(userid, pageSize, callback){
    this.userid = userid
    if(pageSize){
      this.pageSize = pageSize
    }
    if(callback){
      this.callback = callback
    }
  }

  convertID2DocumentID(data){
    data.userInfo.documentID = data.userInfo.id
    for(var i=0; i<data.shareMessages.length; i++){
      data.shareMessages[i].documentID = data.shareMessages[i].id
    }
    return data
  }

  getNextPageData(){
    var self = this
    var localCacheKey = "d_space_local_cache_" + this.userid
    var shouldCacheData = this.isFirstLoad
    if(this.isFirstLoad){
      this.isFirstLoad = false
      //第一次要读取缓存
      LocalCache.get(localCacheKey, function(data){
        if(data && !data.error){
          if(self.callback) self.callback(data)
        }
      })
    }

    //TODO 要用宝时server真正的服务器
    // var webBaoshiServerURL = "http://115.29.229.128:5000/"
    var url = Config.webBaoshiServerURL + "sharemessage/get_user_shares" //Config.webBaoshiServerURL + "sharemessage/get_user_shares"
    var postData = {}
    postData.userId = this.userid
    postData.page = this.page
    postData.pageSize = this.pageSize

    Fetch.post("",postData,(data) => {
        if(data.error){
          if(this.callback) this.callback(data)
        } else {
          if(this.callback) {
            this.callback(self.convertID2DocumentID(data))
            if(shouldCacheData){
              LocalCache.save(localCacheKey, data)
            }
          }
        }
      },url);

    // fetch(url, {
    //       method: "POST",
    //       headers: {'Content-Type': 'application/json'},
    //       body:JSON.stringify(postData)
    // })
    // .then((response) =>
    //   response.json()
    // )
    // .then((data) => {
    //     if(data.error){
    //       if(this.callback) this.callback(data)
    //     } else {
    //       if(this.callback) {
    //         this.callback(self.convertID2DocumentID(data))
    //         if(shouldCacheData){
    //           LocalCache.save(localCacheKey, data)
    //         }
    //       }
    //     }
    //   }
    // ).catch(function(error) {
    //   if(error){
    //     var err = error
    //     console.log(err);
    //   }
    // })
    this.page += 1
  }
}

module.exports = DoctorSpaceDataSource
