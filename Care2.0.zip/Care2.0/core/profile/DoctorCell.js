/**
 *
 * 医生详细信息页面的个人简介cell，包括头像、姓名等
 * @author reason 2015-12-08
 *
 */

'use strict';

var React = require('react-native');

var {
  AppRegistry,
  StyleSheet,
  Text,
  View,
  Image,
  TouchableHighlight,
  Navigator
} = React;

var {Color,len,Tools} = require('../../Styles')
let w = Tools.fixWidth

class DoctorCell extends React.Component{

	  constructor(props){
    		super(props)
	  }

    loadIcon(imageUrl){
      if(imageUrl){
        return(
          <Image
            style={istyles.itemImage}
            source={{uri: imageUrl}}/>
        )
      }
    }

    //渲染医生分享内容子项，根据是否有图片分为两种类型
    renderItemInfo(info){
      return(
        <View style={istyles.infoContainer}>
          {
            this.loadIcon(info.imageUrl)
          }
          <Text numberOfLines={3} style={istyles.itemLabel}>{info.title||info.content}</Text>
        </View>
      )
    }

	render(){
    var space = this.props.space
    var time = space.update_time?new Date(+space.update_time).format("yyyy-MM-dd HH:mm"):""
    return (
      <TouchableHighlight
        underlayColor={Color.itemClick}
        onPress={(data)=>this.props.onClick(data)}>

        <View style={istyles.itemContainer}>
          <Text style={istyles.timeLabel}>{time}</Text>
          {
            this.renderItemInfo(space)
          }
        </View>

      </TouchableHighlight>
    )
	}
}

var istyles = StyleSheet.create({
  itemContainer:{
    paddingVertical:w(12),
    borderBottomWidth:w(1),
    borderColor:Color.itemDivider,
  },
  timeLabel:{
    fontSize:w(13),
    marginBottom:w(10),
    color:Color.title
  },
  itemLabel:{
    flex:1,
    fontSize:w(13),
    color:'#999'
  },
  infoContainer:{
    flexDirection:'row'
  },
  itemImage:{
    width:w(80),
    height:w(50),
    marginRight:w(10),
    backgroundColor:'#ddd'
  },
});

module.exports = DoctorCell;
