/**
 *
 * 医生详细信息页面的个人简介cell，包括头像、姓名等
 * @author reason 2015-12-08
 *
 */

'use strict';

var React = require('react-native');

var {
  StyleSheet,
  Text,
  View,
  TouchableHighlight,
  Image
} = React;

var {Styles,ImageView,Tools} = require('../../Styles');
var {Color,len,fs} = require('../../Styles')
let w = Tools.fixWidth

class DoctorHead extends React.Component{

	render(){
    var doctor = this.props.profile.state.doctor
    return(
      <View style={istyles.container}>
      <View  style={[istyles.infoContainer]}>
        <ImageView
          style={istyles.head}
          imageKey={doctor.headIcon.objectKey}/>

        <View style={istyles.infoView}>
          <View style={istyles.doctorInfoContainer}>
            <Text style={istyles.doctorInfoLabel}>{doctor.name}</Text>
            <Text style={istyles.doctorInfoLabel}>{doctor.department}</Text>
          </View>
          <Text style={istyles.hospital}>{doctor.hospital}</Text>
        </View>

  		</View>
      <Text style={istyles.shareLabel}>分享:</Text>
      </View>
    )
	}
}

var istyles = StyleSheet.create({
  container:{
    borderBottomWidth:1,
    borderColor:Color.itemDivider
  },
  infoContainer:{
    height:w(55),
    paddingTop:w(15),
    flexDirection:'row',
  },
  infoView:{
    flex:1,
    marginLeft:w(10),
    justifyContent:'flex-end'
  },
  head:{
    width:w(40),
    height:w(40),
    borderRadius:w(5)
  },
  doctorInfoContainer:{
    flexDirection:'row',
  },
  msgContainer:{
    width:w(40),
    height:w(28),
    alignItems:'flex-end',
    justifyContent:'center',
  },
  msgIcon:{
    padding:5,
    width:w(16),
    height:w(16),
    resizeMode:'contain',
  },
  doctorInfoLabel:{
    marginRight:w(10),
  },
  hospital:{
    fontSize:w(12),
    color:'#999',
    marginTop:w(3)
  },
  desLabel:{
    marginVertical:w(10),
    color:Color.title
  },
  detailLabel:{
    fontSize:12,
    color:'#666',
    marginBottom:w(33),
  },
  shareLabel:{
    marginBottom:w(10),
    color:Color.title
  }
});

module.exports = DoctorHead;
