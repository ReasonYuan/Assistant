/**
 *
 * 医生详细信息界面(由所有医生列表的子项点击过来)
 * @author reason 2015-12-08
 *
 */

'use strict';

var React = require('react-native');

var {
  AppRegistry,
  StyleSheet,
  Text,
  View,
  ListView,
  TouchableHighlight,
  Navigator
} = React;

var {User} = require('../Models')
var {Styles,BaseComponent,Tools} = require('../../Styles');
var Header = require('./DoctorHead');
var Cell = require('./DoctorCell');
var DoctorSpaceDataSource = require("./DoctorSpaceDataSource");
let w = Tools.fixWidth;

class DoctorProfile extends BaseComponent{

  doctorSace:DoctorSpaceDataSource;

  constructor(props){
    super(props)

    this.doctor = this.props.user;

    var title = ""
    if(this.doctor.documentID == User.currentUser.documentID){
      title = "我的空间"
    }else{
      title = this.doctor.name+"的分享"
      if(!this.doctor.hospital){//如果医院不存在，表示没有详细信息，需要获取详细信息

      }
    }
    var config = {title:title,showBackIcon:true};
    var ds = new ListView.DataSource({rowHasChanged: (r1, r2) => r1 !== r2});

    this.state = {navigatorBarConfig:config,doctor:this.doctor,dataSource:ds};
  }

  componentWillMount(){
    this.doctorSace = new DoctorSpaceDataSource(this.doctor.documentID || this.doctor.id, 5, (data)=>{this.onSpaceData(data)})
    this.doctorSace.getNextPageData()
  }

  loadDoctorProfile(){

  }

  onSpaceData(data){
    if(!data)return
    // console.log(data)
    this.setState({
      doctor:(data.userInfo),
      dataSource:this.state.dataSource.cloneWithRows(data.shareMessages)
    })
  }

  onLeftPress(){
    this.pop()
  }

  // 聊天
  // onRightPress(){
  //   var message = {}
  //   message.talkers = [this.doctor]
  //   message.imName = this.doctor.name
  //   message.relationship = {type:'FriendShip'}
  //
  //   var CustomerChat = require("../chat/DoctorChatView");
  //   this.pushWidthComponent(<CustomerChat navigator={this.props.navigator} message={message}/>)
  // }

  //一条分享内容被点击
  onItemClick(rowData){
    var WebView = require("../WebView");
    this.pushWidthComponent({
        component:<WebView title={"分享详情"} navigator={this.props.navigator}
        url={rowData.url||"http://www.baidu.com"}/>
      })
  }

  //渲染‘医生的分享’页面的Head，即医生的简介信息
  renderHeader(){
    if(this.doctor.documentID != User.currentUser.documentID){
      return(<Header profile={this}/>)
    }else{
      return(<View style={{marginTop:-20}}/>)
    }
  }

  //渲染一个分享内容
  renderRow(rowData,s,i){
    return (
      <Cell
        space={rowData}
        onClick={()=>this.onItemClick(rowData)}/>
    )
  }

  _render(){
    return (
      <ListView
        pageSize={10}
    		style={istyles.list}
        automaticallyAdjustContentInsets={false}
    		dataSource={this.state.dataSource}
        renderHeader={this.renderHeader.bind(this)}
     		renderRow={this.renderRow.bind(this)}
      />
    )
  }
}

var istyles = StyleSheet.create({
  list:{
    paddingLeft:w(12),
    paddingRight:w(12),
  },
  // cell:{
  //   marginBottom:w(20)
  // }
});

module.exports = DoctorProfile;
