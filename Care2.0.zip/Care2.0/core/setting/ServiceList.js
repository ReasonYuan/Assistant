

'use strict';

var React = require('react-native');
var {
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableHighlight,
  Navigator,
  ScrollView,
  ListView,
} = React;

var {Styles,Button,BaseComponent,Config,Color,Tools,FQListView} = require('../../Styles');
var {User,Plan,Service} = require("../Models")
var {DatabaseManager,DatabaseView} = require('../couchbase/Couchbase');
var WebView = require('../WebView');


class ServiceItem extends React.Component {
  constructor(props) {
    super(props)
    if(!this.props.service)throw new Error("no serice in ServiceItem");
    this.state={relationship:""}
  }
  componentWillMount(){
    this.onSetProps(this.props);
  }
  componentWillReceiveProps(nextProps){
    if(this.props.service.patient != nextProps.service.patien){
      this.onSetProps(nextProps);
    }
  }
  onSetProps(props){
    let patient_id = props.service.patient;
    if(patient_id){
      DatabaseManager.instance.currentDatabase.getModel(patient_id,(patient)=>{
        this.setState({relationship:patient.relationship});
      })
    }
  }
  render(){
    return (
      <TouchableHighlight underlayColor="rgba(221, 221, 221, 0.5)" onPress={()=>{
        var url = Config.webServerURL+"payment/pay_service?";
        url += "serviceId="+this.props.service.documentID;
        this.props.navigator.push({
          component: <WebView navigator={this.props.navigator} url={url} title={this.props.service.name || "服务记录"}/>
        })
      }}>
        <View style={styles.item_content}>
          <View style={[Styles.content,Styles.vCenter]}>
            <View>
             <Text style={styles.item_date}>{this.props.service.date.format("yyyy年MM月d日")}</Text>
             <View style={styles.item_text_content}>
               <Text style={styles.item_text}>{this.props.service.name || "服务名字"}</Text>
              <Text style={styles.item_text}>{this.state.relationship}</Text>
             </View>
            </View>
          </View>

          <View style={styles.line}/>
        </View>
      </TouchableHighlight>
    )
  }
}

var styles = StyleSheet.create({
  dateText:{
    fontSize:20,
  },
  text:{
    fontSize:18,
  }
})


class ServiceList extends BaseComponent {
  constructor(props){
    super(props)
    var config = {title:"服务记录",showBackIcon:true}
    var ds = new ListView.DataSource({rowHasChanged: (r1, r2) => r1 !== r2});
    this.state = {navigatorBarConfig:config,dataSource: ds};
    var db = DatabaseManager.instance.currentDatabase;
    // var serviceView =  new DatabaseView(db,"Service","ServiceView","function(doc) { if(doc.type == 'Service' || (doc.type=='Message' && doc.messageType == 4)) emit(doc.date,doc)}",()=>{
    var serviceView =  new DatabaseView(db,"Service",User.currentUser.documentID+"_ServiceView","function(doc) { if(doc.type == 'Service' && doc.payStatus == 3) emit(doc.date,doc)}",()=>{
        serviceView.descending = true;
        serviceView.setOnDataChangeCallback((data)=>this.onServiceChanged(data));
    });
    this.serviceView = serviceView;
  }
  componentWillUnmount(){
    super.componentWillUnmount();
    if(this.serviceView){
      this.serviceView.stop();
      delete this.serviceView;
    }
  }
  onServiceChanged(data){
    if(data && data.length > 0){
      var allService= [];
      for (var i = 0; i < data.length; i++) {
        var service = new Service();
        service.setProperty(data[i].value);
        allService.push(service);
      }
      this.setState({dataSource:this.state.dataSource.cloneWithRows(allService)});
    }
  }
  onLeftPress(){
    this.pop();
  }
  renderRow(rowData,s,i){
    return (
      <ServiceItem key={rowData.documentID} service={rowData} navigator={this.props.navigator}/>
    )
  }
  _render() {
    return (
      <View style={[Styles.content]}>
        <FQListView
          automaticallyAdjustContentInsets={false}
          dataSource={this.state.dataSource}
          renderRow={this.renderRow.bind(this)}
        />
      </View>
    );
  }
}

let margin = Tools.fixWidth(12);

var styles = StyleSheet.create({
  item_content:{
    backgroundColor:'white',
    height:Tools.fixWidth(60),
    paddingRight:margin,
    paddingLeft:margin,
  },
  item_date:{
    fontSize:Tools.fixWidth(14),
    color:"#333333"
  },
  item_text_content:{
    marginTop:Tools.fixWidth(8),
    flexDirection:'row',
    justifyContent:'space-between'
  },
  item_text:{
    fontSize:Tools.fixWidth(12),
    color:"#666666"
  },
  line:{
    backgroundColor:Color.white_border_color,
    height:1,
  },
});

module.exports = ServiceList;
