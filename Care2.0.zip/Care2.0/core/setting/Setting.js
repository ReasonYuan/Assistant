'use strict';

var React = require('react-native');
var {
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableHighlight,
  Navigator,
  ScrollView,
  AsyncStorage,
} = React;

var {Styles,Button,BaseComponent,ImageView,Color,Tools} = require('../../Styles');
var {User} = require("../Models");
var ResetPassword = require('./ResetPassword');
var {LoginLogic} = require('../../JSLibrary/Logic');


var LastLoginKey = "lastLoginUser"

class Setting extends BaseComponent {
  constructor(props){
    super(props)
    var config = {title:"设置",showBackIcon:true}
    this.state = {navigatorBarConfig:config,head:User.currentUser.headIcon.objectKey}
  }
  onLeftPress(){
    this.pop();
  }
  _renderItem(imageSource,titleName,color,onPress,rendArrow){
    return (
      <TouchableHighlight onPress={onPress} underlayColor={'transparent'}>
        <View>
          <View style={styles.item}>
            <View style={Styles.center}>
              <ImageView  source={imageSource} style={styles.itemImage}/>
            </View>
            <View style={Styles.center}>
              <Text style={[styles.itemTitle,{color:color}]}> {titleName} </Text>
            </View>
            {
              (()=>{
                if(rendArrow){
                  return(
                    <View style={{flex:1,justifyContent:'center',alignItems:'flex-end'}}>
                      <ImageView  source={require('../../images/icon_navigation_back.png')} style={[styles.itemArror,{tintColor:color}]} />
                    </View>
                  )
                }
              })()
            }
          </View>
          <View style={styles.line} />
        </View>
      </TouchableHighlight>
    )
  }
  _render() {
    return (
      <View style={[Styles.content]}>
      {
        this._renderItem(require('../../images/icon_reset_password.png'),"修改密码","#666666",()=>{
          this.push(ResetPassword)
        },true)
      }
      {
        this._renderItem(require('../../images/icon_logou.png'),"退出登录","#666666",()=>{
          var Login = require('../../Login');
          LoginLogic.Logout(this.props.navigator,true);
        })
      }
      </View>
    );
  }
}

var styles = StyleSheet.create({
  line:{
    backgroundColor:Color.white_border_color,
    height:1,
    marginLeft:Tools.fixWidth(12),
    marginRight:Tools.fixWidth(12),
  },
  item:{
    paddingLeft:Tools.fixWidth(12),
    paddingRight:Tools.fixWidth(12),
    height:Tools.fixWidth(50),
    flexDirection:'row',
    backgroundColor:'white',
  },
  itemImage:{
    width:Tools.fixWidth(15),
    height:Tools.fixWidth(15),
  },
  itemTitle:{
    fontSize:Tools.fixWidth(14),
    marginLeft:Tools.fixWidth(12),
  },
  itemArror:{
    width:Tools.fixWidth(7),
    height:Tools.fixWidth(15),
    transform:[{rotate:"180deg"}],
  }
})

module.exports = Setting;
