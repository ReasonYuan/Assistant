'use strict';

var React = require('react-native');
var {
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableHighlight,
  Navigator,
  Image,
  Alert,
  ScrollView,
} = React;

var {Styles,Button,BaseComponent,ImageView,Color,Tools,Config} = require('../../Styles');
var {User,Order} = require("../Models");
var {DatabaseManager,DatabaseView} = require('../couchbase/Couchbase');
var color = "#63c0b5"
var WXPay = require('react-native').NativeModules.WXPay
var {PayLoadingDialog} = require('../../Dialog');
var PayResult = require('./PayResult');
var Porting = require('../../utils/Porting')
var {Fetch} = require('../../JSLibrary/Logic')

let ORDER_CATEGORY_RENEW = 2;//续费
let ORDER_CATEGORY_SERVICE = 3;//服务

//付费
class Pay extends BaseComponent {
  constructor(props){
    super(props)
    var config = {title:"健康年费",showBackIcon:true}
    this.state = {showPayLoading:false,navigatorBarConfig:config,total_charge:0,discount:"",money:0,msg:null,showMsg:false,isError:false};
    this.getTotalPayCount();
  }
  lastRender(){
    return (
      <PayLoadingDialog show={this.state.showPayLoading}/>
    )
  }
  onLeftPress(){
    this.pop();
  }
  getTotalPayCount(){
    this.post("charge/get_personal_payment",{user_id:User.currentUser.documentID,discount_code:this.state.discount},(data)=>{
      if(data.error){
        this.showWarning(data.error);
        return;
      }
      if(data.payment_info){
        var payment_info = data.payment_info;
        var total_charge = Math.round(payment_info.total_charge*100);
        var discount_info = payment_info.discount_info;
        this.setState({total_charge:total_charge,showMsg:true,isError:discount_info.error,msg:discount_info.error||(discount_info.validDate?"优惠码有效期至"+discount_info.validDate:discount_info.success)});
      }
    });
  }
  pay(){
    this.setState({showPayLoading:true});
    Pay.payMoney(Config.PAY_DEBUG?1:this.state.total_charge,"健康年费",ORDER_CATEGORY_RENEW,0,User.currentUser.documentID,(data)=>{
      console.log("------"+data);
      if(data.success){
          var outTradeNo = data.result.out_trade_no
          console.log("------"+outTradeNo);
      }else{
        this.setState({showPayLoading:false});
      }
    },(ok)=>{//ok是字符串 支付成功返回 success,失败返回failed
      console.log("------"+ok);
      if(ok == "success"){
        this.onVipChange = false;
        this.startLoading = true;
        DatabaseManager.sharedInstance.currentDatabase.addChangeCallback("User",this,(data)=>{
          for (var i = 0; i < data.length; i++) {
            DatabaseManager.sharedInstance.currentDatabase.removeChangeCallback("User",this);
            var tmp = data[i];
            if(tmp.type == "User"){
              if(tmp.isVIP){
                var profile = User.currentUser.profile;
                User.currentUser.setProperty(tmp);
                User.currentUser.profile = profile;
                this.onVipChange = true;
                if(!this.startLoading)this.pop();
              }
            }
          }
        })
      }else{
        this.showWarning("支付失败");
      }
      this.setState({showPayLoading:false});
    },{},this.props.navigator,(success)=>{
      this.setState({showPayLoading:false});
      if(success){
        if(this.onVipChange){
          var routes = this.props.navigator.getCurrentRoutes();
          var route = routes[routes.length-3];
          this.props.navigator.popToRoute(route);
        }else{
          this.startLoading = false;
          this.pop();
        }
      }else {
        this.pop();
      }
    });

  }

  //money是int
  //shopName是String
  //OrderFormCallBack 下订单回调
  //PayFinishCallBack 支付完成回调
  //orderCategory 订单分类 2是续费 3是服务
  //serverId 服务的id  orderCategory是3时，必传
  //userId 续费或接受服务的人员的id  orderCategory是2时，必传
  static payMoney(money,shopName,orderCategory,serverId,userId,OrderFormCallBack,PayFinishCallBack,extra,navigator,onLeftPress){
    if(!extra)extra = {};
    var params = {};
    if(orderCategory == ORDER_CATEGORY_RENEW){
      params = Object.assign({total_fee:money,description:shopName,user_id:userId,order_category:orderCategory},extra);
    }else if(orderCategory == ORDER_CATEGORY_SERVICE){
      params = Object.assign({total_fee:money,description:shopName,service_id:serverId,order_category:orderCategory},extra);
    }
    Pay.getOrderForm(params,(data)=>{
      try {
        OrderFormCallBack(data);
      } catch (e) {

      } finally {

      }
      if(data.error){
        Alert.alert(
          '提示',
          '获取订单失败',
          [
            {text: '确定', onPress: () => console.log('OK Pressed')},
          ]
        )
        return;
      }
      if(data.success){
          var result = data.result;
          WXPay.sendWxPay(result,(ok)=>{
            if(navigator&&onLeftPress){
              navigator.push({component:<PayResult success={ok=="success"} onLeftPress={onLeftPress}/>});
            }
            PayFinishCallBack(ok);
          });
      }else{
        Alert.alert(
          '提示',
          '获取订单失败',
          [
            {text: '确定', onPress: () => console.log('OK Pressed')},
          ]
        )
      }
    })
  }

  static getOrderForm(params,callBack) {
    var url = "payment/get_order";
    Pay.post(url,params,callBack);
  }

  static post(route,parameters,cb){
    console.log("HTTP请求:",parameters,"url:"+Config.webServerURL+route);
    Fetch.post(route,parameters,cb,Config.webServerURL);
    // fetch(Config.webServerURL+route, {
    //   method: "POST",
    //   headers: {
    //     'Accept': 'application/json',
    //     'Content-Type': 'application/json'
    //   },
    //   body: JSON.stringify(parameters)
    // }).then((response) => response.json())
    // .then((data) => {
    //   console.log("HTTP返回:",data,"url:"+Config.webServerURL+route);
    //   if(cb)cb(null,data);
    // }).catch((e)=>{
    //   console.log("-->","Http errer:",e);
    //   if(cb)cb(e);
    // })
  }
  onTextChange(text){
    this.setState({discount:text});
    if(text && text.length==4){
      this.refs.textInput.props.onEndEditing();
    }
  }

  _renderContentView(){
    var self = this;
    return (
      <View style={[styles.content]}>
        <View style={styles.imageContent}>
          <View style={styles.imageZ}/>
          <Image style={styles.imageSize} source={require('../../images/img_pay_icon.png')}/>
          <View style={styles.imageZ}/>
        </View>
        <View style={styles.bottomContent}>
         <View style={{alignItems:'center'}}>
          <Text style={styles.money}>{"￥ "+ parseFloat(this.state.total_charge/100).toFixed(2)}</Text>
         </View>
         <View style={{flex:1,marginBottom:Tools.fixWidth(35),justifyContent:'flex-end',alignItems:'center'}}>
            <View style={{height:Tools.fixWidth(35),width:Tools.fixWidth(260),marginBottom:5,alignItems:"flex-end",justifyContent:'flex-end'}}>
              {
                (()=>{
                  if(this.state.showMsg){
                    return(
                      <Text style={[styles.msgText,{color:this.state.isError?'rgba(255,0,0,0.5)':color}]}>{this.state.msg}</Text>
                    )
                  }
                })()
              }
            </View>
            <View style={styles.inputBg}>
              <TextInput style={styles.input}
                ref='textInput'
                textAlign={'center'}
                maxLength={4}
                placeholder={'请输入优惠码'}
                value={this.state.discount}
                onChangeText={(text)=>self.onTextChange(text)}
                onEndEditing={this.getTotalPayCount.bind(this)}/>
            </View>
            <Button style={styles.buttonPay} title="支付" onPress={this.pay.bind(this)}/>
         </View>
        </View>
      </View>
    );
  }

  _render() {
    if (React.Platform.OS === 'ios'){
      return (
        <View>
          {
          this._renderContentView()
          }
        </View>
      );
    }else{
      return (
        <ScrollView ref='scroll' keyboardShouldPersistTaps={true}>
          {
          this._renderContentView()
          }
        </ScrollView>
      );

    }
  }
}


Pay.ORDER_CATEGORY_RENEW = ORDER_CATEGORY_RENEW;//续费
Pay.ORDER_CATEGORY_SERVICE = ORDER_CATEGORY_SERVICE;//服务

var styles = StyleSheet.create({
  content:{
    height:Tools.contentHeight(),
  },
  msgText:{
    fontSize:Tools.fixWidth(10),
  },
  inputBg:{
    height:Tools.fixWidth(35),
    width:Tools.fixWidth(260),
    borderColor:color,
    borderWidth:1,
    alignItems:'center',
    marginBottom:Tools.fixWidth(15),
  },
  input:{
    height:Tools.fixWidth(35),
    width:Tools.fixWidth(260),
    fontSize:Tools.fixWidth(14),
    backgroundColor:'transprent',
  },
  buttonPay:{
    height:Tools.fixWidth(35),width:Tools.fixWidth(260),backgroundColor:color,borderColor:color
  },
  imageContent:{
    flex:2,
    flexDirection:'row',
  },
  bottomContent:{
    flex:3,
    flexDirection:'column',
  },
  imageZ:{
    flex:1
  },
  imageSize:{
    flex:5,
    resizeMode:'contain',
    width:90,
  },
  money:{
    fontSize:Tools.fixWidth(22)
  },
})

module.exports = Pay;
