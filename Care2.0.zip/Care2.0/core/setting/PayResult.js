

'use strict';

var React = require('react-native');
var {
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableHighlight,
  Image,
} = React;

var {Styles,Button,BaseComponent,ImageView,Color,Tools,UserIcon} = require('../../Styles');


class PayResult extends BaseComponent {
  constructor(props){
    super(props);
    var config = {title:"在线支付",showBackIcon:true};
    this.state = {navigatorBarConfig:config,success:this.props.success||false};
  }
  renderStatus(success){
    var source = success ? require("../../images/icon_pay_success.png") : require("../../images/icon_pay_fail.png");
    var textColor = success ? Color.default_color : "#CB4A5C";
    var text = success ? "付款成功" : "支付失败";
    return (
      <View  style={[Styles.content,Styles.center]}>
        <Image style={styles.image} resizeMode={"contain"} source={source}/>
        <Text style={{fontSize:Tools.fixWidth(12),marginTop:Tools.fixWidth(10),color:textColor}}>{text}</Text>
      </View>
    )
  }
  onLeftPress(){
    if(this.props.onLeftPress)this.props.onLeftPress(this.state.success);
  }
  _render() {
    return (
      <View style={[Styles.content]}>
        <View style={[Styles.content,Styles.center]}>
          {
            this.renderStatus(this.state.success)
          }
        </View>
        <View style={styles.button_content}>
          <Button fontSize={Tools.fixWidth(16)} style={styles.button} title={"确定"} onPress={this.onLeftPress.bind(this)}/>
        </View>
      </View>
    );
  }
}

var styles = StyleSheet.create({
  button_content:{
    height:Tools.fixWidth(80),
  },
  button:{
    marginLeft:Tools.fixWidth(12),
    marginRight:Tools.fixWidth(12),
    height:Tools.fixWidth(40),
    backgroundColor:Color.default_color,
  },
  image:{
    width:Tools.fixWidth(36),
    height:Tools.fixWidth(36),
  }
})

module.exports = PayResult;
