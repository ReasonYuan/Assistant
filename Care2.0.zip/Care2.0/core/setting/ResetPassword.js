
'use strict';

var React = require('react-native');
var {
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableHighlight,
  Navigator,
  ScrollView,
} = React;

var {Styles,Button,BaseComponent,ImageView,Config,Color,Tools,Theme} = require('../../Styles');
var {User} = require("../Models");

var {Fetch} = require('../../JSLibrary/Logic');

class ResetPassword extends BaseComponent {
  constructor(props){
    super(props)
    var config = {title:"修改密码",showBackIcon:true}
    this.security_code = "";
    this.state = {navigatorBarConfig:config,securityButtonDisable:true,securityCount:0,security_code:"",phone_number:"",password:"",conform_password:""}
  }
  onLeftPress(){
    this.props.navigator.pop();
  }
  getSecurityCode(){
    do{
      if(this.checkStringIsNull(this.state.phone_number,"手机号不能为空"))break;
      if(!this.isPhoneNumber()){this.showToast("手机号格式错误");break;};
      this.post("users/send_security_code",{"phone_number":this.state.phone_number,"role_type":Config.role_type,"sms_category":3},(data)=>{
        if(data.error){
          this.showToast(data.error)
        }else if(data.security_code){
          this.security_code = data.security_code;
        }
      })
    }while (false);
  }
  isPhoneNumber(){
    if(this.checkStringIsNull(this.state.phone_number))return false;
    var reg = /^0?1[3|4|5|8][0-9]\d{8}$/;
    return reg.test(this.state.phone_number);
  }
  updateSecurityCount(){
    var currentCount = this.state.securityCount;
    if(currentCount > 0){
      --currentCount;
      this.setState({securityCount:currentCount,securityButtonDisable:currentCount>0});
    }else {
      if(this.updateId){
        clearInterval(this.updateId);
        delete this.updateId;
      }
      this.setState({securityCount:0,securityButtonDisable:false});
    }
  }
  done(){
    do{
      if(this.checkStringIsNull(this.state.phone_number,"手机号不能为空"))break;
      if(!this.isPhoneNumber()){this.showToast("手机号格式错误");break;};
      if(this.checkStringIsNull(this.state.password,"密码不能为空"))break;
      if(this.state.password != this.state.conform_password){this.showWarning("两次输入的密码不一致");break;}
      if(this.state.password.length <= 3){this.showToast("密码必须大于3位");break;};
      if(this.checkStringIsNull(this.state.security_code,"验证码不能为空"))break;
      var body = {"phone_number":this.state.phone_number,"password":this.state.password,"security_code":this.state.security_code,"role_type":Config.role_type};
      var url = Config.webServerURL+"users/reset_password";
      Fetch.post("",body,(data) => {
        if(data.error){
          this.showToast(data.error);
        }else{
          this.props.navigator.popToTop();
        }
      },url);
      // fetch(url, {
      //   method: "POST",
      //   headers: {
      //     'Accept': 'application/json',
      //     'Content-Type': 'application/json'
      //   },
      //   body: JSON.stringify(body)
      // }).then((response) => response.json())
      // .then((data) => {
      //   if(data.error){
      //     this.showToast(data.error);
      //   }else{
      //     this.props.navigator.popToTop();
      //   }
      // })
    }while (false);
  }
  _render() {
    return (
      <View style={[Styles.content,{marginLeft:Theme.input_marginleft,marginRight:Theme.input_marginleft}]}>
        <TextInput
          style={[styles.input,{marginTop:Tools.fixHeight(30)}]}
          placeholder={"请输入手机号"}
          textAlign={"center"}
          onChangeText={(text) => {
            this.setState({phone_number:text});
          }}
          keyboardType={"numeric"}
          value={this.state.phone_number}
          onEndEditing={()=>{
            if(!this.isPhoneNumber()){
              this.showWarning("手机号格式错误");
              this.setState({securityButtonDisable:true});
            }else{
              this.setState({securityCount:0,securityButtonDisable:false});
            }
          }}
          />

        <TextInput
          style={[styles.input]}
          placeholder={"请输入新密码"}
          textAlign={"center"}
          secureTextEntry={true}
          onChangeText={(text) => {
            this.setState({password:text});
          }}
          value={this.state.password}
          />

          <TextInput
            style={[styles.input]}
            placeholder={"新密码确认"}
            textAlign={"center"}
            secureTextEntry={true}
            onChangeText={(text) => {
              this.setState({conform_password:text});
            }}
            value={this.state.conform_password}
            />

        <View>
        <TextInput
          style={[styles.input]}
          placeholder={"验证码"}
          textAlign={"center"}
          onChangeText={(text) => {
            this.state.security_code = text;
          }}
          />
          <Button style={[styles.security,Styles.warningBackground]} title={this.state.securityCount > 0 ? this.state.securityCount+"s":"获取"}  fontSize={Tools.fixWidth(12)} titleColor={"#f1f1f1"} pressTitleColor={"#f1f1f1"} disable={this.state.securityButtonDisable} onTouch={()=>{
            this.getSecurityCode();
            this.setState({securityCount:60,securityButtonDisable:true});
            if(this.updateId){
              clearInterval(this.updateId);
              delete this.updateId;
            }
            this.updateId = this.setInterval(this.updateSecurityCount.bind(this),1000);
          }}/>
          </View>

          <Button style={styles.button} title={"完成"} onPress={this.done.bind(this)}/>
      </View>
    );
  }
}

var styles = StyleSheet.create({
  input:{
    borderWidth:1,
    height: Theme.input_height,
    borderColor: Color.gray_border_color,
    borderRadius:Theme.input_height / 2,
    color:'#333333',
    marginTop:Tools.fixHeight(10),
    fontSize:Tools.fixWidth(12)
  },
  button:{
    marginTop:Tools.fixHeight(36),
    borderRadius:Tools.fixWidth(5),
    backgroundColor:'#62C0B4',
    height:Tools.fixHeight(35)
  },
  security:{
    position:'absolute',
    width:Tools.fixWidth(46),
    height: Theme.input_height,
    borderRadius:Theme.input_height / 2,
    borderWidth:0,
    right:0,
    top:Tools.fixHeight(10),
  },
})

module.exports = ResetPassword;
