'use strict';

var React = require('react-native');
var {
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableHighlight,
  Navigator,
  Alert,
  ScrollView,
} = React;

var {Config,Styles,Button,BaseComponent,ImageView,Color,Tools,UserIcon} = require('../../Styles');
var UIImagePickerManager = require('NativeModules').UIImagePickerManager;
var {User} = require("../Models");
var ResetPassword = require('./ResetPassword');
var ServiceList = require('./ServiceList');
var {DatabaseManager} = require("../couchbase/Couchbase");
var Setting = require('./Setting');
var Pay = require('./Pay');
var CareList = require('../../CareList');


class MySetting extends BaseComponent {
  constructor(props){
    super(props)
    var config = {title:"我"}
    this.state = {navigatorBarConfig:config,head:User.currentUser.headIcon.objectKey}
    // React.NativeModules.CouchbaseHelper.getVersion((v)=>{
      // this.setState({version:v});
    // })
  }
  selectHead(){
    var self = this;
    var options = {
      title:"选择头像",
      cancelButtonTitle: '取消',
      takePhotoButtonTitle: '拍照', // specify null or empty string to remove this button
      chooseFromLibraryButtonTitle: '选择图片', // specify null or empty string to remove this button
      maxWidth: 600,
      maxHeight: 600,
      quality: 0.7,
      allowsEditing: false, // Built in iOS functionality to resize/reposition the image
      noData: false, // Disables the base64 `data` field from being generated (greatly improves performance on large photos)
      storageOptions: { // if this key is provided, the image will get saved in the documents directory (rather than a temporary directory)
        skipBackup: true, // image will NOT be backed up to icloud
        path: User.currentUser.documentID+'/Images' // will save image at /Documents/images rather than the root
      }
    };

    if(React.Platform.OS === 'ios'){
      UIImagePickerManager.showImagePicker(options, (didCancel, response) => {
        if (didCancel) {
        }
        else {
          User.currentUser.headIcon = {objectKey:response.fileName,status:0};
          User.currentUser.save(()=>{
              DatabaseManager.instance.currentDatabase.checkUploadFile();
          });
          self.setState({head:response.fileName});
        }
      });
    }else if (React.Platform.OS === 'android') {
      React.NativeModules.ActionSheet.showActionSheet(["拍照","选择图片"],"取消",(index)=>{
        React.NativeModules.AndroidSelectPhoto.selectPhoto(index,options,(response)=>{

          User.currentUser.headIcon = {objectKey:response.fileName,status:0};
          User.currentUser.save(()=>{
              DatabaseManager.instance.currentDatabase.checkUploadFile();
          });
          this.setState({head:response.fileName})
        })
      })
    }

  }
  refresh(){
    if (this.state.name != User.currentUser.name){
      this.setState({name:User.currentUser.name})
    }

  }
  _renderHeader(){
    return (
      <TouchableHighlight  onPress={this.selectHead.bind(this)} underlayColor='transparent'>
        {
          (()=>{
            if(User.currentUser.isVIP){
              return (
                <View style={styles.headWidth}>
                <UserIcon user={User.currentUser.documentID} thumbnailWidth={100} style={styles.headWidth}>
                  <ImageView  source={require('../../images/icon_head_vip.png')} style={styles.headWidth}/>
                </UserIcon>
                </View>
              )
            }else {
              return  (
                <View style={styles.headWidth}>
                  <UserIcon user={User.currentUser.documentID} thumbnailWidth={100} style={styles.headWidth}/>
                </View>
              )
            }
          })()
        }
      </TouchableHighlight>
    )
  }
  _renderLine(){
    return(
      <View style={styles.line} />
    )
  }
  _renderItem(imageSource,titleName,color,onPress,hideArror,text){
    return (
      <TouchableHighlight onPress={onPress} underlayColor={'transparent'}>
        <View>
          <View style={styles.item}>
            <View style={Styles.center}>
              <ImageView  source={imageSource} style={styles.itemImage}/>
            </View>
            <View style={Styles.center}>
              <Text style={[styles.itemTitle,{color:color}]}> {titleName} </Text>
            </View>
            {
              (()=>{
                if(hideArror){
                  return(
                    <View style={{flex:1,justifyContent:'center',alignItems:'flex-end'}}>
                      <Text style={styles.version}>{Config.boundleVersion}</Text>
                    </View>
                  )
                }else{
                  return(
                    <View style={{flex:1,justifyContent:'center',alignItems:'flex-end'}}>
                      <ImageView  source={require('../../images/icon_navigation_back.png')} style={[styles.itemArror,{tintColor:color}]} />
                    </View>
                  )
                }
              })()
            }
          </View>
          <View style={styles.line} />
        </View>
      </TouchableHighlight>
    )
  }
  _render() {
    return (
      <View style={[Styles.content]}>
        <View style={{height:Tools.fixWidth(75),flexDirection:'row',backgroundColor:'white'}}>
           <View style={[styles.head,styles.headWidth]}>
           {
             this._renderHeader()
           }
           </View>
           <View style={styles.userName}>
            <Text style={{fontSize:Tools.fixWidth(12)}}> {User.currentUser.name} </Text>
            <Text style={styles.phoneNumber}> {User.currentUser.phone_number} </Text>
           </View>
        </View>
        {
          this._renderLine()
        }
        {
          this._renderItem(require('../../images/icon_vip_l.png'),User.currentUser.isVIP?"会员续费":"成为会员","#F39800",()=>{
            // if (!User.currentUser.isVIP) {
              this.push(Pay);
            // }
          })
        }
        {
          this._renderItem(require('../../images/icon_record.png'),"服务记录","#666666",()=>{
            this.push(ServiceList)
          })
        }
        {
          this._renderItem(require('../../images/icon_setting.png'),"设置","#666666",()=>{
            this.push(Setting);
          })
        }
        {
          this._renderItem(require('../../images/icon_version.png'),"版本号","#666666",()=>{

          },true,this.state.version)
        }
      </View>
    );
  }
}

var styles = StyleSheet.create({
  head:{
    marginTop:Tools.fixWidth(12.5),
    marginLeft:Tools.fixWidth(12),
  },
  headWidth:{
    width:Tools.fixWidth(50),
    height:Tools.fixWidth(50),
    borderRadius:Tools.fixWidth(5),
  },
  button:{
    borderRadius:0,
    marginTop:10
  },
  line:{
    backgroundColor:Color.white_border_color,
    height:1,
    marginLeft:Tools.fixWidth(12),
    marginRight:Tools.fixWidth(12),
  },
  userName:{
    marginTop:Tools.fixWidth(12.5),
    marginBottom:Tools.fixWidth(12.5),
    marginLeft:Tools.fixWidth(12),
    flex:1,
    justifyContent:'center'
  },
  phoneNumber:{
    position:'absolute',
    left:0,
    bottom:0,
    color:"#c1c1c1",
    fontSize:Tools.fixWidth(12),
  },
  item:{
    paddingLeft:Tools.fixWidth(12),
    paddingRight:Tools.fixWidth(12),
    height:Tools.fixWidth(50),
    flexDirection:'row',
    backgroundColor:'white'
  },
  itemImage:{
    width:Tools.fixWidth(15),
    height:Tools.fixWidth(15),
  },
  itemTitle:{
    fontSize:Tools.fixWidth(14),
    marginLeft:Tools.fixWidth(12),
  },
  itemArror:{
    width:Tools.fixWidth(7),
    height:Tools.fixWidth(15),
    transform:[{rotate:"180deg"}],
  },
  version:{
    fontSize:Tools.fixWidth(14),
    color:Color.chatBorder
  }
})

module.exports = MySetting;
