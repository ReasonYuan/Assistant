// BrowerImages
'use strict';
var React = require('react-native');
var {
  StyleSheet,
  Text,
  View,
  Image,
  ListView,
  ScrollView,
  TouchableHighlight,
  WebView,
} = React;

var {ImageView,Styles,Color,BaseComponent,Tools,Config} = require("../../Styles");
var { requireNativeComponent } = React;

class OCRResult extends BaseComponent {
  constructor(props) {
    super(props)
    var config = {title:"OCR结果",showBackIcon:true}
    this.state = {navigatorBarConfig:config,text:""}
    if(this.props.imageKey){
      var parameters = {image_key:this.props.imageKey};
      this.post("records/image/view_ocr_by_key",parameters,(data)=>{
        if(data.results){
          this.setState({text:data.results.image_txt});
        }else{
          this.showWarning("获取OCR结果失败！");
        }
      },Config.webShowForwardServerURL);
    }
  }
  onLeftPress(){
    this.pop();
  }

  _render(){
    return (
      <WebView automaticallyAdjustContentInsets={false}
      style={{flex:1}}
      html={this.state.text}
      javaScriptEnabledAndroid={true}
      scalesPageToFit={true}
      />
    )
  }
}


var styles = StyleSheet.create({
  text:{
    flex:1,
    fontSize:Tools.fixWidth(11),
  },
});


module.exports = OCRResult;
