// NoRecognizeList
'use strict';
var React = require('react-native');
var {
  StyleSheet,
  TabBarIOS,
  Text,
  View,
  Image,
  ListView,
  ScrollView,
  TextInput,
  TouchableHighlight,
  InteractionManager,
} = React;

var {ImageView,Styles,Color,BaseComponent,Tools,FQListView} = require("../../Styles");
var {DatabaseManager,DatabaseView} = require('../couchbase/Couchbase');
var {User,Record,Patient} = require("../Models");
var BrowerImages = require('./BrowerImages');

class NoRecognizeList extends BaseComponent {
  allImages:[];
  constructor(props) {
    super(props);
    if(!this.props.patient) throw new Error("no patient");
    this.allImages = [];
    var config = {title:"待识别",showBackIcon:true}
    var ds = new ListView.DataSource({rowHasChanged: (r1, r2) => r1 !== r2});
    this.state = {navigatorBarConfig:config,dataSource: ds,renderPlaceholderOnly: true}
  }
  onLeftPress(){
    this.pop();
  }
  componentWillMount(){
    var db = DatabaseManager.instance.currentDatabase;
    var channel = this.props.patient.documentID;
    var noRecognizeView =  new DatabaseView(db,"Record","NoRecognizeRecordView_"+channel,"function(doc) { if(doc.type == 'Record' && doc.status != 2 && doc.patient=='"+channel+"') emit(doc.date,doc)}",()=>{
      noRecognizeView.setOnDataChangeCallback((data)=>this.onRecordsDataChange(data));
    });
    this.noRecognizeView = noRecognizeView;
  }
  componentWillUnmount(){
    super.componentWillUnmount();
    if(this.noRecognizeView)this.noRecognizeView.stop();
  }
  componentDidMount(){
    InteractionManager.runAfterInteractions(() => {
          this.setState({renderPlaceholderOnly: false});
    });
  }
  onRecordsDataChange(data){
    var group = {};
    this.allImages = [];
    var count = 0;
    var getGroup = (key)=>{
      if(!group[key]) group[key] = [];
      return group[key];
    }
    for (var i = 0; i < data.length; i++) {
      var record = new Record();
      record.setProperty(data[i].value);
      for (var j = 0; j < record.images.length; j++) {
        record.images[j].index = count++;
        record.images[j].userId = User.currentUser.documentID;
        record.images[j].status = record.status;
        this.allImages.push(record.images[j]);
      }
      getGroup(record.date.format("yyyy-MM-dd")).push(record);
    }
    var allReacord = [];
    Object.keys(group).forEach((key)=>{
      allReacord.push({date:key,records:group[key]})
    })
    this.setState({dataSource:this.state.dataSource.cloneWithRows(allReacord)})
  }
  renderImage(rowData,s,i){
    return (
       <TouchableHighlight underlayColor={"transparent"} onPress={()=>{
         this.pushWidthComponent({component:<BrowerImages navigator={this.props.navigator} index={rowData.index} source={this.allImages} showTips={true}/>})
       }}>
          <View style={[styles.row]}>
            <ImageView kye={rowData} style={[styles.row]} imageKey={rowData.key} />
            {
              (()=>{
                if(rowData.status == 3){
                  return <Image style={{position:"absolute",right:0,bottom:0,borderRadius:Tools.fixWidth(10),width:Tools.fixWidth(20),height:Tools.fixWidth(20)}} source={require('../../images/icon_no_recognize.png')}/>
                }
              })()
            }
          </View>

       </TouchableHighlight>
    );
  }
  // <TextInput style={{color:'red',backgroundColor:'blue',width:200,height:20,fontSize:12}} value={record.documentID}></TextInput>
  renderRecord(record,s,i){
    return (
      <View key={record} style={[Styles.vCenter]}>
       <Text style={[Styles.center,{marginTop:Tools.fixWidth(5),marginBottom:Tools.fixWidth(5)}]}> {"第"+(new Number(i)+1)+"份"} </Text>

       <FQListView
         automaticallyAdjustContentInsets={false}
         contentContainerStyle={[styles.list]}
         dataSource={this.state.dataSource.cloneWithRows(record.images)}
         renderRow={this.renderImage.bind(this)}
       />
      </View>
    )
  }
  renderlist(rowData,s,i){
    return (
      <View key={rowData} style={[Styles.vCenter,styles.margin]}>
       <View style={Styles.center}>
          <Text style={styles.text_date}> {rowData.date} </Text>
       </View>
       <FQListView
         pageSize={15}
         automaticallyAdjustContentInsets={false}
         dataSource={this.state.dataSource.cloneWithRows(rowData.records)}
         renderRow={this.renderRecord.bind(this)}
       />
      </View>
    )
  }
  _render() {
    if (this.state.renderPlaceholderOnly) {
      return  (
        <View style={[Styles.center,{flex:1}]}>
          <Text>Loading...</Text>
        </View>
      );
    }
    return (
      <View style={[styles.tabContent, {backgroundColor: '#FFFFFF'}]}>
          <FQListView
            pageSize={3}
            automaticallyAdjustContentInsets={false}
            dataSource={this.state.dataSource}
            renderRow={this.renderlist.bind(this)}
          />
      </View>
    );
  }
}

let rowMargin = Tools.fixWidth(2.5);
let rowWidth = (require('Dimensions').get('window').width - Tools.fixWidth(24+2.5*8))/4

var styles = StyleSheet.create({
  text_date:{
    color:"#333333",
    fontSize:Tools.fixWidth(12),
    marginTop:Tools.fixWidth(20),
  },
  margin:{
    marginLeft:Tools.fixWidth(12),
    marginRight:Tools.fixWidth(12),
  },
  tabContent: {
    flex: 1,
    alignItems: 'stretch',
  },
  tabText: {
    color: 'white',
    margin: 50,
  },
  list: {
    justifyContent: 'flex-start',
    flexDirection: 'row',
    flexWrap: 'wrap'
  },
  row: {
    justifyContent: 'center',
    width: rowWidth,
    height: rowWidth,
    backgroundColor: '#F6F6F6',
    alignItems: 'center',
    margin:rowMargin,
  },
});



module.exports = NoRecognizeList;
