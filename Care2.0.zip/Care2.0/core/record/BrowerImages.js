// BrowerImages
'use strict';
var React = require('react-native');
var {
  StyleSheet,
  Text,
  View,
  Image,
  ListView,
  ScrollView,
  TouchableHighlight,
  NativeModules,
  NativeAppEventEmitter,
  DeviceEventEmitter,
} = React;

var {ImageView,Styles,Color,BaseComponent,Tools} = require("../../Styles");
var { requireNativeComponent } = React;
var GalleryView = requireNativeComponent('GalleryView', null);
var OCRResult = require('./OCRResult');

/**
*source [{userId,key,status}]
**/
class BrowerImages extends BaseComponent {
  constructor(props) {
    super(props)
    //TODO==YY==当前版本去掉OCR查看功能
    // this.props.hiddenRightTitle = true

    var config = {title:this.props.title||"查看",showBackIcon:true,rightTextColor:Color.default_color}//,rightButtonTitle:'OCR结果'}
    if(this.props.hiddenRightTitle) delete config.rightButtonTitle;
    var status = 1;
    if(this.props.source && this.props.index && this.props.source[this.props.index]) status = this.props.source[this.props.index].status;
    this.state = {navigatorBarConfig:config,tips:this.props.tips,status:status,text:""};
  }
  componentWillMount(){
    if (React.Platform.OS === "ios"){
      this.listener = NativeAppEventEmitter.addListener("GalleryViewManager_onIndexChange",
        (index) => {
          var status = 1;
          if(this.props.source && this.props.source[index]) status = this.props.source[index].status;
          this.setState({status:status});
          if(this.props.onIndexChange)this.props.onIndexChange(this,index);
        }
      );
    }else if (React.Platform.OS === "android"){
      this.listener = DeviceEventEmitter.addListener("GalleryViewManager_onIndexChange",
        (e) => {
          var status = 1;
          if(this.props.source && this.props.source[e.index]) status = this.props.source[e.index].status;
          this.setState({status:status});
          if(this.props.onIndexChange)this.props.onIndexChange(this,e.index);
        }
      );
    }
  }
  componentWillUnmount(){
    super.componentWillUnmount();
    if(this.listener)this.listener.remove();
  }
  onLeftPress(){
    this.pop();
  }
  onRightPress(){
    // if(this.props.hiddenRightTitle) return;
    // NativeModules.GalleryViewManager.getCurrentIndex((index)=>{
    //   var imagekey = this.props.source[index].key;
    //   this.pushWidthComponent({component:<OCRResult navigator={this.props.navigator} imageKey={imagekey} />})
    // })
  }
  onDelete(){
    NativeModules.GalleryViewManager.deleteCurrentIndex((index)=>{
      if(this.props.onDelete)this.props.onDelete(this,index);
    });
  }
  _render(){
    return (
      <View style = {Styles.content} >
        <GalleryView style = {[Styles.content]} dataSource={this.props.source} index={this.props.index || 0}/>
        {
          (()=>{
            if(this.props.onDelete){
              return (
                <View style = {styles.delete}>
                  <TouchableHighlight style={styles.button} underlayColor="transparent" onPress={this.onDelete.bind(this)}>
                    <Text style={styles.text_delete}>删除</Text>
                  </TouchableHighlight>
                </View>
              )
            }
          })()
        }
        {
          (()=>{
            if(this.props.showTips){
              return (
                <View style={[styles.tips_posotion,{bottom:this.props.onDelete?Tools.fixWidth(35):0}]}>
                  <Text style={[styles.tips]}>{this.state.tips || (this.state.status == 3?"无法识别":"云识别中")}</Text>
                </View>
              )
            }
          })()
        }
        <Text style={{position:'absolute',backgroundColor:'transprent',color:'transprent',height:0}}>{this.state.text}</Text>
      </View>
    )
  }
}


var styles = StyleSheet.create({
  tips:{
    color:"white",
    fontSize:Tools.fixWidth(11),
  },
  tips_posotion:{
    position:"absolute",
    backgroundColor:'rgba(0,0,0,0.7)',
    justifyContent:'center',
    alignItems: 'center',
    left:0,
    bottom:0,
    right:0,
    height:Tools.fixWidth(25),
  },
  delete:{
    height:Tools.fixWidth(35),
    backgroundColor:'white',
    justifyContent:"center",
    alignItems:'flex-end'
  },
  button:{
    height:Tools.fixWidth(35),
    width:Tools.fixWidth(50),
    justifyContent:'center',
    alignItems:'center'
  },
  text_delete:{
    fontSize:Tools.fixWidth(14),
    textAlign:'center',
  }
});


module.exports = BrowerImages;
