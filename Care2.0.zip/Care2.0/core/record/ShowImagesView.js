'use strict';

var React = require('react-native');
var {
  StyleSheet,
  TabBarIOS,
  Text,
  View,
  Image,
  ListView,
  ScrollView,
  TouchableHighlight,
} = React;
var {ImageView,BaseComponent,FQListView} = require("../../Styles");
var ShowGalleryImagesView = require('./ShowGalleryImagesView');

class ShowImagesView extends BaseComponent {
  constructor(props) {
      super(props);
      if(!this.props.group) console.error("no image data");
      var ds = new ListView.DataSource({rowHasChanged: (r1, r2) => r1 !== r2});
      var config = {title:"查看",leftButtonTitle:"返回"}
      this.state = {navigatorBarConfig:config,dataSource:ds};
  }
  onLeftPress(){
    this.pop();
  }
  onItemPress(){

  }
  renderlist(rowData,s,i,group){
    return (
        <TouchableHighlight kye={rowData} style={{borderRadius:6}} underlayColor={"gray"} onPress={()=>{
          this.pushWidthComponent({component:<ShowGalleryImagesView navigator={this.props.navigator} group={group} showDelete={true} onDelete={(index)=>{
            try {
              group.splice(index,1);
              if(this.props.onImageDelete)this.props.onImageDelete();
            } catch (e) {
            }

          }}/>})
        }}>
          <ImageView style={[styles.row]} imageKey={rowData} />
        </TouchableHighlight>
    );
  }
  _render() {
    var images = [];
    for (var i = 0; i < this.props.group.length; i++) {
      var imageSource = this.props.group[i];
      images.push(
        <View>
          <Text style={{fontSize:20,color:'blue'}}> { "第"+(i+1)+"份" } </Text>
          <FQListView
            contentContainerStyle={styles.list}
            dataSource={this.state.dataSource.cloneWithRows(imageSource)}
            renderRow={(rowData,section,row)=>this.renderlist(rowData,section,row,imageSource)}
          />
        </View>
      )
    }
    return (
      <View style={[styles.tabContent, {backgroundColor: '#FFFFFF'}]}>
          <ScrollView>
            {
              images
            }
          </ScrollView>
      </View>
    );
  }
}

var styles = StyleSheet.create({
  tabContent: {
    flex: 1,
    alignItems: 'stretch',
  },
  tabText: {
    color: 'white',
    margin: 50,
  },
  list: {
    justifyContent: 'flex-start',
    flexDirection: 'row',
    flexWrap: 'wrap'
  },
  row: {
    justifyContent: 'center',
    width: 80,
    height: 80,
    backgroundColor: '#F6F6F6',
    alignItems: 'center',
    borderWidth: 1,
    borderRadius: 5,
    margin:10,
    borderColor: '#CCC'
  },
});



module.exports = ShowImagesView;
