// NoRecognizeList
'use strict';
var React = require('react-native');
var {
  StyleSheet,
  TabBarIOS,
  Text,
  View,
  Image,
  ListView,
  ScrollView,
  TouchableHighlight,
} = React;

var {ImageView,Styles,Color,BaseComponent,Tools,FQListView} = require("../../Styles");
var {DatabaseManager,DatabaseView} = require('../couchbase/Couchbase');
var {User,Record,Patient} = require("../Models");
var BrowerImages = require('./BrowerImages');

class NoRecognizeList extends BaseComponent {
  allImages:[];
  constructor(props) {
    super(props);
    if(!this.props.group) throw new Error("no image group");
    var config = {title:"查看",showBackIcon:true}
    this.ds = new ListView.DataSource({rowHasChanged: (r1, r2) => {
      if(Array.isArray(r1) && Array.isArray(r2)){
        return true;
      }else {
        return r1 !== r2
      }
    }});
    this.renderBrowserImage=false;
    this.state = {navigatorBarConfig:config,dataSource: this.ds.cloneWithRows(this.props.group)}

    this.yes = 0 ;
  }
  onLeftPress(){
    this.pop();
  }
  getSource(source,data){
    var index = 0;
    var count = 0;
    for (var i = 0; i < this.props.group.length; i++) {
      var oneGroup = this.props.group[i];
      for (var j = 0; j < oneGroup.length; j++) {
        if(oneGroup[j] == data){
          index = count;
        }else{
          count++;
        }
        source.push({userId:User.currentUser.documentID,key:oneGroup[j]});
      }
    }
    return index;
  }
  onDelete(browerImages,index){

    var imagesize = 0;
    for (var i = 0; i < this.props.group.length; i++) {
      var oneGroup = this.props.group[i];
      for (var j = 0; j < oneGroup.length; j++) {
        imagesize++
      }
    }

    var tmp = 0;
    var count = 0;
    for (var i = 0; i < this.props.group.length; i++) {
      var oneGroup = this.props.group[i];
      for (var j = 0; j < oneGroup.length; j++) {
        if(tmp == index){
          //TODO 删除本地文件
          oneGroup.splice(j,1);
          if (tmp+1 < imagesize){
            browerImages.setState({tips:this.getTips(index,"a"+(this.yes++)),text:"a"+(this.yes++)});
          }else{
            browerImages.setState({tips:this.getTips(index-1)});
          }
          this.setState({dataSource:this.ds.cloneWithRows(this.props.group)})
          if(this.props.onDelete)this.props.onDelete();
          return;
        }
        tmp++;
      }
    }
  }
  getTips(index,text){
    var length = 0;
    for (var i = 0; i < this.props.group.length; i++) {
      var oneGroup = this.props.group[i];
      for (var j = 0; j < oneGroup.length; j++) {
        length++
      }
    }

    if(length <= 0) return "没有图片";
    var group = 0;
    var count = 0;
    var tmp = 0;
    for (var i = 0; i < this.props.group.length; i++) {
      var oneGroup = this.props.group[i];
      count = 0;
      for (var j = 0; j < oneGroup.length; j++) {
        if(tmp == index){
          return "第"+(group + 1)+"份：第"+(count + 1)+"页";
        }
        count++;
        tmp++;
      }
      group++;
    }
    return "第"+(group + 1)+"份：第"+(count + 1)+"页";
  }
  onIndexChange(browerImages,index){
    var tips = this.getTips(index);
    browerImages.setState({tips:tips});
  }
  renderImage(rowData,s,i){
    return (
       <TouchableHighlight underlayColor={"transparent"} onPress={()=>{
          var source = [];
          var index = this.getSource(source,rowData);
          var tips = this.getTips(index);
          this.pushWidthComponent({component:<BrowerImages navigator={this.props.navigator}
              index={index}
              source={source}
              onDelete={this.onDelete.bind(this)}
              showTips={true}
              tips={tips}
              onIndexChange={this.onIndexChange.bind(this)}
              hiddenRightTitle={true}/>})
       }}>
          <ImageView kye={rowData} style={[styles.row]} imageKey={rowData} />
       </TouchableHighlight>
    );
  }
  renderlist(rowData,s,i){
    return (
      <View key={rowData} style={[styles.margin]}>
        <Text style={styles.text_date}>{"第"+(new Number(i)+1)+"份"}</Text>
       <FQListView
         automaticallyAdjustContentInsets={false}
         contentContainerStyle={[styles.list]}
         dataSource={this.state.dataSource.cloneWithRows(rowData)}
         renderRow={this.renderImage.bind(this)}
       />
      </View>
    )
  }
  _render() {
    return (
      <View style={[styles.tabContent, {backgroundColor: '#FFFFFF'}]}>
        <FQListView
          automaticallyAdjustContentInsets={false}
          dataSource={this.state.dataSource.cloneWithRows(this.props.group)}
          renderRow={this.renderlist.bind(this)}
        />
      </View>
    );
  }

}

let rowMargin = Tools.fixWidth(2.5);
let rowWidth = (require('Dimensions').get('window').width - Tools.fixWidth(24+2.5*8))/4

var styles = StyleSheet.create({
  text_date:{
    color:"#333333",
    fontSize:Tools.fixWidth(12),
    marginTop:Tools.fixWidth(15),
  },
  margin:{
    marginLeft:Tools.fixWidth(12),
    marginRight:Tools.fixWidth(12),
  },
  tabContent: {
    flex: 1,
    alignItems: 'stretch',
  },
  tabText: {
    color: 'white',
    margin: 50,
  },
  list: {
    justifyContent: 'flex-start',
    flexDirection: 'row',
    flexWrap: 'wrap'
  },
  row: {
    justifyContent: 'center',
    width: rowWidth,
    height: rowWidth,
    backgroundColor: '#F6F6F6',
    alignItems: 'center',
    margin:rowMargin,
  },
});



module.exports = NoRecognizeList;
