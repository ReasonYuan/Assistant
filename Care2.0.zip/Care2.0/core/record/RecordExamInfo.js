/**
 * 化验单类型的病历详情
 * @auth reason
 * @date 2016-01-12
 **/
'use strict';

var React = require('react-native');
var {
  StyleSheet,
  Text,
  View,
  Image,
  Alert,
  ListView,
  ScrollView,
  TouchableHighlight,
} = React;

var {BaseComponent,ImageView,Color,Tools} = require('../../Styles')
var w = Tools.fixWidth;
var h = Tools.fixWidth;
var Dimensions = require('Dimensions');
var screenWidth = function(){
  return Dimensions.get('window').width;
}

class RecordExamInfo extends BaseComponent{
  constructor(props){
    super(props)
    this.unNormal = false

    var title = props.title || props.record.recordType
    var rightTitle = props.hideRightTitle?null:"删除"
    this.state = {
      navigatorBarConfig:{title:title,showBackIcon:true,rightButtonTitle:rightTitle},
    }
  }
  onRightPress(){
    if (this.props.onDelete) {
      Alert.alert( ' ', '删除后无法恢复，确认要删除吗？',
        [
          {text: '确定', onPress: () => {
            this.props.onDelete(this.props.record);
          }},
          {text: '取消'}
        ]
      )
    }
  }

  componentWillMount(){
    var record = this.props.record.info
    if(!record)return
    if((!record.examItems || record.examItems.length == 0) && record.other_txt){
      this.unNormal = true
    }

    try{
      var datas = null
      if(this.unNormal){
        datas = JSON.parse(record.other_txt)
        var count = datas[0].length
        // if(count == 0 || count > 3) count = 3
        this.itemWidth = (screenWidth()-w(26))/count
      }else{
        datas = record.examItems
        this.itemWidth = (screenWidth()-w(26))/5//-w(24)-w(2)...分5份,分别为3:1:1
      }
      this.setState({dataSource:datas})
    }catch(error){ }
  }

  onLeftPress(){
    this.pop()
  }

  showImages(){
    var ShowGalleryImagesView = require('./ShowGalleryImagesView');
    var images = []
    var record = this.props.record
    for (var i = 0; i < record.images.length; i++) {
      images.push(record.images[i].key)
    }
    this.pushWidthComponent({component:<ShowGalleryImagesView navigator={this.props.navigator} group={images} title={"查看原图"}/>})
  }

  //非标准化验单标题栏
  renderUnNormalTitle(data){
    var views = []
    for(var i = 0; i < data.length; i++){
      views.push(
        <View style={{width:this.itemWidth}}>
          <Text style={styles.titleLabel}>{data[i]}</Text>
        </View>
      )
    }
    return(
      <View style={styles.itemTitle}>
        {views}
      </View>
    )
  }

  //非标准化验单一行数据
  renderUnNormalItem(data){
    var views = []
    for(var i = 0; i < data.length; i++){
      var isb = (i != data.length - 1)
      views.push(
        <View style={[{width:this.itemWidth},styles.cell,isb&&styles.cellRight]}>
          <Text style={styles.label} numberOfLines={2}>{data[i]}</Text>
        </View>
      )
    }
    return(
      <View style={styles.item}>
        {views}
      </View>
    )
  }

  //标准化验单标题栏
  renderTitle(){
    return(
      <View style={styles.itemTitle}>
        <View style={{width:this.itemWidth*3}}>
          <Text style={styles.titleLabel}>项目</Text>
        </View>
        <View style={{width:this.itemWidth}}>
          <Text style={styles.titleLabel}>结果</Text>
        </View>
        <View style={{width:this.itemWidth}}>
          <Text style={styles.titleLabel}>单位</Text>
        </View>
      </View>
    )
  }

  //标准化验单一行数据
  renderItem(data){
    var isb = ("H"==data.abnormal_value || "L"==data.abnormal_value)
    return(
      <View style={styles.item}>
        <View style={[{width:this.itemWidth*3},styles.cell,styles.cellRight]}>
          <Text style={[styles.label,isb&&styles.abnormalItem]} numberOfLines={2}>{data.item_name}</Text>
        </View>

        <View style={[{width:this.itemWidth},styles.cell,styles.cellRight]}>
          <Text style={[styles.label,isb&&styles.abnormalItem]} numberOfLines={2}>{data.exam_value}</Text>
        </View>

        <View style={[{width:this.itemWidth},styles.cell]}>
          <Text style={[styles.label,isb&&styles.abnormalItem]} numberOfLines={2}>{data.item_unit}</Text>
        </View>
      </View>
    )
  }

    renderUnNormalExamList(data){
      var views = []
      for(var i = 1; i < data.length; i++){
        views.push(this.renderUnNormalItem(data[i]))
      }
      return views
    }

    renderNormalExamList(data){
      var views = []
      for(var i = 0; i < data.length; i++){
        views.push(this.renderItem(data[i]))
      }
      return views
    }

    //渲染化验单数据列表的标题
    renderListTitle(){
      var data = this.state.dataSource
      if(!data || data.length == 0)return
      if(this.unNormal){
        return this.renderUnNormalTitle(data[0])
      }else{
        return this.renderTitle()
      }
    }

    //渲染化验单数据列表
    renderList(){
      var data = this.state.dataSource
      if(!data || data.length == 0)return
      if(this.unNormal){
        return this.renderUnNormalExamList(data)
      }else{
        return this.renderNormalExamList(data)
      }
    }

  _render(){
    var record = this.props.record.info

    var names = record.exam_templates
    var name = "化验单名称："
    for(var i = 0; i < names.length; i++){
      name += names[i]
      if(i != names.length-1){
        name += "，"
      }
    }

    var image = null
    try{image = record.images[0].image_key}
    catch(error){}

    return(
      <View style={styles.full}>

        <View style={styles.titleView}>
          <Text style={styles.dateLabel}>{record.record_time}</Text>
          <Text style={styles.specimenLabel} numberOfLines={1}>{name}</Text>
          <Text style={styles.specimenLabel}>标本：{record.item_specimen}</Text>
        </View>

        <View style={styles.contentView}>
          {this.renderListTitle()}
          <ScrollView style={styles.list} automaticallyAdjustContentInsets={false}>
            {this.renderList()}
          </ScrollView>

          <TouchableHighlight style={styles.thumbnail} underlayColor={Color.itemClick} onPress={this.showImages.bind(this)} >
            <ImageView style={styles.img} imageKey={image} source={require('../../images/icon_def.png')}/>
          </TouchableHighlight>
        </View>

      </View>
    )
  }
}

var styles = StyleSheet.create({
  full:{
    flex:1,
    paddingHorizontal:w(12),
    backgroundColor:'#f1f1f1',
  },
  titleView:{
    borderRadius:w(5),
    marginTop:w(9),
    marginBottom:w(9),
    paddingVertical:w(10),
    paddingHorizontal:w(8),
    backgroundColor:'#fff'
  },
  contentView:{
    flex:1,
    backgroundColor:'#fff'
  },
  dateLabel:{
    fontSize:w(16),
    marginTop:w(5),
    marginBottom:w(16)
  },
   specimenLabel:{
    fontSize:w(13),
    marginTop:w(6)
  },
  list:{
    flex:1,
    marginBottom:w(5)
  },
  itemTitle:{
    flexDirection:'row',
    backgroundColor:'#DEDFE0',
    height:w(25),
    alignItems:'center',
  },
  item:{
    flex:1,
    flexDirection:'row',
    alignItems:'center',
    justifyContent:'center',
    marginBottom:w(2),
    borderWidth:1,
    borderColor:'#f1f1f1',
  },
  hcenter:{
    alignItems:'center'
  },
  cell:{
    height:w(38),
    justifyContent:'center',
    alignItems:'center',
  },
  cellRight:{
    borderRightWidth:1,
    borderColor:'#f1f1f1',
  },
  titleLabel:{
    color:"#333",
    fontSize:w(15),
    alignSelf:'center'
  },
  label:{
    color:"#333",
    fontSize:w(14),
  },
  thumbnail:{
    width:w(50),
    height:w(50),
    marginLeft:w(5),
    marginBottom:w(5),
  },
  img:{
    width:w(50),
    height:w(50),
    resizeMode:'contain',
  },
  abnormalItem:{
    color:"#ec6876"
  }
})

module.exports = RecordExamInfo
