'use strict';

var React = require('react-native');
var {
  StyleSheet,
  TabBarIOS,
  Text,
  View,
  Image,
  TouchableHighlight,
} = React;
var Dimensions = require('Dimensions');
var Camera = require('react-native-camera');
var {Styles,Button,BaseComponent,ImageView} = require('../../Styles');
var {User,Record} = require("../Models")
var ShowImagesView = require('./ShowImagesView');
var {DatabaseManager,DatabaseView} = require('../couchbase/Couchbase');

class AddRecordView extends BaseComponent {
  group:[Object];
  currnetGroupIndex:Number;
  constructor(props) {
    super(props);
    var config = {title:"添加记录",leftButtonTitle:"返回",rightButtonTitle:"确定"}
    this.state = {
      navigatorBarConfig:config,
      cameraType: Camera.constants.Type.back,
      imageCount:0,
      lastImage:null
    }
    this.group = [];
    this.currnetGroupIndex = 0;
    this.group.push([]);
  }
  componentDidMount(){
    super.componentDidMount();
  }
  componentWillUnmount(){
    super.componentWillUnmount();
    delete this.record;
    delete this.images;
    delete this.refs.cam;
  }
  showImages(){
    this.props.navigator.push({
      component: <ShowImagesView navigator={this.props.navigator} group={this.group} onImageDelete={this.onImageDelete.bind(this)}/>
    })
  }
  takePicture(){
    var self = this;
    var localPath = User.currentUser.documentID+'/uploadImages';
    this.refs.cam.capture({path:localPath},function(err, fileName) {
      if(err) {
        console.log(err);
        return;
      }
      self.group[self.currnetGroupIndex].push(fileName);
      var count  = self.state.imageCount + 1;
      self.setState({
        imageCount:count,
        lastImage:fileName
      });
    });
  }
  onRightPress(){
    var self = this;
    var count = 0;
    var check = ()=>{
      if(count == self.group.length-1){
          this.props.navigator.pop();
          DatabaseManager.instance.currentDatabase.checkUploadFile();
      }
      count ++;
    }
    for (var i = 0; i < this.group.length; i++) {
      var images = this.group[i];
      if(images.length > 0){
        var record = new Record();
        record.patient = this.props.patient;
        record.recordType = this.props.recordType;
        if(this.props.patient.user != User.currentUser.documentID){
          record.useUserChannel = true;
        }
        record.images = [];
        for (var j = 0; j < images.length; j++) {
          record.images.push({key:images[j],status:0})
        }
        record.save(()=>{
          check();
        });
      }else{
        check();
      }
    }

  }
  onLeftPress(){
    this.props.navigator.pop()
  }
  nextGroup(){
    this.currnetGroupIndex += 1;
    this.group.push([]);
    this.setState({imageCount:0})
  }
  onImageDelete(){
    var count = 0;
    var lastImageKey = null;
    for (var i = 0; i < this.group.length; i++) {
      for (var j = 0; j < this.group[i].length; j++) {
        count++;
        lastImageKey = this.group[i][j];
      }
    }
    if(count != this.state.imageCount){
      this.setState({imageCount:count,lastImage:lastImageKey})
    }
  }
  _render() {
    return (
      <View style={styles.container}>
        <View >

        </View>
        <View style={{justifyContent:'flex-end',flex:1}}>
          <Camera
            ref="cam"
            captureTarget = {Camera.constants.CaptureTarget.disk}
            style={styles.container}
            onBarCodeRead={this._onBarCodeRead}
            type={this.state.cameraType}
          />

          <View style={{height:80,backgroundColor:'white',justifyContent:'center',alignItems:'center'}}>
            <TouchableHighlight onPress={this.takePicture.bind(this)}  underlayColor='transparent' style={{height:50,width:80,justifyContent:'center',alignItems:'center',backgroundColor: '#48BBEC',borderColor: '#48BBEC',borderWidth: 1,borderRadius: 4}}>
              <Text style ={{fontSize:20}}>拍摄</Text>
            </TouchableHighlight>
            <TouchableHighlight onPress={this.nextGroup.bind(this)}  underlayColor='transparent' style={[styles.finishButton,{justifyContent:'center',alignItems:'center',backgroundColor: '#48BBEC',borderColor: '#48BBEC',borderWidth: 1,borderRadius: 4}]}>
              <Text style ={{fontSize:16}}>下一份</Text>
            </TouchableHighlight>

            <View style={{position:'absolute',top:0,left:0, height:60,width:60,backgroundColor:'transparent',margin:10}}>
              <TouchableHighlight style={{flex : 1}} onPress={this.showImages.bind(this)} >
                <ImageView style={{backgroundColor:'blue',flex : 1 }} imageKey={this.state.lastImage} />
              </TouchableHighlight>

              <TouchableHighlight underlayColor='transparent' style={{position:'absolute',width:20,height:20,backgroundColor:'red',borderColor:'red',top:-10,right:-10,justifyContent:'center',alignItems:'center',borderWidth: 1,borderRadius:10}} >
                  <Text style={{color:'#FFFFFF',fontSize:13}}>{this.state.imageCount}</Text>
              </TouchableHighlight>
            </View>

          </View>
        </View>
      </View>
    );
  }
}

var styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  finishButton: {
    position: "absolute",
    height:35,
    width:50,
    top: (80-35)/2,
    right: 15,
  },
  tabContent: {
    flex: 1,
    alignItems: 'stretch',
  },
  tabText: {
    color: 'white',
    margin: 50,
  },
});

module.exports = AddRecordView;
