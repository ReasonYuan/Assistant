'use strict';

var React = require('react-native');
var {
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableHighlight,
  Navigator,
  ScrollView,
  ListView,
} = React;

var {Styles,Button,BaseComponent} = require('../../Styles');
var AddRecordView = require('./AddRecordView');
var {PatientTabList} = require('../BaseComponent')
var {User,Record,Patient} = require("../Models")
var {DatabaseManager,DatabaseView} = require('../couchbase/Couchbase');
var Profile = require('./Profile');
var ShowGalleryImagesView = require('./ShowGalleryImagesView');
var ShowContextView = require('./ShowContextView');

class AllRecord extends BaseComponent {
  currentPatient:Patient;
  constructor(props){
    super(props)
    var config = {title:"健康档案",leftButtonTitle:"健康计划",rightButtonTitle:"添加"}
    var ds = new ListView.DataSource({
      getSectionHeaderData: this.getSectionData,
      getRowData: this.getRowData,
      rowHasChanged: (r1, r2) => r1 !== r2,
      sectionHeaderHasChanged: (s1, s2) => s1 !== s2
    })
    this.state = {navigatorBarConfig:config,dataSource:ds}
  }
  getSectionData(dataBlob, sectionId){
    return sectionId;
  }
  getRowData(dataBlob, sectionId,rowId){
    return dataBlob[sectionId][rowId]
  }
  onRightPress(){
    if(this.currentPatient){
      this.pushWidthComponent({component:<AddRecordView navigator={this.props.navigator} patient={this.currentPatient}/>});
    }
  }
  onLeftPress(){
    this.pop()
  }
  _stopView(){
    if(this.userRecordsView)this.userRecordsView.stop();
    delete this.userRecordsView;
  }
  _onSelectPatient(patient){
    if(patient){
      this._stopView()
      this.currentPatient = patient;
      var db = DatabaseManager.instance.currentDatabase;
      var userRecordsView =  new DatabaseView(db,"Record","RecordsView","function(doc) { if(doc.type == 'Record') emit(doc.patient,doc)}",()=>{
        userRecordsView.key = patient.documentID;
        userRecordsView.setOnDataChangeCallback((data)=>this.onRecordsDataChange(data));
      });
      this.userRecordsView = userRecordsView;
    }
  }
  onRecordsDataChange(data){
    var groups = {};
    var sectionIds = [];
    var rowIds = [];
    var getGroup = function(key){
      if(!groups[key])groups[key] =  [];
      return groups[key];
    }
    //分组
    for (var i = 0; i < data.length; i++) {
        var record = new Record();
        record.setProperty(data[i].value);
        var group;
        if(record.status != 2){ //未识别
          group = getGroup("待识别");
        }else{
          var date = record.date.format("yyyy-MM-dd");
          group = getGroup(date);
        }
        group.push(record);
    }
    //排序
    sectionIds = Object.keys(groups).sort(function(a,b){
      if(a == "待识别")return -1;
      if(b == "待识别")return 1;
      return a > b;
    });
    sectionIds.forEach((key)=>{
      var oneGroup = groups[key];
      oneGroup.sort((a,b)=>{
        return b.date.getTime() - a.date.getTime()
      })
      rowIds.push(Object.keys(oneGroup));
    })
    this.setState({dataSource:this.state.dataSource.cloneWithRowsAndSections(groups,sectionIds,rowIds)})
  }
  showDetail(record){
    var images = []
    for (var i = 0; i < record.images.length; i++) {
      images.push(record.images[i].key)
    }
    if(record.status != 2){
      this.pushWidthComponent({component:<ShowGalleryImagesView navigator={this.props.navigator} group={images} title={"待识别"} showNoOCR={true}/>})
    }else{
      this.pushWidthComponent({component:<ShowContextView navigator={this.props.navigator} record={record}/>})
    }
  }
  renderRow(rowData,s,i){
    return (
      <View style={{height:44,width:144,margin:10}}>
        <TouchableHighlight style={{borderWidth:2}} underlayColor="rgba(221, 221, 221, 0.5)" onPress={()=>this.showDetail(rowData)}>
          <View style={[{margin:7,height:44,width:140},Styles.center]}>
            <Text style={{fontSize:20}}> {
              (()=>{
                if(rowData.status != 2){
                  var index = new Number(i)+1;
                  return "第"+index+"份";
                }else{
                  return rowData.info?(rowData.info.diagnosis || "查看详情"):"查看详情";
                }
              })()
            } </Text>
          </View>
        </TouchableHighlight>
      </View>
    )
  }
  renderSectionHeader(sectionData,sectionID){
    return (
      <View style={[Styles.vCenter,{height:40}]}>
       <Text style={{fontSize:20}}> {sectionData} </Text>
      </View>
    )
  }
  _render() {
    return (
      <View style={[Styles.content]}>
        <PatientTabList onSelected={(index,patient)=>{
          this._onSelectPatient(patient);
        }} />
        <Button title={"基本信息"} onTouch={()=>{
          this.pushWidthComponent({component:<Profile navigator={this.props.navigator} patient={this.currentPatient}/>})
        }}/>
        <ListView
            style={{marginLeft:10,marginRight:10,marginBottom:10}}
            dataSource={this.state.dataSource}
            renderRow={this.renderRow.bind(this)}
            renderSectionHeader={this.renderSectionHeader.bind(this)}
        />
      </View>
    );
  }
}

module.exports = AllRecord;
