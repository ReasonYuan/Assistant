// CamerScanner
'use strict';

var React = require('react-native');
var {
  StyleSheet,
  TabBarIOS,
  Text,
  View,
  Image,
  TouchableHighlight,
  NativeModules,
  NativeAppEventEmitter,
} = React;
var Dimensions = require('Dimensions');
var {Styles,Button,BaseComponent,ImageView,Tools,Color} = require('../../Styles');
var {User,Record} = require("../Models");
var {DatabaseManager,DatabaseView} = require('../couchbase/Couchbase');
var { requireNativeComponent } = React;
var CameraScannerView = requireNativeComponent('CameraScannerView', null);
var ShowGroupImage = require('./ShowGroupImage');

class CameraScanner extends BaseComponent {
  group:[Object];
  currnetGroupIndex:Number;
  navigatorConfig:Object;
  constructor(props) {
    super(props);
    if(!this.props.patient) throw new Error("no patient");
    this.group = [];
    this.currnetGroupIndex = 0;
    this.group.push([]);
    this.navigatorConfig = {title:"添加记录",showBackIcon:true,rightTextColor:"gray",rightButtonTitle:'上传'};
    this.state = {
      navigatorBarConfig:this.navigatorConfig,
      showUseImage:false,
      imageCount:0,
      lastImage:null,
      showUpState:false,
    }
  }
  onLeftPress(){
    this.pop();
  }
  showUseImage(s){
    if(s){
      delete this.navigatorConfig.rightButtonTitle;
      this.setState({showUseImage:true,navigatorBarConfig:this.navigatorConfig});
    }else{
      this.navigatorConfig.rightButtonTitle = "上传";
      this.setState({showUseImage:false,navigatorBarConfig:this.navigatorConfig});
    }
  }
  componentWillMount(){
    if(React.Platform.OS === 'ios'){
      this.listener = NativeAppEventEmitter.addListener("CameraScannerView_onPerview",
        (data) => {
          this.showUseImage(true);
        }
      );
    }else if (React.Platform.OS === 'android') {
      this.listener = React.DeviceEventEmitter.addListener("CameraScannerView_onPerview",
      (data) => {
        this.showUseImage(true);
      }
      );
    }

  }
  componentDidMount(){
    super.componentDidMount();
  }
  componentWillUnmount(){
    super.componentWillUnmount();
    if(this.listener)this.listener.remove();
  }
  onRightPress(){
    if(!this.state.showUpState) return;
    var self = this;
    var count = 0;
    var check = ()=>{
      if(count == self.group.length-1){
          this.props.navigator.pop();
          this.props.patient.save();
          DatabaseManager.instance.currentDatabase.checkUploadFile();
      }
      count ++;
    }
    for (var i = 0; i < this.group.length; i++) {
      var images = this.group[i];
      if(images.length > 0){
        var record = new Record();
        record.patient = this.props.patient.documentID;
        record.recordType = this.props.recordType;
        if(this.props.patient.user != User.currentUser.documentID){
          record.useUserChannel = true;
        }
        record.images = [];
        for (var j = 0; j < images.length; j++) {
          record.images.push({key:images[j],status:0})
        }
        record.save((d)=>{
          check();
        });
      }else{
        check();
      }
    }

  }
  takePhoto(){
    NativeModules.CameraScannerViewManager.takePhoto();
  }
  userPhoto(){
    NativeModules.CameraScannerViewManager.usePerviewPhoto({use:true,path:User.currentUser.documentID+'/uploadImages'},(res)=>{
      this.showUseImage(false);
      var fileName = res.fileName;
      this.group[this.currnetGroupIndex].push(fileName);
      var count  = this.state.imageCount + 1;
      var state = {
        imageCount:count,
        lastImage:fileName
      };
      if(!this.state.showUpState){
        state.showUpState = true;
        this.navigatorConfig.rightTextColor = "rgba(255,0,0,0.5)"
        state.navigatorBarConfig = this.navigatorConfig;
      }
      this.setState(state);
    });
  }
  cannelUse(){
    NativeModules.CameraScannerViewManager.usePerviewPhoto({use:false},()=>{
      this.showUseImage(false);
    });
  }
  onDelete(){
    var lastGroup = this.group[this.group.length - 1];
    var state = {};
    if(this.state.imageCount != lastGroup.length){
      var lastImage = null;
      if(lastGroup.length>0){
        lastImage = lastGroup[lastGroup.length - 1];
      }
      state.imageCount = lastGroup.length;
      state.lastImage = lastImage;
    }
    var tmp = 0
    for (var i = 0; i < this.group.length; i++) {
      for (var j = 0; j < this.group[i].length; j++) {
        tmp ++;
      }
    }
    if(tmp == 0){
      state.showUpState = false;
      this.navigatorConfig.rightTextColor = "gray"
      state.navigatorBarConfig = this.navigatorConfig;
    }
    this.setState(state);
  }
  nextGroup(){
    if(this.group[this.currnetGroupIndex].length){
      this.currnetGroupIndex += 1;
      this.group.push([]);
      this.setState({imageCount:0})
    }
  }
  onImageDelete(){

  }
  showAllImage(){
    this.props.navigator.push({
      component: <ShowGroupImage onDelete={this.onDelete.bind(this)}  navigator={this.props.navigator} group={this.group} onImageDelete={this.onImageDelete.bind(this)}/>
    })
  }
  _renderNormalBottomButton(){
    return (
      <View style={styles.bottom_container}>
        <TouchableHighlight underlayColor='transparent' onPress={this.showAllImage.bind(this)}>
          <View style={{flexDirection:'row',width:50,height:45}}>
            <ImageView imageKey={this.state.lastImage} thumbnailWidth={90} style={{width:45,height:45,backgroundColor:'rgba(255,255,255,0.3)'}}/>
            <View style={[Styles.center,{height:45}]}>
              <Text style={[styles.text_image_count]}>{this.state.imageCount || ""}</Text>
            </View>
          </View>
        </TouchableHighlight>

        <TouchableHighlight underlayColor='transparent' onPress={this.takePhoto.bind(this)}>
          <View style={styles.bottom_big_button}>
           <View style={styles.bottom_small_button}/>
          </View>
        </TouchableHighlight>

        <TouchableHighlight underlayColor='transparent' onPress={this.nextGroup.bind(this)}>
          <View style={styles.text_container}>
           <Text style={styles.text}>{"("+(this.currnetGroupIndex+1)+")"+"下一份"}</Text>
          </View>
        </TouchableHighlight>
      </View>
    )
  }
  _renderUsePhotoBottomButton(){
    return (
      <View style={[styles.bottom_container,{height:50}]}>
        <TouchableHighlight underlayColor='transparent' onPress={this.cannelUse.bind(this)}>
          <View style={styles.text_container}>
           <Text style={styles.text}>{"重拍"}</Text>
          </View>
        </TouchableHighlight>

        <TouchableHighlight underlayColor='transparent' onPress={this.userPhoto.bind(this)}>
          <View style={styles.text_container}>
           <Text style={styles.text}>{"使用照片"}</Text>
          </View>
        </TouchableHighlight>
      </View>
    )
  }
  _render() {
    return (
      <View style={styles.container}>
        <CameraScannerView style={styles.camera}/>
        {
          (()=>{
            if(this.state.showUseImage){
              return this._renderUsePhotoBottomButton()
            }
            return this._renderNormalBottomButton()
          })()
        }

      </View>
    );
  }
}

var styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  camera:{
    flex:1
  },
  text_image_count:{
    color:'#eb6877',
    fontSize:12,
    marginLeft:10,
  },
  text_container:{
    height:45,
    justifyContent:'center',
    alignItems:'center',
  },
  text:{
    fontSize:14,
    color:'white',
  },
  bottom_big_button:{
    backgroundColor:'white',
    borderRadius:30,
    width:60,
    height:60,
    alignItems:"center",
    justifyContent:'center',
  },
  bottom_small_button:{
    backgroundColor:'transparent',
    borderRadius:53/2,
    width:53,
    height:53,
    borderWidth:3,
    borderColor:'black',
  },
  bottom_container:{
    height:75,
    flexDirection:'row',
    backgroundColor:"black",
    paddingLeft:Tools.fixWidth(12),
    paddingRight:Tools.fixWidth(12),
    alignItems:'center',
    justifyContent:"space-between",
  }
});

module.exports = CameraScanner;
