'use strict';

var React = require('react-native');
var {
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableHighlight,
  Navigator,
  ScrollView,
} = React;

var {Styles,Button,BaseComponent} = require('../../Styles');
var {User,Record,Patient} = require("../Models")
var MK = require('react-native-material-kit');
const {
  MKRadioButton,
} = MK;


class Profile extends BaseComponent {
  constructor(props){
    super(props)
    if(!this.props.patient) throw new Error("no patient")
    var config = {title:this.props.patient.relationship,leftButtonTitle:"健康档案",rightButtonTitle:"编辑"}
    this.state = {navigatorBarConfig:config,editMode:false,name:this.props.patient.name,year:this.props.patient.year}
    this.radioGroup = new MKRadioButton.Group();
    this.gender = this.props.patient.gender;
  }
  onLeftPress(){
    this.props.navigator.pop();
  }
  onRightPress(){
    var newMode = !this.state.editMode;
    var rightButtonTitle = "编辑";
    if(newMode){
      rightButtonTitle = "完成"
    }else { //当前是完成,应该保存当前数据
      var patient = this.props.patient;
      if((patient.name != this.state.name) ||(patient.year != this.state.year) || patient.gender != this.gender ){ //数据有更改
        patient.name = this.state.name;
        patient.year = this.state.year;
        patient.gender = this.gender;
        patient.save();
      }
    }
    var config = this.state.navigatorBarConfig;
    config.rightButtonTitle = rightButtonTitle;
    this.setState({editMode:newMode,navigatorBarConfig:config})
  }
  _render() {
    return (
      <View style={[Styles.content]}>
        <View style={[Styles.vCenter],{height:30}}>
          <Text style={[{fontSize:18,marginLeft:20,marginRight:20,marginTop:10}]}>
            姓名：
          </Text>
        </View>

        <View>
          <TextInput
            style={[{height:45,marginLeft:20,marginRight:20,marginTop:10,borderWidth: this.state.editMode ? 0.5 : 0}]}
            placeholder={"姓名"}
            onChangeText={(text) => {
            this.setState({name:text})
          }}
          value={this.state.name?this.state.name:""}
          editable={this.state.editMode}
          />
        </View>

          <View style={[Styles.vCenter],{height:30}}>
            <Text style={[{fontSize:18,marginLeft:20,marginRight:20,marginTop:10}]}>
              出生年份：
            </Text>
          </View>

          <View style={{marginTop:3}}>
            <TextInput
              style={[{height:45,marginLeft:20,marginRight:20,marginTop:10,borderWidth: this.state.editMode ? 0.5 : 0}]}
              placeholder={"出生年份"}
              keyboardType={"numeric"}
              onChangeText={(text) => {
              this.setState({year:text})
            }}
            value={this.state.year?this.state.year:""}
            editable={this.state.editMode}
            />
          </View>


          <View style={[Styles.vCenter],{height:30}}>
            <Text style={[{fontSize:18,marginLeft:20,marginRight:20,marginTop:10}]}>
              性别：
            </Text>
          </View>

          <View style={{flexDirection:'row',marginLeft:20,marginRight:20}}>
              <View style={[Styles.hCenter,{flex:1}]}>
                <MKRadioButton
                  checked={this.gender?true:false}
                  group={this.radioGroup}
                  onCheckedChange={(changed)=>{
                    if(changed.checked){
                      this.gender = 1;
                    }
                  }}/>
                <Text>男</Text>
              </View>
              <View style={[Styles.hCenter,{flex:1}]}>
                <MKRadioButton
                 group={this.radioGroup}
                 checked={this.gender?false:true}
                 onCheckedChange={(changed)=>{
                   if(changed.checked){
                     this.gender = 0;
                   }
                 }}
                 />
                <Text>女</Text>
              </View>
            </View>
      </View>
    );
  }
}

module.exports = Profile;
