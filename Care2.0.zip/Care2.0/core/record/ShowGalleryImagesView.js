'use strict';

var React = require('react-native');
var {
  StyleSheet,
  TabBarIOS,
  Text,
  View,
  Image,
  ListView,
  ScrollView,
  TouchableHighlight,
  NativeModules,
  Alert,
} = React;
var {ImageView,BaseComponent,Button,FQListView} = require("../../Styles");
var GalleryView = React.requireNativeComponent('GalleryView', null);
var {User,Record,Patient} = require("../Models");
var Dimensions = require('Dimensions');

class ShowGalleryImagesView extends BaseComponent {
  constructor(props) {
      super(props);
      if(!this.props.group) console.error("no image data");
      var title = this.props.title || "查看";
      var config = {title:title,showBackIcon:true,rightButtonTitle:this.props.record?'删除':''}
      var images = [];
      var le = this.props.group.length;
      for (var i = 0; i < le; i++) {
          var image = {};
          image.userId = User.currentUser.documentID;
          image.key = this.props.group[i];
          images.push(image);
      }
      this.state = {images:images,navigatorBarConfig:config,showDelete:this.props.showDelete || false,showNoOCR:this.props.showNoOCR || false};
  }
  onLeftPress(){
    this.pop();
  }
  onRightPress(){
    if(this.props.record){
      Alert.alert(
        '确认删除？',
        '确认删除当前记录',
        [
          {text: '确定', onPress: () => {
            User.currentUser.moveToTrash(this.props.record.documentID);
            this.pop();
          }},
          {text: '取消'},
        ]
      )
    }
  }
  renderlist(rowData,s,i){
    return (
        <ImageView kye={rowData} style={[styles.row]} imageKey={rowData} />
    );
  }
  _render() {
    return (
      <View style={[styles.tabContent, {backgroundColor: '#FFFFFF'}]}>
          <GalleryView style = {{flex:1}} dataSource={ this.state.images }/>
          {
            (()=>{
              if(this.props.showNoOCR){
                return (
                  <View style = {[styles.fullScreen,{position:"absolute",backgroundColor:'transparent',justifyContent:'center',alignItems: 'center'}]}>
                    <Text style={styles.centerText}>智能识别中...</Text>
                  </View>
                )
              }
            })()
          }
          {
            (()=>{
              if(this.state.showDelete){
                return (
                  <View style={{alignItems:'flex-end'}}>
                   <Button style={{width:80,margin:10}} title={"删除"} onTouch={()=>{
                     NativeModules.GalleryViewManager.deleteCurrentIndex((index)=>{
                       if(this.props.onDelete)this.props.onDelete(index);
                     })
                   }}/>
                  </View>
                )
              }
            })()
          }
      </View>
    );
  }
}

var styles = StyleSheet.create({
  tabContent: {
    flex: 1,
    alignItems: 'stretch',
  },
  fullScreen:{
    width:Dimensions.get('window').width,
    height:60,
    top:Dimensions.get('window').height/2 - 60,
    left:0
  },
  centerText:{
    color:"blue",
    fontSize:18
  },
  tabText: {
    color: 'white',
    margin: 50,
  },
  list: {
    justifyContent: 'flex-start',
    flexDirection: 'row',
    flexWrap: 'wrap'
  },
  row: {
    justifyContent: 'center',
    width: 80,
    height: 80,
    backgroundColor: '#F6F6F6',
    alignItems: 'center',
    borderWidth: 1,
    borderRadius: 5,
    margin:10,
    borderColor: '#CCC'
  },
});



module.exports = ShowGalleryImagesView;
