
var React = require('react-native');
var {
  StyleSheet,
  TabBarIOS,
  Text,
  View,
  Image,
  TouchableHighlight,
  ScrollView,
  TextInput,
  InteractionManager,
  Alert,
} = React;

var {ImageView,BaseComponent,ImageView,Tools} = require("../../Styles");
var {Record,Patient} = require("../Models")

class TitleValeView extends React.Component {
  constructor(props) {
    super(props);
  }
  render(){
    let title = this.props.title;
    let value = this.props.value;
    let textSize = Tools.fixWidth(10.5);
    var titleSize = Tools.fixWidth(12);
    if(value instanceof Array){
      var allItem = [];
      for (var i = 0; i < value.length; i++) {
        var item = value[i];
        if(item["title"] && item["content"]){
          var ti = item["title"];
          var co = item["content"];
          if(item["img"]){
            var replaceString = item["img"];
            if(React.Platform.OS == 'android'){
              co = co.replace(replaceString,"#  图片处理中  #")
            }else{
              co = co.replace(replaceString,"#  ⛰ #")
            }
          }
          allItem.push(
            <View style={{margin:5}} key={i}>
             <Text style={{fontSize:titleSize}}>
              {ti}
             </Text>
             <Text style={{fontSize:textSize}}>
              {co}
             </Text>
            </View>
          )
        }
      }
      return (
        <View style={{margin:5}}>
        {
          allItem
        }
        </View>
      )
    }
    return(
      <View style={{margin:5}}>
        <Text style={{color:'#333333',marginTop:Tools.fixWidth(8),fontSize:titleSize}}>
          {title}
        </Text>
        {
          (()=>{
            if(typeof(value) == "string"){
              return (
                <Text style={{color:'#333333',marginTop:Tools.fixWidth(6.5),fontSize:textSize}}>
                {
                  value
                }
                </Text>
              )
            }else{
              if(value instanceof Array){
                var items = [];
                for (var i = 0; i < value.length; i++) {
                  items.push(<JSONStringView json={value[i]} root={false}/> )
                }
                return (
                  <View>
                  {
                    items
                  }
                  </View>
                );
              }else if (value instanceof Object) {
                return (
                  <View>
                   <JSONStringView json={value} root={false}/>
                  </View>
                );
              }
              return (
                <View />
              )
            }
          })()
        }
      </View>
    )
  }
}

class JSONStringView extends React.Component {
  constructor(props){
    super(props);
  }
  render(){
    var json = this.props.json;
    var keys =  Object.keys(json);
    var texts = [];
    let publicKey = ["patient_name","gender","age","inpatient_no","department","hospital_name","record_type","bed_no","imgBaseUrl","need_process_imgs"];
    if(this.props.root){
      let publicName = ["姓名","性别","生日","住院号","科室","医院名称","记录类型","床号"];
      for (var i = 0; i < publicName.length; i++) {
        texts.push(<TitleValeView key={i} title={publicName[i]} value={json[publicKey[i]]} />)
      }
    }
    keys = keys.sort(function(a,b){
      if(json[a] instanceof Object){
        return -1;
      }
      if(json[b] instanceof Object){
        return 1;
      }
      return 0;
    })

    keys.forEach(function (key) {
        if(!publicKey.contains(key)){
          var value = json[key];
          texts.push(<TitleValeView title={key} value={value}/>)
        }
    })

    return(
      <View style={{flex:1}}>
      {
        texts
      }
      </View>
    )
  }
}

class ShowContextView extends BaseComponent {
  constructor(props) {
    super(props);
    if(!this.props.record)console.error("no record");
    var config = {title:this.props.title||"查看",showBackIcon:true,rightButtonTitle:'删除'}
    var info = this.props.record.info;
    var toArray = (str)=>{
      if(str){
        var array = [];
        try {
          array = JSON.parse(str);
        } catch (e) {
          console.log(e);
        } finally{
          return array;
        }
      }else {
        return [];
      }
    }
    var basic_identity_info = toArray(info.basic_identity_info);
    var basic_info = toArray(info.basic_info);
    var note_identity_info = toArray(info.note_identity_info);
    var note_info = toArray(info.note_info);
    var content = basic_identity_info.concat(basic_info,note_identity_info,note_info);
    content.sort((a,b)=>{
      if(a.index && b.index){
        return a.index - b.index;
      }
      return 0;
    })

    var showData = {};
    for (var i = 0; i < content.length; i++) {
      var c = content[i];
      Object.keys(c).forEach((k)=>{
        if(k != "index"){
          showData[k] = c[k];
        }
      })
    }

    this.state = {navigatorBarConfig:config,content :showData};
  }
  onLeftPress(){
    this.pop();
  }
  onRightPress(){

    if (this.props.onDelete) {
      Alert.alert( ' ', '删除后无法恢复，确认要删除吗？',
        [
          {text: '确定', onPress: () => {
            this.props.onDelete(this.props.record);
          }},
          {text: '取消'}
        ]
      )
    }
    // if (this.props.onDelete) {
    //   this.props.onDelete(this.props.record);
    // }
  }
  showImages(){
    var ShowGalleryImagesView = require('./ShowGalleryImagesView');
    var images = []
    var record = this.props.record;
    for (var i = 0; i < record.images.length; i++) {
      images.push(record.images[i].key)
    }
    this.pushWidthComponent({component:<ShowGalleryImagesView navigator={this.props.navigator} group={images} title={"查看原图"}/>})
  }
  _render(){
    var lastImageKey = null;
    if(this.props.record.images.length > 0){
      lastImageKey = this.props.record.images[this.props.record.images.length - 1].key;
    }
    return (
      <View style = {[styles.content,{backgroundColor:'#f1f1f1'}]} >
          <View style={{flex:1,flexDirection:"column",justifyContent:'flex-end',marginLeft:Tools.fixWidth(12),marginRight:Tools.fixWidth(12),marginTop:Tools.fixWidth(9),backgroundColor:'white'}}>
            <ScrollView style ={{flex:1}}  automaticallyAdjustContentInsets={false}>
            {
              (()=>{
                if(typeof(this.state.content) == 'string' || this.state.content.noteTxt){
                  var str = this.state.content.noteTxt;
                  if(!str) str = this.state.content;
                  return (
                    <Text> {str} </Text>
                  )
                }else{
                  return (
                    <JSONStringView json={this.state.content} root={false}/>
                  )
                }
              })()
            }
            </ScrollView>
            <View style ={{height:60,flexDirection:"row"}}>
              <View style={{width:60,justifyContent:"center",alignItems:'center'}}>
                <TouchableHighlight style={{width:50,height:50}} onPress={this.showImages.bind(this)} >
                  <ImageView style={{flex : 1 }} imageKey={lastImageKey}/>
                </TouchableHighlight>
              </View>
            </View>
        </View>

      </View>
    )
  }
}


var styles = StyleSheet.create({
  content: {
    flex: 1,
    alignItems: 'stretch',
  },
  tabText: {
    color: 'white',
    margin: 50,
  },
});


module.exports = ShowContextView;
