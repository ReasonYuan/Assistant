var React = require('react-native');
var {
  StyleSheet,
  Text,
  View,
  Image,
  TouchableHighlight,
} = React;
var IOSWebView = React.WebView;
var {BaseComponent} = require('../Styles')

class WebView extends BaseComponent {
  constructor(props) {
    super(props)
    if(!this.props.url)console.error("no url");
    var config = {title:this.props.title||"网页浏览",showBackIcon:true};
    this.state = {navigatorBarConfig:config};
  }
  onLeftPress(){
    this.pop();
  }
  _render(){
    return (
      <View style ={{flex: 1,alignItems: 'stretch'}}>
          <IOSWebView
            automaticallyAdjustContentInsets={false}
            style={{flex:1}}
            url={this.props.url}
            javaScriptEnabledAndroid={true}
            startInLoadingState={true}
            scalesPageToFit={true}
          />
      </View>
    )
  }
}



module.exports = WebView;
