
'use strict';

var Config = require("../Config");
var DBModel = require("./DBModel");
var {DBPullReplication,DBPushReplication} = require("./DBReplication");
var Models = require("../Models")
var React = require('react-native');
var { NativeAppEventEmitter } = React;
var CouchbaseHelper = React.NativeModules.CouchbaseHelper;
var {UploadImageSync} = require('../sync/ImageSync')

var UPDATA_INTERVAL = 200; //更新间隔，0.5s

class Database {
  cache:Object;
  dbName:String;
  created:Boolean;//本地数据库是否创建
  push:DBPushReplication;
  pull:DBPullReplication;
  changeCallbacks:Function;
  lastSeq:Number;
  allViews:Object; // key - databaseView
  uploadImageSync:UploadImageSync;
  constructor(name,initCallback) {
    this.cache = {};
    this.dbName = name;
    this.allViews = {};
    if(!this.dbName) throw new Error("database name can't be null");
    var url = Config.localURL+this.dbName;
    this.changeCallbacks = {};
    var self = this;
    CouchbaseHelper.registerDBNamed(this.dbName,()=>{
      self.onCreated(initCallback);
    });
    if(React.Platform.OS === 'ios'){
      this.changeListener = NativeAppEventEmitter.addListener(this.dbName+"_changes",
        (data) => self.onChange(data)
      );
    }else if (React.Platform.OS === 'android') {
      this.changeListener = React.DeviceEventEmitter.addListener(this.dbName+"_changes",
        (data) => self.onChange(data)
      );
    }
  }
  clean(){
    React.NativeModules.CouchbaseHelper.stopReplication();
    if(this.changeListener){
      this.changeListener.remove();
      delete this.changeListener;
    }
  }
  //初始化回调
  onCreated(callback){
    this.created = true;
    //开启change监听
    // var updateFunc = function(){
    //     this.update(()=>{
    //       setTimeout(updateFunc,UPDATA_INTERVAL);
    //     });
    // }.bind(this);
    // setTimeout(updateFunc,UPDATA_INTERVAL);
    this.addChangeCallback("User",this,(body)=>{
      var {User} = Models;
      for (var i = 0; i < body.length; i++) {
        var item = body[i];
        if(User.currentUser && item.type == "User" && item._id == User.currentUser.documentID){
          var profile = User.currentUser.profile;
          User.currentUser.setProperty(item);
          User.currentUser.profile = profile;
        }
      }
    })
    this.initImageStatusListener();
    if(callback)callback();
  }
  viewNamed(type,name,mapFunction,initCallback){
    var DatabaseView = require('./DatabaseView');
    var view = this.allViews[name];
    if(view){
      initCallback(view);
      return view;
    }else{
      view = new DatabaseView(this,type,name,mapFunction,initCallback);
      this.allViews[name] = view;
      return view;
    }
  }
  checkUploadFile(){ //检查是否有文件上传
    if(!this.uploadImageSync)this.uploadImageSync = new UploadImageSync(this);
    this.uploadImageSync.update();
  }
  //轮训查看变化
  update(callback){
    var self = this;
    var url = Config.localURL+this.dbName+"/_changes?include_docs=true&limit=1&descending=true";
    fetch(url).then((response) => response.json())
    .then((data)=>{
      if(self.lastSeq != data.last_seq){
        self.lastSeq = data.last_seq;
        self.onChange(data.results[0]);
      }
    });
    if(this.changeCallbacks){
      var count = 0;
      for (var key in this.changeCallbacks) {
        // if(key === "Message"){
          var funcs = this.changeCallbacks[key];
          for (var i = 0; i < funcs.length; i++) {
             count++;
          }
        // }
      }
      console.log("---->listener count:",count);
    }
    if(callback)callback();
  }
  addChangeCallback(type,key,func,fitter){
    if(func && (typeof(func) == 'function')){
      if(fitter && (typeof(func) != 'function')) {
        console.error("fitter must a function");
      }
      var add = (function(t){
        var funcs = this.changeCallbacks[t];
        if(!funcs){
          funcs = this.changeCallbacks[t] = [];
        }
        funcs.push({
          "key":key,
          "callback":func,
          "fitter":fitter
        })
      }).bind(this);
      if(type instanceof Array){
        for (var i = 0; i < type.length; i++) {
          add(type[i])
        }
      }else {
        add(type)
      }

    }
  }
  removeChangeCallback(type,key){
    try {
      var rmv = (function(t){
        var funcs = this.changeCallbacks[t];
        if(funcs && (funcs instanceof Array)){
          var tmp = [];
          for (var i = 0; i < funcs.length; i++) {
            var value = funcs[i];
            if(value.key === key){
              tmp.push(value);
            }
          }
          funcs.remove(tmp);
        }
      }).bind(this)
      if(type instanceof Array){
        for (var i = 0; i < type.length; i++) {
          rmv(type[i])
        }
      }else {
        rmv(type)
      }
    } catch (e) {

    } finally {

    }
  }
  onChange(body){
    console.log("<----> database change:",body);
    try {
      // for (var key in this.changeCallbacks) {
      //   var funcs = this.changeCallbacks[key];
      //   for (var i = 0; i < funcs.length; i++) {
      //     var value = funcs[i];
      //     if(value.fitter && !value.fitter(doc)){
      //       return;
      //     }
      //     value.callback(body);
      //   }
      // }
      var notifyed = [];
      for (var i = 0; i < body.length; i++) {
        var item = body[i];
        if(item.delete){ //删除，全部通知更新
          if(this.cache[item._id]) delete this.cache[item._id];
          for (var key in this.changeCallbacks) {
            var funcs = this.changeCallbacks[key];
            if(!funcs)continue;
            for (var j = 0; j < funcs.length; j++) {
              var value = funcs[j];
              if(value.fitter && !value.fitter(doc)){
                continue;
              }
              try {
                if(value.callback)value.callback(body);
              } catch (e) {
                console.log(e);
              }

            }
          }
          return;
        } else {
          if(this.cache[item._id] && (this.cache[item._id] instanceof DBModel))this.cache[item._id].setProperty(item);
          var doc = item;
          var type = doc.type;
          if(!notifyed.contains(type)){
            notifyed.push(type);
            var funcs = this.changeCallbacks[type];
            if(!funcs)continue;
            for (var j = 0; j < funcs.length; j++) {
              var value = funcs[j];
              if(value.fitter && !value.fitter(doc)){
                continue;
              }
              try {
                if(value.callback)value.callback(body);
              } catch (e) {
                console.log(item,e);
              }
            }
          }
        }
      }
    } catch (e) {
      console.log(e);
    }
  }
  setSession(session){
    //开启同步
    // this.push = new DBPushReplication(this);
    // this.pull = new DBPullReplication(this);
    // this.pull.setSession(session);
    // this.push.setSession(session);
    // this.pull.start();
    // this.push.start();
    React.NativeModules.CouchbaseHelper.setSession(session.session_id,this.dbName,Config.serverURL,Config.serverBucket);
  }
  //保存document
  saveModel(model,callback){
    if(!(model instanceof DBModel)) throw new Error("model not an instanceof DBModel");

    var saveFunc = function(method){
      var url = Config.localURL+this.dbName;
      if(method == "PUT") {
        url = url+"/" + model.documentID;
        if(model.rev){
          url = url+"?rev=" + model.rev;
        }
      }
      var self = this;
      fetch(url, {
          method: method,
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(model.getSaveModel())
        })
        .then((response) => response.json())
        .then((data) => {
          if(data.status && data.status == 409){
            self.getModel(model.documentID,(m)=>{
              model.rev = m.rev;
              model.save(callback);
            })
            return;
          }
          if(data.id) model.documentID = data.id;
          if(data.rev) model.rev = data.rev;
          if(callback)callback(model);
        }).catch((err)=>{
          console.dblog(err);
        });
    }.bind(this);
    //存在更新
    if(model.documentID){
      saveFunc("PUT")
    }else{ //不存在插入
      saveFunc("POST")
    }
  }
  //获取document,it will be null
  getModel(documentID,callback,callback2){
    if(this.cache[documentID] && callback){
      callback(this.cache[documentID]);
      return;
    }
    fetch(Config.localURL+this.dbName+"/"+documentID)
      .then((response) => response.json())
      .then((data) => {
        if(data.status === 404){
          if(callback)callback();
          return ;
        }
        if(callback2)callback2(data)
        if(data.type){
          var object = Models.modelForType(data.type);
          if(object instanceof DBModel){
            object.setProperty(data);
            if(callback)callback(object);
          }
          return object;
        }else {
          if(callback)callback(data);
        }
      }).catch((err)=>{
        console.dblog(err);
      });
  }

  //删除document
  deleteModel (model) {
    if(!(model instanceof DBModel)) throw new Error("model not an instanceof DBModel");
    if(model.documentID && model.rev){
      fetch(Config.localURL+this.dbName+"/"+model.documentID+"?rev="+model.rev,{
          method: "DELETE"
        }).then((response) => response.json())
        .then((data) => {
          console.dblog(data);
        }).catch((err)=>{
          console.dblog(err);
        });
    }
 }

 //添加附件，document，附件名，附件，回调（true/false）
 addAttachment(model,attachmentId,contentType,data,callback){
   if(!(model instanceof DBModel)) throw new Error("model not an instanceof DBModel");
   if(model.documentID && model.rev && data){
     CouchbaseHelper.addAttachmnet(this.dbName,model.documentID,attachmentId,contentType,data,(newRev)=>{
       model.rev = newRev;
       callback(true);
     });
     return;
     fetch(Config.localURL+this.dbName+"/"+model.documentID+"/"+attachmentId+"?rev="+model.rev,{
         method: "PUT",
         headers: {
           'Content-Type': contentType
         },
         body: data
       }).then((response) => response.json())
       .then((data) => {
         if(data.status === 404){
           if(callback)callback(false);
           return ;
         }
         if(data.rev) model.rev = data.rev;
        if(callback)callback(true);
       }).catch((err)=>{
         console.dblog(err);
       });
   }
 }

 //获取附件，document，附件名，回调（null/data）
 getAttachment(model,attachmentId,callback){
   if(!(model instanceof DBModel)) throw new Error("model not an instanceof DBModel");
   if(model.documentID){
     CouchbaseHelper.getAttachment(this.dbName,model.documentID,attachmentId,(data)=>{
       callback(data);
     });
     return;
     var url = Config.localURL+this.dbName+"/"+model.documentID+"/"+attachmentId;
     var request = new XMLHttpRequest();
      request.onreadystatechange = (e) => {
        if (request.readyState !== 4) {
          return;
        }
        if (request.status === 200) {
          if(request.responseText != '{"ok":true}'){
            if(callback)callback(request.responseText);
            request = null;
          }
        } else {
          console.warn('error');
        }
      };

      request.open('GET', url);
      request.send();
   }
 }

 initImageStatusListener(){
   this.imageStatusChangeCallbacks = [];
   this.addChangeCallback(["User","Record","Message"],this,(body)=>{
     for (var i = 0; i < body.length; i++) {
       var item = body[i];
       switch (item.type) {
         case "User":
           if(item.headIcon && item.headIcon.status){
             this.dispatchOnImageStatusChangeEvent(item.headIcon.objectKey);
           }
           break;
         case "Record":
           if(Array.isArray(item.images)){
             for (var l = 0; l < item.images.length; l++) {
               if(item.images[l].status){
                 this.dispatchOnImageStatusChangeEvent(item.images[l].key);
               }
             }
           }
           break;
         case "Message":
           if(item.messageType == 1 && item.message.status){
             this.dispatchOnImageStatusChangeEvent(item.message.objectKey);
           }
           break;
         default:

       }
     }
   })
 }
 dispatchOnImageStatusChangeEvent(objectKey){
   for (var i = 0; i < this.imageStatusChangeCallbacks.length; i++) {
     if(this.imageStatusChangeCallbacks[i])this.imageStatusChangeCallbacks[i](objectKey);
   }
 }
 addImageStatusChangeCallback(func){
   this.imageStatusChangeCallbacks.push(func);
 }
 removeImageStatusChangeCallback(func){
   this.imageStatusChangeCallbacks.remove(func)
 }
}

module.exports = Database;
