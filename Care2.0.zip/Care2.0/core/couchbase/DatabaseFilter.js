'use strict';
var Config = require("../Config");
var Database = require("./Database");

var UPDATA_INTERVAL = 500; //更新间隔，0.5s

class DatabaseFilter {
  filterName:String;
  //本地数据库是否创建
  created:Boolean;
  database:Database;
  constructor(database,name,filterFunction,initCallback) {
    this.filterName = name;
    if(!this.filterName) throw new Error("database view name can't be null");
    this.database = database;
    if(!this.database) throw new Error("no a database here");
    if(typeof(filterFunction) != "string" )  throw new Error("map function not string");
    var url = Config.localURL+this.database.dbName+"/_design/"+this.filterName;
    fetch(url).then((response) => {
      if (response.status !== 200) {
        var filters = {};
        filters[this.filterName] = filterFunction;
        fetch(url, {
          method: "PUT",
          headers: {'Content-Type': 'application/json'},
          body: JSON.stringify({
            "language" : "javascript",
            "filters" :filters
          })
        }).then((response) => response.json())
          .then((data) => {
             this.created = true;
             if(initCallback)initCallback();
          });
      } else {
         this.created = true;
         if(initCallback)initCallback();
      }
    })
  }
}

module.exports = DatabaseFilter;
