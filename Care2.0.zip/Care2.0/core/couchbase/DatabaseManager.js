'use strict';
var Database = require("./Database")

class DatabaseManager {
  currentDatabase:Database;
  databaseNamed(name,callback) {
    var self = this;
    this.currentDatabase = new Database(name,()=>{
        // self.currentDatabase =  self[name];
        if(callback) callback(  this.currentDatabase);
      });
    // if(!this[name]){
    //   self[name] = new Database(name,function(){
    //     self.currentDatabase =  self[name];
    //     if(callback) callback(self[name]);
    //   });
    // }else{
    //   self.currentDatabase =  self[name];
    //   if(callback) callback(self[name]);
    // }
  }
  clean(){
      if(this.currentDatabase)this.currentDatabase.clean()
  }
}


var instance = new DatabaseManager();
DatabaseManager.sharedInstance = instance;
DatabaseManager.instance = instance;

module.exports = DatabaseManager;
