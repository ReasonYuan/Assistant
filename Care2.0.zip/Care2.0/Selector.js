'use strict';

var React = require('react-native');
var {
  StyleSheet,
  Text,
  View,
  PickerIOS,
  ListView,
  TouchableHighlight,
  DatePickerIOS,
  ActionSheetIOS,
} = React;

var PickerItemIOS = PickerIOS.Item;
var {Styles,Button,BaseComponent,Color} = require('./Styles');
var Tools = require('./utils/Tools')

let Relationship_Values = ['丈夫','妻子','儿子','女儿','父亲','母亲','岳父','岳母','公公','婆婆','爷爷','奶奶','姥姥','姥爷','外公','外婆'];
let getGender=(value)=>{
  if( value == '丈夫' || value == '儿子' || value == '父亲'|| value == '岳父'|| value == '公公'|| value == '爷爷'|| value == '姥爷'|| value == '外公'){
    return 0;
  }else {
    return 1;
  }
}
// <View style={{flexDirection:'row',justifyContent:'flex-end'}}>
//  <Button style={{width:50,height:25,margin:0}} fontSize={14} title={"确定"} onTouch={()=>{
//     if(this.props.onClose)this.props.onClose(this.state.select,getGender(this.state.select));
//  }}/>
// </View>
class RelationshipSelector extends React.Component {
  constructor(props){
    super(props)
    this.state = {select:Relationship_Values[4]}
  }
  render() {
    return (
      <View style={{position:"absolute",left:0,right:0,bottom:0}}>

        <PickerIOS
         style = {styles.gender}
         selectedValue={this.state.select}
         onValueChange={(change) => {
           this.setState({select:change});
           if(this.props.onDateChange)this.props.onDateChange(this.state.select,getGender(change));
         }}>
         {Object.keys(Relationship_Values).map((carMake,u) => (
           <PickerItemIOS
             key={Relationship_Values[carMake]}
             value={Relationship_Values[carMake]}
             label={Relationship_Values[carMake]}
             />
            ))}
        </PickerIOS>
      </View>
    );
  }
}
RelationshipSelector.height = 120;

// <View style={{flexDirection:'row',justifyContent:'flex-end'}}>
//  <Button style={{width:50,height:25,margin:0}} fontSize={14} title={"确定"} onTouch={()=>{
//     if(this.props.onClose)this.props.onClose(this.state.date);
//  }}/>
// </View>

class DateSelector extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      date: this.props.data || new Date(),
      timeZoneOffsetInHours: (-1) * (new Date()).getTimezoneOffset() / 60,
    };
    if(this.props.onDateChange)this.props.onDateChange(this.state.date);
  }
  render(){
    return (
      <View style={{position:"absolute",left:0,right:0,bottom:0}}>

        <View style={Styles.center}>
          <DatePickerIOS
              style={[styles.date]}
              date={this.state.date}
              mode="date"
              timeZoneOffsetInMinutes={this.state.timeZoneOffsetInHours * 60}
              onDateChange={(date)=>{
                this.setState({date:date});
                if(this.props.onDateChange)this.props.onDateChange(date);
              }}
          />
        </View>
      </View>
    )
  }
}

class SelectRealationship extends BaseComponent {
  constructor(props){
    super(props)
    var config = {title:"选择关系",showBackIcon:true};
    var ds = new ListView.DataSource({rowHasChanged: (r1, r2) => r1 !== r2});
    this.state = {navigatorBarConfig:config,dataSource:ds.cloneWithRows(Relationship_Values)};
  }

  onLeftPress(){
    this.props.navigator.pop();
  }
  onDataClick(rowData){
    if(this.props.onRelationshipSelect){
      this.props.onRelationshipSelect(rowData);
      this.props.navigator.pop();
    }
  }
  getRowTitle(rowData){
    return rowData
  }
  hasNext(rowData){
    return false;
  }
  renderRow(rowData,sId,rId){
    return(
      <TouchableHighlight style={styles.rowContent} key={rowData} onPress={()=>this.onDataClick(rowData)} underlayColor="transparent">
          <View style={Styles.content}>
          <View style={[styles.text_wrap,Styles.center]}>
            <Text style={styles.text_title}>{this.getRowTitle(rowData)}</Text>
          </View>
            <View style={styles.line} />
          </View>
      </TouchableHighlight>
    )
  }
  _render() {
    return (
      <View style={[Styles.content]}>
      <ListView
          automaticallyAdjustContentInsets={false}
          dataSource={this.state.dataSource}
          pageSize={Relationship_Values.count}
          renderRow={this.renderRow.bind(this)}
      />
      </View>
    )
  }
}


DateSelector.height = 200;

var styles = StyleSheet.create({
  gender:{
    height:RelationshipSelector.height,
    overflow:'hidden',
    justifyContent:'space-around',

  },
  date:{
    height:DateSelector.height,
    overflow:'hidden',
    justifyContent:'space-around',
  },
  rowContent : {
    marginLeft:Tools.fixWidth(12),
    marginRight:Tools.fixWidth(12),
    height:Tools.fixWidth(40),
  },
  text_title:{
    textAlign:'center',
    fontSize:16,
    color:'#666666'
  },
  text_wrap:{
    flex:1,
  },
  line:{
    backgroundColor:Color.white_border_color,
    height:1,
  },
  itemArror:{
    width:Tools.fixWidth(7),
    height:Tools.fixWidth(15),
    transform:[{rotate:"180deg"}],
  },
})

module.exports = {
  "RelationshipSelector":RelationshipSelector,
  "DateSelector":DateSelector,
  "SelectRealationship":SelectRealationship,
}
