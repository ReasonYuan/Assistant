
module.exports = {
  default_color:"#3F8A7F",
  navigation_bar_title_color:"#333333",
  white_border_color:"#f1f1f1", //背景为白色的描边色
  gray_border_color:"#c1c1c1", //背景为f1f1f1的描边色
  chatBorder: '#CCC',
  itemDivider:'#f1f1f1',    //item分隔线颜色
  navigation_bar_bg_color:'#FFFFFF'
}
