
'use strict';

var React = require('react-native');
var {
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableHighlight,
  Navigator,
  ScrollView,
  Image,
  PanResponder,
  LayoutAnimation,
  ActionSheetIOS,
} = React;

var UIImagePickerManager = require('NativeModules').UIImagePickerManager;
var {DateSelector} = require('./Selector');
var {User,Patient} = require('./core/Models');
var {Styles,Button,BaseComponent,Color,Tools,Theme,ImageView,Config} = require('./Styles');
var {DatabaseManager} = require("./core/couchbase/Couchbase");
var Home = require('./core/Home2');

class Profile extends BaseComponent {
  constructor(props){
    super(props)
    var config = {title:"个人信息设置",showBackIcon:true}
    this.state = {navigatorBarConfig:config}
  }
  onLeftPress(){
    this.pop();
  }
  selectHead(){
    var options = {
      title:"选择头像",
      cancelButtonTitle: '取消',
      takePhotoButtonTitle: '拍照', // specify null or empty string to remove this button
      chooseFromLibraryButtonTitle: '选择图片', // specify null or empty string to remove this button
      maxWidth: 600,
      maxHeight: 600,
      quality: 0.7,
      allowsEditing: true, // Built in iOS functionality to resize/reposition the image
      noData: false, // Disables the base64 `data` field from being generated (greatly improves performance on large photos)
      storageOptions: { // if this key is provided, the image will get saved in the documents directory (rather than a temporary directory)
        skipBackup: true, // image will NOT be backed up to icloud
        path: User.currentUser.documentID+'/uploadImages' // will save image at /Documents/images rather than the root
      }
    };

    if(React.Platform.OS === 'ios'){
      UIImagePickerManager.showImagePicker(options, (didCancel, response) => {
        if (!didCancel && response)  {
          this.setState({header:{objectKey:response.fileName,status:0}})
        }
      })
    }else if (React.Platform.OS === 'android') {
      React.NativeModules.ActionSheet.showActionSheet(["拍照","选择图片"],"取消",(index)=>{
        React.NativeModules.AndroidSelectPhoto.selectPhoto(index,options,(response)=>{
          this.setState({header:{objectKey:response.fileName,status:0}})
        })
      })
    }


  }

  showGenderSelector(){
    var BUTTONS = [
      '男',
      '女',
      '取消',
    ];

    if(React.Platform.OS === 'ios'){
      ActionSheetIOS.showActionSheetWithOptions({
        options: BUTTONS,
        cancelButtonIndex: 2,
      },
      (buttonIndex) => {
        if(buttonIndex < 2)this.setState({ gender: BUTTONS[buttonIndex] });
      });
    }else if (React.Platform.OS === 'android') {
        React.NativeModules.ActionSheet.showActionSheet(["男","女"],"取消",(index)=>{
          if(index < 2)this.setState({ gender: BUTTONS[index]});
        })
    }
  }

  componentWillMount(){
    this._panResponder = PanResponder.create({
      onStartShouldSetPanResponder: (evt, gestureState) => { this.hideSelector(); return false;},
      onStartShouldSetPanResponderCapture: (evt, gestureState) => {this.hideSelector(); return false;},
    });
    if(React.Platform.OS === 'android'){
        this.listener =  React.DeviceEventEmitter.addListener("Android_Date_Picker",
        (data) => {
          this.setState({age:new Date(new Number(data.time)).format('yyyy-MM-dd')})
        }
      );
    }
  }
  componentWillUnmount(){
    super.componentWillUnmount()
    if(React.Platform.OS === 'android'){
      if(this.listener)this.listener.remove()
    }
  }

  showDateSelector(){

    if (React.Platform.OS === 'android') {
          var date = new Date();
          var year = date.getFullYear();
          var month = date.getMonth() + 1;
          var day = date.getDate();
          React.NativeModules.DatePicker.showDatePicker(year,month,day);
          return;
      }

    LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
    this.setState({showDateSelector:true})
  }
  hideSelector(){
    LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
    this.setState({showDateSelector:false})
  }
  saveUserInfo(){
    do{
      if(!this.state.header){this.showWarning("未选择头像");break;}
      if(this.checkStringIsNull(this.state.name,"姓名不能为空"))break;
      if(this.checkStringIsNull(this.state.gender,"未选择性别"))break;
      if(this.checkStringIsNull(this.state.age,"未选择生日"))break;
      var MProfile = require('./core/Models').Profile;
      var profile = new MProfile();
      this.showLoadingDialog(true,'正在提交...');
      this.post("users/set_profile",profile,(data)=>{
        if(data.error){
          this.showLoadingDialog(false);
          this.showWarning(data.error);
          return;
        }
        profile.documentID = data.profileId;
        User.currentUser.profile = profile;
        User.currentUser.name = this.state.name;
        User.currentUser.gender = this.state.gender == "男" ? 0 : 1;
        User.currentUser.birthday = this.state.age;
        User.currentUser.headIcon = this.state.header;

        var saveUser = ()=>{
          User.currentUser.save(()=>{
              User.currentUser.getProfile((p)=>{
                p.setting.isSetProfile = true;
                p.save(()=>{
                  DatabaseManager.instance.currentDatabase.checkUploadFile();
                  this.showLoadingDialog(false);
                  this.push(Home);
                });
              })
          });
        }

        if(!User.currentUser.patient){
          var patient = new Patient();
          patient.documentID = "patient_"+User.currentUser.documentID;
          patient.user = User.currentUser.documentID;
          patient.name = User.currentUser.name;
          patient.birthday = this.state.age;
          patient.gender = User.currentUser.gender;
          patient.relationship = "我";
          patient.save(()=>{
            User.currentUser.patient = patient;
            saveUser();
          })
        }else {
          saveUser();
        }
      },Config.webShowForwardServerURL);
    }while (false);

  }
  _render() {
    return (
      <View style={[Styles.content]}>
        <View style={[Styles.content]} {...this._panResponder.panHandlers}>
        <View style={[Styles.center,{marginTop:Tools.fixWidth(25)}]}>
          <TouchableHighlight style={{borderRadius:Tools.fixWidth(10)}} underlayColor="gray" onPress={this.selectHead.bind(this)}>
            <ImageView style={[Styles.center,styles.selectHead]} imageKey={this.state.header?this.state.header.objectKey:null} source={require("./images/icon_select_head_profile.png")}>
              {
                (()=>{
                  if(!this.state.header){
                    return <Text style={{fontSize:Tools.fixWidth(11),color:Color.gray_border_color}}> 选择头像 </Text>
                  }
                })()
              }
            </ImageView>
          </TouchableHighlight>
        </View>
        <View style={styles.inputBg}>
        <TextInput style={[styles.input]} placeholder={"请输入姓名"}
          placeholderTextColor={Color.gray_border_color}
          value={this.state.name}
          textAlign={"center"}
          maxLength={15}
          onChangeText={(text) => this.setState({name: text})}
        />
      </View>
        <Button style={[styles.selectorButton]}
          title={this.state.gender?this.state.gender:"性别"}
          titleColor={Color.gray_border_color}
          fontSize={Tools.fixWidth(12)}
          onTouch={this.showGenderSelector.bind(this)}
        />
        <Button style={[styles.selectorButton]}
          title={this.state.age?this.state.age:"生日"}
          titleColor={Color.gray_border_color}
          fontSize={Tools.fixWidth(12)}
          onTouch={this.showDateSelector.bind(this)}
        />

        <Button style={[Styles.defaultBackground,styles.button]} title="确认" onTouch={this.saveUserInfo.bind(this)}/>
        </View>

          {
            (()=>{
              if(this.state.showDateSelector){
                return <DateSelector onDateChange={(date)=>{
                    this.setState({age:date.format("yyyy-MM-dd")})
                  }}
                  data={this.state.age?new Date(this.state.age):null}
                  onClose={(date)=>{
                    this.setState({age:date.format("yyyy-MM-dd")})
                    this.hideSelector();
                  }}
                />
              }
            })()
          }


      </View>
    );
  }
}


var styles = StyleSheet.create({
  inputBg:{
    borderWidth:1,
    height: Theme.input_height,
    borderColor: Color.gray_border_color,
    borderRadius:Theme.input_height / 2,
    marginLeft:Theme.input_marginleft,
    marginRight:Theme.input_marginleft,
    marginTop:Tools.fixWidth(25)
  },
  input : {
    height: Theme.input_height,
    borderRadius:Theme.input_height / 2,
    color:Color.gray_border_color,
    fontSize:Tools.fixWidth(12),
    backgroundColor:'transprent',
  },
  button:{
    marginTop:Tools.fixHeight(65/2),
    borderRadius:Tools.fixWidth(5),
    backgroundColor:'#62C0B4',
    height:Tools.fixHeight(35),
    marginLeft:Theme.input_marginleft,
    marginRight:Theme.input_marginleft
  },
  selectHead:{
    width:Tools.fixWidth(80),
    height:Tools.fixWidth(80),
    borderWidth:1,
    borderColor: Color.gray_border_color,
    borderRadius:Tools.fixWidth(10)
  },
  selectorButton:{
    borderWidth:1,
    height: Theme.input_height,
    borderColor: Color.gray_border_color,
    borderRadius:Theme.input_height / 2,
    backgroundColor:'transparent',
    marginTop:Tools.fixHeight(10),
    marginLeft:Theme.input_marginleft,
    marginRight:Theme.input_marginleft
  }
});

module.exports = Profile;
