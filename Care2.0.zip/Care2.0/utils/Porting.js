/**
 *
 * 图片管理工具
 * @author johnny 2015-12-21
 *
 */


'use strict';


let DESIGN_WIDTH = 320;  //设计尺寸宽dp
let DESIGN_HEIGTH = 568;  //设计尺寸高dp
var Screen = require('Dimensions').get('window');
let TARGET_WIDTH = Screen.width;
let TARGET_HEIGHT = Screen.height;
let scaleWidth =  TARGET_WIDTH / DESIGN_WIDTH;
let scaleHeight = TARGET_HEIGHT / DESIGN_HEIGTH;



var Porting = {
  w:function(w){
    return w * scaleWidth;
  },
  h:function(h){
    return h * scaleHeight;
  },
  f:function(f){
    return f * 1.0
  },
  screenWidth:function(){
    return TARGET_WIDTH
  },
  screenHeight:function(){
    return TARGET_HEIGHT
  }
}

module.exports = Porting
