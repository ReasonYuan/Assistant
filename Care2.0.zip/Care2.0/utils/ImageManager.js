
var REFRENCE_COUNT = "refrenceCount"
var IMAGE = "image"
var defaultIcon = require('.core/DefaultIcon')

/*
*图片管理
*/
class ImageManager {
  images:Object//格式{"objectKey":{refrenceCount:0,image:"base64Image",width:100}}
  constructor() {

  }

  //获取阿里云上的图片
  getImage(objectKey,width,cb){
    var cache = this.images[objectKey];
    if(cache && cache[IMAGE]){
      cb(cache[IMAGE]);
    }else{ //TODO

    }
  }
  //加引用
  retain(objectKey){
    var img = this.images[objectKey];
    var refrenceCount = img[REFRENCE_COUNT];
    if(img && refrenceCount){
      var ref = ++refrenceCount;
      img[REFRENCE_COUNT] = ref;
    }
  }
  //删除引用
  release(objectKey){
    var img = this.images[objectKey];
    var refrenceCount = img[REFRENCE_COUNT];
    if(img && refrenceCount){
      var ref = --refrenceCount;
      if(ref <=0 ){
        delete  this.images[objectKey]
      }else{
        img[REFRENCE_COUNT] = ref
      }
    }
  }
}


module.exports = new ImageManager()
