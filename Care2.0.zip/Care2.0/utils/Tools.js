'use strict';

var React = require('react-native');
var {
  AsyncStorage,
} = React;
let CouchbaseHelper = React.NativeModules.CouchbaseHelper;
let STATUS_BAR_HEIGHT = CouchbaseHelper.STATUSBARHEIGHT;

let DESIGN_WIDTH = 320;  //设计尺寸宽dp
let DESIGN_HEIGTH = 568;  //设计尺寸高dp
var Screen = require('Dimensions').get('window');
let TARGET_WIDTH = Screen.width;
let TARGET_HEIGHT = Screen.height;
let scaleWidth =  TARGET_WIDTH / DESIGN_WIDTH;
let scaleHeight = TARGET_HEIGHT / DESIGN_HEIGTH;
let NAVIGATION_BAR_HEIGHT = React.Platform.OS === 'ios'?64:44;

class Tools {
    static fixWidth(s){
      return s * scaleWidth;
    }
    static fixHeight(s){
      return s * scaleHeight;
    }

    static contentHeight(){
      if (React.Platform.OS === 'ios'){
        return TARGET_HEIGHT - NAVIGATION_BAR_HEIGHT;
      }else{
        return TARGET_HEIGHT - NAVIGATION_BAR_HEIGHT - STATUS_BAR_HEIGHT;
      }
    }

    static activityHeight(){
      if (React.Platform.OS === 'ios'){
        return TARGET_HEIGHT;
      }else{
        return TARGET_HEIGHT - STATUS_BAR_HEIGHT;
      }
    }

    //保存Storage数据
  //value  String 类型数据
  static saveStorageData(key,value){
    if(!key || !value)return
    try{
      AsyncStorage.setItem(key, value);
    }catch(error){
      console.log("--save Storage error-->key:"+key+" error:"+error);
    }
  }

  //得到保存的Storage数据
  static getStorageData(key,cb){
    if(!key || !cb)return
    try{
      AsyncStorage.getItem(key,(error,result)=>{
        if(!error || result){
          cb(result)
        }else{
          cb(null)
        }
      });
    }catch(error){
      cb(null)
    }
  }
}


module.exports = Tools;
