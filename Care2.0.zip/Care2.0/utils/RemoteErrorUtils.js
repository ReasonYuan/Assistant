var {RemoteLog, User} = require("../core/Models")
//var StackTrackTool = require("./StackTraceTool")
var {Styles} = require('../Styles');
var {Platform} = require('react-native');

function remotelog(error, isFatal){
  //console.log("e: " + e.toString());
  if(User.currentUser){
    var now = new Date();
    var datetime = now.format("yyyy-MM-dd hh:MM:ss");
    //var emsg = StackTrackTool.printStackTrace(e)
    var log = new RemoteLog()
    log.dateTime = datetime
    log.message = error instanceof Error ? error.message : error.toString()
    log.user = User.currentUser.documentID
    //TODO==JP==获得机型==
    log.device = ""
    log.platform = Platform.OS
    log.save()
  }
}

//Debug 模式
function setUpErrorHandler() {
  if (global.__fbDisableExceptionsManager) {
    return;
  }

  function handleError(e, isFatal) {
    try {
      remotelog(e, isFatal)
    } catch(ee) {
      console.log('Failed to print error: ', ee.message);
    }
    try {
      require('ExceptionsManager').handleException(e, isFatal);
    } catch(ee) {
      console.log('Failed to print error: ', ee.message);
    }
  }

  var ErrorUtils = require('ErrorUtils');
  ErrorUtils.setGlobalHandler(handleError);
}

module.exports = {setUpErrorHandler, remotelog}
