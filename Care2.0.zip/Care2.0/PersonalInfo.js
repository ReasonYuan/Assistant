
'use strict';

var React = require('react-native');
var {
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableHighlight,
  Navigator,
  ScrollView,
  Image,
  PanResponder,
  LayoutAnimation,
  ActionSheetIOS,
  Alert,
  ListView,
} = React;

var {User,Patient} = require('./core/Models')
var {Styles,Button,BaseComponent,Color,Tools,Theme,ImageView} = require('./Styles');
var {DatabaseManager} = require("./core/couchbase/Couchbase");
var ModifyPersonalInfo = require('./ModifyPersonalInfo');
var {DateSelector} = require('./Selector');
var UserZone = require('./core/team/UserZone');

class PersonalInfo extends BaseComponent {
  constructor(props){
    super(props)
    if(!this.props.patient) throw new Error("no patient");
    var config = {title:"个人信息",showBackIcon:true};
    var patient = this.props.patient;
    var ds = new ListView.DataSource({rowHasChanged: (r1, r2) => r1 !== r2});
    this.state = {dataSource:ds.cloneWithRows(patient.authorizer),navigatorBarConfig:config,name:patient.name,gender:patient.gender,birthday:patient.birthday,address:patient.address};
  }
  onLeftPress(){
    if(this.props.patient.birthday != this.state.birthday){
      this.props.patient.birthday = this.state.birthday;
      this.props.patient.save();
    }
    this.pop();
  }

  editName(){
    this.pushWidthComponent({component:<ModifyPersonalInfo maxLength={15} navigator={this.props.navigator} title={"更改姓名"} onRightPress={(text)=>{
      if(text && text.length > 15){
        Alert.alert("","姓名不能超过15个字",[{title:"确定"}])
        return;
      }
      this.props.patient.name = text;
      if(this.props.patient.relationship == "我"){
        User.currentUser.name = text;
        User.currentUser.save();
      }
      this.props.patient.save(()=>{
        this.setState({name:text});
      });
      this.pop();
    }} value={this.state.name}/>})
  }
  editGender(){
    var BUTTONS = [
      '男',
      '女',
      '取消',
    ];

    if(React.Platform.OS === 'ios'){
      ActionSheetIOS.showActionSheetWithOptions({
        options: BUTTONS,
        cancelButtonIndex: 2,
      },
      (buttonIndex) => {
        if(buttonIndex < 2){
          this.props.patient.gender = buttonIndex;
          this.props.patient.save(()=>{
            this.setState({ gender: buttonIndex});
          })
        }
      });
    }else if (React.Platform.OS === 'android') {
            React.NativeModules.ActionSheet.showActionSheet(["男","女"],"取消",(index)=>{
              if(index < 2){
                this.props.patient.gender = index;
                this.props.patient.save(()=>{
                  this.setState({ gender: index});
                })
              }
            });
    }


  }
  componentWillMount(){
    this._panResponder = PanResponder.create({
      onStartShouldSetPanResponder: (evt, gestureState) => { this.hideSelector(); return false;},
      onStartShouldSetPanResponderCapture: (evt, gestureState) => {this.hideSelector(); return false;},
    });
    if(React.Platform.OS === 'android'){
       this.listener =  React.DeviceEventEmitter.addListener("Android_Date_Picker",
        (data) => {
          this.setState({birthday:new Date(new Number(data.time)).format('yyyy-MM-dd')})
        }
      );
    }
  }
  componentWillUnmount(){
      super.componentWillUnmount()
      if(React.Platform.OS === 'android'){
        if(this.listener)this.listener.remove()
      }
    }

  editBirthday(){
    if (React.Platform.OS === 'android') {
      var date = new Date();
      var year = date.getFullYear();
      var month = date.getMonth() + 1;
      var day = date.getDate();
      React.NativeModules.DatePicker.showDatePicker(year,month,day);
      return;
    }
    LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
    this.setState({showDateSelector:true})
  }
  hideSelector(){
    LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
    this.setState({showDateSelector:false})
  }
  editAddress(){
    this.pushWidthComponent({component:<ModifyPersonalInfo navigator={this.props.navigator} title={"更改常驻地址"} onRightPress={(text)=>{
      this.props.patient.address = text;
      this.props.patient.save(()=>{
        this.setState({address:text});
      });
      this.pop();
    }} value={this.state.address}/>})
  }

  // <View style={styles.item}>
  //   <TouchableHighlight style={styles.item_content} underlayColor="transparent" onPress={this.editAddress.bind(this)}>
  //     <View style={styles.item_content}>
  //       <Text style={styles.text_title}>常驻地址</Text>
  //       <Text style={[styles.text_value,{maxWidth:Tools.fixWidth(200)}]} numberOfLines={1}>{this.state.address}</Text>
  //     </View>
  //   </TouchableHighlight>
  //   <View style={Styles.line}/>
  // </View>

  _render() {
    return (
      <View style={[Styles.content,{backgroundColor:'white'}]} >
        <View style={[Styles.content]} {...this._panResponder.panHandlers}>
        <View style={styles.item}>
          <TouchableHighlight style={styles.item_content} underlayColor="transparent" onPress={this.editName.bind(this)}>
            <View style={styles.item_content}>
              <Text style={styles.text_title}>姓名</Text>
              <Text style={styles.text_value}>{this.state.name}</Text>
            </View>
          </TouchableHighlight>
          <View style={Styles.line}/>
        </View>

        <View style={styles.item}>
          <TouchableHighlight style={styles.item_content} underlayColor="transparent" onPress={this.editGender.bind(this)}>
            <View style={styles.item_content}>
              <Text style={styles.text_title}>性别</Text>
              <Text style={styles.text_value}>{this.state.gender ? "女":"男"}</Text>
            </View>
          </TouchableHighlight>
          <View style={Styles.line}/>
        </View>

        <View style={styles.item}>
          <TouchableHighlight style={styles.item_content} underlayColor="transparent" onPress={this.editBirthday.bind(this)}>
            <View style={styles.item_content}>
              <Text style={styles.text_title}>生日</Text>
              <Text style={styles.text_value}>{this.state.birthday}</Text>
            </View>
          </TouchableHighlight>
          <View style={Styles.line}/>
        </View>


        <Text style={[styles.text_title,styles.text_authorize]}>健康档案授权给：</Text>

        <ListView
          contentContainerStyle={[styles.list]}
          automaticallyAdjustContentInsets={false}
          dataSource={this.state.dataSource}
          renderRow={this.renderlist.bind(this)}
        />
        <View style={Styles.line}/>
        </View>

          {
            (()=>{
              if(this.state.showDateSelector){
                return <DateSelector onDateChange={(date)=>{
                    this.setState({birthday:date.format("yyyy-MM-dd")})
                  }}
                  data={this.state.birthday?new Date(this.state.birthday):null}
                  onClose={(date)=>{
                    var text = date.format("yyyy-MM-dd");
                    this.props.patient.birthday = text;
                    this.props.patient.save(()=>{
                      this.setState({birthday:text})
                      this.hideSelector();
                    });
                  }}
                />
              }
            })()
          }

      </View>
    );
  }
  renderlist(rowData,s,i){
    return (
       <DoctorIcon onRightPress={()=>{
         this.post("patient/remove_authorize_user",{doctor_id:rowData,patient_id:this.props.patient.documentID},(data)=>{
           if(data.error){
             this.showWarning(data.error);
           }else {
             this.pop();
             this.props.patient.authorizer.remove(rowData);
             this.setState({dataSource:this.state.dataSource.cloneWithRows(this.props.patient.authorizer)});
           }
         })
       }} key={rowData} navigator={this.props.navigator} patient={this.props.patient} userId={rowData} />
    );
  }
}

class DoctorIcon extends React.Component {
  doctor:User;
  constructor(prop) {
    super(prop)
    this.state ={imagekey:null,userId:null};

  }
  componentWillReceiveProps(nextProps) {
    this.onPropSet(nextProps);
  }
  onPropSet(props){
    if(props.userId && this.state.userId != props.userId){
      DatabaseManager.instance.currentDatabase.getModel(props.userId,(u)=>{
        this.doctor = u;
        this.setState({imageKey:u.headIcon.objectKey,userId:props.userId})
      });
    }
  }
  componentDidMount(){
    this.onPropSet(this.props);
  }
  render(){
    return(
      <TouchableHighlight underlayColor={"transparent"} onPress={()=>{
        if(this.props.userId && this.props.patient){
          this.props.navigator.push({
            component:<UserZone {...this.props}
            name={this.doctor?this.doctor.name:""}
            objectKey={this.state.imageKey}
            userInfo = {this.doctor}
          />
          })
        }
      }}>
         <ImageView style={[styles.row]} imageKey={this.state.imageKey} />
      </TouchableHighlight>
    )
  }
}

let rowMargin = Tools.fixWidth(8);
let rowWidth = (require('Dimensions').get('window').width - Tools.fixWidth(8*6))/5
var styles = StyleSheet.create({
  list: {
    justifyContent: 'flex-start',
    flexDirection: 'row',
    flexWrap: 'wrap'
  },
  row: {
    justifyContent: 'center',
    width: rowWidth,
    height: rowWidth,
    backgroundColor: '#F6F6F6',
    alignItems: 'center',
    margin:rowMargin,
    borderRadius:rowWidth/5
  },
  item:{
    marginLeft:Tools.fixWidth(12),
    marginRight:Tools.fixWidth(12),
    height:Tools.fixWidth(50),
  },
  item_content:{
    flex:1,
    flexDirection:'row',
    alignItems:'center',
    justifyContent:'space-between',
  },
  text_title:{
    color:"#333333",
    fontSize:Tools.fixWidth(12),
  },
  text_value:{
    color:"#999999",
    fontSize:Tools.fixWidth(12),
  },
  text_authorize:{
    marginLeft:Tools.fixWidth(12),
    marginTop:Tools.fixWidth(18),
  }
});

module.exports = PersonalInfo;
