'use strict';
var React = require('react-native');
var {Button,Config,Styles,Tools,Color} = require("./Styles")
var Dimensions = require('Dimensions');
var TimerMixin = require('react-timer-mixin');
var reactMixin = require('react-mixin');
var {
  TouchableHighlight,
  Text,
  View,
  StyleSheet,
  Image,
  Animated,
} = React;

//Dialog
class Dialog extends React.Component {
  width:Number;
  constructor(props) {
    super(props)
    this.width = Dimensions.get('window').width * 4 / 5;
    this.state = {scale:new Animated.Value(1),show:this.props.show}
  }
  componentWillReceiveProps(nextProps){
    if(this.state.show == nextProps.show)return;
    var toScale = 1;
    if(nextProps.show){
      this.setState({show:nextProps.show});
      this.state.scale.setValue(0);
    }else{
      this.state.scale.setValue(1);
      toScale = 0;
    }
    if(toScale == 1){
      Animated.spring(
        this.state.scale,
        {
          toValue: toScale,
        }
      ).start((c)=>{
        if(toScale == 0)this.setState({show:nextProps.show});
      })
    }else{
      Animated.timing(
        this.state.scale,
        {
          toValue: toScale,
          duration:40,
        },
      ).start((c)=>{
        if(toScale == 0)this.setState({show:nextProps.show});
        if(this.props.dismissCallback)this.props.dismissCallback();
      })
    }

  }
  _render(){
    return (
      <View></View>
    )
  }
  render(){
    if(!this.state.show){
      return <View/>;
    }
    return(
      <View style={[Styles.overlay,Styles.center]}>
        <Animated.View style={{backgroundColor:'white',width:this.width,borderWidth:1,borderRadius:20,transform: [{scale: this.state.scale}]}}>
          <View style={{margin:20}}>
          {
            this._render()
          }
        </View>
        </Animated.View>
      </View>
    )
  }
}

Dialog.propTypes = {
  message:React.PropTypes.string,
  show:React.PropTypes.bool,   //是否显示
}

Dialog.defaultProps = {
  message:"",
  show:false,
}
reactMixin(Dialog.prototype, TimerMixin);

class MessageDialog extends Dialog {
  constructor(props) {
    super(props)
  }
  _render(){
    return (
      <View style={Styles.center}>
        <Text sytle={styles.messageText}>
          {
            this.props.message
          }
        </Text>
      </View>
    )
  }
}

class PayLoadingDialog extends Dialog {
  constructor(props) {
    super(props);
    this.index = 1;
  }
  getPointViews(){
    var views = [];
    var index = (this.index || 0) % 5;
    var width = Tools.fixWidth(10);
    for (var i = 0; i < 4; i++) {
      var color = i < index ? Color.default_color:Color.gray_border_color;
      views.push(<View style={{width:Tools.fixWidth(8),height:Tools.fixWidth(8),borderRadius:Tools.fixWidth(4),margin:Tools.fixWidth(2),backgroundColor:color}}/>)
    }
    return views;
  }
  componentWillUnmount(){
    if(this.interval)this.clearInterval(this.interval);
    delete this.interval;
  }
  componentWillMount(){
    this.interval = this.setInterval(()=>{
      this.index ++;
      this.setState({index:this.index});
    },1000);
  }
  render(){
    if(!this.state.show){
      return <View/>;
    }
    return(
      <View style={[Styles.overlay,Styles.center]}>
        <Animated.View style={{backgroundColor:'transform',width:this.width,transform: [{scale: this.state.scale}]}}>
          {
            this._render()
          }
        </Animated.View>
      </View>
    )
  }
  _render(){
    return (
      <View>
      <View style={styles.payLoading}>
        <Image style={styles.payImage} source={require("./images/icon_pay.png")}/>
        <Text style={styles.payText}>正在支付中..</Text>
      </View>
      <View style={{flexDirection:'row',marginTop:Tools.fixWidth(4),justifyContent:"center"}}>
      {
        this.getPointViews()
      }
      </View>

      </View>
    )
  }
}

var styles = StyleSheet.create({
  messageText:{
    fontSize:20,
  },
  payLoading:{
    height:Tools.fixHeight(100),
    backgroundColor:'white',
    borderWidth:0.5,
    borderColor:Color.default_color,
    borderRadius:Tools.fixWidth(8),
    alignItems:'center',
    justifyContent:'center'
  },
  payImage:{
    width:Tools.fixWidth(36),
    height:Tools.fixWidth(36),
  },
  payText:{
    fontSize:Tools.fixWidth(13),
    marginTop:Tools.fixWidth(10),
  }
});


module.exports = {
  "Dialog":Dialog,
  "MessageDialog":MessageDialog,
  "PayLoadingDialog":PayLoadingDialog,
};
