package com.yiyihealth.hitales.library.React;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.Camera;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;

import com.facebook.react.uimanager.SimpleViewManager;
import com.facebook.react.uimanager.ThemedReactContext;

import java.util.List;

/**
 * Created by liaomin on 15/11/9.
 */
public class ReactCamera extends SimpleViewManager<ReactCamera.CameraViewLayout> {

    private ThemedReactContext context;

    static CameraView cameraView;
    static CameraViewLayout cameraViewLayout;

    @Override
    public String getName() {
        return "CameraScannerView";
    }

    @Override
    protected CameraViewLayout createViewInstance(ThemedReactContext reactContext) {
        CameraView cameraView = new CameraView(reactContext);
        CameraViewLayout cameraViewLayout = new CameraViewLayout(reactContext);
        context = reactContext;
        this.cameraView = cameraView;
        this.cameraViewLayout = cameraViewLayout;
        cameraViewLayout.addCameraView(cameraView);
        return cameraViewLayout;
    }

    class CameraViewLayout extends FrameLayout {

        ImageView imageView;
        View cameraView;

        public CameraViewLayout(Context context) {
            super(context);
            imageView = new ImageView(context);
            imageView.setScaleType(ImageView.ScaleType.FIT_XY);
        }

        public CameraViewLayout(Context context, AttributeSet attrs) {
            super(context, attrs);
        }

        public CameraViewLayout(Context context, AttributeSet attrs, int defStyleAttr) {
            super(context, attrs, defStyleAttr);
        }

        public void addCameraView(View view) {
            cameraView = view;
            LayoutParams params = new LayoutParams(LayoutParams.MATCH_PARENT,LayoutParams.MATCH_PARENT);
            this.addView(view,params);
            params = new LayoutParams(LayoutParams.MATCH_PARENT,LayoutParams.MATCH_PARENT);
            this.addView(imageView,params);
            imageView.setVisibility(INVISIBLE);
        }

        public void showTakePhoto(String path) {
            imageView.setVisibility(VISIBLE);
            Bitmap realImage =  BitmapRotaTools.rotateBitmapByDegree(BitmapManager.decodeBitmap2ScaleForTakePic(path, this.getWidth()), BitmapRotaTools.getBitmapDegree(path));
            imageView.setImageBitmap(realImage);
        }

        public void hiddenTakePhoto() {
            imageView.setVisibility(INVISIBLE);
        }
    }

    class CameraView extends SurfaceView {

        private SurfaceHolder holder = null;

        Camera camera;

        public CameraView(Context context) {
            super(context);
            holder = this.getHolder();
            this.setOnTouchListener(new OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    if(camera != null){
                        try{
                            camera.autoFocus(new Camera.AutoFocusCallback() {
                                @Override
                                public void onAutoFocus(boolean success, Camera camera) {

                                }
                            });
                        }catch (Exception e){
                            e.printStackTrace();
                        }
                    }

                    return false;
                }
            });
            holder.addCallback(new SurfaceHolder.Callback() {
                @Override
                public void surfaceCreated(SurfaceHolder holder) {
                    camera = Camera.open();
                    try {
                        //设置camera预览的角度，因为默认图片是倾斜90度的
                        camera.setDisplayOrientation(90);
                        //设置holder主要是用于surfaceView的图片的实时预览，以及获取图片等功能，可以理解为控制camera的操作..
                        camera.setPreviewDisplay(holder);
                    } catch (Exception e) {
                        camera.release();
                        camera = null;
                        e.printStackTrace();
                    }
                }

                @Override
                public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {

                    Camera.Parameters parameters = camera.getParameters();
                    //以下注释掉的是设置预览时的图像以及拍照的一些参数
                    parameters.setPictureFormat(PixelFormat.JPEG);
                    if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) {
                        parameters.set("orientation", "portrait");
                        parameters.set("rotation", 90);
                    }
                    if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE) {
                        parameters.set("orientation", "landscape");
                        parameters.set("rotation", 90);
                    }
                    List<Camera.Size> sizes = parameters.getSupportedPictureSizes();
                    Camera.Size maxSize = sizes.get(0);
                    for (int i = 0; i < sizes.size(); i++) {
                        Camera.Size tmp = sizes.get(i);
                        if (tmp.width > maxSize.width) {
                            maxSize = tmp;
                        }
                    }
                    parameters.setPictureSize(maxSize.width, maxSize.height);
//                     parameters.setPreviewSize(maxSize.width,
//                             maxSize.height);
                    parameters.setFocusMode(Camera.Parameters.FOCUS_MODE_AUTO);
//                     parameters.setPictureSize(width, height);
                    camera.setParameters(parameters);
                    camera.startPreview();

                }

                @Override
                public void surfaceDestroyed(SurfaceHolder holder) {
                    camera.stopPreview();
                    camera.release();
                    camera = null;
                }
            });

        }
    }
}
