package com.yiyihealth.hitales.library.React;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.hardware.Camera;
import android.net.Uri;
import android.os.Environment;
import android.util.Log;

import com.facebook.react.bridge.Callback;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.facebook.react.bridge.ReadableMap;
import com.facebook.react.bridge.WritableMap;
import com.facebook.react.bridge.WritableNativeMap;
import com.facebook.react.modules.core.DeviceEventManagerModule;
import com.yiyihealth.hitales.library.BaseActivity;

import java.io.File;
import java.util.UUID;

/**
 * Created by liaomin on 15/11/9.
 */
public class CameraHelper extends ReactContextBaseJavaModule {

    private static boolean IS_TAKE_PICTURE = false;

    private static Bitmap mBitmap;
    public CameraHelper(ReactApplicationContext reactContext) {
        super(reactContext);
    }

    public String tmpPath = "";
    public String imageName = "";
    public String tmpFullPath = "";
    public String reUsePhotoPath = Environment.getExternalStorageDirectory() + "/HiTales/海苔健康/";

    @Override
    public String getName() {
        return "CameraScannerViewManager";
    }

    @ReactMethod
    public void takePhoto() {

        imageName = UUID.randomUUID() + ".jpeg";
        tmpPath = FileHelper.mDocumentDir + "tmpImage/";
        tmpFullPath = tmpPath + imageName;

        if(ReactCamera.cameraView != null && !IS_TAKE_PICTURE){
            IS_TAKE_PICTURE = true;
            ReactCamera.cameraView.camera.takePicture(null, null, new Camera.PictureCallback() {
                @Override
                public void onPictureTaken(byte[] data, Camera camera) {
//                    String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
//                    String output_file_name = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM) + File.separator + timeStamp + ".jpeg";

                    boolean isSave = FileManager.saveFile(data, tmpPath, imageName);
                    FileManager.saveFile(data, reUsePhotoPath, imageName);
                    AndroidSelectPhoto.scanFile(Environment.getExternalStorageDirectory() + "/HiTales/海苔健康/", getReactApplicationContext());
//                    Bitmap bitmap = null;
//                    try {
//                        FileInputStream fis = new FileInputStream(tmpPath+imageName);
//                        bitmap  = BitmapFactory.decodeStream(fis);
//                    } catch (FileNotFoundException e) {
//                        e.printStackTrace();
//                    }


                    BaseActivity.instance.sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.parse("file://" + new File(reUsePhotoPath,imageName).getAbsolutePath())));
                    BaseActivity.instance.sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, Uri.parse("file://" + new File(tmpPath,imageName).getAbsolutePath())));


//                    try {
//
//
//                        // Save the screenshot to the MediaStore
//                        ContentValues values = new ContentValues();
//                        ContentResolver resolver = MainActivity.instance.getContentResolver();
//                        values.put(MediaStore.Images.ImageColumns.DATA, tmpPath);
//                        values.put(MediaStore.Images.ImageColumns.TITLE, imageName);
//                        values.put(MediaStore.Images.ImageColumns.DISPLAY_NAME, imageName);
//                        values.put(MediaStore.Images.ImageColumns.DATE_TAKEN, System.currentTimeMillis());
////            values.put(MediaStore.Images.ImageColumns.DATE_ADDED, dateSeconds);
////            values.put(MediaStore.Images.ImageColumns.DATE_MODIFIED, dateSeconds);
//                        values.put(MediaStore.Images.ImageColumns.MIME_TYPE, "image/jpg");
//                        values.put(MediaStore.Images.ImageColumns.WIDTH, bitmap.getWidth());
//                        values.put(MediaStore.Images.ImageColumns.HEIGHT, bitmap.getHeight());
//                        Uri uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
//
//                        OutputStream out = resolver.openOutputStream(uri);
//                        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, out);
//                        out.flush();
//                        out.close();
//
//                        // update file size in the database
//                        values.clear();
//                        values.put(MediaStore.Images.ImageColumns.SIZE, new File(tmpPath + imageName).length());
//                        resolver.update(uri, values, null, null);
//
//
//                    } catch (Exception e) {
//
//                    }




                    Log.i("pic full tmp path", tmpFullPath);
                    Log.i("pic info data size", String.valueOf(data.length));
                    Log.i("pic is save", String.valueOf(isSave));
                    File pictureFile = new File(tmpFullPath);

//                    if (pictureFile.exists()) {
//                        pictureFile.delete();
//                    }

                    try {
//                        FileOutputStream fos = new FileOutputStream(pictureFile);
                        Bitmap realImage = BitmapManager.decodeBitmap2Scale(tmpFullPath,3);
//
//                        ExifInterface exif = new ExifInterface(pictureFile.toString());
//                        Log.d("EXIF value", exif.getAttribute(ExifInterface.TAG_ORIENTATION));
//                        if (exif.getAttribute(ExifInterface.TAG_ORIENTATION).equalsIgnoreCase("6")) {
//                            realImage = rotate(realImage, 90);
//                        } else if (exif.getAttribute(ExifInterface.TAG_ORIENTATION).equalsIgnoreCase("8")) {
//                            realImage = rotate(realImage, 270);
//                        } else if (exif.getAttribute(ExifInterface.TAG_ORIENTATION).equalsIgnoreCase("3")) {
//                            realImage = rotate(realImage, 180);
//                        } else if (exif.getAttribute(ExifInterface.TAG_ORIENTATION).equalsIgnoreCase("0")) {
//                            realImage = rotate(realImage, 90);
//                        }


                        realImage =  BitmapRotaTools.rotateBitmapByDegree(realImage, BitmapRotaTools.getBitmapDegree(tmpFullPath));
//                        fos.close();
                        mBitmap = realImage;

                        ReactCamera.cameraViewLayout.showTakePhoto(tmpFullPath);

                        getReactApplicationContext().getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter.class)
                                .emit("CameraScannerView_onPerview", 1);

                    } finally {
                        getReactApplicationContext().runOnUiQueueThread(new Runnable() {
                            @Override
                            public void run() {
                                ReactCamera.cameraView.camera.stopPreview();
                            }
                        });
//                        ReactCamera.cameraView.camera.startPreview();

                        IS_TAKE_PICTURE = false;
                    }

                }
            });

        }
    }


    @ReactMethod
    public void usePerviewPhoto(final ReadableMap args,final Callback callback) {
        getReactApplicationContext().runOnUiQueueThread(new Runnable() {
            @Override
            public void run() {
                ReactCamera.cameraViewLayout.hiddenTakePhoto();
                final WritableMap response = new WritableNativeMap();
//                mBitmap = BitmapManager.decodeBitmap2Scale(tmpFullPath, 1);
                mBitmap =  BitmapRotaTools.rotateBitmapByDegree(BitmapManager.decodeBitmap2Scale(tmpFullPath, 1), BitmapRotaTools.getBitmapDegree(tmpFullPath));
                if (mBitmap != null && args.getBoolean("use") && args.hasKey("path")) {
                    String path = args.getString("path");
                    String imageName = UUID.randomUUID() + ".jpg";
                    String fullPath = FileHelper.mDocumentDir + path + "/" + imageName;
                    response.putInt("width", mBitmap.getWidth());
                    response.putInt("height", mBitmap.getHeight());
                    response.putString("fileName", imageName);
                    response.putString("uri", fullPath);
                    BitmapManager.saveToLocal(mBitmap, FileHelper.mDocumentDir + path, imageName, true);

                }
                getReactApplicationContext().runOnNativeModulesQueueThread(new Runnable() {
                    @Override
                    public void run() {
                        callback.invoke(response);
                    }
                });
                if (mBitmap != null && !mBitmap.isRecycled()) mBitmap.recycle();
                mBitmap = null;
                File file = new File(tmpFullPath);
                FileManager.deleteFile(file, false);
                ReactCamera.cameraView.camera.startPreview();
            }
        });
    }

//    @ReactMethod
//    public void takePicture(final Callback callback) {
//        if(ReactCamera.cameraView != null && !IS_TAKE_PICTURE){
//            IS_TAKE_PICTURE = true;
//            ReactCamera.cameraView.camera.takePicture(null, null, new Camera.PictureCallback() {
//                @Override
//                public void onPictureTaken(byte[] data, Camera camera) {
//                    String timeStamp = new SimpleDateFormat( "yyyyMMdd_HHmmss").format( new Date( ));
//                    String output_file_name = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM) + File.separator + timeStamp + ".jpeg";
//
//                    File pictureFile = new File(output_file_name);
//                    if (pictureFile.exists()) {
//                        pictureFile.delete();
//                    }
//
//                    try {
//                        FileOutputStream fos = new FileOutputStream(pictureFile);
//                        Bitmap realImage = BitmapFactory.decodeByteArray(data, 0, data.length);
//                        ExifInterface exif=new ExifInterface(pictureFile.toString());
//                        Log.d("EXIF value", exif.getAttribute(ExifInterface.TAG_ORIENTATION));
//                        if(exif.getAttribute(ExifInterface.TAG_ORIENTATION).equalsIgnoreCase("6")){
//                            realImage= rotate(realImage, 90);
//                        } else if(exif.getAttribute(ExifInterface.TAG_ORIENTATION).equalsIgnoreCase("8")){
//                            realImage= rotate(realImage, 270);
//                        } else if(exif.getAttribute(ExifInterface.TAG_ORIENTATION).equalsIgnoreCase("3")){
//                            realImage= rotate(realImage, 180);
//                        } else if(exif.getAttribute(ExifInterface.TAG_ORIENTATION).equalsIgnoreCase("0")){
//                            realImage= rotate(realImage, 90);
//                        }
//                        fos.close();
//                        ByteArrayOutputStream baos = new ByteArrayOutputStream();
//                        realImage.compress(Bitmap.CompressFormat.PNG, 100, baos);
//                        final String base64Data = Base64.encodeToString(baos.toByteArray(), Base64.DEFAULT);
//                        getReactApplicationContext().runOnNativeModulesQueueThread(new Runnable() {
//                            @Override
//                            public void run() {
//                                callback.invoke(base64Data);
//                            }
//                        });
//                    } catch (FileNotFoundException e) {
//                        Log.d("Info", "File not found: " + e.getMessage());
//                    } catch (IOException e) {
//                        Log.d("TAG", "Error accessing file: " + e.getMessage());
//                    } finally {
//                        ReactCamera.cameraView.camera.startPreview();
//                        IS_TAKE_PICTURE = false;
//                    }
//
//                }
//            });
//        }
//    }
    public static Bitmap rotate(Bitmap bitmap, int degree) {
        int w = bitmap.getWidth();
        int h = bitmap.getHeight();
        Matrix mtx = new Matrix();
        mtx.postRotate(degree);
        return Bitmap.createBitmap(bitmap, 0, 0, w, h, mtx, true);
    }
}