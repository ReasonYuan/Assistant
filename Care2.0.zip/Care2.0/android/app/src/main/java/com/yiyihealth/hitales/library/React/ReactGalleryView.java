package com.yiyihealth.hitales.library.React;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.annotation.Nullable;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Gallery;
import android.widget.ImageView;

import com.facebook.react.bridge.Arguments;
import com.facebook.react.bridge.Callback;
import com.facebook.react.bridge.ReactContext;
import com.facebook.react.bridge.ReadableArray;
import com.facebook.react.bridge.WritableMap;
import com.facebook.react.modules.core.DeviceEventManagerModule;
import com.facebook.react.uimanager.ReactProp;
import com.facebook.react.uimanager.SimpleViewManager;
import com.facebook.react.uimanager.ThemedReactContext;
import com.yiyihealth.hitales.library.BaseActivity;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;

/**
 * Created by liaomin on 15/11/11.
 */
public class ReactGalleryView extends SimpleViewManager<Gallery> {


    private ThemedReactContext reactContext;
    private int index;

    static Gallery scrollGalleryView;

    @Override
    public String getName() {
        return "GalleryView";
    }

    @Override
    protected Gallery createViewInstance(ThemedReactContext reactContext) {
        Gallery scrollGalleryView =  new Gallery(reactContext);
        this.reactContext = reactContext;
        this.scrollGalleryView = scrollGalleryView;
        return scrollGalleryView;
    }

    static ImageAdapter adapter;
    static  ArrayList<Bitmap> images;

    @ReactProp(name = "dataSource")
    public void setDataSource(final  Gallery view, final ReadableArray src) {
        BaseActivity.instance.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                images = new ArrayList<Bitmap>();
                try {
                    String json = src.toString();
                    JSONArray array = new JSONArray(json);
                    for (int i = 0; i < array.length(); i++) {
                        JSONObject tmp = array.optJSONObject(i);
                        System.out.println("tmp ------------------" + i + tmp.toString());
//                        Database database =  MainActivity.mDBManager.getDatabase(tmp.getString("dbName"));
//                        Document document = database.getDocument(tmp.getString("documentID"));
//                        Attachment attachment = document.getCurrentRevision().getAttachment(tmp.getString("attachmentID"));
//                        InputStream inStream = attachment.getContent();
//                        ByteArrayOutputStream swapStream = new ByteArrayOutputStream();
//                        byte[] buff = new byte[100]; //buff用于存放循环读取的临时数据
//                        int rc = 0;
//                        while ((rc = inStream.read(buff, 0, 100)) > 0) {
//                            swapStream.write(buff, 0, rc);
//                        }
//                        byte[] in_b = swapStream.toByteArray(); //in_b为转换之后的结果
//                        byte[] imageBytes = Base64.decode(in_b,Base64.DEFAULT);
//                        Bitmap bitmap = BitmapFactory.decodeByteArray(imageBytes,0,imageBytes.length);
//                        bitmap = BitmapManager.scaleBitmap(bitmap,150);
//                        swapStream.close();
//                        images.add(bitmap);
                        final String userId = tmp.optString("userId");
                        final String imageKey = tmp.optString("key");
                        final boolean fromAMD = tmp.optBoolean("fromAMD");
                        String path = FileHelper.getLocalImagePath(userId, imageKey);
                        if (path != null) {
//                            int scale = calculateInSampleSize(path);
                            Bitmap bitmap = BitmapManager.decodeBitmap2Scale(path, 600);
                            images.add(bitmap);
                        } else {
                            images.add(null);
                            final int index = i;
                            ImageHelper.instance.getImage(userId, imageKey,fromAMD, new Callback() {
                                @Override
                                public void invoke(Object... args) {
                                    String path = FileHelper.getLocalImagePath(userId, imageKey);
                                    if (path != null) {
//                                        int scale = calculateInSampleSize(path);
                                        Bitmap bitmap = BitmapManager.decodeBitmap2Scale(path, 600);
                                        images.remove(index);
                                        images.add(index, bitmap);
//                                        ImageAdapter adapter = new ImageAdapter(MainActivity.instance,images);
//                                        view.setAdapter(adapter);
                                        ((BaseAdapter) view.getAdapter()).notifyDataSetChanged();
                                    }
                                }
                            });
                        }
                    }
                    adapter = new ImageAdapter(BaseActivity.instance, images);
                    view.setAdapter(adapter);
                    view.setSelection(index);
                    view.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                        @Override
                        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                            WritableMap params = Arguments.createMap();
                            params.putInt("index",position);
                            sendEvent(reactContext, "GalleryViewManager_onIndexChange", params);
                        }

                        @Override
                        public void onNothingSelected(AdapterView<?> parent) {

                        }
                    });
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });


    }


    @ReactProp(name = "index")
    public void currentIndex(Gallery view,int src){
        index = src;

    }

    private void sendEvent(ReactContext reactContext,
                           String eventName,
                           @Nullable WritableMap params) {
        reactContext
                .getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter.class)
                .emit(eventName, params);
    }

    class  ImageAdapter extends BaseAdapter{
        private Context mContext;
        private ArrayList<Bitmap> images;
        private int width;
        public ImageAdapter(Context c,ArrayList<Bitmap> images) {
            mContext = c;
            WindowManager wm = (WindowManager) c.getSystemService(Context.WINDOW_SERVICE);
            int screenWidth = wm.getDefaultDisplay().getWidth();
            width = screenWidth;
            this.images = images;
        }
        @Override
        public int getCount() {
            return images.size();
        }

        @Override
        public Object getItem(int position) {
            return position;
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        public void removAt(int index){
            if (this.images.size() <= 0 )return;
            images.remove(index);
            this.notifyDataSetChanged();
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            ImageView i = new ImageView (mContext);
            Bitmap bitmap = images.get(position);
            i.setImageBitmap(bitmap);
            i.setScaleType(ImageView.ScaleType.FIT_CENTER);
            i.setLayoutParams(new Gallery.LayoutParams(width, Gallery.LayoutParams.MATCH_PARENT));
            return i;
        }

    };

    private static int calculateInSampleSize(String path) {

        int reqWidth = BaseActivity.SCREEN_WIDTH*2/3;
        int reqHeight = BaseActivity.SCREEN_HEIGHT*2/3;
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        try {
            BitmapFactory.decodeStream(new FileInputStream(path), null, options);
            // Raw height and width of image
            final int height = options.outHeight;
            final int width = options.outWidth;
            int inSampleSize = 1;

            if (height > reqHeight || width > reqWidth) {

                final int halfHeight = height / 2;
                final int halfWidth = width / 2;

                // Calculate the largest inSampleSize value that is a power of 2 and keeps both
                // height and width larger than the requested height and width.
                while ((halfHeight / inSampleSize) > reqHeight
                        && (halfWidth / inSampleSize) > reqWidth) {
                    inSampleSize *= 2;
                }
            }

            return inSampleSize;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        return 1;
    }
}

