package com.yiyihealth.hitales.library.React;

import android.content.Context;
import android.graphics.Paint;
import android.text.Spannable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.facebook.csslayout.CSSConstants;
import com.facebook.csslayout.CSSNode;
import com.facebook.csslayout.MeasureOutput;
import com.facebook.csslayout.Spacing;
import com.facebook.react.uimanager.BaseViewManager;
import com.facebook.react.uimanager.PixelUtil;
import com.facebook.react.uimanager.ReactProp;
import com.facebook.react.uimanager.ThemedReactContext;
import com.facebook.react.uimanager.ViewProps;
import com.facebook.react.views.text.ReactTextShadowNode;
import com.facebook.react.views.text.ReactTextUpdate;
import com.yiyihealth.hitales.library.BaseActivity;

import javax.annotation.Nullable;


/**
 * Created by liaomin on 16/1/21.
 */
public class RNChatTextViewManager extends BaseViewManager<RNChatTextViewManager.RNText,RNChatTextViewManager.RNTextCSSNode> implements CSSNode.MeasureFunction{

    public static final int TEXT_MARGIN = 6;

    public static void SetTextAttribute(TextView textView){
        textView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        textView.setBackgroundColor(0x0);
        textView.setPadding(0,0,0,0);
    }

    class RNTextCSSNode extends ReactTextShadowNode {

        private @Nullable
        Spannable mSpannableText;

        float maxWidth = 0;

        float fontSize = 0;

        public RNTextCSSNode(boolean isVirtual) {
            super(isVirtual);
            fontSize = 14;
        }

        @Override
        public void onBeforeLayout() {
            mSpannableText = fromTextCSSNode(this);
            super.onBeforeLayout();
        }

        @ReactProp(name = "maxWidth", defaultFloat = CSSConstants.UNDEFINED)
        public void setMaxWidth(float maxWidth) {
            this.maxWidth = CSSConstants.isUndefined(maxWidth) ? 0 : PixelUtil.toPixelFromDIP(maxWidth);
        }

        @ReactProp(name = ViewProps.FONT_SIZE, defaultFloat = UNSET)
        public void setFontSize(float fontSize) {
            if (fontSize != UNSET) {
                this.fontSize = fontSize;
            }
        }

    }


    class RNText extends  LinearLayout{

        TextView mText;

        public RNText(Context context) {
            super(context);
            setOrientation(LinearLayout.HORIZONTAL);
            mText = new TextView(context);
            RNChatTextViewManager.SetTextAttribute(mText);
            LayoutParams params = new LayoutParams(LayoutParams.MATCH_PARENT,LayoutParams.WRAP_CONTENT);
            mText.setLayoutParams(params);
            this.addView(mText);
        }

        public void setalignLeft(boolean alignLeft){
            if(alignLeft){
                this.setGravity(Gravity.LEFT);
            }else{
                this.setGravity(Gravity.RIGHT);
            }
        }

        public void setText(String text){
            mText.setText(text);
        }


    }

    /**
     * Should measure the given node and put the result in the given MeasureOutput.
     * <p/>
     * NB: measure is NOT guaranteed to be threadsafe/re-entrant safe!
     *
     * @param node
     * @param width
     * @param measureOutput
     */
    @Override
    public void measure(CSSNode node, float width, MeasureOutput measureOutput) {
        float measureWidth = width;
        RNTextCSSNode cssNode = (RNTextCSSNode)node;
        if(Float.isNaN(width) || width <=0) measureWidth = cssNode.maxWidth > 0?cssNode.maxWidth: BaseActivity.SCREEN_WIDTH;

        if(cssNode.mSpannableText != null){
            String text = cssNode.mSpannableText.toString();
            int margin  = (int)cssNode.getMargin().get(Spacing.ALL);
            TextView mMeasureText = new TextView(BaseActivity.instance);
            RNChatTextViewManager.SetTextAttribute(mMeasureText);
            mMeasureText.setTextSize(TypedValue.COMPLEX_UNIT_SP, cssNode.fontSize);
            mMeasureText.setText(text);
            mMeasureText.setPadding(margin,margin,margin,margin);
            mMeasureText.measure(View.MeasureSpec.makeMeasureSpec((int)measureWidth - margin * 2, View.MeasureSpec.AT_MOST), View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
            int w = mMeasureText.getMeasuredWidth();
            int h = mMeasureText.getMeasuredHeight();
            measureOutput.width = w;
            measureOutput.height = h;

        }else{
            measureOutput.width = 0;
            measureOutput.height = 0;
        }
    }

    @ReactProp(name = ViewProps.FONT_SIZE, defaultFloat = ReactTextShadowNode.UNSET)
     public void setFontSize(RNText view, float fontSize) {
        if (fontSize != ReactTextShadowNode.UNSET) {
            view.mText.setTextSize(TypedValue.COMPLEX_UNIT_SP, fontSize);
        }
    }

    @ReactProp(name = "textDecorationLine")
    public void setTextDecorationLine(RNText view, String decorationline) {
        if (decorationline.equals("underline")) {
            view.mText.getPaint().setFlags(Paint.UNDERLINE_TEXT_FLAG);
        }
    }

    @ReactProp(name = ViewProps.MARGIN, defaultFloat = ReactTextShadowNode.UNSET)
    public void setMargin(RNText view, float margin) {
        if (margin != ReactTextShadowNode.UNSET) {
            int padding = (int)PixelUtil.toPixelFromDIP(margin);
            view.mText.setPadding(padding,padding,padding,padding);
        }
    }

    @ReactProp(name = ViewProps.COLOR)
    public void setColor(RNText view, Integer color) {
        view.mText.setTextColor(color);
    }

    @Override
    public void updateExtraData(RNText root, Object extraData) {
        ReactTextUpdate update = (ReactTextUpdate) extraData;
        root.setText(update.getText().toString());
    }

    @Override
    public String getName() {
        return "RNChatTextViewManager";
    }

    @Override
    protected RNText createViewInstance(ThemedReactContext reactContext) {
        return new RNText(reactContext);
    }

    @Override
    public RNTextCSSNode createShadowNodeInstance() {
        RNTextCSSNode shadowNode = new RNTextCSSNode(false);
        shadowNode.setMeasureFunction(this);
        return shadowNode;
    }

    @Override
    public Class<RNTextCSSNode> getShadowNodeClass() {
        return RNTextCSSNode.class;
    }
}
