package com.yiyihealth.hitales.patient.wxapi;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;


import com.tencent.mm.sdk.constants.ConstantsAPI;
import com.tencent.mm.sdk.modelbase.BaseReq;
import com.tencent.mm.sdk.modelbase.BaseResp;
import com.tencent.mm.sdk.openapi.IWXAPI;
import com.tencent.mm.sdk.openapi.IWXAPIEventHandler;
import com.tencent.mm.sdk.openapi.WXAPIFactory;
import com.yiyihealth.hitales.library.BaseActivity;
import com.yiyihealth.hitales.library.WXpay.WxPay;

public class WXPayEntryActivity extends Activity implements IWXAPIEventHandler{
	
    private IWXAPI api;

	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
    	api = WXAPIFactory.createWXAPI(this, BaseActivity.APP_ID);
        api.handleIntent(getIntent(), this);
    }

	@Override
	protected void onNewIntent(Intent intent) {
		super.onNewIntent(intent);
		setIntent(intent);
        api.handleIntent(intent, this);
	}

	@Override
	public void onReq(BaseReq req) {
	}

	@Override
	public void onResp(BaseResp resp) {

		if (resp.getType() == ConstantsAPI.COMMAND_PAY_BY_WX) {
			String msg = "";
			String state = "";

			if(resp.errCode == 0)
			{
				msg = "支付成功";
				state = "success";

			}
			else if(resp.errCode == -1)
			{
				msg = "已取消支付";
				state = "failed";
			}
			else if(resp.errCode == -2)
			{
				msg = "支付失败";
				state = "failed";
			}
			System.out.print(msg);
			WxPay.callback.invoke(state);

			finish();



//			AlertDialog.Builder builder = new AlertDialog.Builder(this);
//			builder.setTitle("微信支付");
//			builder.setMessage(msg);
//			builder.show();


		}
	}
}