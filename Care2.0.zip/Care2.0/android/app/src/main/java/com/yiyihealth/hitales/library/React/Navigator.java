package com.yiyihealth.hitales.library.React;

import android.content.Context;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.FrameLayout;

import com.yiyihealth.hitales.patient.R;
import com.facebook.react.bridge.WritableMap;
import com.facebook.react.bridge.WritableNativeMap;
import com.facebook.react.modules.core.DeviceEventManagerModule;
import com.facebook.react.uimanager.ThemedReactContext;

import org.json.JSONObject;

/**
 * Created by liaomin on 15/11/11.
 */
public class Navigator extends FrameLayout implements Animation.AnimationListener{

    private int screenWidth = 0;

    private ThemedReactContext context;

    private JSONObject mOption;

    public void setOption(JSONObject option){
        this.mOption = option;
        context.runOnUiQueueThread(new Runnable() {
            @Override
            public void run() {
                if(mOption.optBoolean("showAnimation")){ //显示动画
                    if(mOption.optBoolean("push")){ //push 动画
                        Animation animation = AnimationUtils.loadAnimation(context, R.anim.right_in);
                        animation.setAnimationListener(Navigator.this);
                        getChildAt(1).startAnimation(animation);
                        getChildAt(0).startAnimation( AnimationUtils.loadAnimation(context, R.anim.left_out));
                    }else{ //pop 动画
                        Animation animation = AnimationUtils.loadAnimation(context, R.anim.right_out);
                        animation.setAnimationListener(Navigator.this);
                        getChildAt(1).startAnimation(animation);
                        getChildAt(0).startAnimation( AnimationUtils.loadAnimation(context, R.anim.left_in));
                    }
                }
            }
        });
    }

    public Navigator(ThemedReactContext context) {
        super(context);
        this.context = context;
        WindowManager wm = (WindowManager) getContext().getSystemService(Context.WINDOW_SERVICE);
        screenWidth = wm.getDefaultDisplay().getWidth();
    }



    @Override
    public void addView(View child, int index) {
        super.addView(child, index);
        if(index != 0){ //第一个view,不需要动画
//            if(isPush){ //push 动画
//                child.startAnimation(AnimationUtils.loadAnimation(context, R.anim.right_in));
//                Animation out = AnimationUtils.loadAnimation(context, R.anim.left_out);
//                out.setAnimationListener(this);
//                this.getChildAt(0).startAnimation(out);
//            }else{ //pop 动画
//                child.startAnimation(AnimationUtils.loadAnimation(context, R.anim.left_in));
//                Animation out = AnimationUtils.loadAnimation(context, R.anim.right_out);
//                out.setAnimationListener(this);
//                this.getChildAt(0).startAnimation(out);
//            }
        }
    }


    /**
     * <p>Notifies the start of the animation.</p>
     *
     * @param animation The started animation.
     */
    @Override
    public void onAnimationStart(Animation animation) {

    }

    /**
     * <p>Notifies the end of the animation. This callback is not invoked
     * for animations with repeat count set to INFINITE.</p>
     *
     * @param animation The animation which reached its end.
     */
    @Override
    public void onAnimationEnd(Animation animation) {
        getChildAt(0).clearAnimation();
        getChildAt(1).clearAnimation();
        WritableMap params = new WritableNativeMap();
        CouchbaseHelper.context.getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter.class)
                .emit("Navigator_Animation_end", params);
    }

    /**
     * <p>Notifies the repetition of the animation.</p>
     *
     * @param animation The animation which was repeated.
     */
    @Override
    public void onAnimationRepeat(Animation animation) {

    }
}