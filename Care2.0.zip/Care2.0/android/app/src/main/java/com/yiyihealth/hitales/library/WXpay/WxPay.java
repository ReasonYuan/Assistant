package com.yiyihealth.hitales.library.WXpay;

import android.widget.Toast;

import com.facebook.react.bridge.Callback;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.facebook.react.bridge.ReadableMap;
import com.tencent.mm.sdk.modelpay.PayReq;
import com.tencent.mm.sdk.openapi.IWXAPI;
import com.tencent.mm.sdk.openapi.WXAPIFactory;
import com.yiyihealth.hitales.library.BaseActivity;

/**
 * Created by chenjie on 16/1/26.
 */
public class WxPay extends ReactContextBaseJavaModule {

    private IWXAPI api;

    public static Callback callback;

    public WxPay(ReactApplicationContext reactContext){
        super(reactContext);
        api = WXAPIFactory.createWXAPI(reactContext, BaseActivity.APP_ID);
        }

    @Override
    public String getName() {
        return "WXPay";
    }

    @ReactMethod
    public void sendWxPay(ReadableMap map,final Callback callback){

        if(!api.isWXAppInstalled())
        {
            callback.invoke("failed");
            Toast.makeText(getCurrentActivity(), "没安装微信", Toast.LENGTH_SHORT).show();
            return;
        }
        if(!api.isWXAppSupportAPI())
        {
            callback.invoke("failed");
            Toast.makeText(getCurrentActivity(), "当前微信版本不支持支付功能", Toast.LENGTH_SHORT).show();
            return;
        }

//        String url = "http://wxpay.weixin.qq.com/pub_v2/app/app_pay.php?plat=android";




        Toast.makeText(getCurrentActivity(), "获取订单中...", Toast.LENGTH_SHORT).show();

        PayReq req = new PayReq();
        req.appId = BaseActivity.APP_ID;
        req.partnerId = BaseActivity.PARTNERID;
        req.prepayId = map.getString("prepay_id");
        req.nonceStr = map.getString("nonce_str");
        req.timeStamp = map.getInt("timestamp")+"";
        req.packageValue = "Sign=WXPay";
        req.sign = map.getString("clientSign");
        req.extData	= "app data"; // optional
        Toast.makeText(getCurrentActivity(), "正常调起支付", Toast.LENGTH_SHORT).show();
        // 在支付之前，如果应用没有注册到微信，应该先调用IWXMsg.registerApp将应用注册到微信
        api.sendReq(req);

        WxPay.callback = callback;


    }


}
