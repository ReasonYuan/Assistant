package com.yiyihealth.hitales.library.React;

import com.facebook.react.bridge.ReadableMap;
import com.facebook.react.uimanager.ReactProp;
import com.facebook.react.uimanager.ThemedReactContext;
import com.facebook.react.uimanager.ViewGroupManager;

import org.json.JSONObject;

/**
 * Created by liaomin on 15/11/11.
 */
public class NavigatorAndroid extends ViewGroupManager<Navigator> {

    @Override
    public String getName() {
        return "NavigatorAndroid";
    }

    @Override
    protected Navigator createViewInstance(ThemedReactContext reactContext) {
        return new Navigator(reactContext);
    }

    @ReactProp(name = "option")
    public void setOption( Navigator view,  ReadableMap option) {
        try {
            JSONObject object = new JSONObject(option.toString());
            view.setOption(object.optJSONObject("NativeMap"));
        }catch (Exception e){
            e.printStackTrace();
        }

    }



}
