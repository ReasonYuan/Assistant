package com.yiyihealth.hitales.library.React;

import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.widget.Toast;

import com.baidu.android.pushservice.PushManager;
import com.couchbase.lite.Attachment;
import com.couchbase.lite.CouchbaseLiteException;
import com.couchbase.lite.Database;
import com.couchbase.lite.Document;
import com.couchbase.lite.DocumentChange;
import com.couchbase.lite.UnsavedRevision;
import com.couchbase.lite.internal.RevisionInternal;
import com.couchbase.lite.replicator.Replication;
import com.facebook.react.bridge.Callback;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.facebook.react.bridge.WritableArray;
import com.facebook.react.bridge.WritableMap;
import com.facebook.react.bridge.WritableNativeArray;
import com.facebook.react.bridge.WritableNativeMap;
import com.facebook.react.modules.core.DeviceEventManagerModule;
import com.yiyihealth.hitales.library.BaseActivity;
import com.yiyihealth.hitales.library.Constans;
import com.yiyihealth.hitales.library.PushTestReceiver;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

    /**
     * Created by liaomin on 15/11/8.
     */
    public class CouchbaseHelper extends ReactContextBaseJavaModule {

        private static final String SERVER_URL = "SERVER_URL";
        private static final String LOCAL_PORT = "LOCAL_PORT";
        private static final String ENV = "ENV";

    public static ReactApplicationContext context;

    public Replication push;

    public Replication pull;

    public String currnetUserId;

    public ArrayList currnetUserTargs;

    public CouchbaseHelper(ReactApplicationContext reactContext) {
        super(reactContext);
        context = reactContext;
    }

    @Override
    public String getName() {
        return "CouchbaseHelper";
    }

    @Override
    public Map<String, Object> getConstants() {
        final Map<String, Object> constants = new HashMap<String, Object>();
        constants.put(SERVER_URL, Constans.SERVER_URL);
        constants.put(LOCAL_PORT, Constans.LOCAL_PROT);
        constants.put(ENV, Constans.ENV);
        constants.put("STATUSBARHEIGHT", BaseActivity.STATUSBARHEIGHT);
        constants.put("ACTIVITYHEIGHT", BaseActivity.ACTIVITYHEIGHT);
        return constants;
    }

    @ReactMethod
    public void showToast(String message) {
        Toast.makeText(getReactApplicationContext(), message, Toast.LENGTH_SHORT).show();
    }

    @ReactMethod
    public void getAttachment(final String dbName,final String documentID,final String attachmentId, final Callback callback) {
        getReactApplicationContext().runOnUiQueueThread(new Runnable() {
            @Override
            public void run() {
                try {
                    Database database = BaseActivity.mDBManager.getDatabase(dbName);
                    Document document = database.getDocument(documentID);
                    Attachment attachment = document.getCurrentRevision().getAttachment(attachmentId);
                    if (attachment != null) {
                        InputStream inStream = attachment.getContent();
                        ByteArrayOutputStream swapStream = new ByteArrayOutputStream();
                        byte[] buff = new byte[100];
                        int rc = 0;
                        while ((rc = inStream.read(buff, 0, 100)) > 0) {
                            swapStream.write(buff, 0, rc);
                        }
                        byte[] data = swapStream.toByteArray();
                        final String base64Image = new String(data);
                        getReactApplicationContext().runOnJSQueueThread(new Runnable() {
                            @Override
                            public void run() {
                                callback.invoke(base64Image);
                            }
                        });
                        swapStream.close();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    @ReactMethod
    public void addAttachmnet(final String dbName,final String documentID,final String attachmentId, final String contenType, final String data, final Callback callback) {
        getReactApplicationContext().runOnUiQueueThread(new Runnable() {
            @Override
            public void run() {
                try {
                    InputStream sbs = new ByteArrayInputStream(data.getBytes());
                    Database database = BaseActivity.mDBManager.getDatabase(dbName);
                    Document document = database.getDocument(documentID);
                    final UnsavedRevision rev = document.getCurrentRevision().createRevision();
                    rev.setAttachment(attachmentId, contenType, sbs);
                    rev.save();

                    getReactApplicationContext().runOnJSQueueThread(new Runnable() {
                        @Override
                        public void run() {
                            callback.invoke(rev.getId());
                        }
                    });

                } catch (Exception e) {
                    e.printStackTrace();
                    ;
                }
            }
        });
    }

    @ReactMethod
    public void registerDBNamed(final String dbName, final Callback callback){
        getReactApplicationContext().runOnUiQueueThread(new Runnable() {
            @Override
            public void run() {
                try {
                    ImageHelper.mTask = new UploadImageTask(dbName);
                    Database db = BaseActivity.mDBManager.getDatabase(dbName);
                    if(db != null){
                        currnetUserId = dbName;
                        db.addChangeListener(new DBChangeListener(db));
                        getReactApplicationContext().runOnJSQueueThread(new Runnable() {
                            @Override
                            public void run() {
                                callback.invoke();
                            }
                        });
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        });
    }


    @ReactMethod
    public void setSession(String session,String name,String serverUrl,String bucket){
        if(push != null)push.stop();
        if(pull !=null)pull.stop();
        Database database = null;
        try {
            database = BaseActivity.mDBManager.getDatabase(currnetUserId);
        } catch (CouchbaseLiteException e) {
            e.printStackTrace();
        }
        String urlStr = serverUrl + bucket;
        URL url = null;
        try {
            url = new URL(urlStr);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        push = database.createPushReplication(url);
        pull = database.createPullReplication(url);
        pull.setContinuous(true);
        push.setContinuous(true);
        pull.setCookie("SyncGatewaySession", session, null, null, false, false);
        push.setCookie("SyncGatewaySession", session, null, null, false, false);

        pull.start();
        push.start();
    }

    @ReactMethod
    public void stopReplication(){
        if(push != null) push.stop();
        if(pull != null) pull.stop();
    }

    public void registerUserBaiduTags(){
        if(currnetUserId != null){
            getReactApplicationContext().runOnUiQueueThread(new Runnable() {
                @Override
                public void run() {
                    Database database = null;
                    try {
                        database = BaseActivity.mDBManager.getDatabase(currnetUserId);
                        if(database != null){
                            Document document = database.getDocument(currnetUserId);
                            Map<String, Object> properties = document.getProperties();
                            if(properties != null){
                                ArrayList tags = (ArrayList)properties.get("tags");
                                if(tags != null && !tags.equals(currnetUserTargs)){
                                    PushManager.setTags(context,tags);
                                    currnetUserTargs =  tags;
                                }
                            }
                        }
                    } catch (CouchbaseLiteException e) {
                        e.printStackTrace();
                    }
                }
            });
        }
    }


    //TODO 百度推送的key
    @ReactMethod
    public void getBaiduChannelId(final Callback callback){
        getReactApplicationContext().runOnJSQueueThread(new Runnable() {
            @Override
            public void run() {
                callback.invoke(PushTestReceiver.getBaiduChannelId());
            }
        });
    }

    /**
     * 解除百度推送绑定
     * @param callback
     */
    @ReactMethod
    public  void unBindBaiDuPush(Callback callback){
        PushManager.stopWork(context);
        callback.invoke("unBindBaiDuPush");
    }

    /**
     * 重新绑定百度推送
     * @param callback
     */
    @ReactMethod
    public void BindBaiDuPush(Callback callback){
        PushManager.resumeWork(context);
        callback.invoke("BindBaiDuPush");
    }

    /**
     * 获取DeviceId号
     * @return 当前应用的版本号
     */
    @ReactMethod
    public void getDeviceId(Callback callback) {
        final TelephonyManager tm = (TelephonyManager) context.getSystemService(context.TELEPHONY_SERVICE);
        final String tmDevice, tmSerial, androidId;
        tmDevice = "" + tm.getDeviceId();
        tmSerial = "" + tm.getSimSerialNumber();
        androidId = "" + android.provider.Settings.Secure.getString(context.getContentResolver(), android.provider.Settings.Secure.ANDROID_ID);
        UUID deviceUuid = new UUID(androidId.hashCode(), ((long)tmDevice.hashCode() << 32) | tmSerial.hashCode());
        String uniqueId = deviceUuid.toString();
        Log.i("device uuid", uniqueId);
        callback.invoke(uniqueId);
    }

    /**
     * 获取版本号
     * @return 当前应用的版本号
     */
    @ReactMethod
    public void getVersion(Callback callback) {
        try {
            PackageManager manager = getCurrentActivity().getPackageManager();
            PackageInfo info = manager.getPackageInfo(getCurrentActivity().getPackageName(), 0);
            String version = info.versionName;
            callback.invoke(version);
        } catch (Exception e) {
            e.printStackTrace();
            callback.invoke("未知版本");
        }

    }

    public static WritableMap MapToWritableMap(Map<String,Object> properties){
        WritableMap value = new WritableNativeMap();
        for (String key : properties.keySet()){
            Object vo = properties.get(key);
            if(vo instanceof List){
                value.putArray(key, CouchbaseHelper.ListToWritableMap((List) vo));
            }else if(vo instanceof Map){
                value.putMap(key, CouchbaseHelper.MapToWritableMap((Map<String,Object>)vo));
            }else if(vo instanceof Integer){
                value.putInt(key, ((Integer) vo).intValue());
            }else if(vo instanceof Float){
                value.putDouble(key, ((Float) vo).floatValue());
            }else if(vo instanceof Double){
                value.putDouble(key, ((Double) vo).doubleValue());
            }else if(vo instanceof Long){
                value.putInt(key, (int) ((Long)vo).longValue());
            }else if(vo instanceof Short){
                value.putInt(key, ((Short)vo).shortValue());
            }else if(vo instanceof Boolean){
                value.putBoolean(key, ((Boolean)vo).booleanValue());
            }else if(vo != null){
                String v = vo.toString();
                value.putString(key,v);
            }
        }
        return value;
    }

    public static WritableArray ListToWritableMap(List array) {
        WritableArray value = new WritableNativeArray();
        for (int i = 0;i<array.size();i++){
            Object vo = array.get(i);
            if(vo instanceof List){
                value.pushArray(CouchbaseHelper.ListToWritableMap((List) vo));
            }else if(vo instanceof Map){
                value.pushMap(CouchbaseHelper.MapToWritableMap((Map<String, Object>) vo));
            }else if(vo instanceof Integer){
                value.pushInt(((Integer) vo).intValue());
            }else if(vo instanceof Float){
                value.pushDouble(((Float) vo).floatValue());
            }else if(vo instanceof Double){
                value.pushDouble(((Double) vo).doubleValue());
            }else if(vo instanceof Long){
                value.pushInt((int) ((Long)vo).longValue());
            }else if(vo instanceof Short){
                value.pushInt(((Short)vo).shortValue());
            }else if(vo instanceof Boolean){
                value.pushBoolean(((Boolean)vo).booleanValue());
            }else if(vo != null){
                value.pushString(vo.toString());
            }
        }
        return value;
    }

    class DBChangeListener implements Database.ChangeListener{

        private Database db;

        public DBChangeListener(Database db){
            this.db =db;
        }

        @Override
        public void changed(Database.ChangeEvent event) {
            List<DocumentChange> changes = event.getChanges();
            WritableArray docChanges = new WritableNativeArray();
            for (int i = 0 ; i < changes.size() ; i++){
                DocumentChange change = changes.get(i);
                RevisionInternal addedRevision = change.getAddedRevision();
                if(addedRevision.isDeleted()){
                    WritableMap delete = new WritableNativeMap();
                    delete.putBoolean("delete",true);
                    docChanges.pushMap(delete);

                }else {
                    Map<String, Object> properties = addedRevision.getProperties();
                    if(properties != null){
                        if(properties.get("type") != null){//document 需要有type
                            docChanges.pushMap(CouchbaseHelper.MapToWritableMap(properties));
                            if(change.getDocumentId().equals(currnetUserId)){
                                registerUserBaiduTags();
                            }
                        }
                    }else{//其他不知道的情况，当删除处理，全更新
                        WritableMap delete = new WritableNativeMap();
                        delete.putBoolean("delete",true);
                        docChanges.pushMap(delete);
                    }
                }
            }
            if(docChanges.size() > 0){
                CouchbaseHelper.sendEventToJS(this.db.getName() + "_changes", docChanges);
            }
        }
    }

    public static void sendEventToJS(String eventName,Object data){
        context.getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter.class)
                .emit(eventName, data);
    }

}
