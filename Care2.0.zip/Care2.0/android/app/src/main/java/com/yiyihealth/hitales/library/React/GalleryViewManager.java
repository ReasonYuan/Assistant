package com.yiyihealth.hitales.library.React;

import com.facebook.react.bridge.Callback;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;

/**
 * Created by chenjie on 16/1/22.
 */
public class GalleryViewManager extends ReactContextBaseJavaModule {

    public GalleryViewManager(ReactApplicationContext reactContext) {
        super(reactContext);
    }

    @Override
    public String getName() {
        return "GalleryViewManager";
    }


    @ReactMethod
    public void getCurrentIndex(Callback callback){
       if(callback != null) callback.invoke(ReactGalleryView.scrollGalleryView.getSelectedItemPosition());
    }

    @ReactMethod
    public  void deleteCurrentIndex(Callback callback){
        int currentIndex = ReactGalleryView.scrollGalleryView.getSelectedItemPosition();
        ReactGalleryView.adapter.removAt(currentIndex);
        ReactGalleryView.adapter.notifyDataSetChanged();
        if(callback != null)callback.invoke(currentIndex);

    }



}
