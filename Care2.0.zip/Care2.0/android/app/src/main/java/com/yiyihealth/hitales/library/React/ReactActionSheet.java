package com.yiyihealth.hitales.library.React;

import com.baoyz.actionsheet.ActionSheet;
import com.facebook.react.bridge.Callback;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.facebook.react.bridge.ReadableArray;
import com.yiyihealth.hitales.library.BaseActivity;


/**
 * Created by liaomin on 15/11/9.
        */
public class ReactActionSheet  extends ReactContextBaseJavaModule {


    public ReactActionSheet(ReactApplicationContext reactContext) {
        super(reactContext);
    }
    private long firstTime = 0;
    private long sencondTime = 0;

    @Override
    public String getName() {
        return "ActionSheet";
    }


    @ReactMethod
    public void showActionSheet(final ReadableArray itmes, final String cannelTitle, final Callback callback) {
        getReactApplicationContext().runOnUiQueueThread(new Runnable() {
            @Override
            public void run() {
                String[] titles = new String[itmes.size()];
                for (int i = 0; i < itmes.size(); i++) {
                    titles[i] = itmes.getString(i);
                }
                ActionSheet.createBuilder(BaseActivity.instance, BaseActivity.instance.getSupportFragmentManager())
                        .setCancelButtonTitle(cannelTitle)
                        .setOtherButtonTitles(titles)
                        .setCancelableOnTouchOutside(true)
                        .setListener(new ActionSheet.ActionSheetListener() {
                            @Override
                            public void onDismiss(ActionSheet actionSheet, boolean isCancel) {

                            }

                            @Override
                            public void onOtherButtonClick(ActionSheet actionSheet, final int index) {
                                sencondTime =  System.currentTimeMillis();
                                if (sencondTime - firstTime > 1000) {
                                    firstTime = sencondTime;
                                    if (callback != null) {
                                        ReactActionSheet.this.getReactApplicationContext().runOnNativeModulesQueueThread(new Runnable() {
                                            @Override
                                            public void run() {
                                                callback.invoke(index);
                                            }
                                        });
                                    }
                                } else {
                                   return;
                                }


                            }
                        }).show();
            }
        });


    }

}