package com.yiyihealth.hitales.library;

import android.content.Intent;
import android.support.v4.app.FragmentActivity;

import com.couchbase.lite.Manager;
import com.facebook.react.ReactInstanceManager;

import java.util.HashMap;

/**
 * Created by chenjie on 16/3/10.
 */
public class BaseActivity extends FragmentActivity {
    public interface Callback{
        public void doCallback(int resultCode, Intent data);
    }
    //onActivityResult 的回调,key为requestCode
    public HashMap<Integer,Callback> resultsCallback = new HashMap<Integer,Callback>();

    public static int SCREEN_WIDTH;
    public static int SCREEN_HEIGHT;
    public static Manager mDBManager;
    public static BaseActivity instance;
    public static ReactInstanceManager mReactInstanceManager;

    //状态栏高度
    public static int STATUSBARHEIGHT = 0;
    //界面高度
    public static int ACTIVITYHEIGHT = 0;
    //除开状态栏和导航栏的高度
    public static int CONTENTHEIGHT = 0;
    //1dp占的像素
    public static float SCALE = 0;

    ///仅病人版使用
    //微信支付APPID
    public static String APP_ID = "wxc082b2b611f918fe";
    //微信支付商户号
    public static String PARTNERID = "1310382701";



}
