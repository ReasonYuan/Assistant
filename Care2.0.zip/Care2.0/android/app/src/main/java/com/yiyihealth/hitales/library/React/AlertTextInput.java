package com.yiyihealth.hitales.library.React;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;

import com.facebook.react.bridge.Callback;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.yiyihealth.hitales.library.BaseActivity;
import com.yiyihealth.hitales.patient.R;


/**
 * Created by liaomin on 15/11/8.
 */
public class AlertTextInput extends ReactContextBaseJavaModule {

    private EditText mEditText;

    public AlertTextInput(ReactApplicationContext reactContext) {
        super(reactContext);
    }

    @Override
    public String getName() {
        return "AlertTextInput";
    }


    @ReactMethod
    public void showTextInputAlertView(final String title,final String placeHolder,final Callback callback) {
        BaseActivity.instance.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                LayoutInflater inflater = LayoutInflater.from(BaseActivity.instance);
                View showView = inflater.inflate(R.layout.dialoglayout, null);
                mEditText = (EditText) showView.findViewById(R.id.edtInput);
                mEditText.setHint(placeHolder);
                final AlertDialog.Builder builder = new AlertDialog.Builder(BaseActivity.instance);
                builder.setCancelable(false);
                builder.setTitle(title);
                builder.setView(showView);
                builder.setPositiveButton("确认",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
                                if (callback != null) {
                                    AlertTextInput.this.getReactApplicationContext().runOnNativeModulesQueueThread(new Runnable() {
                                        @Override
                                        public void run() {
                                            callback.invoke(mEditText.getText().toString());
                                        }
                                    });

                                }
                            }
                        });
                builder.setNegativeButton("取消",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
                                dialog.dismiss();
                            }
                        });
                builder.show();
            }
        });

    }
}
