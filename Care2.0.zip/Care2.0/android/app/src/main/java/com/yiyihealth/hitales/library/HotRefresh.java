package com.yiyihealth.hitales.library;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Environment;
import android.preference.PreferenceManager;
import android.widget.TextView;

import com.facebook.react.ReactInstanceManager;
import com.facebook.react.bridge.JSBundleLoader;
import com.facebook.react.bridge.JSCJavaScriptExecutor;
import com.facebook.react.bridge.JavaScriptExecutor;
import com.kaopiz.kprogresshud.KProgressHUD;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.Response;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/**
 * Created by wangxi on 16/3/8.
 */
public class HotRefresh {

    private KProgressHUD mProgressBar;

    private TextView mTextProgress;

    private final OkHttpClient client = new OkHttpClient();

    long bytesRead = 0;

    private String serverIp = "";//http://192.168.0.108:8080";

    private String resoureName = "";// "/web/index.android.bundle.zip";

    private String bundleUrl = "";//serverIp + resoureName;

    private String bundleZipName = "";//"index.android.bundle.zip";

    private static String bundleName = "";//"index.android.bundle";

    private String downloadZipBundleLocalPath = "";//Environment.getExternalStorageDirectory() + "/" + bundleZipName;

    private String unZipBundleToPath = Environment.getExternalStorageDirectory() + "/";

    public static String bundlePath = "";//Environment.getExternalStorageDirectory() + "/" + bundleName;

    public static SharedPreferences mSharePreferences;

    public HotRefresh(String url,String fileName,String unZipBundleName){
            this.bundleUrl = url;
            this.bundleZipName = fileName;
            this.bundleName = unZipBundleName;
            this.downloadZipBundleLocalPath = Environment.getExternalStorageDirectory() + "/" + bundleZipName;
            this.bundlePath =  Environment.getExternalStorageDirectory() + "/" + bundleName;
    }

    //final ReactInstanceManager mReactInstanceManager, final Context context
    public void run() throws Exception {

        final Request request = new Request.Builder().tag("下载资源")
                .url(bundleUrl)
                .build();

        showDialog();

        client.newCall(request).enqueue(new com.squareup.okhttp.Callback() {

            @Override
            public void onFailure(Request request, IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(Response response) throws IOException {
                if (!response.isSuccessful()) throw new IOException("Unexpected code " + response);

                System.out.println("tag________" + request.tag());
                InputStream is = null;
                byte[] buf = new byte[2048];
                int len = 0;
                FileOutputStream fos = null;
                is = response.body().byteStream();
                File file = new File(downloadZipBundleLocalPath);
                fos = new FileOutputStream(file);

                while ((len = is.read(buf)) != -1) {
                    fos.write(buf, 0, len);
                    bytesRead += len;
                    final int progress = (int) ((bytesRead * 100) / response.body().contentLength());
                    BaseActivity.instance.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            mProgressBar.setProgress(progress);
                            if (progress == 100) {
                                mProgressBar.dismiss();
                            }
                        }
                    });

                    System.out.println("progress-------" + progress + "%");
                }
                fos.flush();

                File mFile = new File(downloadZipBundleLocalPath);

                try {
                    ZipUtils.upZipFile(mFile, unZipBundleToPath, new ZipUtils.ZipFileFinishCallBack() {
                        @Override
                        public void onZipFinishCallBack() {
                            File file = new File(bundlePath);
                            if (file.exists()){
                                putBundleToPrefenrences();
                                onJSBundleLoadedFromServer(bundlePath, BaseActivity.mReactInstanceManager, BaseActivity.instance);
                            }

                        }
                    });


                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    private void onJSBundleLoadedFromServer(final String path,final ReactInstanceManager mReactInstanceManager,final Context context) {

        BaseActivity.instance.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    Class<?> RIManagerClazz = mReactInstanceManager.getClass();
                    Method method = RIManagerClazz.getDeclaredMethod("recreateReactContextInBackground",
                            JavaScriptExecutor.class, JSBundleLoader.class);
                    method.setAccessible(true);
                    method.invoke(mReactInstanceManager,
                            new JSCJavaScriptExecutor(),
                            JSBundleLoader.createFileLoader(context, path));
                } catch (NoSuchMethodException e) {
                    e.printStackTrace();
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                } catch (InvocationTargetException e) {
                    e.printStackTrace();
                } catch (IllegalArgumentException e) {
                    e.printStackTrace();
                }
            }
        });

    }


    public void showDialog(){
        BaseActivity.instance.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                mProgressBar = KProgressHUD.create(BaseActivity.instance)
                        .setStyle(KProgressHUD.Style.BAR_DETERMINATE)
                        .setLabel("更新资源中。。。")
                        .setMaxProgress(100)
                        .show();

            }
        });
    }

    /**
     * 将新下载的bundle 路径存入sharepreference
     * 并标记为SUCCESS
     */
    public static void putBundleToPrefenrences(){
        mSharePreferences = PreferenceManager.getDefaultSharedPreferences(BaseActivity.instance);
        SharedPreferences.Editor editor = mSharePreferences.edit();
        editor.putBoolean("DOWNLOAD_SUCCESS", true);
        editor.putString("BUNDLE_PATH", bundlePath);
        editor.commit();
        System.out.println("存入Preference成功");
    }

    /**
     * 是否需要加载新的bundle
     */
    public static boolean getBundleIsNeedLoadNewBundle(){
        mSharePreferences = PreferenceManager.getDefaultSharedPreferences(BaseActivity.instance);
        return  mSharePreferences.getBoolean("DOWNLOAD_SUCCESS",false);
    }

    /**
     * 加载本地bundle，里面已经做出判断
     */
    public static String loadLocalBundleFile(){
        if(getBundleIsNeedLoadNewBundle()){
            System.out.println("本地有新的bundle");
            mSharePreferences = PreferenceManager.getDefaultSharedPreferences(BaseActivity.instance);
            return mSharePreferences.getString("BUNDLE_PATH","");
        }
        return "";
    }

    /**
     * 返回local bundle 的路径。
     */
    public static String getBundleFilePath(){
        mSharePreferences = PreferenceManager.getDefaultSharedPreferences(BaseActivity.instance);
        return mSharePreferences.getString("BUNDLE_PATH","");
    }


}
