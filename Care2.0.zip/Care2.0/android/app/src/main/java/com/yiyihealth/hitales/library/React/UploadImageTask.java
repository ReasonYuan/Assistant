package com.yiyihealth.hitales.library.React;

import com.alibaba.sdk.android.oss.ClientConfiguration;
import com.alibaba.sdk.android.oss.ClientException;
import com.alibaba.sdk.android.oss.OSSClient;
import com.alibaba.sdk.android.oss.ServiceException;
import com.alibaba.sdk.android.oss.callback.OSSCompletedCallback;
import com.alibaba.sdk.android.oss.callback.OSSProgressCallback;
import com.alibaba.sdk.android.oss.common.auth.OSSCredentialProvider;
import com.alibaba.sdk.android.oss.common.auth.OSSPlainTextAKSKCredentialProvider;
import com.alibaba.sdk.android.oss.model.PutObjectRequest;
import com.alibaba.sdk.android.oss.model.PutObjectResult;
import com.facebook.react.bridge.WritableMap;
import com.facebook.react.bridge.WritableNativeMap;
import com.yiyihealth.hitales.library.BaseActivity;

import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

/**
 * Created by liaomin on 16/1/17.
 */
public class UploadImageTask{

    private String localSerializablePath;

    private ArrayList<String> upLoadImages;

    private  String userId;

    private OSSClient oss;

    private boolean isRuning = false;

    private boolean isWork = false;

    private Timer mTimer;

    public UploadImageTask(String userId){
        mTimer = new Timer();
        this.localSerializablePath = FileHelper.mDocumentDir + userId + "/upLoadTask";
        Object cache = FileHelper.loadSerializableObject(localSerializablePath);
        if(cache != null && cache instanceof ArrayList){
            upLoadImages = (ArrayList<String>)cache;
        }else {
            upLoadImages = new ArrayList<String>();
        }
        this.userId = userId;

        OSSCredentialProvider credentialProvider = new OSSPlainTextAKSKCredentialProvider(ImageHelper.OSS_ACCESS_KEY, ImageHelper.OSS_SECRET_KEY);

        ClientConfiguration conf = new ClientConfiguration();
        conf.setConnectionTimeout(30 * 1000); // 连接超时，默认15秒
        conf.setSocketTimeout(30 * 1000); // socket超时，默认15秒
        conf.setMaxConcurrentRequest(2); // 最大并发请求书，默认5个
        conf.setMaxErrorRetry(5); // 失败后最大重试次数，默认2次
        oss = new OSSClient(BaseActivity.instance, ImageHelper.OSS_UPLOAD_ENDPOINT, credentialProvider, conf);
//        this.start();
    }

    public void addImage(String objectKey){
        if(!upLoadImages.contains(objectKey)){
            upLoadImages.add(objectKey);
            save();
        }
        this.start();
    }


    public void start(){
        if(!isRuning){
            isRuning = true;
        }
        featchTask();
    }

    public void stop(){
        this.save();
        isRuning = false;
    }

    public int size(){
        return upLoadImages.size();
    }

    private synchronized void featchTask(){

        if(isRuning && upLoadImages.size() > 0 && !isWork){
            isWork = true;
            mTimer.schedule(new TimerTask() {
                @Override
                public void run() {
                    final String objectKey = upLoadImages.get(0);
                    final String uploadFilePath = FileHelper.getLocalImagePath(userId, objectKey);
                    PutObjectRequest put = new PutObjectRequest(ImageHelper.OSS_BUCKET_NAME, objectKey, uploadFilePath);
                    // 异步上传时可以设置进度回调
                    put.setProgressCallback(new OSSProgressCallback<PutObjectRequest>() {
                        @Override
                        public void onProgress(PutObjectRequest request, long currentSize, long totalSize) {
                            double process = (double) currentSize / totalSize;
                            WritableMap map = new WritableNativeMap();
                            map.putString("key", objectKey);
                            map.putDouble("progress", process);
                            CouchbaseHelper.sendEventToJS(ImageHelper.NOTI_UPLOAD_IMAGE_PROGRESS, map);
                        }
                    });
                    oss.asyncPutObject(put, new OSSCompletedCallback<PutObjectRequest, PutObjectResult>() {
                        @Override
                        public void onSuccess(PutObjectRequest request, PutObjectResult result) {
                            CouchbaseHelper.sendEventToJS(ImageHelper.NOTI_UPLOAD_IMAGE_COMPLETE, objectKey);
                            upLoadImages.remove(objectKey);
                            save();
                            isWork = false;
                            featchTask();
                        }

                        @Override
                        public void onFailure(PutObjectRequest request, ClientException clientExcepion, ServiceException serviceException) {
                            upLoadImages.remove(objectKey);
                            upLoadImages.add(objectKey);
                            isWork = false;
                            save();
                            featchTask();
                        }
                    });
                }
            }, 3000);
        }
    }

    private void save(){
        FileHelper.saveSerializableObject(upLoadImages,localSerializablePath);
        WritableMap countMap = new WritableNativeMap();
        countMap.putInt("count", upLoadImages.size());
        CouchbaseHelper.sendEventToJS(ImageHelper.NOTI_UPLOAD_COUNT_CHANGE, countMap);
    }

}
