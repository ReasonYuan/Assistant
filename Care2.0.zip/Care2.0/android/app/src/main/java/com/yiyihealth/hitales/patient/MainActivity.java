package com.yiyihealth.hitales.patient;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.DisplayMetrics;
import android.view.KeyEvent;

import com.baidu.android.pushservice.PushConstants;
import com.baidu.android.pushservice.PushManager;
import com.couchbase.lite.Manager;
import com.couchbase.lite.View;
import com.couchbase.lite.android.AndroidContext;
import com.couchbase.lite.javascript.JavaScriptViewCompiler;
import com.couchbase.lite.listener.LiteListener;
import com.couchbase.lite.util.Log;
import com.facebook.react.LifecycleState;
import com.facebook.react.ReactInstanceManager;
import com.facebook.react.ReactRootView;
import com.facebook.react.modules.core.DefaultHardwareBackBtnHandler;
import com.facebook.react.shell.MainReactPackage;
import com.tencent.mm.sdk.openapi.IWXAPI;
import com.tencent.mm.sdk.openapi.WXAPIFactory;
import com.yiyihealth.hitales.library.BaseActivity;
import com.yiyihealth.hitales.library.Constans;
import com.yiyihealth.hitales.library.HotRefresh;
import com.yiyihealth.hitales.library.React.CouchbaseHelperPackage;
import com.yiyihealth.hitales.library.React.FileHelper;



public class MainActivity extends BaseActivity implements DefaultHardwareBackBtnHandler {




    private ReactRootView mReactRootView;
    private SharedPreferences mPreferences;
    private static String BAIDU_API_KEY = "NhGIb5lATbuf6of08kwz9Syi";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = mPreferences.edit();
        editor.putString("debug_http_host", "192.168.0.118:8081");
        editor.putBoolean("reload_on_js_change", true);
        editor.commit();

        DisplayMetrics dm  = getResources().getDisplayMetrics();
        SCALE = dm.density;
        BaseActivity.STATUSBARHEIGHT = (int)(getStatusBarHeight() / SCALE + 0.5f);
        System.out.print("---------------------------->" + BaseActivity.STATUSBARHEIGHT);



        IWXAPI msgApi = WXAPIFactory.createWXAPI(this, null);
        // 将该app注册到微信
        msgApi.registerApp(APP_ID);

        instance = this;
        SCREEN_WIDTH = getWindowManager().getDefaultDisplay().getWidth();
        SCREEN_HEIGHT = getWindowManager().getDefaultDisplay().getHeight();
        ACTIVITYHEIGHT = (int)(SCREEN_HEIGHT/SCALE +0.5f - STATUSBARHEIGHT);
        CONTENTHEIGHT = SCREEN_HEIGHT - getStatusBarHeight() - (int)(64 * SCALE);
        System.out.print("---------------------------->" + BaseActivity.CONTENTHEIGHT);
        FileHelper.init(instance);
        View.setCompiler(new JavaScriptViewCompiler());

        try {
            Manager.enableLogging(Log.TAG, Log.VERBOSE);
            Manager.enableLogging(Log.TAG_SYNC, Log.VERBOSE);
            Manager.enableLogging(Log.TAG_QUERY, Log.VERBOSE);
            Manager.enableLogging(Log.TAG_VIEW, Log.VERBOSE);
            Manager.enableLogging(Log.TAG_CHANGE_TRACKER, Log.VERBOSE);
            Manager.enableLogging(Log.TAG_BLOB_STORE, Log.VERBOSE);
            Manager.enableLogging(Log.TAG_DATABASE, Log.VERBOSE);
            Manager.enableLogging(Log.TAG_LISTENER, Log.VERBOSE);
            Manager.enableLogging(Log.TAG_MULTI_STREAM_WRITER, Log.VERBOSE);
            Manager.enableLogging(Log.TAG_REMOTE_REQUEST, Log.VERBOSE);
            Manager.enableLogging(Log.TAG_ROUTER, Log.VERBOSE);
            mDBManager = new Manager(new AndroidContext(this), Manager.DEFAULT_OPTIONS);
            LiteListener listener = new LiteListener(mDBManager, Constans.LOCAL_PROT, null);
            Constans.LOCAL_PROT = listener.getListenPort();
            listener.start();
        } catch (Exception e) {
            e.printStackTrace();
        }

        mReactRootView = new ReactRootView(this);

        if(!HotRefresh.loadLocalBundleFile().equals("")){
            System.out.println("------加载新的bundle-------");
            mReactInstanceManager = ReactInstanceManager.builder()
                    .setApplication(getApplication())
                    .setJSBundleFile(HotRefresh.loadLocalBundleFile())
                    .setJSMainModuleName("index.android")
                    .addPackage(new MainReactPackage())
                    .addPackage(new CouchbaseHelperPackage())
                    .setUseDeveloperSupport(BuildConfig.DEBUG)
                    .setInitialLifecycleState(LifecycleState.RESUMED)
                    .build();
            System.out.println("bundlel路径：---"+HotRefresh.loadLocalBundleFile());
        }else{
            System.out.println("------加载Assets的bundle-------");
            mReactInstanceManager = ReactInstanceManager.builder()
                    .setApplication(getApplication())
                    .setBundleAssetName("index.android.bundle")
                    .setJSMainModuleName("index.android")
                    .addPackage(new MainReactPackage())
                    .addPackage(new CouchbaseHelperPackage())
                    .setUseDeveloperSupport(BuildConfig.DEBUG)
                    .setInitialLifecycleState(LifecycleState.RESUMED)
                    .build();
        }


        mReactRootView.startReactApplication(mReactInstanceManager, "Care", null);

        setContentView(mReactRootView);
        PushManager.startWork(getApplicationContext(), PushConstants.LOGIN_TYPE_API_KEY, BAIDU_API_KEY);



    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Callback callback = this.resultsCallback.get(requestCode);
        if(callback != null){
            callback.doCallback(requestCode, data);
        }
    }

    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_MENU && mReactInstanceManager != null) {
            mReactInstanceManager.showDevOptionsDialog();
            return true;
        }
        return super.onKeyUp(keyCode, event);
    }

    @Override
    public void onBackPressed() {
      if (mReactInstanceManager != null) {
        mReactInstanceManager.onBackPressed();
      } else {
        super.onBackPressed();
      }
    }

    @Override
    public void invokeDefaultOnBackPressed() {
      super.onBackPressed();
    }

    @Override
    protected void onPause() {
        super.onPause();

        if (mReactInstanceManager != null) {
            mReactInstanceManager.onPause();
        }


//        PushManager.startWork(getApplicationContext(), PushConstants.LOGIN_TYPE_API_KEY, BAIDU_API_KEY);
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (mReactInstanceManager != null) {
            mReactInstanceManager.onResume(this, this);
        }



//        PushManager.stopWork(getApplicationContext());
//        System.out.println("解绑成功");
    }



    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);

//
//        Rect outRect = new Rect();
//        DisplayMetrics dm  = getResources().getDisplayMetrics();
////        int w_screen = dm.widthPixels;
////        int h_screen = dm.heightPixels;
//        this.getWindow().findViewById(Window.ID_ANDROID_CONTENT).getDrawingRect(outRect);
//        int h_activity = outRect.height();
//        float scale = dm.density;
////        STATUSBARHEIGHT = (int)((h_screen - h_activity) / scale + 0.5f);
//        ACTIVITYHEIGHT = (int)(h_activity/scale + 0.5f);
//        System.out.print("---------------------------->" + ACTIVITYHEIGHT);



    }

    public int getStatusBarHeight() {
        int result = 0;
        int resourceId = getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (resourceId > 0) {
            result = getResources().getDimensionPixelSize(resourceId);
        }
        return result;
    }


}
