// 'use strict';
//
// var React = require('react-native');
//
// var {
//   StyleSheet,
//   Text,
//   View,
//   TextInput,
//   TouchableHighlight,
//   Navigator,
//   ScrollView,
//   Animated,
// } = React;
// var Dimensions = require('Dimensions');
// var {User,Patient} = require("./core/Models")
// var {DatabaseManager,DatabaseView} = require('./core/couchbase/Couchbase');
// var MK = require('react-native-material-kit');
// const {
//   MKRadioButton,
// } = MK;
//
// var {Styles,Button,BaseComponent} = require('./Styles');
// var CareList = require('./CareList');
// var Home = require('./core/Home');
//
// class Family extends React.Component {
//   constructor(props){
//     super(props);
//     if(this.props.relationship && this.props.relationship === '子女'){
//       this.radioGroup = new MKRadioButton.Group();
//     }
//     this.state = {relationship:this.props.relationship,name:this.props.name,patient:this.props.patient,gender:this.props.patient?this.props.patient.gender:1}
//   }
//   render(){
//     return (
//       <View>
//         {
//           (()=>{
//             if(this.props.relationship){
//               return (
//                 <View style={[Styles.vCenter],{height:30}}>
//                   <Text style={[{fontSize:18,marginLeft:20,marginRight:20,marginTop:10}]}>
//                     {this.props.relationship}
//                   </Text>
//                 </View>
//               )
//             }else{
//               return (
//                 <TextInput
//                   style={[Styles.input,{height:45,marginLeft:20,marginRight:20,marginTop:10}]}
//                   placeholder={"输入关系"}
//                   onChangeText={(text) => {
//                     this.setState({relationship:text});
//                   }}
//                   value={this.state.relationship}
//                   />
//               )
//             }
//           })()
//         }
//         <TextInput
//           style={[Styles.input,{height:45,marginLeft:20,marginRight:20,marginTop:10}]}
//           placeholder={"姓名"}
//           onChangeText={(text) => {
//             this.setState({name:text})
//           }}
//           value={(()=>{
//             if(this.props.patient){
//              return this.props.patient.name
//             }else{
//               return this.state.name
//             }
//           })()}
//           editable={!this.props.patient}
//           />
//           {
//             (()=>{
//               if(this.props.relationship && this.props.relationship === '子女'){
//                 return (
//                   <View style={{flexDirection:'row',marginLeft:20,marginRight:20}}>
//                       <View style={[Styles.hCenter,{flex:1}]}>
//                         <MKRadioButton
//                           checked={this.props.patient?this.props.patient.gender == 1:true}
//                           group={this.radioGroup}
//                           onCheckedChange={(changed)=>{
//                             if(changed.checked){
//                               this.setState({gender:1})
//                             }
//                           }}/>
//                         <Text>儿子</Text>
//                       </View>
//                       <View style={[Styles.hCenter,{flex:1}]}>
//                         <MKRadioButton
//                         checked={this.props.patient?this.props.patient.gender == 0:false}
//                          group={this.radioGroup}
//                          onCheckedChange={(changed)=>{
//                            if(changed.checked){
//                              this.setState({gender:0})
//                            }
//                          }}
//                          />
//                         <Text>女儿</Text>
//                       </View>
//                     </View>
//                 )
//               }
//             })()
//           }
//       </View>
//     )
//   }
// }
//
// class AddCustomFamily extends React.Component {
//   constructor(props) {
//     super(props)
//     var scale = this.props.show ? 1 : 0;
//     this.state = {relationship:"",name:"",scale:new Animated.Value(scale),show:this.props.show}
//   }
//   componentWillReceiveProps(nextProps){
//     var toScale = 1;
//     if(nextProps.show){
//       this.setState({show:nextProps.show});
//       this.state.scale.setValue(0);
//     }else{
//       this.state.scale.setValue(1);
//       toScale = 0;
//     }
//     Animated.timing(
//       this.state.scale,
//       {
//         toValue: toScale,
//         duration:40,
//       },
//     ).start((c)=>{
//       if(toScale == 0)this.setState({show:nextProps.show});
//     })
//   }
//   render(){
//     if(!this.state.show){
//       return (<View/>)
//     }
//     var width = Dimensions.get('window').width * 4 / 5;
//     return (
//       <View style={[Styles.overlay]} >
//         <Animated.View style={{backgroundColor:'white',width:width,borderWidth:1,borderRadius:20,transform: [{scale: this.state.scale}]}}>
//         <TextInput
//           style={[Styles.input,{height:45,marginLeft:20,marginRight:20,marginTop:20}]}
//           placeholder={"输入关系"}
//           onChangeText={(text) => {
//             this.setState({relationship:text});
//
//           }}
//           value={this.state.relationship}
//           />
//         <TextInput
//           style={[Styles.input,{height:45,marginLeft:20,marginRight:20,marginTop:10}]}
//           placeholder={"姓名"}
//           onChangeText={(text) => {
//             this.setState({name:text})
//           }}
//           value={this.state.name}
//           />
//
//           <View style={{flexDirection:'row'}}>
//             <View style={[Styles.hCenter,{flex:1}]}>
//               <Button style={{marginBottom:10,marginTop:10,width:60,height:40}} title="确定" onTouch={()=>{
//                 if(this.props.confirm)this.props.confirm(this.state);
//                 this.setState({relationship:"",name:""});
//               }}/>
//             </View>
//             <View style={[Styles.hCenter,{flex:1}]}>
//               <Button style={{marginBottom:10,marginTop:10,width:60,height:40}} title="取消" onTouch={()=>{
//                 this.setState({relationship:"",name:""});
//                 if(this.props.cancel)this.props.cancel();
//               }}/>
//             </View>
//           </View>
//         </Animated.View>
//       </View>
//     )
//   }
// }
//
// class AddMyFamily extends BaseComponent {
//   allFamily:[Family]
//   lastPatients:[Patient]
//   haveLocal:Boolean
//   inited:Boolean
//   pressed:Boolean
//   constructor(props){
//     super(props)
//     this.lastPatients = [];
//     this.allFamily = [];
//     var config = {title:"关心自己，更关心家人"}
//     this.showDialog = false;
//     this.haveLocal = false;
//     this.inited =false;
//     this.pressed = false;
//     this.state = {showDialog:false,navigatorBarConfig:config,securityButtonDisable:false,securityTitle:"获取"}
//   }
//   componentDidMount() {
//     super.componentDidMount();
//     var db = DatabaseManager.instance.currentDatabase;
//     var patientView =  new DatabaseView(db,"Patient","PatientView","function(doc) { if(doc.type == 'Patient') emit(doc.date,doc)}",()=>{
//         patientView.setOnDataChangeCallback((data)=>this.onPatientChanged(data));
//     });
//     this.onPatientChanged([]);
//     this.patientView = patientView;
//   }
//   componentWillUnmount(){
//     super.componentWillUnmount();
//     if(this.patientView)this.patientView.stop();
//   }
//
//   onPatientChanged(data){
//     if(this.patientView)this.patientView.stop();
//     var patients = [];
//     this.lastPatients = [];
//     if(!this.inited){
//       this.haveLocal = (data.length>0);
//       this.inited=true;
//     }
//     for (var i = 0; i < data.length; i++) {
//         var patient = new Patient();
//         patient.setProperty(data[i].value);
//         patients.push(patient);
//         this.lastPatients.push(patient);
//     }
//     var male = User.currentUser.gender;
//     var defaultRe = ["父亲","母亲",male?"岳父":"公公",male?"岳母":"婆婆",male?"妻子":"丈夫","子女","子女"];
//     var family = [];
//     for (var i = 0; i < defaultRe.length; i++) {
//       var j = patients.length;
//       var p = null;
//       while (j--) {
//           if (patients[j].relationship === defaultRe[i]) {
//               p = patients[j];
//               break;
//           }
//       }
//       if(p) patients.remove(p);
//       family.push(<Family ref={(c) => {if(this.allFamily.indexOf(c) < 0)this.allFamily.push(c);}} key={i} relationship={defaultRe[i]} patient={p}/>)
//     }
//     for (var i = 0; i < patients.length; i++) {
//       var patient = patients[i];
//       if(patient.relationship !== "我"){
//         family.push(<Family ref={(c) => {if(this.allFamily.indexOf(c) < 0)this.allFamily.push(c);}} key={family.length} relationship={patient.relationship} patient={patient}/>)
//       }
//     }
//     this.setState({family:family})
//   }
//   addPatient(family,cb){
//     if(family.relationship === "我"){
//       var lastPatients = this.lastPatients?this.lastPatients:[];
//       var j = lastPatients.length;
//       while (j--) {
//           if (lastPatients[j].relationship === family.relationship) { //已经存在
//               if(cb)cb();
//               return;
//           }
//       }
//     }
//     if(family.patient){
//       if(cb)cb();
//       return;
//     }
//     if(family.patient || this.checkStringIsNull(family.relationship) || this.checkStringIsNull(family.name)){
//       if(cb)cb();
//       return;
//     };
//     var patient = new Patient();
//     patient.user = User.currentUser.documentID;
//     patient.name = family.name;
//     patient.gender = family.gender;
//     patient.relationship = family.relationship;
//     patient.save(()=>{
//       this.lastPatients.push(patient);
//       if(cb)cb();
//     })
//   }
//   _register(func){
//     if(this.pressed)return;
//     this.pressed = true;
//     var lastPatients = this.lastPatients?this.lastPatients:[];
//     var count = -1;
//     var callback = ()=>{
//       count ++;
//       if(count < this.allFamily.length){
//         if(this.allFamily[count]){
//           var f = this.allFamily[count].state;
//           this.addPatient(f,callback)
//         }else{
//           callback();
//         }
//       }else{
//         User.currentUser.getProfile((p)=>{
//           if(!p.setting.isSetFamily){
//             p.setting.isSetFamily = true;
//             p.save();
//           }
//         })
//         this.patientView.update();
//         this.pressed = false;
//         this.props.navigator.push({
//           component:<CareList navigator={this.props.navigator} isRepay={this.haveLocal} jumpOver={this.props.jumpOver}/>
//         })
//       }
//     }
//     this.addPatient({"relationship":'我',"name":User.currentUser.name},callback);
//   }
//   render(){
//     var su = super.render();
//     return (
//       <View style={[Styles.content]}>
//       {
//         su
//       }
//       <AddCustomFamily show={this.state.showDialog} confirm={this.addFamily.bind(this)} cancel={this.dismissDialog.bind(this)}/>
//       </View>
//     )
//   }
//   addFamily(fa){
//     if(fa){
//       if(this.checkStringIsNull(fa.relationship))return;
//       if(this.checkStringIsNull(fa.name))return;
//       var family = this.state.family;
//        family.push(<Family ref={(c) => this.allFamily.push(c)} key={family.length} relationship={fa.relationship} name={fa.name}/>)
//       this.setState({family:family})
//     }
//     this.dismissDialog();
//   }
//   dismissDialog(){
//     this.setState({showDialog:false})
//   }
//   _render() {
//     return (
//       <View style={[Styles.content]}>
//         <ScrollView>
//           <View style={[Styles.center]}>
//             <Text style={{fontSize:20}}> {new Date().format("yyyy-MM-dd")} </Text>
//           </View>
//
//           {
//             this.state.family
//           }
//
//           <Button style={{width:100,height:40,marginLeft:20,marginTop:5}} title={"再加一个"} onTouch={()=>{
//             this.setState({showDialog:true});
//           }}/>
//
//           <View style={{flexDirection:'row'}}>
//             <Button style={{width:100,height:40,margin:20}} title={"确认"} onTouch={()=>{
//               this._register();
//             }}/>
//             <Button style={{width:200,height:40,margin:20}} title={"跳过，以后再关心"} onTouch={()=>{
//               if(this.props.jumpOver){
//                 this.props.jumpOver();
//                 return;
//               }
//               this.addPatient({"relationship":'我',"name":User.currentUser.name},()=>{
//                 this.props.navigator.push({
//                   component:<Home navigator={this.props.navigator} />
//                 })
//               });
//               User.currentUser.getProfile((p)=>{
//                 if(!p.setting.isSetFamily){
//                   p.setting.isSetFamily = true;
//                   p.save();
//                 }
//               })
//             }}/>
//           </View>
//
//         </ScrollView>
//       </View>
//     );
//   }
// }
//
// module.exports = AddMyFamily;
