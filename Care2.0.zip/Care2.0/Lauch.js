'use strict';
var React = require('react-native');
var {
  View,
  Image,
  StyleSheet,
} = React;
var {BaseComponent} = require('./Styles');
var {w,h,screenWidth} = require('./utils/Porting')
var Login = require('./Login')
var About = require('./About')
var TimerMixin = require('react-timer-mixin');

class Lauch extends BaseComponent {

    render(){
      return (
        <View style={{flex:1}}>
          <Image style={styles.lauchImage} source={require('./images/launch.jpg')}/>
        </View>
        )
    }

    constructor(props){
      super(props)
    }

    componentDidMount(){
      this.setTimeout(
        () => { this.replace(Login) },
        2000
      );
    }
}

var styles = StyleSheet.create({
  lauchImage:{
    flex:1,
    // backgroundColor:'red',
    width:screenWidth(),
    resizeMode:'cover',
  },
}
);
module.exports = Lauch;
