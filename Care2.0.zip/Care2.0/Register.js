'use strict';

var React = require('react-native');

var {
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableHighlight,
  Navigator,
  ScrollView,
  AsyncStorage,
  requireNativeComponent,
} = React;

var {Styles,Button,BaseComponent,Config,Color,Tools,Theme} = require('./Styles');
var MK = require('react-native-material-kit');
const {
  MKRadioButton,
} = MK;
var {MessageDialog} = require('./Dialog');

if (React.Platform.OS === "android")Text = requireNativeComponent('RNChatTextViewManager', null);

var {DatabaseManager} = require("./core/couchbase/Couchbase")
var {User} = require("./core/Models")
var AddMyFamily = require('./AddMyFamily');
var Profile = require('./Profile');
var About = require('./About');
var LastLoginKey = "lastLoginUser";
var {LoginLogic} = require('./JSLibrary/Logic');

class Register extends BaseComponent {
  gender:Number;
  constructor(props){
    super(props)
    var config = {showBackIcon:true,title:"注册新账号"}
    this.gender = 1;
    this.security_code = '';
    this.radioGroup = new MKRadioButton.Group();
    this.state = {navigatorBarConfig:config,securityButtonDisable:true,securityCount:0,security_code:"",phone_number:"",password:"",conform_password:""}
  }
  onLeftPress(){
    this.props.navigator.pop();
  }
  componentDidMount() {
    super.componentDidMount();
  }
  getSecurityCode(){
    do{
      if(this.checkStringIsNull(this.state.phone_number,"手机号不能为空"))break;
      if(!this.isPhoneNumber()){this.showToast("手机号格式错误");break;};
      this.post("users/send_security_code",{"phone_number":this.state.phone_number,"role_type":Config.role_type,"sms_category":2},(data)=>{
        if(data.error){
          this.showToast(data.error)
        }else if(data.security_code){
          this.security_code = data.security_code;
          // this.setState({security_code:data.security_code})
        }
      })
    }while (false);
  }
  openProtocol(){
    this.push(About)
  }
  updateSecurityCount(){
    var currentCount = this.state.securityCount;
    if(currentCount > 0){
      --currentCount;
      this.setState({securityCount:currentCount,securityButtonDisable:currentCount>0});
    }else {
      if(this.updateId){
        clearInterval(this.updateId);
        delete this.updateId;
      }
    }
  }
  _render() {
    return (
      <View style={[Styles.content]}>
        <View style={[Styles.content,{margin:Theme.input_marginleft}]}>
          <View style={styles.inputBg}>
          <TextInput style={[styles.input]} placeholder={"请输入手机号"}
            value={this.state.phone_number}
            textAlign={"center"}
            onChangeText={(text) => this.setState({phone_number: text})}
            keyboardType={"numeric"}
            onEndEditing={()=>{
              if(!this.isPhoneNumber()){
                this.showWarning("手机号格式错误");
                this.setState({securityButtonDisable:true});
              }else{
                this.setState({securityCount:0,securityButtonDisable:false});
              }
            }}
          />
          </View>
          <View style={styles.inputBg}>
          <TextInput style={[styles.input]} placeholder={"请输入密码"}
            value={this.state.password}
            onChangeText={(text) => this.setState({password: text})}
            secureTextEntry={true}
            textAlign={"center"}
            />
          </View>
          <View style={styles.inputBg}>
          <TextInput style={[styles.input]} placeholder={"确认密码"}
            value={this.state.conform_password}
            onChangeText={(text) => this.setState({conform_password: text})}
            secureTextEntry={true}
            textAlign={"center"}
            />
          </View>
          <View style={styles.inputBg}>
            <TextInput style={[styles.input]} placeholder={"验证码"}
              textAlign={"center"}
              onChangeText={(text) => this.state.security_code = text}
              />
            <Button style={[styles.security,Styles.warningBackground]} title={this.state.securityCount > 0 ? this.state.securityCount+"s":"获取"} fontSize={Tools.fixWidth(12)} titleColor={"#f1f1f1"} pressTitleColor={"#f1f1f1"} disable={this.state.securityButtonDisable} onTouch={()=>{
              this.getSecurityCode();
              this.setState({securityCount:60,securityButtonDisable:true});
              if(this.updateId){
                clearInterval(this.updateId);
                delete this.updateId;
              }
              this.updateId = this.setInterval(this.updateSecurityCount.bind(this),1000);
            }}/>
          </View>
          <Button style={[Styles.defaultBackground,styles.register]} title="注册" onTouch={this._register.bind(this)}/>

          <TouchableHighlight style={[Styles.center,{marginTop:Tools.fixWidth(20)}]} underlayColor={'transparent'} onPress={this.openProtocol.bind(this)}>
            <View  style={Styles.center}>
              <Text style={styles.textProtocol}> 注册即表示我同意 </Text>
              <Text style={styles.textProtocol}> 海苔健康的服务条款和隐私协议 </Text>
            </View>
          </TouchableHighlight>
         </View>
        <MessageDialog message={"注册中..."} show={this.state.showDialog || false} />
      </View>
    );
  }
  showloading(dimiss){
    var naxtState = {showDialog:!dimiss};
    this.setState(naxtState)
  }
  _register(){
    do{
      if(this.checkStringIsNull(this.state.phone_number,"手机号不能为空"))break;
      if(!this.isPhoneNumber()){this.showToast("手机号格式错误");break;};
      if(this.checkStringIsNull(this.state.password,"密码不能为空"))break;
      if(this.state.password.length <= 3){this.showToast("密码必须大于3位");break;};
      if(this.state.password != this.state.conform_password){this.showWarning("两次输入的密码不一致");break;}
      if(this.checkStringIsNull(this.state.security_code,"验证码不能为空"))break;
      this.showloading(false);
      var body = {"phone_number":this.state.phone_number,"password":this.state.password,"security_code":this.state.security_code,"role_type":Config.role_type,"gender":this.gender};
      this.post("users/register",body,(data)=>{
          if(data.error){
            this.showloading(true);
            this.showWarning(data.error);
          }else{
            var role_type = Config.role_type;
            var self = this;
            var username = this.state.phone_number;
            var userDocId = (()=>{
                if(role_type == 0){
                  return "doctor_"+username;
                }else {
                  return "patient_"+username;
                }
            })();
            try{
              var lastLogin = {name:self.state.phone_number,password:self.state.password}
              AsyncStorage.setItem(LastLoginKey, JSON.stringify(lastLogin));
            }catch(error){
              console.log(error);
            }
            var Login = require('./Login');
            LoginLogic.Login(userDocId,data,self.props.navigator,(p,error,serverError)=>{
              if(error && !serverError){
                self.showWarning(error);
                self.showloading(true);
                return;
              }
              self.push(Profile);
              self.showloading(true);
            });

          }
      })
    }while (false)
  }
  isPhoneNumber(){
    if(this.checkStringIsNull(this.state.phone_number))return false;
    var reg = /^0?1[3|4|5|8][0-9]\d{8}$/;
    return reg.test(this.state.phone_number);
  }
}

var styles = StyleSheet.create({
  inputBg:{
    borderWidth:1,
    height: Theme.input_height,
    borderColor: Color.gray_border_color,
    borderRadius:Theme.input_height / 2,
    marginTop:Tools.fixHeight(10),
  },
  input:{
    height: Theme.input_height,
    borderColor: Color.gray_border_color,
    borderRadius:Theme.input_height / 2,
    color:'#333333',
    fontSize:Tools.fixWidth(12),
    backgroundColor:'transprent'
  },
  security:{
    position:'absolute',
    width:Tools.fixWidth(46),
    height: Theme.input_height,
    borderRadius:Theme.input_height / 2,
    borderWidth:0,
    right:0,
    top:Tools.fixHeight(0),
  },
  register:{
    marginTop:Tools.fixHeight(36),
    borderRadius:Tools.fixWidth(5),
    backgroundColor:'#62C0B4',
    height:Tools.fixHeight(35)
  },
  textProtocol:{
    color: "#62C0B4",
    fontSize:Tools.fixWidth(12),
    textDecorationLine:"underline",
  }
});


module.exports = Register;
