'use strict';

var React = require('react-native');
var {
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableHighlight,
  Navigator,
  Image,
  Alert,
  NavigatorIOS,
  AsyncStorage,
  ScrollView,
} = React;

var {Styles,Button,BaseComponent,Config,Color,Tools,Theme} = require('./Styles');
var Porting = require('./utils/Porting');
var {DatabaseManager} = require("./core/couchbase/Couchbase");
var Register = require('./Register');
var Home = require('./core/Home2');
var AddMyFamily = require('./AddMyFamily');
var CareList = require('./CareList');
var {User} = require("./core/Models");
var ResetPassword = require('./core/setting/ResetPassword');
var {MessageDialog,PayLoadingDialog} = require('./Dialog');
var PlanList = require('./core/plan/PlanList');
var Profile = require('./Profile');
var MessageManager = require('./core/message/MessageManager');

var LastLoginKey = "lastLoginUser"
var {LoginLogic,VersionLogic} = require('./JSLibrary/Logic');
var loginLogic = new LoginLogic();


class Login extends BaseComponent{

  // static Logout(navigator,cleanPassword){
  //   try{
  //     React.NativeModules.CouchbaseHelper.unBindBaiDuPush((result)=>{
  //
  //     });
  //     Login.SetAutoLogin(false);
  //   }catch (error){
  //     console.log('load user error',error);
  //   }finally {
  //     if(navigator)navigator.popToTop();
  //     DatabaseManager.instance.clean();
  //   }
  // }
  //
  // static SetAutoLogin(autoLogin){
  //   var key = "USER_AUTO_LOGIN";
  //   try {
  //     if(autoLogin){
  //       AsyncStorage.setItem(key,"true");
  //     }else{
  //       AsyncStorage.setItem(key,"false");
  //     }
  //   } catch (e) {
  //
  //   }
  // }
  //
  // static IsAutoLogin(cb){
  //   var key = "USER_AUTO_LOGIN";
  //   try {
  //     AsyncStorage.getItem(key,(error,result)=>{
  //       var autoLogin = false;
  //       if( !error || result){
  //         if(result == "true") autoLogin = true;
  //       }
  //       if(cb)cb(autoLogin);
  //     });
  //   } catch (e) {
  //     if(cb)cb(false);
  //   }
  //
  // }
  //
  // static Login(userDocId,data,navigator,cb){
  //   try{
  //     User.currentUser = null;
  //     var timestamp = new Date().getTime();
  //     DatabaseManager.instance.databaseNamed(userDocId,(db)=>{
  //       db.setSession(data.session || data);
  //       var intervalId = setInterval(()=>{
  //         if(new Date().getTime() - timestamp > 30000){
  //           clearInterval(intervalId);
  //           if(cb)cb(null,"登陆超时");
  //           return;
  //         }
  //         db.getModel(userDocId,(user)=>{
  //           if(user && !User.currentUser){
  //             User.currentUser = user;
  //             React.NativeModules.CouchbaseHelper.getDeviceId((uuid)=>{
  //               var inited = true;
  //               db.addChangeCallback("User",null,(body)=>{
  //                 for (var i = 0; i < body.length; i++) {
  //                   var item = body[i];
  //                   if(User.currentUser && item.type == "User" && item._id == User.currentUser.documentID){
  //                     if(uuid != item.deviceId){
  //                        if(timestamp < item.lastLoginTimeStamp && inited){
  //                          inited = false;
  //                          Alert.alert(
  //                            '提示',
  //                            '您的账号已在其他地方登录',
  //                            [
  //                              {text: 'OK'}
  //                            ]
  //                          );
  //                          Login.Logout(navigator,false);
  //                        }
  //                    }
  //                  }
  //                }
  //              })
  //               var uuidStr =  uuid;
  //               clearInterval(intervalId);
  //               db.checkUploadFile();
  //               Login.SetAutoLogin(true);
  //               BaseComponent.post("users/get_profile_by_userId",{userId:userDocId},(error,data)=>{
  //                 if(error || data.error){
  //                   if(cb)cb(null,error || data.error, data?data.error:null);
  //                 }else if(data.profile){
  //                   var MProfile = require("./core/Models").Profile;
  //                   var profile = new MProfile();
  //                   profile.setProperty(data.profile);
  //                   profile.documentID = data.profile.id;
  //                   if(User.currentUser.profile && User.currentUser.profile != profile.documentID){
  //                     User.currentUser.profile = profile;
  //                     User.currentUser.save();
  //                   }else{
  //                     User.currentUser.profile = profile;
  //                   }
  //                   if(cb)cb(profile);
  //                 }
  //               },Config.webShowForwardServerURL);
  //               try {
  //                 React.NativeModules.CouchbaseHelper.BindBaiDuPush(()=>{
  //                   React.NativeModules.CouchbaseHelper.getBaiduChannelId((id)=>{
  //                     var changed = false;
  //                     if(id && User.currentUser.channel_id !== id){
  //                       User.currentUser.channel_id = id;
  //                       changed = true;
  //                     }
  //                     if(User.currentUser.platform != React.Platform.OS){
  //                       changed = true;
  //                       User.currentUser.platform = React.Platform.OS;
  //                     }
  //                     if(User.currentUser.deviceId != uuidStr){
  //                       changed = true;
  //                       User.currentUser.deviceId = uuidStr;
  //                     }
  //                     if(User.currentUser.lastLoginTimeStamp != timestamp){
  //                       changed = true;
  //                       User.currentUser.lastLoginTimeStamp = timestamp;
  //                     }
  //                     if(changed){
  //                       User.currentUser.save();
  //                     }
  //                   });
  //                 });
  //               } catch (e) {
  //                 console.log(e);
  //                 if(cb)cb(null,e);
  //               }
  //             })
  //           }
  //         });
  //       },300);
  //     });
  //
  //   }catch (error){
  //     console.log('load user error',error);
  //     if(cb)cb(null,error);
  //   }finally {
  //
  //   }
  // }


  constructor(props){
    super(props)
    // this.serverName = (Config.serverType != "生产环境")?Config.serverType:""
    this.state = {phone_number:"",password:""}

    loginLogic.init({deleget:this});
    loginLogic.loadUser();


    // try{
    //   React.NativeModules.CouchbaseHelper.unBindBaiDuPush((result)=>{
    //
    //   });
    //   AsyncStorage.getItem(LastLoginKey,(error,result)=>{
    //     if(!error || result){
    //       var lastLogin = eval("(" + result + ")");
    //       if(lastLogin)
    //       this.setState({phone_number:lastLogin.name,password:lastLogin.password})
    //     }
    //     Login.IsAutoLogin((auto)=>{
    //       if(auto){
    //         this.login();
    //       }
    //     })
    //   });
    // }catch (error){
    //   console.log('load user error');
    // }
    //
    // //判断服务器环境是否变化
    // var server = Tools.getStorageData("server_type",(result)=>{
    // if(result){
    //   if(result != Config.serverType){
    //     this.serverChanged = true;
    //   }
    // }else{
    //   Tools.saveStorageData("server_type",Config.serverType)
    // }
    // });
  }
  setAccountState(phoneNumber,password){
    this.setState({phone_number:phoneNumber,password:password});
  }

  loginSuccess(p,error,serverError){

    if(p || serverError){
      if(p){
        this.push(Home);
      }else if (serverError) {
        this.push(Profile);
      }
      this.showloading(false);
    }else if (error) {
      this.showloading(false);
      this.showWarning(error);
    }
  }

  login(){
    loginLogic.login(this.state.phone_number,this.state.password);
    // if(this.serverChanged){
    //   this.showToast("与之前服务器环境不一样，请卸载后再安装");
    //   return;
    // }
    // do{
    //   if(this.checkStringIsNull(this.state.phone_number,"手机号不能为空"))break;
    //   if(this.isPhoneNumber()){this.showToast("手机号格式错误");break;};
    //   if(this.checkStringIsNull(this.state.password,"密码不能为空"))break;
    //   if(this.state.password.length <= 3){this.showToast("密码必须大于3位");break;};
    //   var role_type = Config.role_type;
    //
    //   var body = {"phone_number":this.state.phone_number,"password":this.state.password,"role_type":role_type};
    //   this.showloading(false);
    //   var self = this;
    //   this.post("users/login",body,(error,data)=>{
    //     if(error || data.error){
    //       this.showToast(error || data.error);
    //       self.showloading(true);
    //     }else{
    //       var username = this.state.phone_number;
    //       var userDocId = (()=>{
    //           if(role_type == 0){
    //             return "doctor_"+username;
    //           }else if(role_type == 1){
    //             return "patient_"+username;
    //           }else if (role_type == 2) {
    //             return "assistant_"+username;
    //           }
    //       })();
    //       Login.Login(userDocId,data,self.props.navigator,(p,error,serverError)=>{
    //         //保存账号密码
    //         try{
    //           if(p || serverError){
    //             if(p){
    //               self.push(Home);
    //             }else if (serverError) {
    //               self.push(Profile);
    //             }
    //             self.showloading(true);
    //           }else if (error) {
    //             self.showloading(true);
    //             self.showWarning(error);
    //           }
    //           var lastLogin = {name:self.state.phone_number,password:self.state.password}
    //           AsyncStorage.setItem(LastLoginKey, JSON.stringify(lastLogin));
    //         }catch(error){
    //           console.log(error);
    //         }
    //       });
    //     }
    //   })
    // }while (false)
  }
  isPhoneNumber(){
    if(this.checkStringIsNull(this.state.phone_number))return false;
    var reg = /^0?1[3|4|5|8][0-9]\d{8}$/;
    return !reg.test(this.state.phone_number);
  }
  showloading(dismiss){
    // this.setState({showDialog:dimiss})
    if(dismiss){
      this.showLoadingDialog(true,"登录中...");
      // NativeDialogManager.showLabelPBDialog("登录中...");
    }else{
      this.showLoadingDialog(false);
      // NativeDialogManager.dismissPBDialog();
    }
  }
  lastRender(){
    return (
      <MessageDialog message={"登陆中..."} show={this.state.showDialog || false} />
    )
  }
  _renderContentView(){
    return (
      <View style={[Styles.content,{backgroundColor:Color.default_color}]}>
        <Image style={{flex:1,justifyContent:'center',width:Porting.screenWidth(),height:Tools.activityHeight()}} source={require('./images/login_bg.png')}>
            <Text style={styles.server}>{loginLogic.serverName}</Text>
            <Image style={styles.logo}
              source={require('./images/login_logo.png')}
              resizeMode={'stretch'}/>
            <TextInput style={[styles.input,{marginTop:Porting.h(135)}]} placeholder={"请输入用户名"} keyboardType={"numeric"}
              value={this.state.phone_number}
              textAlign={"center"}
              placeholderTextColor={'white'}
              onChangeText={(text) => this.setState({phone_number: text})}/>

            <TextInput style={[styles.input,{marginTop:Tools.fixHeight(2)}]} placeholder={"密码"} secureTextEntry={true}
              value={this.state.password}
              textAlign={"center"}
              placeholderTextColor={'white'}
              onChangeText={(text) => this.setState({password: text})}/>

            <View style={{flex:1,justifyContent:'space-between',backgroundColor:'transprent'}}>
              <Button style={styles.login} titleColor='#61c1b5' fontSize={Tools.fixWidth(12)} onTouch={()=>{
                this.login();
              }} title={"登录"}/>

              <View style={[{flexDirection:'row',justifyContent:'space-between'}]}>
                <Button style={styles.button} pressColor={"transparent"} onTouch={()=>{
                    this.props.navigator.push({
                      component:<Register navigator={this.props.navigator}/>
                  })
                }} title={"注册账号"} fontSize={Tools.fixWidth(11)}/>
                <Button style={styles.button} pressColor={"transparent"} onTouch={()=>{
                    this.push(ResetPassword);
                  }} title={"忘记密码"} fontSize={Tools.fixWidth(11)}/>
              </View>
          </View>
        </Image>

      </View>
    );
  }

  _render() {
    if (React.Platform.OS === 'ios'){
      return (
        <View>
          {
          this._renderContentView()
          }
        </View>
      );
    }else{
      return (
        <ScrollView ref='scroll' keyboardShouldPersistTaps={true}>
          {
          this._renderContentView()
          }
        </ScrollView>
      );

    }

  }


}


var styles = StyleSheet.create({
  server:{
        position:'absolute',
        left:5,
        top:22,
  },
  input : {
    backgroundColor:"rgba(255, 255, 255, 0.2)",
    height: Tools.fixWidth(40),
    borderColor: 'gray',
    color:'white',
    fontSize:Tools.fixWidth(11)
  },
  version:{
    color:'#fff',
    marginTop:Tools.fixHeight(12),
    marginBottom:Tools.fixHeight(80)
  },
  logo:{width:Porting.screenWidth() - Porting.w(66),
    height:Porting.h(97),
    marginTop:Porting.h(75),
    marginLeft:Porting.w(33),
    marginRight:Porting.w(33),
    backgroundColor:'transprent',
  },
  login:{
    backgroundColor:'#fff',
    borderRadius:Tools.fixWidth(34)/2,
    borderWidth:0,
    height:Tools.fixWidth(34),
    marginLeft:Tools.fixWidth(33),
    marginRight:Tools.fixHeight(33),
    marginTop:Tools.fixHeight(34),
  },
  button:{
    backgroundColor:'transparent',
    borderWidth:0,
    height:Tools.fixWidth(11),
    marginBottom:Tools.fixHeight(12),
    marginLeft:Porting.w(12),
    marginRight:Porting.w(12),
  }
});

module.exports = Login;
