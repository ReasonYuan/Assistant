//
//  WXPay.m
//  Care
//
//  Created by 王曦 on 16/1/26.
//  Copyright © 2016年 Facebook. All rights reserved.
//

#import "WXPay.h"
#import "WXApiRequestHandler.h"
#import "WXApiManager.h"
#import "AppleIPAddress.h"

static RCTResponseSenderBlock payBlock;
NSString * currentTransactionId = @"";
@implementation WXPay

RCT_EXPORT_MODULE();


RCT_EXPORT_METHOD(sendWxPay:(NSDictionary*)payreq callback:(RCTResponseSenderBlock)callback){
  
  BOOL installed = [WXApi isWXAppInstalled];
  if (installed) {
    NSString *res = [WXApiRequestHandler jumpToBizPay:payreq];
    if( ![@"" isEqual:res] ){
      UIAlertView *alter = [[UIAlertView alloc] initWithTitle:@"支付失败" message:res delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
      [alter show];
    }else{
      payBlock = callback;
      currentTransactionId = [payreq objectForKey:@"out_trade_no"];
    }
  }else{
    if(callback)callback(@[@"failed"]);
    dispatch_async(dispatch_get_main_queue(), ^{
      UIAlertView *alter = [[UIAlertView alloc] initWithTitle:@"未安装微信" message:@"请先安装微信。" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
      [alter show];
    });
    
  }
  
}

RCT_EXPORT_METHOD(getIpAdress:(RCTResponseSenderBlock)callback){
  NSString* ipadress = [AppleIPAddress getIPAddress];
  if(![@"" isEqual:ipadress]){
    callback(@[ipadress]);
  }
}

+(RCTResponseSenderBlock)getPayBlock{
  if (payBlock) {
    return payBlock;
  }
  return nil;
}

+(NSString*)getCurrenTRransactionId{
  return currentTransactionId;
}



@end
