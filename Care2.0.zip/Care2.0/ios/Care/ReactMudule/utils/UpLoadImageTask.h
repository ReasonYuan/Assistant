//
//  UpLoadImageTask.h
//  Practice
//
//  Created by 廖敏 on 16/1/5.
//  Copyright © 2016年 Facebook. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UpLoadImageTask : NSObject

+(UpLoadImageTask*)shareInstance;

+(void)Start;

+(void)Stop;

-(void)addUploadTaskUserId:(NSString *)userId ObjectKey:(NSString *)key;

-(void)removeUploadTaskUserId:(NSString *)userId ObjectKey:(NSString *)key;

-(NSNumber*)leftCount;

@end
     