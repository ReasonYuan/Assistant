//
//  GalleryView.h
//  UICollectionGallery
//
//  Created by 廖敏 on 15/11/1.
//  Copyright © 2015年 Charismatic Megafauna Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol GalleryViewDelete <NSObject>

-(void)onIndexChange:(NSInteger)index;

@end

@interface GalleryView : UIView

@property (nonatomic, strong) NSArray *dataArray;

@property (nonatomic) NSInteger currentIndex;

@property (nonatomic, weak) IBOutlet UICollectionView *collectionView;

@property (nonatomic,weak) id<GalleryViewDelete> delegate;

-(void)setIndex:(NSInteger)currentIndex;

@end
