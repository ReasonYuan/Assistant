//
//  GalleryViewManager.m
//  Practice
//
//  Created by 廖敏 on 15/11/1.
//  Copyright © 2015年 Facebook. All rights reserved.
//

#import "GalleryViewManager.h"
#import "GalleryView.h"

@interface GalleryViewManager() <GalleryViewDelete>
{
  GalleryView* galleryView;
}
@end

@implementation GalleryViewManager

RCT_EXPORT_MODULE()

-(void)onIndexChange:(NSInteger)index
{
  NSNumber* number = [NSNumber numberWithInteger:index];
  [self.bridge.eventDispatcher sendAppEventWithName:@"GalleryViewManager_onIndexChange"
                                               body:number];
}

- (UIView *)view
{
  if(!galleryView)galleryView = [[GalleryView alloc] init];
  galleryView.delegate = self;
  return galleryView;
}

RCT_EXPORT_METHOD(deleteCurrentIndex:(RCTResponseSenderBlock)callBack){
  dispatch_sync(dispatch_get_main_queue(), ^{
    if(galleryView.dataArray){
      NSNumber* currentIndex = [NSNumber numberWithInteger:galleryView.currentIndex];
      NSMutableArray* array = [NSMutableArray arrayWithArray:galleryView.dataArray];
      if(array.count > galleryView.currentIndex){
        [array removeObjectAtIndex:galleryView.currentIndex];
        galleryView.dataArray = array;
        callBack(@[currentIndex]);
      }
    }
  });
}

RCT_EXPORT_METHOD(getCurrentIndex:(RCTResponseSenderBlock)callBack){
  NSNumber* currentIndex = [NSNumber numberWithInteger:galleryView.currentIndex];
  callBack(@[currentIndex]);
}

RCT_CUSTOM_VIEW_PROPERTY(index, NSInteger, GalleryView)
{
  NSNumber* i = json;
  [galleryView setIndex:[i integerValue]];
}


RCT_CUSTOM_VIEW_PROPERTY(dataSource, NSArray, GalleryView)
{
  galleryView.dataArray = json;
}


@end
