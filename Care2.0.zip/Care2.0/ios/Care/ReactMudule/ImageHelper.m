//
//  ImageHelper.m
//  Practice
//
//  Created by 廖敏 on 15/11/19.
//  Copyright © 2015年 Facebook. All rights reserved.
//

#import "ImageHelper.h"
#import "RCTEventDispatcher.h"
#import <AliyunOSSiOS/OSSService.h>
#import "AFNetworking.h"
#import "SequenceTask.h"
#import "UpLoadImageTask.h"
#import <ImageIO/ImageIO.h>


@implementation NSFileManager (CreatDirNotExist)

-(void)checkFileDir:(NSString *)fullPath
{
  @try {
    NSRange range = [fullPath rangeOfString:@"/" options:NSBackwardsSearch];
    if (range.location == NSNotFound) {
      return;
    }
    NSString* dir = [fullPath substringToIndex:range.location];
    NSFileManager* fileManager = [NSFileManager defaultManager];
    if(![fileManager fileExistsAtPath:dir]){
      [fileManager createDirectoryAtPath:dir withIntermediateDirectories:YES attributes:nil error:nil];
    }
  }
  @catch (NSException *exception) {
    
  }
  @finally {
    
  }
  
}

@end

@implementation ImageHelper{
  
}

@synthesize bridge = _bridge;

RCT_EXPORT_MODULE();


- (NSDictionary *)constantsToExport
{
  return @{ @"NOTI_UPLOAD_IMAGE_COMPLETE": NOTI_UPLOAD_IMAGE_COMPLETE ,
            @"NOTI_UPLOAD_IMAGE_PROGRESS":NOTI_UPLOAD_IMAGE_PROGRESS,
            @"NOTI_DOWNLOADLOAD_IMAGE_PROGRESS":NOTI_DOWNLOADLOAD_IMAGE_PROGRESS,
            @"NOTI_DOWNLOAD_IMAGE_COMPLETE":NOTI_DOWNLOAD_IMAGE_COMPLETE,
            @"NOTI_UPLOAD_COUNT_CHANGE":NOTI_UPLOAD_COUNT_CHANGE,
            };
}

-(instancetype)init
{
  self = [super init];
  if(self){
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onImageUploadComplete:) name:NOTI_UPLOAD_IMAGE_COMPLETE object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onImageUploadProcess:) name:NOTI_UPLOAD_IMAGE_PROGRESS object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(onImageUploadcountChange:) name:NOTI_UPLOAD_COUNT_CHANGE object:nil];
  }
  return self;
}

-(void)onImageUploadComplete:(NSNotification*)notif
{
  NSDictionary* obj = notif.object;
  NSString* key = obj[@"key"];
  if(key){
    [self.bridge.eventDispatcher sendAppEventWithName:notif.name
                                                 body:key];
  }
}

-(void)onImageUploadcountChange:(NSNotification*)notif
{
  NSDictionary* obj = notif.object;
  if(obj){
    [self.bridge.eventDispatcher sendAppEventWithName:notif.name
                                                 body:obj];
  }
}


-(void)onImageUploadProcess:(NSNotification*)notif
{
  NSDictionary* obj = notif.object;
  if(obj){
    [self.bridge.eventDispatcher sendAppEventWithName:notif.name
                                                 body:obj];
  }
}

-(void)dealloc
{
  [[NSNotificationCenter defaultCenter] removeObserver:self];
}

+(UIImage*)getLoacalImage:(NSString *)userId imageKey:(NSString *)key expectWidth:(NSInteger)width
{
  if(!key) return nil;
  NSString* documentDir = [ImageHelper getDocumentPath];
  NSFileManager* fileManager = [NSFileManager defaultManager];
  NSArray* imageSearchPaths = @[DIR_IMAGE,DIR_THUMBNAIL_IMAGE,DIR_UDLOAD_IMAGE];
  NSInteger index = 0;
  UIImage* image = nil;
  while (index < imageSearchPaths.count) {
    NSString* dirPath = [NSString stringWithFormat:@"%@/%@/%@",documentDir,userId,[imageSearchPaths objectAtIndex:index]];
    if(![fileManager fileExistsAtPath:dirPath]){
      [fileManager createDirectoryAtPath:dirPath withIntermediateDirectories:YES attributes:nil
                                   error:nil];
    }
    NSString* path = [NSString stringWithFormat:@"%@/%@/%@",userId,[imageSearchPaths objectAtIndex:index],key];
    NSString* fullPath = [NSString stringWithFormat:@"%@/%@",documentDir,path];
    if([fileManager fileExistsAtPath:fullPath]){
      image = [ImageHelper createThumbnailImageFromFile:fullPath MaxWidth:width];
      break;
    }
    index++;
  }
  return image;
}


//获取缩略图
RCT_EXPORT_METHOD(getThumbnailImage:(NSString*)userId imageKey:(NSString*)key expectWidth:(NSInteger)width callback:(RCTResponseSenderBlock)callback){
  if(!key) return;
  NSString* documentDir = [ImageHelper getDocumentPath];
  UIImage *image = [ImageHelper getLoacalImage:userId imageKey:key expectWidth:width];
  if(image){
    NSString* base64Image = [UIImageJPEGRepresentation(image, 1) base64EncodedStringWithOptions:0];
    if(callback)callback(@[@(1),base64Image]);
    image = nil;
  }else{
    NSString* path = [NSString stringWithFormat:@"%@/%@/%@",userId,DIR_THUMBNAIL_IMAGE,key];
    NSString* fullPath = [NSString stringWithFormat:@"%@/%@",documentDir,path];
    [ImageHelper downloadImage:key filePath:fullPath expectWidth:width progressBlock:^(CGFloat process) {
      
    } completeBlock:^(NSError *error) {
      if(!error){
        //        UIImage* image = [UIImage imageWithContentsOfFile:fullPath];
        UIImage* image = [ImageHelper createThumbnailImageFromFile:fullPath MaxWidth:width];
        if(image){
          image = [ImageHelper downscaleImageIfNecessary:image maxWidth:width];
          NSString* base64Image = [UIImageJPEGRepresentation(image, 1) base64EncodedStringWithOptions:0];
          if(callback)callback(@[@(1),base64Image]);
          image = nil;
        }
      }else{
        NSLog(@"download image error :%@",error);
      }
    }];
  }
}

RCT_EXPORT_METHOD(getLeftUploadImageCount:(RCTResponseSenderBlock)callback){
  callback(@[[[UpLoadImageTask shareInstance] leftCount]]);
}

//获取原图
RCT_EXPORT_METHOD(getImage:(NSString*)userId imageKey:(NSString*)key  callback:(RCTResponseSenderBlock)callback){
  
}

RCT_EXPORT_METHOD(uploadImage:(NSString*)userId objectKey:(NSString*)objectKey ){
  //  [[SequenceTask getUploadImageSequenceTask] addUploadTaskUserId:userId ObjectKey:objectKey];
  [[UpLoadImageTask shareInstance] addUploadTaskUserId:userId ObjectKey:objectKey];
}

+(NSString*)getDocumentPath{
  NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
  NSString *documentsDirectory = [paths objectAtIndex:0];
  return documentsDirectory;
}

//缩放图片
+ (UIImage*)downscaleImageIfNecessary:(UIImage*)image maxWidth:(float)maxWidth
{
  UIImage* newImage = image;
  if (image.size.width <= maxWidth) {
    return newImage;
  }
  
  CGSize scaledSize = CGSizeMake(image.size.width, image.size.height);
  if (maxWidth < scaledSize.width) {
    scaledSize = CGSizeMake(maxWidth, (maxWidth / scaledSize.width) * scaledSize.height);
  }
  scaledSize.width = (int)scaledSize.width;
  scaledSize.height = (int)scaledSize.height;
  
  UIGraphicsBeginImageContext(scaledSize); // this will resize
  [image drawInRect:CGRectMake(0, 0, scaledSize.width, scaledSize.height)];
  newImage = UIGraphicsGetImageFromCurrentImageContext();
  if (newImage == nil) {
    NSLog(@"could not scale image");
  }
  UIGraphicsEndImageContext();
  
  return newImage;
}



+(UIImage*)createThumbnailImageFromFile:(NSString *)filePath MaxWidth:(CGFloat)exWidth
{
  CGFloat width = [UIScreen mainScreen].bounds.size.width;
  if(exWidth >= 0) width = exWidth;
  if(!filePath)return nil;
  // use ImageIO to get a thumbnail for a file at a given path
  CGImageSourceRef    imageSource = nil;
  NSString *          path = [filePath stringByExpandingTildeInPath];//格式化路径
  CGImageRef          thumbnail = nil;
  // Create a CGImageSource from the URL.
  imageSource = CGImageSourceCreateWithURL((CFURLRef)[NSURL fileURLWithPath: path], NULL);
  if (imageSource == NULL)
  {
    return nil;
  }
  CFStringRef imageSourceType = CGImageSourceGetType(imageSource);
  if (imageSourceType == NULL)
  {
    CFRelease(imageSource);
    return nil;
  }
  CFRelease(imageSourceType);
  CGFloat scale = [UIScreen mainScreen].scale;
  
  NSDictionary *options = [[NSDictionary alloc] initWithObjectsAndKeys:
                           [NSNumber numberWithBool:YES], (NSString *)kCGImageSourceCreateThumbnailFromImageAlways,
                           [NSNumber numberWithBool:YES], (NSString *)kCGImageSourceCreateThumbnailWithTransform,
                           [NSNumber numberWithFloat:width*scale], (NSString *)kCGImageSourceThumbnailMaxPixelSize, //new image size 800*600
                           nil];
  //create thumbnail picture
  thumbnail = CGImageSourceCreateThumbnailAtIndex(imageSource, 0, (CFDictionaryRef)options);
  CFRelease(imageSource);
  UIImage* thumbnailImage = [UIImage imageWithCGImage:thumbnail];
  CGImageRelease(thumbnail);
  return thumbnailImage;
}

//下载图片到本地路径
+(void)downloadImage:(NSString*)Key filePath:(NSString*)path expectWidth:(NSInteger)width progressBlock:(UploadProgressBlock)progressBlock completeBlock:(CompleteBlock)completeBlock{
  NSFileManager* fileManager = [NSFileManager defaultManager];
  if([fileManager fileExistsAtPath:path]) return;
  [fileManager checkFileDir:path];
  NSURLSessionConfiguration *configuration = [NSURLSessionConfiguration defaultSessionConfiguration];
  AFURLSessionManager *manager = [[AFURLSessionManager alloc] initWithSessionConfiguration:configuration];
  NSInteger eWidth = width;
  if(eWidth <= 0)eWidth=[UIScreen mainScreen].bounds.size.width;
  NSURL *URL = [NSURL URLWithString:[NSString stringWithFormat:@"%@/%@@%ldw_1l",DOWNLOAD_ENDPOINT,Key,eWidth]];
  NSURLRequest *request = [NSURLRequest requestWithURL:URL];
  NSURLSessionDownloadTask *downloadTask = [manager downloadTaskWithRequest:request progress:nil destination:^NSURL *(NSURL *targetPath, NSURLResponse *response) {
    return [[NSURL alloc] initFileURLWithPath:path];
  } completionHandler:^(NSURLResponse *response, NSURL *filePath, NSError *error) {
    if(error && filePath){
      [fileManager removeItemAtPath:filePath error:nil];
    }
    if(completeBlock)completeBlock(error);
  }];
  [downloadTask resume];
}



@end
