//
//  ImageHelper.h
//  Practice
//
//  Created by 廖敏 on 15/11/19.
//  Copyright © 2015年 Facebook. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "RCTBridgeModule.h"

typedef void (^UploadProgressBlock) (CGFloat process);
typedef void (^CompleteBlock) (NSError* error);

@interface NSFileManager (CreatDirNotExist)

//检查文件dir目录是否存在，不存在新建
-(void)checkFileDir:(NSString*)fullPath;

@end

@interface ImageHelper : NSObject  <RCTBridgeModule>

+( UIImage* )getLoacalImage:(NSString*)userId imageKey:(NSString*)key expectWidth:(NSInteger)width;

+(void)downloadImage:(NSString*)Key filePath:(NSString*)path expectWidth:(NSInteger)width progressBlock:(UploadProgressBlock)progressBlock completeBlock:(CompleteBlock)completeBlock;

+(NSString*)getDocumentPath;


+(UIImage*)createThumbnailImageFromFile:(NSString*)path MaxWidth:(CGFloat)width;
@end
