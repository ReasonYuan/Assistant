//
//  ScannerViewController.h
//  DoctorPlus_ios
//
//  Created by 廖敏 on 15/7/16.
//  Copyright (c) 2015年 廖敏. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ScannerViewController : UIViewController

@end
