//
//  TestCameraViewController.h
//  Care
//
//  Created by 廖敏 on 15/12/20.
//  Copyright © 2015年 Facebook. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TestCameraViewController : UIViewController

@end
