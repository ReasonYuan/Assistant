//
//  CropView.h
//  MMCamScanner
//
//  Created by 廖敏 on 15/7/28.
//  Copyright (c) 2015年 madapps. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface CropView : UIView


@end
