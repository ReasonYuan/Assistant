//
//  QBImagePerviewViewController.m
//  QBImagePicker
//
//  Created by 廖敏 on 15/12/4.
//  Copyright © 2015年 Katsuma Tanaka. All rights reserved.
//

#import "QBImagePerviewViewController.h"
#import "QBImagePickerController.h"

@interface QBImagePerviewViewController ()
{
    BOOL _isThumbnail;
    UIImageView* _radioImage;
}

@property (weak, nonatomic) IBOutlet UIImageView *ImageView;

@end

@implementation QBImagePerviewViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _isThumbnail = YES;
    _radioImage = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 30, 30)];
    _radioImage.image = [UIImage imageNamed:@"unchecked.png"];
    UIButton* leftView = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 70, 30)];

    UILabel* leftTitle = [[UILabel alloc] initWithFrame:CGRectMake(30, 0, 35, 30)];
    leftTitle.text = @"原图";
    [leftView addSubview:_radioImage];
    [leftView addSubview:leftTitle];
    UIBarButtonItem* leftSpace = [[UIBarButtonItem alloc] initWithCustomView:leftView];
    [leftView addTarget:self action:@selector(changeThumbnail) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *rightSpace = [[UIBarButtonItem alloc] initWithTitle:@"发送" style:UIBarButtonItemStylePlain target:self action:@selector(perviewSend)];

    NSDictionary *attributes = @{ NSForegroundColorAttributeName: [UIColor blackColor] };
    UIBarButtonItem *infoButtonItem =[[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:NULL];
    infoButtonItem.enabled = NO;
    [infoButtonItem setTitleTextAttributes:attributes forState:UIControlStateNormal];
    [infoButtonItem setTitleTextAttributes:attributes forState:UIControlStateDisabled];
    
    self.toolbarItems = @[leftSpace, infoButtonItem, rightSpace];
   
    
    if(self.asset){
        
        CGSize itemSize = self.view.frame.size;
        CGFloat scale = [UIScreen mainScreen].scale;

        [[PHCachingImageManager new] requestImageForAsset:self.asset
                                    targetSize:CGSizeMake(itemSize.width*scale, itemSize.height*scale)
                                    contentMode:PHImageContentModeAspectFit
                                        options:nil
                                  resultHandler:^(UIImage *result, NSDictionary *info) {
                                      self.ImageView.image = result;
                                  }];
    }
}

-(void)changeThumbnail{
    _radioImage.image = [UIImage imageNamed:_isThumbnail?@"checked.png":@"unchecked.png"];
    _isThumbnail = !_isThumbnail;
}

-(void)perviewSend {
    QBImagePickerController *imagePickerController = self.imagePickerController;
    if(self.asset){
        if ([imagePickerController.delegate respondsToSelector:@selector(qb_imagePickerController:didSelectPerviewAsset:isThumbnail:)]) {
            [imagePickerController.delegate qb_imagePickerController:imagePickerController didSelectPerviewAsset:self.asset isThumbnail:_isThumbnail];
        }

    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
