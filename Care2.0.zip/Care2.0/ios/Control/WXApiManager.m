//
//  WXApiManager.m
//  SDKSample
//
//  Created by Jeason on 16/07/2015.
//
//

#import "WXApiManager.h"
#import "WXPay.h"
#import "AFNetworking.h"
@implementation WXApiManager
BOOL isPaySuccess = NO;
#pragma mark - LifeCycle
+(instancetype)sharedManager {
    static dispatch_once_t onceToken;
    static WXApiManager *instance;
    dispatch_once(&onceToken, ^{
        instance = [[WXApiManager alloc] init];
    });
    return instance;
}

- (void)dealloc {
    self.delegate = nil;
    [super dealloc];
}

#pragma mark - WXApiDelegate
- (void)onResp:(BaseResp *)resp {
    if ([resp isKindOfClass:[SendMessageToWXResp class]]) {
        if (_delegate
            && [_delegate respondsToSelector:@selector(managerDidRecvMessageResponse:)]) {
            SendMessageToWXResp *messageResp = (SendMessageToWXResp *)resp;
            [_delegate managerDidRecvMessageResponse:messageResp];
        }
    } else if ([resp isKindOfClass:[SendAuthResp class]]) {
        if (_delegate
            && [_delegate respondsToSelector:@selector(managerDidRecvAuthResponse:)]) {
            SendAuthResp *authResp = (SendAuthResp *)resp;
            [_delegate managerDidRecvAuthResponse:authResp];
        }
    } else if ([resp isKindOfClass:[AddCardToWXCardPackageResp class]]) {
        if (_delegate
            && [_delegate respondsToSelector:@selector(managerDidRecvAddCardResponse:)]) {
            AddCardToWXCardPackageResp *addCardResp = (AddCardToWXCardPackageResp *)resp;
            [_delegate managerDidRecvAddCardResponse:addCardResp];
        }
    }else if([resp isKindOfClass:[PayResp class]]){
        //支付返回结果，实际支付结果需要去微信服务器端查询
      NSString *strMsg,*strTitle = [NSString stringWithFormat:@"支付结果"];
      
      switch (resp.errCode) {
            case WXSuccess:
                NSLog(@"支付成功－PaySuccess，retcode = %d", resp.errCode);
//                [WXApiManager getWxPayResult:[WXPay getCurrenTRransactionId]];
                [WXPay getPayBlock](@[@"success"]);
                break;
                
            default:
            [WXPay getPayBlock](@[@"failed"]);
//                strMsg = [NSString stringWithFormat:@"支付结果：失败！retcode = %d, retstr = %@", resp.errCode,resp.errStr];
//                NSLog(@"错误，retcode = %d, retstr = %@", resp.errCode,resp.errStr);
//                UIAlertView *alert = [[UIAlertView alloc] initWithTitle:strTitle message:strMsg delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
//                [alert show];
//                [alert release];
                break;
        }
      
    }

}

- (void)onReq:(BaseReq *)req {
    if ([req isKindOfClass:[GetMessageFromWXReq class]]) {
        if (_delegate
            && [_delegate respondsToSelector:@selector(managerDidRecvGetMessageReq:)]) {
            GetMessageFromWXReq *getMessageReq = (GetMessageFromWXReq *)req;
            [_delegate managerDidRecvGetMessageReq:getMessageReq];
        }
    } else if ([req isKindOfClass:[ShowMessageFromWXReq class]]) {
        if (_delegate
            && [_delegate respondsToSelector:@selector(managerDidRecvShowMessageReq:)]) {
            ShowMessageFromWXReq *showMessageReq = (ShowMessageFromWXReq *)req;
            [_delegate managerDidRecvShowMessageReq:showMessageReq];
        }
    } else if ([req isKindOfClass:[LaunchFromWXReq class]]) {
        if (_delegate
            && [_delegate respondsToSelector:@selector(managerDidRecvLaunchFromWXReq:)]) {
            LaunchFromWXReq *launchReq = (LaunchFromWXReq *)req;
            [_delegate managerDidRecvLaunchFromWXReq:launchReq];
        }
    }
}

+(void)getWxPayResult:(NSString*)transactionId {
  isPaySuccess = NO;
  NSURLSessionConfiguration *configuration = [NSURLSessionConfiguration defaultSessionConfiguration];
  AFURLSessionManager *manager = [[AFURLSessionManager alloc] initWithSessionConfiguration:configuration];
  
  NSString* ulrStirng = @"http://120.27.199.93:5000/users/get_doctors";
  NSMutableDictionary * parame = [[NSMutableDictionary alloc] init];
  [parame setValue:transactionId forKey:@"transaction_id"];
  
//  [parame setValue:@"1" forKey:@"page"];
//  [parame setValue:@"5" forKey:@"pageSize"];
//  
  NSMutableURLRequest* urlrequest = [[AFJSONRequestSerializer serializer] requestWithMethod:@"POST" URLString:ulrStirng parameters:parame error:nil];
//  [urlrequest setValue:@"application/json" forHTTPHeaderField:@"Accept"];
//  [urlrequest setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
  
  NSURLSessionDataTask *dataTask = [manager dataTaskWithRequest:urlrequest completionHandler:^(NSURLResponse *response, id responseObject, NSError * error) {
    NSString *strMsg,*strTitle = [NSString stringWithFormat:@"支付结果"];
    if (error) {
      NSLog(@"Error: %@", error);
      isPaySuccess = NO;
    } else {
      NSLog(@"%@ %@", response, responseObject);
      isPaySuccess = YES;
    }
    if (isPaySuccess) {
      strMsg = @"支付结果：成功！";
      [WXPay getPayBlock](@[@"success"]);
    }else{
      strMsg = @"支付结果：失败！";
      [WXPay getPayBlock](@[@"failed"]);
    }
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:strTitle message:strMsg delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    [alert show];
    [alert release];
  }];
  [dataTask resume];

}

@end
