'use strict';

var React = require('react-native');
var {
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableHighlight,
  Navigator,
  ListView,
} = React;

var {Styles,Button,BaseComponent} = require('./Styles');
var {User,Patient} = require("./core/Models")
var {DatabaseManager,DatabaseView} = require('./core/couchbase/Couchbase');
var Home = require('./core/Home');

class CareItme extends React.Component{
  constructor(props){
    super(props);
    this.state={relationship:this.props.relationship,name:this.name,charge:this.props.charge?this.props.charge:0,discount_charge:this.props.discount_charge?discount_charge:0}
  }
  render(){
    return (
      <View style={{flexDirection:'row',marginTop:5,marginBottom:5}}>
        <View style={[Styles.hCenter,{flex:1,marginLeft:20,flexDirection:'row'}]}>
          <Text style={{fontSize:20}}> {this.state.relationship + ":"} </Text>
          <Text style={{fontSize:20}}> {this.props.name} </Text>
        </View>
        {
          (()=>{
            if(this.props.isRepay){
              return (
                <View style={{flex:2}}/>
              )
            }else{
              return (
                <View style={{flex:2,flexDirection:'row'}}>
                  <View style={[Styles.hCenter,{flex:1}]}>
                    <Text style={{fontSize:20}}> {this.state.charge} </Text>
                  </View>
                  <View style={[Styles.hCenter,{flex:1}]}>
                    <Text style={{fontSize:20}}> {this.state.discount_charge?this.state.discount_charge:"-"} </Text>
                  </View>
                </View>
              )
            }
          })()
        }

      </View>
    )
  }
}

class CareList extends BaseComponent {
  unPayPatients:[Patient];
  isPaying:Boolean;
  constructor(props){
    super(props)
    this.careItems = [];
    this.unPayPatients= [];
    var ds = new ListView.DataSource({rowHasChanged: (r1, r2) => r1 !== r2});
    var leftButtonTitle = this.props.jumpOver?"返回":""
    var config = {title:"健康年费",showBackIcon:true}
    if(this.props.isRepay){
      config = {title:"补交",leftButtonTitle:"返回"}
    }
    this.isPaying = false;
    this.state = {vipCode:"",startTime:User.currentUser.payStart,endTime:User.currentUser.payEnd,navigatorBarConfig:config,dataSource:ds.cloneWithRows([]),charge:0,discount_charge:0,total_charge:0,total_discount_charge:0}
  }
  componentDidMount(){
    super.componentDidMount();
    var db = DatabaseManager.instance.currentDatabase;
    var patientView =  new DatabaseView(db,"Patient","PatientView","function(doc) { if(doc.type == 'Patient') emit(doc.date,doc)}",()=>{
        patientView.setOnDataChangeCallback((data)=>this.onPatientChanged(data));
    });
    this.patientView = patientView;
  }
  componentWillUnmount(){
    super.componentWillUnmount();
    if(this.patientView)this.patientView.stop();
    delete this.patientView;
  }
  onPatientChanged(data){
    this.unPayPatients = [];
    if(this.patientView)this.patientView.stop();
    delete this.patientView;
    var patients = [];
    for (var i = 0; i < data.length; i++) {
        var patient = new Patient();
        patient.setProperty(data[i].value);
        patients.push(patient);
        if(!patient.isPay)this.unPayPatients.push(patient);
    }
    if(this.unPayPatients.length){
      this.post("charge/get_personal_payment",{user_id:User.currentUser.documentID,need_pay_number:this.unPayPatients.length},(data)=>{
        this.onPaymentReturn(data);
      });
    }
    this.setState({dataSource:this.state.dataSource.cloneWithRows(patients)})
  }
  onVipCodeEdit(){
    if(this.unPayPatients.length){
      this.post("charge/get_personal_payment",{user_id:User.currentUser.documentID,need_pay_number:this.unPayPatients.length,discount_code:this.state.vipCode},(data)=>{
        this.onPaymentReturn(data);
      });
    }
  }
  onPaymentReturn(data){
    if(data && data.payment_info){
      var info = data.payment_info;
      this.discount_charge = info.discount_charge;
      this.charge = info.charge;
      for (var i = 0; i < this.careItems.length; i++) {
        this.careItems[i].setState(info);
      }
      this.setState(info);
    }
  }
  renderListView(rowData,s,r){
    return(
      <CareItme isRepay={this.props.isRepay} ref={(c)=>this.careItems.push(c)} relationship={rowData.relationship} name={rowData.name} charge={this.charge} discount_charge={this.discount_charge}/>
    )
  }
  onLeftPress(){
    this.pop();
    // if(this.props.jumpOver){
    //   this.props.jumpOver();
    // }else{
    //   // this.props.navigator.pop()
    // }
  }
  onRightPress(){
    // if(!this.props.isRepay)this.props.navigator.push({
    //   component: <Home navigator={this.props.navigator}/>
    // })
  }
  pay(){
    if(this.isPaying)return;
    this.isPaying = true;
    this.post("charge/pay_success",{user_id:User.currentUser.documentID},(data)=>{
      if(data.success){
        for (var i = 0; i < this.unPayPatients.length; i++) {
          var patient = this.unPayPatients[i];
          patient.isPay = true;
          patient.save();
        }
        DatabaseManager.sharedInstance.currentDatabase.addChangeCallback("User",this,(data)=>{
          this.isPaying = false;
          for (var i = 0; i < data.length; i++) {
            DatabaseManager.sharedInstance.currentDatabase.removeChangeCallback("User",this);
            var tmp = data[i];
            if(tmp.type == "User"){
              if(tmp.isVIP){
                var profile = User.currentUser.profile;
                User.currentUser.setProperty(tmp);
                User.currentUser.profile = profile;
                this.pop();
              }
            }
          }

        })

      }else{
        this.showWarning(data);
        this.isPaying  = false;
      }
    })
  }
  _renderNormalPay(){
    return (
      <View>
        <View style={[{flexDirection:"row"},Styles.center]}>
            <TextInput style={[Styles.input,{width:80,height:40}]} maxLength={4} placeholder={"VIP优惠码"} value={this.state.vipCode}
            onChangeText={(text)=>this.setState({vipCode:text})}
            onEndEditing={this.onVipCodeEdit.bind(this)}/>
            <Button style={[Styles.input,{width:180,height:40}]} title={"宝洁员工关爱计划"}/>
        </View>

        <View style={{flexDirection:"row"}}>
          <View style={{flex:1}}>
          </View>
          <View style={[{flex:1},Styles.center]}>
            {
              (()=>{
                if(this.state.total_charge){
                  return(
                    <Text style={styles.priceText}> {"原价:"+this.state.total_charge} </Text>
                  )
                }
              })()
            }
            {
              (()=>{
                if(this.state.total_discount_charge){
                  return(
                    <Text style={styles.priceText}> {"优惠价:"+this.state.total_discount_charge} </Text>
                  )
                }
              })()
            }
          </View>
        </View>
        {
          (()=>{
            if(this.unPayPatients.length > 0){
              return(
                <View style={[Styles.center,{marginTop:5}]}>
                  <Button style={{width:160,height:40,marginRight:20,marginBottom:10}} title="支付" onTouch={this.pay.bind(this)}/>
                </View>
              )
            }
          })()
        }
      </View>
    )
  }
  _renderRePay(){
    return (
      <View style={{flexDirection:'row'}}>
        <View style={{flex:1,height:44,justifyContent:'center',alignItems:'center'}}>
         <Text style={styles.priceText}> {"合计年费:"+this.state.total_charge} </Text>
        </View>
        <View style={{flex:1,height:44,justifyContent:'center',alignItems:'center'}}>
          <Button style={{width:100,height:40}} title={'补交'} onTouch={this.pay.bind(this)}/>
        </View>
      </View>
    )
  }
  _render() {
    return (
      <View style={[Styles.content,{justifyContent:'flex-end',marginTop:5,marginBottom:5}]}>

        {
          (()=>{
            if(this.props.isRepay){
              return this._renderRePay()
            }else{
              return this._renderNormalPay()
            }
          })()
        }

      </View>
    );
  }

}

CareList.propTypes = {
  isRepay:React.PropTypes.bool, //是否是补交
}

CareList.defaultProps = {
  isRepay:false,
}

var styles = StyleSheet.create({
  priceText:{
    fontSize:18,
    margin:2
  }
});

module.exports = CareList;
