
'use strict';

var React = require('react-native');
var {
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableHighlight,
  Navigator,
  ScrollView,
  Image,
  PanResponder,
  LayoutAnimation,
  ActionSheetIOS,
} = React;

var {User,Patient} = require('./core/Models')
var {Styles,Button,BaseComponent,Color,Tools,Theme,ImageView} = require('./Styles');
var {DatabaseManager} = require("./core/couchbase/Couchbase");

class PersonalInfo extends BaseComponent {
  constructor(props){
    super(props)
    var title = this.props.title || "更改个人信息";
    var config = {title:title,showBackIcon:true,rightTextColor:Color.default_color}
    this.state = {navigatorBarConfig:config,value:this.props.value || ""}
  }
  onLeftPress(){
    this.pop();
  }
  onRightPress(){

  }
  onSureClick(){
    if(this.props.onRightPress && this.state.value != '')this.props.onRightPress(this.state.value);
  }
  _render() {
    return (
      <View style={[styles.full,{backgroundColor:'white'}]}>
        <View style={Styles.content}>
          <TextInput style={styles.input} maxLength={this.props.maxLength||100000} value={this.state.value} onChangeText={(change)=>this.setState({value:change})} ></TextInput>
          <View style={styles.line}/>
        </View>
        <Button
          title="确认"
          titleColor="#fff"
          style={styles.sure}
          onTouch={()=>{this.onSureClick()}}/>
      </View>
    );
  }
}


var styles = StyleSheet.create({
  full:{
    flex:1,
    paddingHorizontal:Tools.fixWidth(12)
  },
  input:{
    height:Tools.fixWidth(40),
    fontSize:Tools.fixWidth(14),
    marginTop:Tools.fixWidth(10),
    color:"#999",
    backgroundColor:'transprent',
  },
  line:{
    height:Tools.fixWidth(1),
    backgroundColor:Color.white_border_color,
  },
  sure:{
    marginBottom:Tools.fixWidth(50),
    height:Tools.fixWidth(35),
    backgroundColor:'#65c0b5'
  },
  item:{
    marginTop:20,
    marginLeft:Tools.fixWidth(12),
    marginRight:Tools.fixWidth(12),
    height:Tools.fixWidth(35),
  },
  item_content:{
    flex:1,
    flexDirection:'row',
    alignItems:'center',
    justifyContent:'space-between',
    borderColor:'#c1c1c1',
    borderWidth:1,
    borderRadius:Tools.fixWidth(5),
    paddingLeft:Tools.fixWidth(5),
    paddingRight:Tools.fixWidth(5),
  },
  text_value:{
    flex:1,
    color:"#999999",
    fontSize:Tools.fixWidth(12),
    backgroundColor:'transprent',
  }
});

module.exports = PersonalInfo;
