'use strict';
var React = require('react-native');
// var NetInfo = require('./utils/NetInfo');
var TimerMixin = require('react-timer-mixin');
var reactMixin = require('react-mixin');
var Dimensions = require('Dimensions');
var Config = require('./core/Config');
var Color = require('./Color');
var Tools = require('./utils/Tools');
var DEFAULT_BACKGROUND = Color.default_color;
var NAVIGATION_BAR_HEIGHT = React.Platform.OS === 'ios'?64:44;
var NAVIGATION_BAR_TEXT_COLOR = "rgba(13,13,13,0.8)";
var ISIOS = React.Platform.OS === 'ios'
var {Fetch} = require('./JSLibrary/Logic')
var NativeDialogManager = React.NativeModules.DialogManager;
var {
  TouchableHighlight,
  Text,
  View,
  StyleSheet,
  Image,
  Animated,
  LayoutAnimation,
  ListView,
} = React;

var Styles = StyleSheet.create({
  content : {
    flex: 1
  },
  defaultBackground:{
    backgroundColor:DEFAULT_BACKGROUND
  },
  warningBackground:{
    backgroundColor:"#E15064"
  },
  center:{    //居中
    alignItems:'center',
    justifyContent:'center'
  },
  hCenter:{           //水平居中
    alignItems:'center',
  },
  vCenter:{           //垂直居中
    justifyContent:'center'
  },
  roundButton:{       //圆角矩形

  },
  input:{             //输入框
    height: 60,
    borderColor: 'gray',
    borderWidth: 1,
    margin:10,
  },
  line:{ //分割线
    backgroundColor:Color.white_border_color,
    height:1
  },
  overlay: {
    position: 'absolute',
    top: 0,
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: 'rgba(221, 221, 221, 0.5)',
    flex: 1,
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
  },
  warning:{
    position:'absolute',
    justifyContent: 'center',
    alignItems:'center',
    overflow:'hidden',
    left:0,
    top:-NAVIGATION_BAR_HEIGHT,
    right:0,
    height:NAVIGATION_BAR_HEIGHT,
    backgroundColor:'#CB4A5C'
  },
});


//自定义的一些控件
//Button
class Button extends React.Component {
  constructor(props) {
    super(props)
    this.state={titleColor:this.props.titleColor};
  }
  onPress(){
    if(this.props.onPress)this.props.onPress();if(this.props.onTouch)this.props.onTouch();
  }
  _renderNormal(){
    return (
      <TouchableHighlight
        {...this.props}
        onPress={()=>{this.onPress()}}
        style={[
          Styles.center,
          {width:this.props.width,height:this.props.height},
          {backgroundColor: '#48BBEC',borderColor: '#48BBEC',borderWidth: 1,borderRadius: 4},
          this.props.style
        ]}
        underlayColor={this.props.pressColor}
        >
        <Text style={{color:this.state.titleColor,fontSize:this.props.fontSize}}>{this.props.title}</Text>
      </TouchableHighlight>
    )
  }
  _renderDisable(){
    return (
      <TouchableHighlight
        {...this.props}
        style={[
          Styles.center,
          {width:this.props.width,height:this.props.height},
          {borderColor:this.props.pressColor,borderWidth: 1,borderRadius: 4},
          this.props.style,
          {backgroundColor:this.props.pressColor}
        ]}
        underlayColor={this.props.pressColor}
        >
        <Text style={{color:this.props.pressTitleColor,fontSize:this.props.fontSize}}>{this.props.title}</Text>
      </TouchableHighlight>
    )
  }
  render(){
    if(this.props.disable){
      return this._renderDisable();
    }
    return this._renderNormal();
  }
}

Button.propTypes = {
  ...TouchableHighlight.propTypes,
  width:React.PropTypes.number,
  height:React.PropTypes.number,
  onTouch:React.PropTypes.func,
  title:React.PropTypes.string,
  titleColor:React.PropTypes.string,
  pressTitleColor:React.PropTypes.string,
  fontSize:React.PropTypes.number,
  pressColor:React.PropTypes.string,
  disable:React.PropTypes.bool,
}

Button.defaultProps = {
  height:60,
  title:"",
  titleColor:'white',
  pressTitleColor:'white',
  fontSize:16,
  pressColor:'gray',
  disable:false,
}


class ImageView extends React.Component {
  constructor(props) {
    super(props);
    this.state = {imageData:null};
  }
  componentWillMount(){
    this.setImage(this.props.imageKey)
    var {DatabaseManager,Database} = require("./core/couchbase/Couchbase");
    this.db = DatabaseManager.instance.currentDatabase;
    this.listener = this.onUserChange.bind(this);
    this.db.addImageStatusChangeCallback(this.listener);
  }
  componentWillUnmount(){
    this.db.removeImageStatusChangeCallback(this.listener);
  }
  onUserChange(imageKey){
    if(imageKey && imageKey == this.imageKey){
      var {User} = require('./core/Models');
      React.NativeModules.ImageHelper.getThumbnailImage(User.currentUser.documentID,imageKey,false,width,(progress,data)=>{
        if(data){
          self.setState({
            imageData:data,
          })
        }
      });
    }
  }
  componentWillReceiveProps(nextProps) {
    if(this.props.imageKey !== nextProps.imageKey){
      this.clear = true
      this.setState({defaultSource:nextProps.defaultSource})
      this.setImage(nextProps.imageKey);
    }
  }
  setImage(imageKey){
    if(imageKey && (this.imageKey != imageKey || this.state.imageData == null)){
      var self = this;
      var width = Dimensions.get('window').width;
      if(this.props.thumbnailWidth) width = this.props.thumbnailWidth;
      this.setState({imageData:null});
      if(imageKey){
        var {User} = require('./core/Models');
        ((k)=>{
          React.NativeModules.ImageHelper.getThumbnailImage(User.currentUser.documentID,k,false,width,(progress,data)=>{
            if(data && k == this.imageKey){
              self.setState({
                imageData:data,
              })
            }
          });
        })(imageKey)
      }
    }
    this.imageKey = imageKey;
  }
  setNativeProps(nativeProps) {
    if(React.Platform.OS==="ios")this._root.setNativeProps(nativeProps);
  }
  render(){
    var imageUri = null;
    if(this.imageKey && this.state.imageData){
      imageUri = "data:image/jpg;base64," + this.state.imageData;
    }else{
      if(this.props.source){
        return <Image ref={component => this._root = component} {...this.props} />
      }
      if(this.props.defautIcon){
        return <Image ref={component => this._root = component} {...this.props} source={this.props.defautIcon}/>
      }
    }
    return(
        <Image ref={component => this._root = component} {...this.props}  source={imageUri && {uri:imageUri}}/>
    )
  }
}


ImageView.propTypes = {
  ...Image.propTypes,
  imageKey:React.PropTypes.string,//阿里云上的key
}

ImageView.defaultProps = {
  imageKey:null,
}



//Navigationbar
class NavigationBar extends React.Component {
  constructor(props) {
    super(props);
  }

  //渲染左边按钮
  renderLeft(){
    if(this.props.showBackIcon || this.props.leftButtonTitle){
      return(
        <TouchableHighlight
          style={istyles.leftContainer}
          underlayColor="transprent"
          onPress={this.props.onLeftPress}>
          {this.renderLeftContent()}
        </TouchableHighlight>
      )
    }
  }

  //左边按钮的内容
  renderLeftContent(){
    if(this.props.showBackIcon){
      return(<Image style={istyles.leftImg} source={require('./images/icon_navigation_back.png')}/>)
    }else if(this.props.leftButtonTitle){
      return(
        <Text style={istyles.leftTitle}>
          {this.props.leftButtonTitle}
        </Text>
      )
    }
  }

  //渲染右边按钮
  renderRight(){
    if(this.props.rightButtonImage || this.props.rightButtonTitle){
      return(
        <TouchableHighlight
          style={istyles.rightContainer}
          underlayColor="transprent"
          onPress={this.props.onRightPress}>
          {this.renderRightContent()}
        </TouchableHighlight>
      )
    }
  }

  //左边按钮的内容
  renderRightContent(){
    if(this.props.rightButtonImage){
      return(<Image style={istyles.rightImg} source={this.props.rightButtonImage}/>)
    }else if(this.props.rightButtonTitle){
      return(
        <Text style={[istyles.rightTitle,this.props.rightTextColor&&{color:this.props.rightTextColor}]}>
          {this.props.rightButtonTitle}
        </Text>
      )
    }
  }

  render(){
    return (
      <View style={istyles.topbar}>
        {this._renderNofity()}
        <View style={istyles.content}>
          <View style={istyles.btnContainer}>{this.renderLeft()}</View>

          <Text numberOfLines={1}
            style={istyles.titleContainer}>
            <Text
              numberOfLines={1}
              style={istyles.title}>
                {this.props.title}
            </Text>
          </Text>
          <View style={istyles.btnContainer}>{this.renderRight()}</View>
          </View>
          <Image style={istyles.line} source={require('./images/line_nav_bar.png')} />
        </View>
    )
  }

   _renderNofity(){
     if(ISIOS){
       return (<View style={istyles.notify} />);
     }
   }
}


NavigationBar.propTypes = {
  title:React.PropTypes.string,
  leftButtonTitle:React.PropTypes.string,
  rightButtonTitle:React.PropTypes.string,
  onLeftPress:React.PropTypes.func,
  onRightPress:React.PropTypes.func
}

NavigationBar.defaultProps = {
  leftButtonTitle:null,
  rightButtonTitle:null,
  title:"",
}

var istyles = StyleSheet.create({
  topbar:{
    height:NAVIGATION_BAR_HEIGHT,
    borderBottomWidth:1,
    borderColor:'#DAD8D9',
    backgroundColor:Color.navigation_bar_bg_color,
  },
  notify:{
    height:20,//不自适应是因为各个屏幕都是20
    backgroundColor:Color.navigation_bar_bg_color,
  },
  content:{
    height:42,//42.5-2 2是下面线的宽度
    flexDirection:'row',
    justifyContent:'center',
    backgroundColor:'#fff'
  },
  btnContainer:{
    width:Tools.fixWidth(70),
  },
  leftContainer:{
    flex:1,
    paddingLeft:Tools.fixWidth(12),
    justifyContent:'center',
  },
  rightContainer:{
    flex:1,
    paddingRight:Tools.fixWidth(12),
    alignItems:'flex-end',
    justifyContent:'center',
  },
  titleContainer:{
    flex:1,
    textAlign:'center',
    alignSelf:'center',
    alignItems:'center',
    marginHorizontal:Tools.fixWidth(5),
    justifyContent:'center',
    // backgroundColor:'#444'
  },
  title:{
    flex:1,
    color:"#000",
    fontSize:19,
    fontWeight:'400',
  },
  leftTitle:{
    justifyContent:'center',
    color:Color.title,
    // marginLeft:w(15),
    fontSize:15
  },
  rightTitle:{
    justifyContent:'center',
    // marginRight:w(15),
    fontSize:15
  },
  rightImg:{
    width:Tools.fixWidth(15),
    height:Tools.fixWidth(15),
    resizeMode:'cover',
  },
  leftImg:{
    width:Tools.fixWidth(8),
    height:Tools.fixWidth(17),
    resizeMode:'cover',
  },
  line:{
    height:2
  }
})

//BaseComponent 添加了网络监听,子类需实现_render方法替代render
class BaseComponent extends React.Component{
  unmounted:Boolean;
  isWarningAnimFinish = true;
  constructor(props) {
    super(props);
    this.unmounted = false;
  }
  componentDidMount(){
    // NetInfo.addChangeListener(this._handleConnectivityChange.bind(this));
  }
  componentWillUnmount(){
    this.unmounted = true;
    // NetInfo.removeChangeListener(this._handleConnectivityChange.bind(this));
  }

  showLoadingDialog(dismiss,label){
    if(dismiss){
      NativeDialogManager.showLabelPBDialog(label);
    }else{
      NativeDialogManager.dismissPBDialog();
    }
  }
  _handleConnectivityChange(isConnected) {
    // if(isConnected){
    //   this.hideNoNetworkLayer();
    // }else{
    //   this.showNoNetworkLayer();
    // }
  }
  onLeftPress(){ //导航左边按钮被点击

  }
  onRightPress(){//导航右边按钮被点击

  }
  showToast(msg){
    // React.NativeModules.CouchbaseHelper.showToast(msg);
    this.showWarning(msg);
  }

  replace(C){
    this.props.navigator.replace({
      component:<C navigator={this.props.navigator}/>
    })
  }
  replaceAtIndex(C,index){
    this.props.navigator.replaceAtIndex({
      component:<C navigator={this.props.navigator}/>
  },index)
  }

  push(C){
    this.props.navigator.push({
      component:<C navigator={this.props.navigator}/>
    })
  }
  pushWidthComponent(C){
    this.props.navigator.push(C)
  }
  pop(){
    this.props.navigator.pop()
  }
  //调用服务器(Config.webServerURL)接口，
  post(route,parameters,cb,baseurl){
    BaseComponent.post(route,parameters,cb,baseurl);
  }
  static post(route,parameters,cb,baseurl){
    // var url = (baseurl || Config.webServerURL) + route
    // console.log("HTTP请求:",parameters,"url:"+url);
    // fetch(url, {
    //   method: "POST",
    //   headers: {
    //     'Accept': 'application/json',
    //     'Content-Type': 'application/json'
    //   },
    //   body: JSON.stringify(parameters)
    // }).then((response) => response.json())
    // .then((data) => {
    //   console.log("HTTP返回:",data,"url:"+url);
    //   if(cb)cb(null,data);
    // }).catch((e)=>{
    //   console.log("-->","Http errer:",e,"url:"+url);
    //   if(cb)cb(e);
    // })
    Fetch.post(route,parameters,cb,baseurl);
  }
  checkStringIsNull(str,errorMessage){
    var isNUll = (function(){
      if(typeof(str) == 'string'){
        if(str == ''){
          return true;
        }
        return false;
      }
      return true;
    })();
    if(isNUll && errorMessage){
      this.showToast(errorMessage)
    }
    return isNUll;
  }
  _render(){
    throw new Error("not implement");
  }
  render(){
    let warningHeight = this.state.warningMsg ? NAVIGATION_BAR_HEIGHT : 0;
    return (
      <View style={[Styles.content,{backgroundColor:'#f1f1f1'}]}>
        {
          (()=>{ //绘制导航栏
            var navigatorBarConfig = this.state ? this.state.navigatorBarConfig : null;
            if(navigatorBarConfig){
              return(
                  <NavigationBar
                    title={navigatorBarConfig.title}
                    leftButtonTitle={navigatorBarConfig.leftButtonTitle}
                    rightButtonTitle={navigatorBarConfig.rightButtonTitle}
                    showBackIcon={navigatorBarConfig.showBackIcon}
                    rightTextColor={navigatorBarConfig.rightTextColor}
                    onLeftPress={()=>this.onLeftPress()}
                    onRightPress={()=>this.onRightPress()}
                    />
                )

            }
          })()
        }
        {
          this._render()
        }

        {
          // <View style={[Styles.warning,{height:warningHeight}]}>
          //   <View style={[Styles.center,{marginTop:ISIOS?20:0,flex:1,backgroundColor:"transparent"}]}>
          //     <Text style={[{color:'white',fontSize:14,marginLeft:20,marginRight:20},warningHeight==0?{height:warningHeight}:{}]} > {this.state.warningMsg} </Text>
          //   </View>
          // </View>
          this.warningMsgView()
        }
        {
          this.lastRender()
        }
      </View>
    )
  }
  lastRender(){

  }
  warningMsgView(){
    if(this.state.warningMsg && this.state.warning != '') {
        return (
          <Animated.View
            style={[Styles.warning,{transform:[
             {translateY: this.state.anim},
           ]}]}>
              <Text style={{color:'white',fontSize:14,marginLeft:20,marginRight:20}} > {this.state.warningMsg} </Text>
          </Animated.View>
        );
    }
  }

  showWarning(msg){
    if(msg instanceof Error){
      msg = msg.message;
    }
  //   LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
  //   this.setState({warningMsg:msg})
  //   this.setTimeout(()=>{
  //     LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
  //     this.setState({warningMsg:null})
  //   },2000);

    if(!msg || "" == msg || !this.isWarningAnimFinish) return;
     this.isWarningAnimFinish = false;
     this.setState({warningMsg:msg,anim:new Animated.Value(0)});
     Animated.spring(          // Uses easing functions
        this.state.anim,    // The value to drive
        {toValue: NAVIGATION_BAR_HEIGHT}
      ).start(()=>{
        this.setState({anim:new Animated.Value(NAVIGATION_BAR_HEIGHT)});
        this.state.anim.setValue(NAVIGATION_BAR_HEIGHT);
        Animated.spring(          // Uses easing functions
           this.state.anim,    // The value to drive
           {toValue: 0}
         ).start(()=>{
           this.setState({warningMsg:null});
           this.isWarningAnimFinish = true;
         });
      });
  }
}

reactMixin(BaseComponent.prototype, TimerMixin);


Array.prototype.remove = function() {
    var what, a = arguments, L = a.length, ax;
    if(arguments[0] instanceof Array){
      a = arguments[0];
      L = a.length;
    }
    while (L && this.length) {
        what = a[--L];
        while ((ax = this.indexOf(what)) !== -1) {
            this.splice(ax, 1);
        }
    }
    return this;
};

Array.prototype.contains = function(obj) {
    var i = this.length;
    while (i--) {
        if (this[i] === obj) {
            return true;
        }
    }
    return false;
}

// 对Date的扩展，将 Date 转化为指定格式的String
// 月(M)、日(d)、小时(h)、分(m)、秒(s)、季度(q) 可以用 1-2 个占位符，
// 年(y)可以用 1-4 个占位符，毫秒(S)只能用 1 个占位符(是 1-3 位的数字)
// 例子：
// (new Date()).Format("yyyy-MM-dd hh:mm:ss.S") ==> 2006-07-02 08:09:04.423
// (new Date()).Format("yyyy-M-d h:m:s.S")      ==> 2006-7-2 8:9:4.18
Date.prototype.format = function(fmt)
{ //author: meizz
  var o = {
    "M+" : this.getMonth()+1,                 //月份
    "d+" : this.getDate(),                    //日
    "h+" : this.getHours(),                   //小时
    "m+" : this.getMinutes(),                 //分
    "s+" : this.getSeconds(),                 //秒
    "q+" : Math.floor((this.getMonth()+3)/3), //季度
    "S"  : this.getMilliseconds()             //毫秒
  };
  if(/(y+)/.test(fmt))
    fmt=fmt.replace(RegExp.$1, (this.getFullYear()+"").substr(4 - RegExp.$1.length));
  for(var k in o)
    if(new RegExp("("+ k +")").test(fmt))
  fmt = fmt.replace(RegExp.$1, (RegExp.$1.length==1) ? (o[k]) : (("00"+ o[k]).substr((""+ o[k]).length)));
  return fmt;
}

Date.prototype.formatAMPM = function(){
  var date = this;
  var hours = date.getHours();
  var minutes = date.getMinutes();
  var ampm = hours < 12 ? '上午' : '下午';
  hours = hours % 12;
  hours = hours ? hours : 12; // the hour '0' should be '12'
  minutes = minutes < 10 ? '0'+minutes : minutes;
  var strTime = ampm + ' ' + hours + ':' + minutes ;
  return strTime;
}

let Theme = {
  input_height:Tools.fixHeight(35),//输入框的高度
  input_marginleft:Tools.fixHeight(35),//输入框距离左边的距离
}


class UserIcon extends React.Component {
  static headIcons = {};
  constructor(props){
    super(props);
    this.state={imageKey:this.getImagekey()};
  }
  getImagekey(userId){
    return UserIcon.headIcons[this.props.user || userId];
  }
  onUserSet(userId){
    if(!this.userId || this.userId != userId){
      this.userId = userId;
      var {DatabaseManager,Database} = require("./core/couchbase/Couchbase");
      DatabaseManager.instance.currentDatabase.removeChangeCallback("User",this);
      var db = DatabaseManager.instance.currentDatabase;
      db.getModel(userId,(user)=>{
        var imagekey = user.headIcon?user.headIcon.objectKey:null;
        UserIcon.headIcons[userId] = imagekey;
        this.setState({imageKey:imagekey});
      })
      this.removeChangeCallback();
      db.addChangeCallback("User",this,(body)=>{
        for (var i = 0; i < body.length; i++) {
            var item = body[i];
            if(item._id == userId){
              var imagekey = item.headIcon?item.headIcon.objectKey:null;
              UserIcon.headIcons[userId] = imagekey;
              this.setState({imageKey:imagekey});
            }
        }
      })
    }
  }
  componentWillMount(){
    this.onUserSet(this.props.user);
  }
  removeChangeCallback(){
    try {
      var {DatabaseManager,Database} = require("./core/couchbase/Couchbase");
      DatabaseManager.instance.currentDatabase.removeChangeCallback("User",this);
    } catch (e) {

    } finally {

    }
  }
  componentWillUnmount(){
    this.removeChangeCallback();
  }

  componentWillReceiveProps(nextProps){
    this.onUserSet(nextProps.user);
  }

  setNativeProps(nativeProps) {

  }

  render(){
    return <ImageView {...this.props} thumbnailWidth={this.props.thumbnailWidth||60} imageKey={this.state.imageKey}/>
  }

}

class FQListView extends ListView {
  constructor(props) {
    super(props)
  }
  render(){
    if(this.props.dataSource.getRowCount() > 0){
      return super.render();
    }else{
      return <View {...this.props}/>
    }
  }
}


module.exports = {
  "Styles":Styles,
  "Button":Button,
  "NavigationBar":NavigationBar,
  "BaseComponent":BaseComponent,
  "Config":require('./core/Config'),
  "ImageView":ImageView,
  "Color":Color,
  "Tools":Tools,
  "Theme":Theme,
  "UserIcon":UserIcon,
  "FQListView":FQListView,
};
