
'use strict';

var React = require('react-native');
var {
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableHighlight,
  Navigator,
  ScrollView,
  Image,
  PanResponder,
  LayoutAnimation,
  ActionSheetIOS,
} = React;

var {DateSelector,RelationshipSelector,SelectRealationship} = require('./Selector');
var {User,Patient} = require('./core/Models')
var {Styles,Button,BaseComponent,Color,Tools,Theme,ImageView} = require('./Styles');
var {DatabaseManager} = require("./core/couchbase/Couchbase");

class AddMembers extends BaseComponent {
  gender:Number;
  constructor(props){
    super(props)
    this.gender = 0;
    var config = {title:"添加成员",showBackIcon:true}
    this.state = {navigatorBarConfig:config,relationship:'父亲'}
  }
  onLeftPress(){
    this.pop();
  }
  showRelationshipSelector(){
    if (React.Platform.OS === 'android'){
      this.props.navigator.push({
        component:<SelectRealationship onRelationshipSelect={(relationship)=>{
        this.setState({relationship:relationship});
      }} navigator={this.props.navigator}/>
      })
      return;
    }

    LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
    this.setState({showRelationshipSelector:true,showDateSelector:false})
  }
  componentWillMount(){
    this._panResponder = PanResponder.create({
      onStartShouldSetPanResponder: (evt, gestureState) => { this.hideSelector(); return false;},
      onStartShouldSetPanResponderCapture: (evt, gestureState) => {this.hideSelector(); return false;},
    });
    if(React.Platform.OS === 'android'){
       this.listener =  React.DeviceEventEmitter.addListener("Android_Date_Picker",
        (data) => {
          this.setState({age:new Date(new Number(data.time)).format('yyyy-MM-dd')})
        }
      );
    }
  }
  componentWillUnmount(){
    super.componentWillUnmount()
    if(React.Platform.OS === 'android'){
      if(this.listener)this.listener.remove()
    }
  }
  showDateSelector(){
    if (React.Platform.OS === 'android') {
      var date = new Date();
      var year = date.getFullYear();
      var month = date.getMonth() + 1;
      var day = date.getDate();
      React.NativeModules.DatePicker.showDatePicker(year,month,day);
      return;
    }
    LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
    this.setState({showRelationshipSelector:false,showDateSelector:true})
  }
  hideSelector(){
    LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
    this.setState({showRelationshipSelector:false,showDateSelector:false})
  }
  saveUserInfo(){
    do{
      if(this.checkStringIsNull(this.state.name,"姓名不能为空"))break;
      if(this.checkStringIsNull(this.state.age,"未选择生日"))break;
      this.post("patient/add_user_member",{userId:User.currentUser.documentID},(data)=>{
        if(data.error){
          this.showWarning(data.error);
          return;
        }
        var patient = new Patient();
        patient.user = User.currentUser.documentID;
        patient.name = this.state.name;
        patient.birthday = this.state.age;
        patient.gender = this.gender;
        patient.relationship = this.state.relationship;
        patient.save(()=>{
          this.pop();
        })
      })
    }while (false);
  }
  _render() {
    return (
      <View style={[Styles.content]}>
        <View style={[Styles.content]} {...this._panResponder.panHandlers}>
        <Text style={styles.text}>关系：</Text>
        <Button style={[styles.selectorButton]}
          title={this.state.relationship}
          titleColor={"#333333"}
          fontSize={Tools.fixWidth(12)}
          onTouch={this.showRelationshipSelector.bind(this)}
        />
        <Text style={styles.text}>姓名：</Text>
        <View style={[styles.inputBg,{marginTop:Tools.fixWidth(5)}]}>
        <TextInput style={[styles.input]} placeholder={"请输入姓名"}
          value={this.state.name}
          textAlign={"center"}
          onChangeText={(text) => this.setState({name:text})}
        />
        </View>
        <Text style={styles.text}>生日：</Text>
        <Button style={[styles.selectorButton]}
          title={this.state.age?this.state.age:"生日"}
          titleColor={Color.gray_border_color}
          fontSize={Tools.fixWidth(12)}
          onTouch={this.showDateSelector.bind(this)}
        />

        <Button style={[Styles.defaultBackground,styles.button]} title="确认" onTouch={this.saveUserInfo.bind(this)}/>

        </View>
          {
            (()=>{
              if(this.state.showDateSelector){
                return <DateSelector onDateChange={(date)=>{
                    this.setState({age:date.format("yyyy-MM-dd")})
                  }}
                  data={this.state.age?new Date(this.state.age):null}
                  onClose={(date)=>{
                    this.setState({age:date.format("yyyy-MM-dd")})
                    this.hideSelector();
                  }}
                />
              }else if (this.state.showRelationshipSelector) {
                return(
                  <RelationshipSelector onDateChange={(re,gender)=>{
                    this.setState({relationship:re});
                    this.gender = gender;
                  }} onClose={()=>{
                    this.hideSelector();
                  }}/>
                )
              }
            })()
          }

      </View>
    );
  }
}


var styles = StyleSheet.create({
  text:{
    marginLeft:Theme.input_marginleft,
    marginTop:Tools.fixWidth(22),
    color:"#333333",
    fontSize:Tools.fixWidth(12),
  },
  inputBg:{
    borderWidth:1,
    height: Theme.input_height,
    borderColor: Color.gray_border_color,
    borderRadius:Theme.input_height / 2,
    marginTop:Tools.fixHeight(10),
    marginLeft:Theme.input_marginleft,
    marginRight:Theme.input_marginleft
  },
  input : {
    // borderWidth:1,
    height: Theme.input_height,
    // borderColor: Color.gray_border_color,
    borderRadius:Theme.input_height / 2,
    color:'#333333',
    marginTop:Tools.fixHeight(0),
    fontSize:Tools.fixWidth(12),
    backgroundColor:'transprent',

  },
  button:{
    marginTop:Tools.fixHeight(44),
    borderRadius:Tools.fixWidth(5),
    backgroundColor:'#62C0B4',
    height:Tools.fixHeight(35),
    marginLeft:Theme.input_marginleft,
    marginRight:Theme.input_marginleft
  },
  selectHead:{
    width:Tools.fixWidth(80),
    height:Tools.fixWidth(80),
    borderWidth:1,
    borderColor: Color.white_border_color,
    borderRadius:Tools.fixWidth(10)
  },
  selectorButton:{
    borderWidth:1,
    height: Theme.input_height,
    borderColor: Color.gray_border_color,
    borderRadius:Theme.input_height / 2,
    backgroundColor:'transparent',
    marginTop:Tools.fixHeight(5),
    marginLeft:Theme.input_marginleft,
    marginRight:Theme.input_marginleft
  }
});

module.exports = AddMembers;
