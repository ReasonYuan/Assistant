/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 */
'use strict';
// require('./android/jssource/index');
var React = require('react-native');
var {
  AppRegistry,
  StyleSheet,
  Text,
  View,
  BackAndroid,
  ToastAndroid,
} = React;

var Navigator = require("./Navigator")
var Login = require("./Login");
var Lauch = require("./Lauch")
var {Styles} = require('./Styles');

var _navigator;
var firstTime = 0;//点击两次退出 首次点击时间记录
var fTime = 0;//防止点快了 返回到登录界面
var time = 0;//点击次数
BackAndroid.addEventListener('hardwareBackPress', () => {


  var routes = _navigator.getCurrentRoutes();
  var routesLength = routes.length;

  console.log(routesLength);

  if (_navigator && routesLength > 2) {
    var sTime = new Date().getTime();


    // var Profile = require('./Profile');
    var Home = require('./core/Home2');
    var routeType = routes[routes.length-1].component;
    routeType = routeType.type;
    // if(routeType === Profile || routeType === Home){
      if(routeType === Home){
      if (sTime - fTime > 800) {//如果两次按键时间间隔大于800毫秒，则不退出
        ToastAndroid.show('再按一次退出程序', ToastAndroid.SHORT);
        firstTime = sTime;//更新firstTime
      }else{
        BackAndroid.exitApp();//否则退出程序
      }
      return true;
    }

    if (sTime - fTime > 500){//两次点击事件大于500毫秒让返回，否则会出BUG
      fTime = sTime;
      _navigator.pop();
    }

    return true;
  }else if (_navigator && routesLength <= 2) {
    var secondTime = new Date().getTime();

    var Profile = require('./Profile');
    var Register = require('./Register');
    var ResetPassword = require('./core/setting/ResetPassword');
    var routeType = routes[routes.length-1].component;
    if (!routeType)return false;
    routeType = routeType.type;
    if(routeType === Register || routeType === ResetPassword || routeType === Profile){
      _navigator.pop();
      return true;
    }


    if (secondTime - firstTime > 800) {//如果两次按键时间间隔大于800毫秒，则不退出
      ToastAndroid.show('再按一次退出程序', ToastAndroid.SHORT);
      firstTime = secondTime;//更新firstTime
    }else{
      BackAndroid.exitApp();//否则退出程序
    }
    return true;
  }
  return false;
});


// __DEV__ = false;
console.disableYellowBox = true;
//TODO==JP==以后版本稳定后可以不加这个remotelog
//DEV模式下允许
if(__DEV__){
  var setRemoteErrorHandler = require("./utils/RemoteErrorUtils").setUpErrorHandler
  setRemoteErrorHandler()
}


class Care extends React.Component {
  renderScene(route, navigator){
    _navigator = navigator;
    if(route.component){
      return  route.component;
    }else{
       return <Lauch navigator={navigator}  />
    }
  }
  render() {
    return (
      <Navigator
        style={Styles.content}
        initialRoute={{

        }}
        configureScene={(route) => {
          return React.Navigator.SceneConfigs.HorizontalSwipeJump;
        }}
        renderScene={this.renderScene}
      />
    );
  }
}

AppRegistry.registerComponent('Care', () => Care);
