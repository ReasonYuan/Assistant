'use strict';

var React = require('react-native')
// var Third = require('./Third')
var {
  StyleSheet,
  Text,
  TextInput,
  View,
  Image,
  TouchableHighlight,
  ScrollView
} = React;

var{w,h,screenWidth,screenHeight,fixWidth,fixHeight} = require('../utils/Porting');
var BaseComponent = require('./BaseComponent');
var Tools = require('../utils/Tools');
var DBModel = require('../utils/DBModel');

class MainPage extends BaseComponent {

  constructor(props){
    super(props);
    this.state = {errorMsg:"",userInfo:new DBModel()}
  }

  _openProtocol() {
    console.log('openProtocol');
  }

  _submit() {
    if(!this._checkInput()){
      return;
    }
    this.setState({errorMsg:"success"});
  }

  _choseHospital() {
    this.state.userInfo.hospital = "医院";
    this.setState({userInfo:this.state.userInfo})
  }

  _choseDepartent() {
    this.state.userInfo.departent = "departent";
    this.setState({userInfo:this.state.userInfo})
  }

  _checkInput() {
    if(!this.state.userInfo.userName || this.state.userInfo.userName === ""){
      this.setState({errorMsg:"请输入姓名"});
      return false;
    }else{
      return true;
    }
  }

  _errorMessage() {
    if(this.state.errorMsg && this.state.errorMsg !== "") {
      return (
        <View style={styles.errorMessageView}>
          <Text style={styles.errorMessage}>{this.state.errorMsg}</Text>
        </View>
      );
    }
  }

  _getHospital() {
    if(!this.state.userInfo.hospital || this.state.userInfo.hospital === "") {
      return "选择医院"
    }else{
      return this.state.userInfo.hospital
    }
  }

  _getDepartent() {
    if(!this.state.userInfo.departent || this.state.userInfo.departent === "") {
      return "选择医院"
    }else{
      return this.state.userInfo.departent
    }
  }

  _isPhoneNumber(){
    if(this.checkStringIsNull(this.state.phone_number))return false;
    var reg = /^0?1[3|4|5|8][0-9]\d{8}$/;
    return reg.test(this.state.phone_number);
  }

  _render() {
    return (
      <ScrollView>
      <View style={styles.container}>
        <View style={styles.logoView}>
          <Image style={styles.logo} source={'../../images/icon_logo.png'}/>
        </View>
<View style={{alignItems: 'center'}}>

        {
          this._errorMessage()
        }
        <View style={styles.rowView}>
          <Text style={styles.inputTitle}>姓名</Text>
          <TextInput
            style={styles.textInput}
            onChangeText={(text) => this.state.userInfo.userName = text} />
        </View>
        <View style={styles.rowView}>
          <Text style={styles.inputTitle}>手机号</Text>
          <TextInput
            style={styles.textInput}
            keyboardType={"numeric"}
            onChangeText={(text) => this.state.userInfo.phone = text}/>
        </View>
        <View style={styles.rowView}>
          <Text style={styles.inputTitle}>医院</Text>
          <TouchableHighlight style={styles.choseTouch} underlayColor={'transparent'} onPress={this._choseHospital.bind(this)}>
            <Text style={{color:"#FFFFFF"}}>{this._getHospital()}</Text>
          </TouchableHighlight>
        </View>
        <View style={styles.rowView}>
          <Text style={styles.inputTitle}>学科</Text>
          <TouchableHighlight style={styles.choseTouch} underlayColor={'transparent'} onPress={this._choseDepartent.bind(this)}>
            <Text style={{color:"#FFFFFF"}}>{this._getDepartent()}</Text>
          </TouchableHighlight>
        </View>
        <View style={styles.rowView}>
          <Text style={styles.inputTitle}>项目名称</Text>
          <TextInput
            style={styles.textInput}
            onChangeText={(text) => this.state.userInfo.projectName = text}/>
        </View>
        <View style={styles.rowView}>
          <Text style={styles.inputTitle}>项目病历数量</Text>
          <TextInput
            style={styles.textInput}
            keyboardType={"numeric"}
            onChangeText={(text) => this.state.userInfo.recordCount = text}/>
        </View>
</View>
        <View style={{alignItems: 'center'}}>
          <TouchableHighlight style={{marginTop:Tools.fixWidth(20)}} underlayColor={'transparent'} onPress={this._openProtocol.bind(this)}>
            <Text style={styles.textProtocol}>提交即表示我同意项目合作及保密协议</Text>
          </TouchableHighlight>
          <TouchableHighlight style={styles.security} underlayColor={'transparent'} onPress={this._submit.bind(this)}>
            <Text style={{color:"#FFFFFF"}}>提交</Text>
          </TouchableHighlight>
        </View>
      </View>
      </ScrollView>
    );
  }
}

var styles = StyleSheet.create({

  container: {
    flex: 1,
    backgroundColor: '#F5FCFF',
    width:screenWidth,
    height:screenHeight
  },
  rowView:{
    flexDirection:'row',
    padding:w(10),
    width:screenWidth,
    alignItems: 'center'
  },
  logoView:{
    alignItems: 'center',
    marginTop:w(16)
  },
  textInput:{
    fontSize:16,
    padding:w(4),
    width:w(150),
    backgroundColor:"#FFFFFF"
  },
  inputTitle:{
    width:w(100)
  },
  logo:{
    width: w(200),
    height: h(90),
  },
  textProtocol:{
    color: "#62C0B4",
    fontSize:fixWidth(12),
    textDecorationLine:"underline"
  },
  security:{
    width:fixWidth(160),
    height: w(30),
    borderRadius:w(5),
    borderWidth:0,
    marginTop:fixWidth(20),
    fontSize:fixWidth(14),
    backgroundColor:'#62C0B4',
    alignItems: 'center',
    justifyContent: 'center'
  },
  choseTouch:{
    width:fixWidth(150),
    height: w(30),
    borderRadius:w(5),
    borderWidth:0,
    fontSize:fixWidth(14),
    backgroundColor:'#62C0B4',
    alignItems: 'center',
    justifyContent: 'center'
  },
  errorMessageView:{
    alignItems: 'center',
    justifyContent: 'center',
    marginTop:h(16)
  },
  errorMessage:{
    color:'red',
    fontSize:fixWidth(14),
  }
});

module.exports = MainPage;
