'use strict';

var React = require('react-native')
var Config = require('./Config')
var ProtocolPage1 = require('./ProtocolPage1');
// var Config = require('../jssrc/pages/Config');
var {
  StyleSheet,
  Text,
  TextInput,
  View,
  Image,
  TouchableHighlight,
  ScrollView,
  AlertIOS,
} = React;

exports.title = '加入Hitales大数据医学计划';
// var NODE_ENV = process.env.NODE_ENV;
var{w,h,screenWidth,screenHeight,fixWidth,fixHeight} = require('../utils/Porting');
var BaseComponent = require('./BaseComponent');
var Tools = require('../utils/Tools');
var Protocol = require('./Protocol');
var SubmitView = require('./Submit');
var serverName = "";


class MainPage extends BaseComponent {
  constructor(props){
    super(props);
    this.state = {
      errorMsg:"",
      userName:"",
      phone:"",
      hospital:"",
      department:"",
      recordCount:"",
      allowTouch:true,
      }
    // serverName = Config.serverPath(NODE_ENV);

    var address = window.location.href;
    var thisDLoc  = document.location;
    var hostport = document.location.host;
    console.log('address:'+address);
    console.log('thisDLoc:'+thisDLoc);
    console.log('hostport:'+hostport);
  }
              //
              // <View style={styles.rowView}>
              //   <Text style={styles.inputTitle}>项目名称:</Text>
              //   <TextInput
              //     style={styles.textInput}
              //     placeholder={"请输入项目名称"}
              //     value={this.state.projectName}
              //     onChangeText={(text) => this.setState({projectName:text})}/>
              // </View>
              //
              // <View style={styles.cutline}/>
  _openProtocol() {
    console.log('openProtocol');
    this.props.navigator.push({component:<ProtocolPage1 navigator={this.props.navigator}/>});
  }

  _successAlert() {
    var successStr = '';
    this.props.navigator.push({component:<SubmitView navigator={this.props.navigator} name = {this.state.userName}  success ={true}/>});
    this.setState({
      errorMsg:successStr,
      userName:"",
      phone:"",
      hospital:"",
      department:"",
      recordCount:"",
      allowTouch:true,
      });
  }

  _submitError() {
    var errorStr = '';
    this.props.navigator.push({component:<SubmitView navigator={this.props.navigator} name = {this.state.userName}  success ={false}/>});
    this.setState({
      errorMsg:errorStr,
      allowTouch:true,
    });
  }

//测试使用
  mm(body){
    var request = new XMLHttpRequest();
    request.open('POST', 'http://121.41.43.230:3000/users/doctor_add_contracter', true);
    request.setRequestHeader("Content-Type","application/json");
    request.onreadystatechange = (e) => {
      if (request.readyState !== 4) {
        return;
      }
      if (request.status === 200) {
        this._successAlert();
      } else {
        this._submitError();
      }
    };
    request.send(JSON.stringify(body));
}

  _submit() {
    if(!this._checkInput() || !this.state.allowTouch){
      return;
    }else{
      this.setState({
        allowTouch:false,
      });
      var body = {
        "name":this.state.userName,
        "phone_number":this.state.phone,
        "hospital":this.state.hospital,
        "department":this.state.department,
        "record_count":this.state.recordCount};
      // console.log(serverName);
      test(body,this.state.userName,this._successAlert.bind(this),this._submitError.bind(this));
      // this.mm(body);本地可以使用这个代码
    }

  }

  _checkRecordCountInput(inputValue) {
     var re = /^[1-9]+[0-9]*]*$/;
     if (!re.test(inputValue)){
        this.setState({errorMsg:"病例数目必须是正整数"});
        input.rate.focus();
        return false;
     }else{
        return true;
     }
  }

  checkNum(value){
    var reg = /^\d+$/;
    if( value.constructor === String ){
        var re = value.match( reg );
        return true;
    }
    return false;
  }


  _checkInput() {
    if(!this.state.userName || this.state.userName === ""){
      this.setState({errorMsg:"请输入姓名"});
      return false;
    }else if(!this._isPhoneNumber()){
      this.setState({errorMsg:"请输入正确的手机号"});
      return false;
    }else if(this._isNull(this.state.hospital)){
      this.setState({errorMsg:"请输入医院"});
      return false;
    }else if(this._isNull(this.state.department)){
      this.setState({errorMsg:"请输入学科"});
      return false;
    }else if(this._isNull(this.state.recordCount)){
      this.setState({errorMsg:"请输入项目病例数量"});
      return false;
    }else if(!this._checkRecordCountInput(this.state.recordCount)) {
      return false;
    }else{
      this.setState({errorMsg:""});
      return true;
    }
  }
  // else if(this._isNull(this.state.projectName)){
  //   this.setState({errorMsg:"请输入项目名称"});
  //   return false;
  // }
  _errorMessage() {
    if(this.state.errorMsg && this.state.errorMsg !== "") {
      return (
        <View style={styles.errorMessageView}>
          <Text style={styles.errorMessage}>{this.state.errorMsg}</Text>
        </View>
      );
    }
  }

  _isNull(inputText) {
    if(!inputText || inputText === "") {
      return true;
    }else{
      return false;
    }
  }

  _isPhoneNumber(){
    if(!this.state.phone || this.state.phone === "")return false;
    var reg = /^0?1[3|4|5|8][0-9]\d{8}$/;
    return reg.test(this.state.phone);
  }

  render() {
    return (
      <View style={{flex:1,backgroundColor:'#F1F1F1'}}>
      <ScrollView>
        <View style={styles.container}>

          <View style={styles.logoView}>
            <Image style={styles.logo} source={'../../images/icon_logo.png'}/>
          </View>

          <View style={styles.pageTitleView}>
            <Text style={styles.pageTitle}>基于Hitales平台的SLE合作项目</Text>
            <Image style={styles.pageTitleImage} source={'../../images/icon_title.png'}/>
          </View>

          {
            this._errorMessage()
          }

          <View style={styles.inputContainerView}>

            <View style={styles.rowView}>
              <Text style={styles.inputTitle}>姓名:</Text>
              <TextInput
                style={styles.textInput}
                value={this.state.userName}
                placeholder={"请输入姓名"}
                onChangeText={(text) => {
                  this.setState({userName:text});}} />
            </View>

            <View style={styles.cutline}/>

            <View style={styles.rowView}>
              <Text style={styles.inputTitle}>手机:</Text>
              <TextInput
                style={styles.textInput}
                keyboardType={"phone-pad"}
                placeholder={"请输入号码"}
                value={this.state.phone}
                onChangeText={(text) => this.setState({phone:text})}/>
            </View>

            <View style={styles.cutline}/>

            <View style={styles.rowView}>
              <Text style={styles.inputTitle}>医院:</Text>
              <TextInput
                style={styles.textInput}
                placeholder={"请输入医院"}
                value={this.state.hospital}
                onChangeText={(text) => this.setState({hospital:text})}/>
            </View>

            <View style={styles.cutline}/>

            <View style={styles.rowView}>
              <Text style={styles.inputTitle}>学科:</Text>
              <TextInput
                style={styles.textInput}
                placeholder={"请输入学科"}
                value={this.state.department}
                onChangeText={(text) => this.setState({department:text})}/>
            </View>

            <View style={styles.cutline}/>

            <View style={styles.rowView}>
              <Text style={styles.inputTitle}>参与病例数量:</Text>
              <TextInput
                style={styles.textInput}
                keyboardType={"phone-pad"}
                placeholder={"请输入病例数量"}
                value={this.state.recordCount}
                onChangeText={(text) => this.setState({recordCount:text})}/>
            </View>
          </View>

          <View style={{flex:1}}>
            <TouchableHighlight
              style={styles.security}
              underlayColor={'transparent'}
              onPress={this._submit.bind(this)}>
              <Text style={{color:"#FFFFFF"}}>提交</Text>
            </TouchableHighlight>
            <TouchableHighlight underlayColor={'transparent'} onPress={this._openProtocol.bind(this)}>
              <View style={styles.protocolTouch}>
                <Image style={styles.imageProtocol} source={'../../images/icon_protocol.png'} />
                <Text style={styles.textProtocol}>提交即表示我同意SLE项目合作及保密协议</Text>
              </View>
            </TouchableHighlight>
          </View>
        </View>

      </ScrollView>
      </View>
    );
  }
}

var styles = StyleSheet.create({

  container: {
    flex: 1,
  },
  pageTitleView:{
    alignItems: 'center',
    justifyContent: 'center',
    marginLeft:w(16),
    marginRight:w(16),
    marginTop:w(16),
    backgroundColor:'#FFFFFF',
    borderRadius:w(5),
    height:h(40),
  },
  pageTitle:{
    color:'#333333',
    fontSize:fixWidth(14),
  },
  pageTitleImage:{
    position: 'absolute',
    top:0,
    right:w(10),
    width:w(15),
    height:h(35)
  },
  inputContainerView:{
    marginLeft:w(16),
    marginRight:w(16),
    marginTop:w(16),
    backgroundColor:'#FFFFFF',
    borderRadius:w(5),
  },
  cutline:{
    marginLeft:w(4),
    marginRight:w(4),
    height:1,
    backgroundColor:'#F1F1F1'
  },
  rowView:{
    padding:h(8),
    flexDirection:'row',
    width:screenWidth,
    alignItems: 'center'
  },
  logoView:{
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor:'#FFFFFF',
    marginLeft:w(16),
    marginRight:w(16),
    marginTop:w(16),
    borderRadius:w(5),
    height:h(110)
  },
  textInput:{
    flex:1,
    marginLeft:w(8),
    backgroundColor:"transparent",
    color:'#333333',
  },
  inputTitle:{
    fontSize:fixWidth(12),
    color:'#333333'
  },
  logo:{
    width: w(200),
    height: h(90),
  },
  protocolTouch:{
    flexDirection:'row',
    marginLeft:w(16),
    marginRight:w(16),
    marginTop:h(20),
    marginBottom:h(20),
    height:h(40),
    alignItems: 'center',
    justifyContent: 'center'
  },
  textProtocol:{
    color:'#333333',
    fontSize:fixWidth(9),
    textDecorationLine:"underline"
  },
  imageProtocol:{
    width:w(7),
    height:w(8),
    marginRight:w(8)
  },
  security:{
    height: w(30),
    marginTop:fixWidth(20),
    marginLeft:w(16),
    marginRight:w(16),
    fontSize:fixWidth(14),
    backgroundColor:'#62C0B4',
    alignItems: 'center',
    justifyContent: 'center'
  },
  choseTouch:{
    width:fixWidth(150),
    height: w(30),
    borderRadius:w(5),
    borderWidth:0,
    fontSize:fixWidth(14),
    backgroundColor:'#62C0B4',
    alignItems: 'center',
    justifyContent: 'center'
  },
  errorMessageView:{
    alignItems: 'center',
    justifyContent: 'center',
    marginTop:h(16),
    marginLeft:h(16),
    marginRight:h(16),
    borderRadius:w(5),
    height:h(24),
  },
  errorMessage:{
    color:'red',
    fontSize:fixWidth(12),
  }
});

module.exports = MainPage;
