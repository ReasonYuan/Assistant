'use strict';

var React = require('react-native')
var BaseComponent = require('./BaseComponent');
var{w,h,screenWidth,screenHeight,fixWidth,fixHeight} = require('../utils/Porting');
var {
  StyleSheet,
  Text,
  TextInput,
  View,
  Navigator,
  TouchableHighlight,
  ScrollView,
  Image,
} = React;


class Protocol extends BaseComponent {
  constructor(props) {
    super(props);
    this.state = {
      showNaBar:true,
      showLeftBtn:false,
      showRightBtn:false,
      showTitleUnderLine:true,
      tittle:'返回',
    }
    this.teshustring = "基于对计算机自动SLEDAI评分结果的分析，详细分析各个中心住院病史对SLEDAI评分完整度的贡献（即该份病史中的资料是否完整反映了SLEDAI所有的评分项，若评分项有缺失则该病史贡献度将<100%）。尝试基于该体系，建立SLE住院病史打分体系，并进而提供各参与中心上传病史反馈系统，在上传病史被结构化后，反馈病史中是否存在SLEDAI评分缺项及计算机评分，供各个中心参考。";
  }

  _render(){
    return (
      <ScrollView style={styles.contentView}>
        <Image style={styles.logo} source={'../../images/xieyi.png'}/>
         </ScrollView>
    )
  }

//     _render(){
//         return (
//           <ScrollView style={styles.contentView}>
//             <Text style={styles.title}>甲方：上海翼依信息技术有限公司</Text>
//
//             <View style={styles.yifang}>
//               <Text style={styles.newTittle}>乙方：</Text>
//               <View style={styles.rightTittle}>
//
//                 <Text style={styles.name}>李挺</Text>
//                 <View style={styles.underLine}></View>
//               </View>
//               <Text style={styles.newTittle}>医生</Text>
//             </View>
//             <View style={styles.yifang}>
//               <Text style={styles.newTittle}>丙方：</Text>
//               <View style={styles.rightTittle}>
//                 <Text style={styles.bingname}>_</Text>
//                 <View style={styles.underLine}></View>
//               </View>
//               <Text style={styles.newTittle}>医生</Text>
//             </View>
//
//             <Text style={[styles.content1,{marginTop:40}]}><Text style={{color:'transparent'}}>____</Text>上海翼依信息技术有限公司（以下简称甲方）是一家医学大数据公司，Hitales是上海翼依信息技术有限公司开发和运营的技术平台。在本项目中，甲方提供数据采集服务、技术支持平台、数据分析服务。</Text>
//
//             <Text style={styles.content3}><Text style={{color:'transparent'}}>____</Text>李挺医生（以下简称乙方）为项目发起人。</Text>
//
//             <Text style={styles.content3}><Text style={{color:'transparent'}}>____</Text>丙方为项目共同参与者，本合同以开放式丙方作为参与方，即丙方可为一方或多方，可在本合同内签订也可分别签订，均不影响合同效力的发生。</Text>
//
//             <Text style={styles.content1}>三方就相关合作达成以下约定：</Text>
//
//             <Text style={styles.content1}>1、自签订本约定之日起， 丙方加入由乙方发起的“基于Hitales平台的SLE合作项目”(以下简称“SLE合作项目”) 。该项目为多中心协作项目，由发起方（乙方）以及若干共同参与者共同参与协作。丙方为共同参与者之一，共同参与者以是否签订本协议为标志。</Text>
//
//             <Text style={styles.content1}>2、甲方为“SLE合作项目”提供技术平台服务。</Text>
//
//             <Text style={styles.content1}>3、“Hitales平台提供的服务包含：</Text>
//
//             <Text style={styles.content2}>a)Hitales APP医生版</Text>
//
//             <Text style={styles.content2}>b)病例智能采集<Text style={{color:'transparent'}}>___________________</Text></Text>
//
//             <Text style={styles.content2}>c)建立乙方和丙方的云病例库<Text style={{color:'transparent'}}>________</Text></Text>
//
//             <Text style={styles.content2}>d)病例数据结构化<Text style={{color:'transparent'}}>___________________</Text></Text>
//
//             <Text style={styles.content2}>e)分析与统计服务<Text style={{color:'transparent'}}>___________________</Text></Text>
//
//             <Text style={styles.content2}>f)协助进行多中心科研项目<Text style={{color:'transparent'}}>_________________</Text></Text>
//
//             <Text style={styles.content1}>4、乙方负责研究方案设计及协调，负责对sledai算法优化提供建议，负责对丙方10份病例进行人工sledai积分以作校正。</Text>
//
//             <Text style={styles.content1}>5、丙方参与“SLE合作项目”的病例数量为______例。</Text>
//
//             <Text style={styles.content1}>6、“SLE合作项目”计划于2016年10月31日完成。</Text>
//
//             <Text style={styles.content1}>7、知识产权和合作细节</Text>
//
//             <Text style={styles.content2}>a)乙方、丙方、其他共同参与者为独立中心，建立独立自主管理的云病例库。<Text style={{color:'transparent'}}>_________________</Text></Text>
//
//             <Text style={styles.content2}>b)“SLE合作项目”获得乙方、丙方授权后，建立多中心数据的虚拟数据库，项目完成后根据乙方、丙方要求解散各自虚拟数据库。在研究过程中乙方、丙方、其他共同参与者无法接触到他方的原始数据。<Text style={{color:'transparent'}}>_________________</Text></Text>
//
//             <Text style={styles.content2}>c)乙方为研究成果作者，具体项目的发起者作为第一通讯作者进行署名，之后的署名根据丙方中贡献大者优先选择作者排名，具体署名数按具体杂志承认的最多署名作者确定，贡献以提供的有效完整住院病历数量来确定，以数量最多者为贡献最大，以此类推。关于共同第一作者及共同通讯作者的分配举例如下：杂志承认两个并列作者的情况下：第一作者1，并列第一作者2，——并列通讯作者3，通讯作者4；乙方直接确定为第一通讯作者1，另三个具体署名名额由贡献排名前三的丙方依次按顺序挑选，其他丙方则作为共同作者在之后逐一列明，排名按贡献确定。在“SLE合作项目”进行过程中，乙方为联系人和协调人，直至项目结束。<Text style={{color:'transparent'}}></Text></Text>
//
//             <Text style={styles.content2}>d)乙方、丙方及其他参与者共同协商讨论项目组织进行中的规程、以及科研协调和争议裁定。如有无法解决问题依照国家有关科研课题管理规定及协商仲裁解决。<Text style={{color:'transparent'}}>_________________</Text></Text>
//
//             <Text style={styles.content2}>e)“SLE合作项目”的大数据研究项目均由Hitales平台负责技术平台的开发和运营。<Text style={{color:'transparent'}}>_________________</Text></Text>
//
//             <Text style={styles.content2}>f)默认论文著作权归属乙方、丙方和其他共同参与者所有，作者需在致谢中提及Hitales的贡献，贡献的文字表述为“本项目感谢上海翼依信息技术有限公司全权提供相关技术平台服务和支持！”。<Text style={{color:'transparent'}}>_________________</Text></Text>
//
//             <Text style={styles.content2}>g)考虑到平台延续性，及以前项目中作者贡献的算法和规则对平台的贡献，后续项目作者如引用该算法，须引用前一版本算法作者所发表文献。如若想针对前版本算法升级，必须经过前述作者授权。<Text style={{color:'transparent'}}>_________________</Text></Text>
//
//             <Text style={styles.content1}>8、关于患者的隐私</Text>
//
//             <Text style={styles.content2}>a)患者的隐私会得到充分保障，云病例库中的数据受到金融级的加密管理。<Text style={{color:'transparent'}}>_________________</Text></Text>
//
//             <Text style={styles.content2}>b)患者病例会得到去身份化处理，除去其病例所有的医生外，其他医生无法查看患者的身份信息。<Text style={{color:'transparent'}}>_________________</Text></Text>
//
//             <Text style={styles.content2}>c)每个医生的云病例库独立管理，只有得到病例所有的医生授权后，其他医生才可以查看到去身份化处理后的病例信息。<Text style={{color:'transparent'}}>_________________</Text></Text>
//
//             <Text style={styles.content2}>d)多中心科研项目组处理数据时，提取的数据不包含身份信息。<Text style={{color:'transparent'}}>_________________</Text></Text>
//
//             <Text style={styles.content1}>9、参与方法</Text>
//
//             <Text style={styles.content2}>a)各参与中心各提供基于各种途径的可电子化的完整SLE住院病史至少30份（包括入院录和出院小结，出院小结中应尽量包括入院后全套检测结果）；<Text style={{color:'transparent'}}>_________________</Text></Text>
//
//             <Text style={styles.content2}>b)基于前期已建立的SLE自动化SLEDAI评分规则，对各中心提供的SLE病史进行结构化和SLEDAI评分；<Text style={{color:'transparent'}}>_________________</Text></Text>
//
//             <Text style={styles.content2}>c)各参与中心对该中心提供的SLE病史中，进行至少10份病史的人工SLEDAI积分，以供系统校正用；<Text style={{color:'transparent'}}>_________________</Text></Text>
//
//             <Text style={styles.content2}>d)仁济医院提供技术支持，对各中心人工SLEDAI积分的病史，基于仁济医院的评分习惯进行SLEDAI积分一次，供系统校正、分析用；<Text style={{color:'transparent'}}>_________________</Text></Text>
//
//             <Text style={styles.content2}>e)对各中心的SLEDAI积分结果进行分析，对其中存在计算机打分、中心自行打分、仁济医院打分存在明显差异者进行人工复合，计算机规则适配，提高三者的一致性。这部分工作需要各中心指定一位医生参与，我们保证该位医生累计投入该工作的时间不超过10小时；
// <Text style={{color:'transparent'}}></Text></Text>
//
//             <Text style={styles.content2}>f)基于适配后的规则，对所有参与中心的SLE病史进行SLEDAI评分；<Text style={{color:'transparent'}}>_________________</Text></Text>
//
//             <Text style={styles.content2}>g)基于结构化病例分析和SLEDAI评分，形成多中心中国SLE住院患者临床横断面分析结果，发表；<Text style={{color:'transparent'}}>_________________</Text></Text>
//
//             <Text style={styles.content2}>{this.teshustring}</Text>
//
//             <Text style={styles.content1}>10、项目进度</Text>
//
//             <Text style={styles.content2}>a)项目报名：2周；<Text style={{color:'transparent'}}>_________________</Text></Text>
//
//             <Text style={styles.content2}>b)协议签署：1个月；<Text style={{color:'transparent'}}>_________</Text></Text>
//
//             <Text style={styles.content2}>c)病史采集及sledai人工评分：2个月；<Text style={{color:'transparent'}}></Text></Text>
//
//             <Text style={styles.content2}>d)计算机评分矫正适配：2个月；<Text style={{color:'transparent'}}></Text></Text>
//
//             <Text style={styles.content2}>e)数据分析挖掘1个月。<Text style={{color:'transparent'}}>______________</Text></Text>
//
//             <Text style={styles.content2}>f)定期设计抽检，以保证项目的准确性。<Text style={{color:'transparent'}}></Text></Text>
//
//             <Text style={styles.content1}>11、合作过程中，如有争议，三方本着真诚友好的态度进行协商；未协商一致，则可按照国家法律法规进行协商解决。</Text>
//
//             <Text style={styles.content1}>12、本协议一式叁份，甲乙丙三方各保留一份。</Text>
//
//             <Text style={styles.title}>附录一：隐私保护及保密协议</Text>
//
//             <Text style={styles.content1}>1、乙方、丙方在项目履行过程中需配合向甲方提供相应数据，乙方、丙方对其提供的病例数据享有所有权，乙方、丙方享有对经甲方数据处理后的数字化数据使用的权利。甲方承诺不得将原始数据以任何形式用作于任何侵害乙方、丙方权益或侵害病例所有人权益的商事活动中，不得在未经数字化去身份化处理前调用数据，并将保护隐私权作为甲方展开研究、分析行为的首要准则。</Text>
//
//             <Text style={styles.content1}>2、甲方承诺对于经甲方数据处理后的数字化初始数据仅供自身科研使用，不向任何第三方商业机构提交初始数据的全部或任意部分。</Text>
//
//             <Text style={styles.content1}>3、本协议订立前以及在本协议期限内，一方（下称“披露方”）曾经或者可能不时向对方（下称“受方”）披露该方的保密资料。在本协议期限内以及随后[ 2 ]年间，受方必须：</Text>
//
//             <Text style={styles.content2}>  a）对保密资料进行保密；</Text>
//
//             <Text style={styles.content2}>  b）不为除协议明确规定的目的之外的其他目的使用保密资料；</Text>
//
//             <Text style={styles.content2}>  c）除为履行其职责而确有必要知悉保密资料的该方雇员（或其关联机构、该方律师、会计师或其他顾问的雇员）外，不向其他任何人披露，且上述人员须签署书面保密协议，其中保密义务的严格程度不得低于本条的规定。</Text>
//
//             <Text style={styles.content1}>4、上述条款对以下信息不适用：</Text>
//
//             <Text style={styles.content2}>  d）受方有在披露方向其披露前存在的书面记录证明其已经掌握；</Text>
//
//             <Text style={styles.content2}>  e）并非由于受方违反本协议而已经或者在将来进入公共领域；</Text>
//
//             <Text style={styles.content2}>  f）受方从对该信息无保密义务的第三方获得。</Text>
//
//             <Text style={styles.content1}>5、本附录与主文具备同等法律效力。</Text>
//
//           </ScrollView>
//       );
//     }

    leftClick(){
        this.props.navigator.pop();
    }

    rightClick(){
      this.props.navigator.push({component:<ProtocolPage2 navigator={this.props.navigator}/>});
    }


}

var styles = StyleSheet.create({
  rightTittle:{
    // backgroundColor:'red',
    height:25,
    flexDirection:'colums',
  },
  bingname:{
    color:'transparent',
    height:20,
    width:100,
    textAlign:'center',
  },
  name:{
    fontSize:18,
    height:20,
    width:100,
    textAlign:'center',
    // backgroundColor:'green',
  },
  underLine:{
    backgroundColor:'black',
    height:1,
    width:100,
    // marginTop:4,
  },
  yifang:{
    flexDirection:'row',
    marginTop:20,
    marginLeft:20,
    marginRight:20,
  },
  newTittle:{
    fontSize:18,
    // backgroundColor:'red',

  },
  contentView: {
    flex: 1,
    // marginTop: 65,
    backgroundColor: 'white'
  },
  content:{
    flexDirection:'row',
  },
  title:{
    marginTop:20,
    marginLeft:20,
    marginRight:20,
    fontSize:18,
    // textDecorationStyle:'double'

  },
  content1:{
    marginTop:20,
    marginRight:20,
    marginLeft:20,
    color:"#666666",
    fontSize:14,
  },

  content2:{
    marginTop:2,
    marginRight:20,
    marginLeft:30,
    color:"#666666",
    fontSize:14,
  },
  content3:{
    marginRight:20,
    marginLeft:20,
    color:"#666666",
    fontSize:14,
  },
  logo:{
    width: screenWidth() -w(20),
    height: 3000,
    resizeMode:'contain',
  },

});
module.exports = Protocol;
