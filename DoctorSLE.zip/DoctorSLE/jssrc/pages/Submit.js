'use strict';

var React = require('react-native')
var BaseComponent = require('./BaseComponent');
var ProtocolPage1 = require('./ProtocolPage1');
var{w,h,screenWidth,screenHeight,fixWidth,fixHeight} = require('../utils/Porting');
var {
  StyleSheet,
  Text,
  TextInput,
  View,
  Navigator,
  TouchableHighlight,
  Alert,
  Image,
} = React;


class Submit extends BaseComponent {
  constructor(props) {
    super(props);
    this.state = {
      showNaBar:false,
      showLeftBtn:false,
      showRightBtn:false,
      showTitleUnderLine:false,
      tittle:'上海翼依信息技术有限公司',
      success:this.props.success,
    }
  }

    _render(){
        return (
        <View style={styles.content}>
        <View style={styles.logoView}>
            <Image style={styles.logo} source={'../../images/icon_logo.png'}/>
        </View>
        <View style={styles.message}>
          <View style={styles.leftView}>
            <Image style={styles.iconLeft} source={'../../images/submit_left_icon.png'}/>
          </View>

          <View style={styles.rightView}>
            <Text style={styles.toptext} numberOfLines = {1}>{this.getMessage()}</Text>
            <Text style={styles.bottomtext}>{this.getNextMessage()}</Text>
          </View>
        </View>
        </View>
      );
    }

    getMessage(){
      if(this.state.success){
        return "提交成功！感谢" + this.props.name + "医生！";
      }else{
        return "提交失败！感谢" + this.props.name + "医生！";
      }
    }

    getNextMessage(){
      if(this.state.success){
        return "我们会在24小时内与您联系。";
      }else{
        return "请尝试重新注册。谢谢!";
      }
    }

}



var styles = StyleSheet.create({
  iconLeft:{
    reSizeMode:'cover',
    marginLeft:30,
    width:25,
    height:105,
  },
  rightView:{
    // backgroundColor:'blue',
    marginTop:7,
    height:105,
    marginLeft:20,
  },
  leftView:{
    width:50,
    // backgroundColor:'gray',
  },
  bottomtext:{
    marginTop:21,
    color:'gray',
    fontSize:16,
  },
  toptext:{
    color:'#62c0b4',
    fontSize:16,
  },
  message:{
    marginTop:5,
    height:120,
    flexDirection:'row',
    alignItems:'center',
    backgroundColor:'white',
  },
  logoView:{
    height:h(110),
    backgroundColor:'white',
    justifyContent:'center',
    marginTop:10,
  },
  logo:{
    reSizeMode:'cover',
    marginLeft:30,
    width: w(200),
    height: h(90),
    // backgroundColor:'red',
  },
  text:{
    fontSize:fixWidth(16),
  },
  content:{
    flex:1,
    backgroundColor:'#f1f1f1',
  }
});
module.exports = Submit;
