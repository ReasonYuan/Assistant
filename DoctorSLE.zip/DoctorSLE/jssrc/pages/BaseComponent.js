'use strict';

var React = require('react-native')
var{w,h,screenWidth,screenHeight,fixWidth,fixHeight} = require('../utils/Porting');
var {
  StyleSheet,
  Text,
  TextInput,
  View,
  Image,
  Navigator,
  TouchableHighlight,
  Alert,
  Animated,
  Platform
} = React;

class BaseComponent extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      showNaBar:false,
      showLeftBtn:true,
      showRightBtn:true,
      showTitleUnderLine:true,
    }
  }

  render() {
    return (
      <View style = {Styles.content} >
      {
        this._render()
      }
      {
        this.isRenderNavBar()
      }
      </View>


    );
    }

    isRenderNavBar(){
      if(this.state.showNaBar){
        return this.renderNavBar();
      }
    }
    _render(){
      throw new Error("not implement");
    }

    renderNavBar(){
      if(this.state.showNaBar){
        return (
          <View style ={Styles.bothTopBar}>
          <View style = {Styles.topBar}>
            <View style = {Styles.leftBtn} >{this.renderLeftBtn()}</View>
            <View style = {Styles.tittle}>{this.renderTittle()}</View>
            <View style = {Styles.rightBtn}>{this.renderRightBtn()}</View>
          </View>
          </View>
        );
      }
    }

    renderLeftBtn(){
        if(this.state.showLeftBtn){
          return (<TouchableHighlight style={Styles.touch} onPress={()=>{this.leftClick()}}>
            <Image style={Styles.left} source={'../../images/icon_left.png'}></Image>
          </TouchableHighlight>);
        }else{
            return (<View style={Styles.left}></View>);
        }
    }


    renderRightBtn(){
      if(this.state.showRightBtn){
        return (<TouchableHighlight style={Styles.touch} onPress={()=>{this.rightClick()}}>
          <Image style={Styles.right} source={'../../images/icon_right.png'}></Image>
        </TouchableHighlight>);
      }else{
        return (<View style={Styles.right}></View>);
      }

    }

    renderTittle(){
      if (this.state.showTitleUnderLine){
        return (
          <TouchableHighlight style={Styles.touch} onPress={()=>{this.centerClick()}}>
            <Text style={Styles.tittlecontent2}>{this.state.tittle}</Text>
          </TouchableHighlight>
        );
      }else{
        return (
            <Text style={Styles.tittlecontent}>{this.state.tittle}</Text>
        );
      }

    }

    centerClick(){
      this.props.navigator.popToTop();
    }

    leftClick(){

    }

    rightClick(){

    }

}


      var Styles = StyleSheet.create({
        bothTopBar:{
          height:41,
        },
          line:{
            height:1,
            backgroundColor:'gray',
          },
          content:{
            flex:1,
            padding:10,
            backgroundColor:'#f1f1f1',
          },
          topBar:{
              height:40,
              // backgroundColor:'red',
              flexDirection:'row',
          },
          leftBtn:{
            flex:1,
            height:40,
            backgroundColor:'white',
            justifyContent:'center',
            alignItems:'flex-start',
          },
          tittle:{
            flex:2,
            height:40,
            backgroundColor:'white',
            justifyContent:'center',
            alignItems:'center',
            fontSize:fixWidth(10),
          },
          rightBtn:{
            flex:1,
            height:40,
            backgroundColor:'white',
            justifyContent:'center',
            alignItems:'flex-end',
          },
          touch:{
            // backgroundColor:'red',
          },
          left:{
            with:10,
            height:10,
            margin:15,
            resizeMode:'cover',
            // color:'black',
          },
          right:{
            with:10,
            height:10,
            margin:15,
            resizeMode:'cover',
            // color:'black',
          },
          tittlecontent:{
            color:'#999999',
          },
          tittlecontent2:{
            color:'#62C0B4',
            textDecorationLine:'underline',
            fontSize:14,
          }



        })



module.exports = BaseComponent;
