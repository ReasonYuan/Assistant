'use strict';
class DBModel {
  userName:String;
  phone:String;
  hospital:String;
  department:String;
  projectName:String;
  recordCount:String;
}

module.exports = DBModel;
