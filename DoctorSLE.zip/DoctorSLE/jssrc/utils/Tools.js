'use strict';

var React = require('react-native');
var {
  AsyncStorage,
} = React;

let DESIGN_WIDTH = 320;  //设计尺寸宽dp
let DESIGN_HEIGTH = 568;  //设计尺寸高dp
let TARGET_WIDTH = document.documentElement.clientWidth;
let TARGET_HEIGHT = document.documentElement.clientHeight;
let scaleWidth =  TARGET_WIDTH / DESIGN_WIDTH;
let scaleHeight = TARGET_HEIGHT / DESIGN_HEIGTH;

let TIMES = ["凌晨","上午","下午","晚上"]

class Tools {

    static screenWidth(){
      return TARGET_WIDTH
    }

    static screenHeight(){
      return TARGET_HEIGHT
    }

    static fixWidth(s){
      return s * scaleWidth;
    }

    static fixHeight(s){
      return s * scaleHeight;
    }

    //保存Storage数据
    //value  String 类型数据
    static saveStorageData(key,value){
      if(!key || !value)return
      try{
        AsyncStorage.setItem(key, value);
      }catch(error){
        console.log("--save Storage error-->key:"+key+" error:"+error);
      }
    }

    //得到保存的Storage数据
    static getStorageData(key,cb){
      if(!key || !cb)return
      try{
        AsyncStorage.getItem(key,(error,result)=>{
          if(!error || result){
            cb(result)
          }else{
            cb(null)
          }
        });
      }catch(error){
        cb(null)
      }
    }


    //判读字符的长度，因为一个中文为2个英文
    static charLen(s) {
     var l = 0;
     var a = s.split("");
     for (var i=0;i<a.length;i++) {
      if (a[i].charCodeAt(0)<299) {
       l++;
      } else {
       l+=2;
      }
     }
     return l;
    }

}

module.exports = Tools;
